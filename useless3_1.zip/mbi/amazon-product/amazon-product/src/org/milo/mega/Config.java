package org.milo.mega;

public class Config {
    /** Developer AWS access key. */
    public static final String accessKey = "AKIAJMKWZYV5KHZW6O2A";

    /** Developer AWS secret key. */
    public static final String secretKey = "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";

    /** The client application name. */
    public static final String productAppName = "Products";

    /** The client application version. */
    public static final String productAppVersion = "2011-10-01";

    /**
     * The endpoint for region service and version.
     * ex: serviceURL = MWSEndpoint.NA_PROD.toString();
     */
    public static final String productServiceURL = "https://mws.amazonservices.com/Products/2011-10-01";

    
    public static final String sellerId = "A1JF0FEJIRJQ6I";

    public static final String marketplaceId = "ATVPDKIKX0DER";

}
