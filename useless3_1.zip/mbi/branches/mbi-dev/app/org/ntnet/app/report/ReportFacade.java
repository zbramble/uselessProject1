package org.ntnet.app.report ;

import java.util.List;

import javax.persistence.Query;

import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.util.QueryUtil;

public class ReportFacade extends BaseFacade {
	
	private static ReportFacade reportdFacade = new ReportFacade();


	public static ReportFacade getInstance() {
		return reportdFacade;
	}


	/**
	 * @param filter پارامتر اول فیلتر مشخص کنند گزارش است
	 * @return	ردیف اول پاسخ نام فیلدهاست
	 */
	public ServiceResult users(BusinessParam businessParam) throws Exception {
		businessParam.getFilter().getParams().iterator();
		businessParam.getUserSession().checkAccess("VRewardListAction", ACTION.view);
        
        BaseDB db = null;
        try {
            db = BaseDB.open("BaseService.saveEntity");
            
            String where = QueryUtil.genQuery(null, businessParam.getFilter(), QueryUtil.QUERY_TYPE.WHERE_ONLY);
            final String queryString = "select ROW_NUMBER() OVER (ORDER BY  UPDATED desc) rm,e.* from (select USERNAME, FIRST_NAME || ' '  || LAST_NAME as name, IS_ACTIVE, TO_CHAR(updated,'yyyy/mm/dd','NLS_CALENDAR=''PERSIAN''')updated from co_user) e " + 
            		(where.length() > 0 ? where: "")  + " order by UPDATED desc";
            Query query = db.createNativeQuery(queryString);
            query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
            query.setMaxResults(businessParam.getFilter().getPageSize());
	        
            List<Object[]> ret = (List<Object[]>) query.getResultList();
	        int countAll = ret.size();
            db.commitAndclose();
            if(ret.size() == 0)
            	return new ServiceResult(null, countAll);
            String[] header = {"ردیف", "نام کاربری", "نام","فعال", "زمان به روزرسانی"};
            ret.add(0, header);            
            return new ServiceResult(ret, countAll);
        } catch (Exception e) {
            e.printStackTrace();
            db.rollbackAndClose();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
        }
	}


	@Override
	public BaseCopier getCopier() {//Didn't use
		return null;
	}

}