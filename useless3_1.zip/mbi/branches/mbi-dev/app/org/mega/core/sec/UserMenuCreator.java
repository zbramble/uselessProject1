package org.mega.core.sec;

import java.util.HashMap;
import java.util.Map;

import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO;

public class UserMenuCreator implements UserMenuCreatorI{

	private static Map<Long,String> menuTreeCache = new HashMap<Long, String>();
	private static Map<Long,String> menuDataCache = new HashMap<Long, String>();

	UserInfo userInfo;
	Map<String, Integer> access;
	StringBuilder menuTree = new StringBuilder();
	StringBuilder menuData = new StringBuilder();

	@Override
	public UserMenuCreatorI init(UserInfo userInfo) {
		UserMenuCreator creator = new UserMenuCreator();
		creator.userInfo = userInfo;
		creator.access = userInfo.getAccess();
		creator.createMenu();
		return creator;
	}

	public void createMenu() {
		int showInMenuAct = ActionDTO.ACTION.showInMenu.ordinal();

		menuData.append("{");
		menuTree.append("[");
		
		addItem("Inventory"				, "#"					, "Inventory"				    , null							,"ion-tshirt"	, -1, -1, true, showInMenuAct);
		addItem("Product"				, "Inventory"			, "Product"				    ,"app/product"						,null			, -1, -1, true, showInMenuAct);
		addItem("Amazon_products"		, "Inventory"		  	, "Amazon products"			,"app/amazon/product"				,null			, -1, -1, true, showInMenuAct);
		
		addItem("Orders"				, "#"		          , "Orders"				    , null				,"ion-ios-cart"					, -1, -1, true, showInMenuAct);
		addItem("Shipment"				, "#"		          , "Shipment"				    , null				,"ion-android-car"				, -1, -1, true, showInMenuAct);
		addItem("Reports and Analytics" , "#"		          , "Reports and Analytics"	    , null				,"ion-ios-speedometer"			, -1, -1, true, showInMenuAct);
		addItem("UserManagment"			, "#"		          , "User Managment"			, null				,"ion-person-stalker"			, -1, -1, true, showInMenuAct);
	
		if(userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID) {
			addItem("Action"			, "UserManagment"			, "Action"					, "core/page/action"				, null		, -1, -1, true, showInMenuAct);
			addItem("UseCase"			, "UserManagment"			, "Usecase"					, "core/page/usecase"				, null		, -1, -1, true, showInMenuAct);
			addItem("AccessGroup"		, "UserManagment"			, "Access group"			, "core/page/accessgrp"				, null		, -1, -1, true, showInMenuAct);
			addItem("Role"				, "UserManagment"			, "Role"					, "core/page/role"					, null		, -1, -1, true, showInMenuAct);
		}
		addItem("User"					, "UserManagment"					  , "User"			  		, "core/masterdetail.html?urlPath=/core/page/user/index.html&isMaster=1"
				, null				, -1, -1, true, showInMenuAct);

		
		addItem("Settings"				, "#"		          , "Settings"				    , null					,"ion-settings"		, -1, -1, true, showInMenuAct);
		addItem("Location"				, "Settings"	      , "Location"				    , null					,null				, -1, -1, true, showInMenuAct);
		addItem("ComboVal"				, "Settings"	      , "Combo values"				, "core/page/comboval"	,null				, -1, -1, true, showInMenuAct);
		addItem("ChangePassword"		, "Settings"          , "Change Password"		    , "ui/change_pass.html"	,null			, 400, 300, false, showInMenuAct);

		menuData.append("}");
		menuTree.append("]");

		menuTreeCache.put(userInfo.getRoleId(), menuTree.toString());
		menuDataCache.put(userInfo.getRoleId(), menuData.toString());
	}

	private void addItem(String usecase, String parentUC, String title, String path, String icon, int width, int height, boolean createNew, int actionToCheck) {
		if(!hasAccess(usecase, actionToCheck))
			return;
		if(menuTree.length() > 1){
			menuTree.append(",");
			menuData.append(",");
		}

		menuTree.append("{ \"id\" : \"").append(usecase).append("\", \"parent\" : \"")
			.append(parentUC).append("\", \"text\" : \"").append(title).append("\"")
			.append(",\"icon\": \"").append(icon != null ? icon : "none").append("\"");
		if (path != null)
			menuTree.append(",\"li_attr\": {\"data-name\": \"").append(usecase).append("\"}");

		menuTree.append(" }");

		//return such this:    "CUSTOMER": {"EN": "customer", "FA": "فروشندگان", "COUNT": "0", "PATH":"app/merchant", "WIDTH": "800", "HEIGHT": "650", "CREATE_NEW": "true"}
		menuData.append("\"").append(usecase).append("\": {\"EN\": \"").append(usecase).append("\", \"FA\": \"").append(title)
			.append("\", \"COUNT\": 0, \"PATH\":\"").append(path).append("\", \"WIDTH\": \"").append(width)
			.append("\", \"HEIGHT\": \"").append(height).append("\", \"CREATE_NEW\": \"").append(true).append("\"}");
	}


	@Override
	public String getMenuData() {
		return menuData.toString();
	}

	@Override
	public String getMenuTree() {
		return menuTree.toString();
	}

	private boolean hasAccess(String userCase, int action){
		if(!SystemConfig.CHECK_ACCESSES || userInfo.getRoleId() == SystemConfig.ADMIN_USER_ROLE_ID || userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID || userInfo.getRoleId() == SystemConfig.SYSTEM_ROLE_ID)
			return true;
		Integer acs = access.get(userCase);
		int p =(int) Math.pow(2, action);
		return acs != null && (acs.intValue() | p) == acs;
	}
	
}
