/******************************************************************************* 
o *  Copyright 2009 Amazon Services.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *
 *  Marketplace Web Service Java Library
 *  API Version: 2009-01-01
 *  Generated: Wed Feb 18 13:28:48 PST 2009 
 * 
 */



package org.mega.amazon;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.mega.amazon.test.Config;
import org.mega.bse.currency.CurrencyFacade;
import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.util.QueryUtil;

import com.amazonaws.mws.MarketplaceWebService;
import com.amazonaws.mws.MarketplaceWebServiceClient;
import com.amazonaws.mws.MarketplaceWebServiceConfig;
import com.amazonaws.mws.MarketplaceWebServiceException;
import com.amazonaws.mws.model.GetReportListRequest;
import com.amazonaws.mws.model.GetReportRequest;
import com.amazonaws.mws.model.GetReportResponse;
import com.amazonaws.mws.model.IdList;
import com.amazonaws.mws.model.ReportRequestInfo;
import com.amazonaws.mws.model.RequestReportRequest;
import com.amazonaws.mws.model.RequestReportResponse;
import com.amazonaws.mws.model.RequestReportResult;
import com.amazonaws.mws.model.ResponseMetadata;

/**
 *
 * Request Report  Samples
 *
 *
 */
public class AmazonProductsFacade {
	private static AmazonProductsFacade facade = new AmazonProductsFacade();

	public ServiceResult importData(BusinessParam businessParam) {
		int importedCount = 0;

		try {
			/************************************************************************
			 * Access Key ID and Secret Access Key ID, obtained from:
			 * http://aws.amazon.com
			 ***********************************************************************/
			final String accessKeyId = Config.accessKey;
			final String secretAccessKey = Config.secretKey;

			final String appName = Config.reportAppName;
			final String appVersion = Config.reportAppVersion;

			MarketplaceWebServiceConfig config = new MarketplaceWebServiceConfig();

			/************************************************************************
			 * Uncomment to set the appropriate MWS endpoint.
			 ************************************************************************/
			// US
			config.setServiceURL("https://mws.amazonservices.com/");
			// UK
			// config.setServiceURL("https://mws.amazonservices.co.uk/");
			// Germany
			// config.setServiceURL("https://mws.amazonservices.de/");
			// France
			// config.setServiceURL("https://mws.amazonservices.fr/");
			// Italy
			// config.setServiceURL("https://mws.amazonservices.it/");
			// Japan
			// config.setServiceURL("https://mws.amazonservices.jp/");
			// China
			// config.setServiceURL("https://mws.amazonservices.com.cn/");
			// Canada
			// config.setServiceURL("https://mws.amazonservices.ca/");
			// India
			// config.setServiceURL("https://mws.amazonservices.in/");

			/************************************************************************
			 * You can also try advanced configuration options. Available
			 * options are:
			 *
			 * - Signature Version - Proxy Host and Proxy Port - User Agent
			 * String to be sent to Marketplace Web Service
			 *
			 ***********************************************************************/

			/************************************************************************
			 * Instantiate Http Client Implementation of Marketplace Web Service
			 ***********************************************************************/

			MarketplaceWebService service = new MarketplaceWebServiceClient(accessKeyId, secretAccessKey, appName,
					appVersion, config);
			/************************************************************************
			 * Uncomment to try out Mock Service that simulates Marketplace Web
			 * Service responses without calling Marketplace Web Service
			 * service.
			 *
			 * Responses are loaded from local XML files. You can tweak XML
			 * files to experiment with various outputs during development
			 *
			 * XML files available under com/amazonaws/mws/mock tree
			 *
			 ***********************************************************************/
			// MarketplaceWebService service = new MarketplaceWebServiceMock();

			/************************************************************************
			 * Setup request parameters and uncomment invoke to try out sample
			 * for Request Report
			 ***********************************************************************/

			/************************************************************************
			 * Marketplace and Merchant IDs are required parameters for all
			 * Marketplace Web Service calls.
			 ***********************************************************************/
			final String merchantId = Config.sellerId;
			final String sellerDevAuthToken = "";// <Merchant Developer MWS Auth
													// Token>";
			// marketplaces from which data should be included in the report;
			// look at the
			// API reference document on the MWS website to see which
			// marketplaces are
			// included if you do not specify the list yourself
			final IdList marketplaces = new IdList(Arrays.asList(
			// "Marketplae1",
			// "Marketplace2"
			));

			RequestReportRequest request = new RequestReportRequest().withMerchant(merchantId)
					.withMarketplaceIdList(marketplaces).withReportType("_GET_MERCHANT_LISTINGS_DATA_");
			// .withReportOptions("ShowSalesChannel=true");
			// request = request.withMWSAuthToken(sellerDevAuthToken);

			// demonstrates how to set the date range
			DatatypeFactory df = null;
			try {
				df = DatatypeFactory.newInstance();
			} catch (DatatypeConfigurationException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
			XMLGregorianCalendar startDate = df.newXMLGregorianCalendar(new GregorianCalendar(2011, 1, 1));
			request.setStartDate(startDate);

			// 1: Create a report
			// invokeRequestReport(service, request);

			// 2: Get ReportId
			GetReportListRequest repListRequest = new GetReportListRequest();
			repListRequest.setMerchant(merchantId);
			// request.setMWSAuthToken(sellerDevAuthToken);
			// GetReportListSample.invokeGetReportList(service, repListRequest);

			// 3: Run report
			GetReportRequest reportRequest = new GetReportRequest();
			reportRequest.setMerchant(merchantId);
			reportRequest.setReportId("4703957818017259");

			// OutputStream report = new FileOutputStream(new
			// File("e:\\2.xml"));
			ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();

			reportRequest.setReportOutputStream(arrayOutputStream);

			// GetReportSample.invokeGetReport(service, reportRequest);
			GetReportResponse response = service.getReport(reportRequest);
			// response.getGetReportResult().getMD5Checksum()
			String[] rows = arrayOutputStream.toString().split("\n");
			StringBuilder insertCols = new StringBuilder("insert into tmp_amazon_products(id, merchant_id ");
			int sellerSkuIndex = -1;
			int listingIdIndex = -1;
			String[] cols = rows[0].split("\t");
			for (int i = 0; i < cols.length; i++) {
				if ("seller-sku".equals(cols[i]))
					sellerSkuIndex = i;
				if ("listing-id".equals(cols[i]))
					listingIdIndex = i;
				insertCols.append(", ").append(cols[i].replaceAll("-", "_").replaceAll(" ", "_"));
			}
			insertCols.append(")");

			int lastId = 0;
			BaseDB db = businessParam.getDB(200);
			for (int i = 1; i < rows.length; i++) {
				try {
					StringBuilder sql = new StringBuilder(insertCols);
					sql.append("VALUES ('").append(SystemConfig.ID_PREFIX).append(lastId + i).append("'").append(", '")
							.append(merchantId).append("'");
					cols = rows[i].split("\t");
					for (String col : cols) {
						sql.append(",'").append(col.replaceAll("'", "''")).append("'");
					}
					sql.append(")");
					System.out.println(sql);
					Query delQ = db.createNativeQuery("delete from tmp_amazon_products where merchant_id=:merchantId and seller_sku=:sku and listing_id=:listingId ");
					delQ.setParameter("merchantId", merchantId);
					delQ.setParameter("sku", cols[sellerSkuIndex]);
					delQ.setParameter("listingId", cols[listingIdIndex]);
					delQ.executeUpdate();

					db.runNativeQuery(sql.toString());
					importedCount++;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			businessParam.releaseDB();
		} catch (Exception e) {
			return new ServiceResult(ServiceResult.ERROR_CODE.IMPORT_ERROR, e.getMessage(), e);
		}
		return new ServiceResult(importedCount, importedCount);
	}


                                                        
    /**
     * Request Report  request sample
     * requests the generation of a report
     *   
     * @param service instance of MarketplaceWebService service
     * @param request Action to invoke
     */
    public static void invokeRequestReport(MarketplaceWebService service, RequestReportRequest request) {
        try {
            
            RequestReportResponse response = service.requestReport(request);

            
            System.out.println ("RequestReport Action Response");
            System.out.println ("=============================================================================");
            System.out.println ();

            System.out.print("    RequestReportResponse");
            System.out.println();
            if (response.isSetRequestReportResult()) {
                System.out.print("        RequestReportResult");
                System.out.println();
                RequestReportResult  requestReportResult = response.getRequestReportResult();
                if (requestReportResult.isSetReportRequestInfo()) {
                    System.out.print("            ReportRequestInfo");
                    System.out.println();
                    ReportRequestInfo  reportRequestInfo = requestReportResult.getReportRequestInfo();
                    if (reportRequestInfo.isSetReportRequestId()) {
                        System.out.print("                ReportRequestId");
                        System.out.println();
                        System.out.print("                    " + reportRequestInfo.getReportRequestId());
                        System.out.println();
                    }
                    if (reportRequestInfo.isSetReportType()) {
                        System.out.print("                ReportType");
                        System.out.println();
                        System.out.print("                    " + reportRequestInfo.getReportType());
                        System.out.println();
                    }
                    if (reportRequestInfo.isSetStartDate()) {
                        System.out.print("                StartDate");
                        System.out.println();
                        System.out.print("                    " + reportRequestInfo.getStartDate());
                        System.out.println();
                    }
                    if (reportRequestInfo.isSetEndDate()) {
                        System.out.print("                EndDate");
                        System.out.println();
                        System.out.print("                    " + reportRequestInfo.getEndDate());
                        System.out.println();
                    }
                    if (reportRequestInfo.isSetSubmittedDate()) {
                        System.out.print("                SubmittedDate");
                        System.out.println();
                        System.out.print("                    " + reportRequestInfo.getSubmittedDate());
                        System.out.println();
                    }
                    if (reportRequestInfo.isSetReportProcessingStatus()) {
                        System.out.print("                ReportProcessingStatus");
                        System.out.println();
                        System.out.print("                    " + reportRequestInfo.getReportProcessingStatus());
                        System.out.println();
                    }
                } 
            } 
            if (response.isSetResponseMetadata()) {
                System.out.print("        ResponseMetadata");
                System.out.println();
                ResponseMetadata  responseMetadata = response.getResponseMetadata();
                if (responseMetadata.isSetRequestId()) {
                    System.out.print("            RequestId");
                    System.out.println();
                    System.out.print("                " + responseMetadata.getRequestId());
                    System.out.println();
                }
            } 
            System.out.println();
            System.out.println(response.getResponseHeaderMetadata());
            System.out.println();

           
        } catch (MarketplaceWebServiceException ex) {
            
            System.out.println("Caught Exception: " + ex.getMessage());
            System.out.println("Response Status Code: " + ex.getStatusCode());
            System.out.println("Error Code: " + ex.getErrorCode());
            System.out.println("Error Type: " + ex.getErrorType());
            System.out.println("Request ID: " + ex.getRequestId());
            System.out.print("XML: " + ex.getXML());
            System.out.println("ResponseHeaderMetadata: " + ex.getResponseHeaderMetadata());
        }
    }

	public static AmazonProductsFacade getInstance() {
		return facade;
	}
         
	public ServiceResult list(BusinessParam businessParam) throws Exception {
		businessParam.getUserSession().checkAccess("AmazonProducts", ACTION.view);
        
        BaseDB db = null;
        try {
			db = businessParam.getDB(120);
			
            String where = QueryUtil.genQuery(null, businessParam.getFilter(), QueryUtil.QUERY_TYPE.WHERE_ONLY);
            String sql ="SELECT ITEM_NAME,ASIN1,SELLER_SKU,PRICE,QUANTITY,OPEN_DATE,PRODUCT_ID,BUSINESS_PRICE,QUANTITY_PRICE_TYPE,QUANTITY_LOWER_BOUND_1,QUANTITY_PRICE_1 FROM TMP_AMAZON_PRODUCTS";
			final String queryString = "select ROW_NUMBER() OVER (ORDER BY  seller_sku desc) rm,e.* from ("+sql +") e " + 
            		(where.length() > 0 ? where: "") ;// + " order by UPDATED desc";
            Query query = db.createNativeQuery(queryString);
            query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
            query.setMaxResults(businessParam.getFilter().getPageSize());
	        
            List<Object[]> ret = (List<Object[]>) query.getResultList();
	        int countAll = ret.size();
			businessParam.releaseDB();

            if(ret.size() == 0)
            	return new ServiceResult(null, countAll);
            String[] header = "#,ITEM NAME,ASIN1,SELLER SKU,PRICE,QUANTITY,OPEN DATE,PRODUCT ID,BUSINESS PRICE,QUANTITY PRICE TYPE,QUANTITY LOWER BOUND 1,QUANTITY PRICE 1".split(",");
            ret.add(0, header);            
            return new ServiceResult(ret, countAll);
        } catch (Exception e) {
            e.printStackTrace();
            businessParam.rolback();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
        }
	}
	
	public ServiceResult load(BusinessParam businessParam) throws Exception {
		businessParam.getFilter().getParams().iterator();
		businessParam.getUserSession().checkAccess("AmazonProducts", ACTION.view);
		
		BaseDB db = null;
		try {
			db = businessParam.getDB();
			
			String where = QueryUtil.genQuery(null, businessParam.getFilter(), QueryUtil.QUERY_TYPE.WHERE_ONLY);
			String sql ="SELECT ID,MERCHANT_ID,ITEM_NAME,ITEM_DESCRIPTION,LISTING_ID,SELLER_SKU,PRICE,QUANTITY,OPEN_DATE,IMAGE_URL,ITEM_IS_MARKETPLACE,PRODUCT_ID_TYPE,ZSHOP_SHIPPING_FEE,ITEM_NOTE,ITEM_CONDITION,ZSHOP_CATEGORY1,ZSHOP_BROWSE_PATH,ZSHOP_STOREFRONT_FEATURE,ASIN1,ASIN2,ASIN3,WILL_SHIP_INTERNATIONALLY,EXPEDITED_SHIPPING,ZSHOP_BOLDFACE,PRODUCT_ID,BID_FOR_FEATURED_PLACEMENT,ADD_DELETE,PENDING_QUANTITY,FULFILLMENT_CHANNEL,BUSINESS_PRICE,QUANTITY_PRICE_TYPE,QUANTITY_LOWER_BOUND_1,QUANTITY_PRICE_1,QUANTITY_LOWER_BOUND_2,QUANTITY_PRICE_2,QUANTITY_LOWER_BOUND_3,QUANTITY_PRICE_3,QUANTITY_LOWER_BOUND_4,QUANTITY_PRICE_4,QUANTITY_LOWER_BOUND_5,QUANTITY_PRICE_5,MERCHANT_SHIPPING_GROUP "
					+ " FROM TMP_AMAZON_PRODUCTS e ";
			//final String queryString = "select ROW_NUMBER() OVER (ORDER BY  seller_sku desc) rm,e.* from ("+sql +") e " + 	(where.length() > 0 ? where: "") ;// + " order by UPDATED desc";
			final String queryString = sql + (where.length() > 0 ? where: "") ;// + " order by UPDATED desc";
			Query query = db.createNativeQuery(queryString);
			
			List<Object[]> ret = (List<Object[]>) query.getResultList();
			int countAll = ret.size();
			businessParam.releaseDB();
			if(ret.size() == 0)
				return new ServiceResult(null, countAll);
			String[] header = "ID,MERCHANT ID,ITEM NAME,ITEM DESCRIPTION,LISTING ID,SELLER SKU,PRICE,QUANTITY,OPEN DATE,IMAGE URL,ITEM IS MARKETPLACE,PRODUCT ID TYPE,ZSHOP SHIPPING FEE,ITEM NOTE,ITEM CONDITION,ZSHOP CATEGORY1,ZSHOP BROWSE PATH,ZSHOP STOREFRONT FEATURE,ASIN1,ASIN2,ASIN3,WILL SHIP INTERNATIONALLY,EXPEDITED SHIPPING,ZSHOP BOLDFACE,PRODUCT ID,BID FOR FEATURED PLACEMENT,ADD DELETE,PENDING QUANTITY,FULFILLMENT CHANNEL,BUSINESS PRICE,QUANTITY PRICE TYPE,QUANTITY LOWER BOUND 1,QUANTITY PRICE 1,QUANTITY LOWER BOUND 2,QUANTITY PRICE 2,QUANTITY LOWER BOUND 3,QUANTITY PRICE 3,QUANTITY LOWER BOUND 4,QUANTITY PRICE 4,QUANTITY LOWER BOUND 5,QUANTITY PRICE 5,MERCHANT SHIPPING GROUP".split(",");
			ret.add(0, header);            
			return new ServiceResult(ret, countAll);
		} catch (Exception e) {
			e.printStackTrace();
			businessParam.rolback();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
		}
	}
}
