package org.mega.amazon.test;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.mega.util.IOUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.fasterxml.jackson.databind.ObjectMapper;

/*
 * This class shows how to make a simple authenticated call to the
 * Amazon Product Advertising API.
 *
 * See the README.html that came with this sample for instructions on
 * configuring and running the sample.
 */
public class Amazon1 {

    private static final String AWS_ACCESS_KEY_ID = "AKIAJMKWZYV5KHZW6O2A";

    private static final String AWS_SECRET_KEY = "FLeO/3KhqCJOUgXVcufnWclzOHxubFiEcou32KpI";

    private static final String ENDPOINT = "https://mws.amazonservices.com";
    private static final String REQUEST_URI = "/Products/2011-10-01";
    

    public static void main(String[] args) throws IOException, InvalidKeyException, NoSuchAlgorithmException {

        Map<String, String> params = new HashMap<String, String>();
        SignedRequestsHelper helper = new SignedRequestsHelper();

        params.put("Action", "ListMatchingProducts");
        params.put("SellerId","A1JF0FEJIRJQ6I");
        params.put("SignatureVersion", "2");
        params.put("Version", "2011-10-01");
        params.put("MarketplaceId", "ATVPDKIKX0DER");
        params.put("SignatureMethod", "HmacSHA256");
        
        String formData = helper.sign(params);
		
        URL url = new URL(ENDPOINT + REQUEST_URI);
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
       // connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        //connection.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
       
//        String status =   "AWSAccessKeyId=AKIAJMKWZYV5KHZW6O2A&Action=GetServiceStatus&SellerId=A1JF0FEJIRJQ6I&SignatureVersion=2&Timestamp=2017-03-31T04%3A45%3A47Z&Version=2011-10-01&Signature=E7c0OZxXuRS27tKoOjzmzbSQfvHFJOMtvX3iDFLnyrw%3D&SignatureMethod=HmacSHA256";
//        String formDate = "AWSAccessKeyId=AKIAJMKWZYV5KHZW6O2A&Action=GetServiceStatus&SellerId=A1JF0FEJIRJQ6I&SignatureVersion=2&Timestamp=2017-03-31T03%3A56%3A46Z&Version=2011-07-01&Signature=np3ftsnuNd%2B5j0K5FudS%2FLVGOkC8HSPhJFp2FU%2Bso6A%3D&SignatureMethod=HmacSHA256";

		OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
		//out.write(formData);
		out.close();
		
        byte[] read = IOUtil.readAndCloseStream(connection.getInputStream());
        System.out.println(new String(read));
    }
}