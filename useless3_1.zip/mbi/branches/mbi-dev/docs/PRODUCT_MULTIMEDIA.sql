﻿alter table MBI1.PRODUCT_MULTIMEDIA
   drop constraint FK_PRODUCT__REFERENCE_PRODUCT;

alter table MBI1.PRODUCT_MULTIMEDIA
   drop constraint FK_PRODUCT__REFERENCE_CO_COMBO;

drop table MBI1.PRODUCT_MULTIMEDIA cascade constraints;

/*==============================================================*/
/* Table: PRODUCT_MULTIMEDIA                                    */
/*==============================================================*/
create table MBI1.PRODUCT_MULTIMEDIA 
(
   PRODUCT_MULTIMEDIA_ID NUMBER(40)           not null,
   PRODUCT_ID           NUMBER(19,0),
   MULTIMEDIA_TYPE      NUMBER(19,0),
   IS_DELETED           NUMBER(19,0),
   FULL_TITLE           VARCHAR2(200 CHAR),
   UPDATED              TIMESTAMP (6),
   ACCESS_KEY           VARCHAR2(110 CHAR),
   DESCRIPTION          VARCHAR2(500 CHAR),
   IS_ENABLE            NUMBER(1,0),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   MULTIMEDIA_PRIORITY  NUMBER(5)            not null,
   MULTIMEDIA_DESCRIPTION NVARCHAR2(3000),
   MULTIMEDIA_FILE      BLOB,
   IS_DEFAULT_MULTIMEDIA NUMBER(1),
   constraint PK_PRODUCT_MULTIMEDIA primary key (PRODUCT_MULTIMEDIA_ID)
);

alter table MBI1.PRODUCT_MULTIMEDIA
   add constraint FK_PRODUCT__REFERENCE_PRODUCT foreign key (PRODUCT_ID)
      references MBI1.PRODUCT (PRODUCT_ID);

alter table MBI1.PRODUCT_MULTIMEDIA
   add constraint FK_PRODUCT__REFERENCE_CO_COMBO foreign key (MULTIMEDIA_TYPE)
      references MBI1.CO_COMBO_VAL (COMBO_VAL_ID);
