﻿alter table MBI1.PRODUCT_EXTENDED_PROPERTIES
   drop constraint FK_PRODUCT__REFERENCE_PRODUCT;

alter table MBI1.PRODUCT_EXTENDED_PROPERTIES
   drop constraint FK_PRODUCT__REFERENCE_CO_COMBO;

drop table MBI1.PRODUCT_EXTENDED_PROPERTIES cascade constraints;

/*==============================================================*/
/* Table: PRODUCT_EXTENDED_PROPERTIES                           */
/*==============================================================*/
create table MBI1.PRODUCT_EXTENDED_PROPERTIES 
(
   PRODUCT_EXTENDED_PROPERTIE_ID NUMBER(40)           not null,
   PRODUCT_ID           NUMBER(19,0),
   EXTENDED_PROPERTY_DATA_TYPE NUMBER(19,0),
   IS_DELETED           NUMBER(19,0),
   FULL_TITLE           VARCHAR2(200 CHAR),
   UPDATED              TIMESTAMP (6),
   ACCESS_KEY           VARCHAR2(110 CHAR),
   DESCRIPTION          VARCHAR2(500 CHAR),
   IS_ENABLE            NUMBER(1,0),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   EXTENDED_PROPERTY_NAME NVARCHAR2(300),
   EXTENDED_PROPERTY_VALUE NVARCHAR2(3000),
   EXTENDED_PROPERTY_FILE BLOB,
   constraint PK_PRODUCT_EXTENDED_PROPERTIES primary key (PRODUCT_EXTENDED_PROPERTIE_ID)
);

alter table MBI1.PRODUCT_EXTENDED_PROPERTIES
   add constraint FK_PRODUCT__REFERENCE_PRODUCT foreign key (PRODUCT_ID)
      references MBI1.PRODUCT (PRODUCT_ID);

alter table MBI1.PRODUCT_EXTENDED_PROPERTIES
   add constraint FK_PRODUCT__REFERENCE_CO_COMBO foreign key (EXTENDED_PROPERTY_DATA_TYPE)
      references MBI1.CO_COMBO_VAL (COMBO_VAL_ID);
