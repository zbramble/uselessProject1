alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_BRAN;

drop table MBI.BSE_BRAND cascade constraints;

/*==============================================================*/
/* Table: BSE_BRAND                                             */
/*==============================================================*/
create table MBI.BSE_BRAND 
(
   BRAND_ID             number(40)           not null,
   BRAND_TITLE          nvarchar2(300)       not null,
   SLOGAN               NVARCHAR2(1000),
   CODE                 VARCHAR2(10 BYTE),
   IMPORTED             NUMBER(1,0)          default 0,
   CREATED              TIMESTAMP (6),
   UPDATED              TIMESTAMP (6),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   DESCRIPTION          nvarchar(500),
   ACCESS_KEY           NVARCHAR2(110)       not null,
   constraint PK_BSE_BRAND primary key (BRAND_ID)
);
