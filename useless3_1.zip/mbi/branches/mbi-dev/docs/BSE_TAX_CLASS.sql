alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_TAX_;

drop table MBI.BSE_TAX_CLASS cascade constraints;

/*==============================================================*/
/* Table: BSE_TAX_CLASS                                         */
/*==============================================================*/
create table MBI.BSE_TAX_CLASS 
(
   TAX_CLASS_ID         NUMBER(10)           not null,
   TAX_CLASS_TITLE      NVARCHAR2(300)       not null,
   RATE                 DECIMAL(2,2)         not null,
   CODE                 VARCHAR2(10 BYTE),
   IMPORTED             NUMBER(1,0)          default 0,
   CREATED              TIMESTAMP (6),
   IS_ACTIVE            NUMBER(1,0)          default 0,
   UPDATED              TIMESTAMP (6),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   DESCRIPTION          nvarchar(500),
   IS_ENABLE            number(1),
   ACCESS_KEY           NVARCHAR2(110)       not null,
   constraint PK_BSE_TAX_CLASS primary key (TAX_CLASS_ID)
);
