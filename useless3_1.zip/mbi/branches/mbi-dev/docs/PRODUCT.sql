alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_PRODUCT;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_PROD;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_PROD;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_PROD;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_CO_COMBO;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_TAX_;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_CURR;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_BRAN;

drop table MBI.PRODUCT cascade constraints;

/*==============================================================*/
/* Table: PRODUCT                                               */
/*==============================================================*/
create table MBI.PRODUCT 
(
   PRODUCT_ID           NUMBER(40)           not null,
   RELATED_PRODUCT_ID   NUMBER(40),
   CATEGORY_ID          NUMBER(40),
   SUB_CATEGORY_ID      NUMBER(40),
   CLASSIFICATION_ID    NUMBER(40),
   PRODUCT_RELATIONSHIP_TYPE_ID NUMBER(19,0),
   TAX_CLASS_ID         NUMBER(10),
   CURRENCY_TYPE_ID     number(10),
   BRAND_ID             number(40),
   CODE                 VARCHAR2(10 BYTE),
   IMPORTED             NUMBER(1,0)          default 0,
   CREATED              TIMESTAMP (6),
   IS_ACTIVE            NUMBER(1,0)          default 0,
   UPDATED              TIMESTAMP (6),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   MBI_SKU              NVARCHAR2(30)        not null,
   MANUFACTURER_SKU     NVARCHAR2(30),
   BARCODE              NVARCHAR2(30),
   PRODUCT_TITLE        NVARCHAR2(500)       not null,
   RETAIL_PRICE         DECIMAL(15,2),
   SALE_PRICE           DECIMAL(15,2),
   IS_ENABLE            Number(1),
   TAX_AMOUNT           DECIMAL(10,2),
   ACCESS_KEY           NVARCHAR2(110)       not null,
   constraint PK_PRODUCT primary key (PRODUCT_ID)
);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_PRODUCT foreign key (RELATED_PRODUCT_ID)
      references MBI.PRODUCT (PRODUCT_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_BSE_PROD foreign key (CATEGORY_ID)
      references MBI.BSE_PRODUCT_CATEGORY (CATEGORY_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_BSE_PROD foreign key (SUB_CATEGORY_ID)
      references MBI.BSE_PRODUCT_CATEGORY (CATEGORY_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_BSE_PROD foreign key (CLASSIFICATION_ID)
      references MBI.BSE_PRODUCT_CATEGORY (CATEGORY_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_CO_COMBO foreign key (PRODUCT_RELATIONSHIP_TYPE_ID)
      references MBI.CO_COMBO_VAL (COMBO_VAL_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_BSE_TAX_ foreign key (TAX_CLASS_ID)
      references MBI.BSE_TAX_CLASS (TAX_CLASS_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_BSE_CURR foreign key (CURRENCY_TYPE_ID)
      references MBI.BSE_CURRENCY_TYPE (CURRENCY_TYPE_ID);

alter table MBI.PRODUCT
   add constraint FK_PRODUCT_REFERENCE_BSE_BRAN foreign key (BRAND_ID)
      references MBI.BSE_BRAND (BRAND_ID);
