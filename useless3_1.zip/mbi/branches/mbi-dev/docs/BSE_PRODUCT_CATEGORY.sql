alter table MBI.BSE_PRODUCT_CATEGORY
   drop constraint FK_BSE_PROD_REFERENCE_BSE_PROD;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_PROD;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_PROD;

alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_PROD;

drop table MBI.BSE_PRODUCT_CATEGORY cascade constraints;

/*==============================================================*/
/* Table: BSE_PRODUCT_CATEGORY                                  */
/*==============================================================*/
create table MBI.BSE_PRODUCT_CATEGORY 
(
   CATEGORY_ID          NUMBER(40)           not null,
   TOP_CATEGORY_ID      NUMBER(40),
   CATEGOTY_DESCRIPTION NVARCHAR2(300)       not null,
   CODE                 VARCHAR2(10 BYTE),
   IMPORTED             NUMBER(1,0)          default 0,
   CREATED              TIMESTAMP (6),
   IS_ACTIVE            NUMBER(1,0)          default 0,
   UPDATED              TIMESTAMP (6),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   DESCRIPTION          nvarchar(500),
   IS_ENABLE            number(1),
   ACCESS_KEY           NVARCHAR2(110)       not null,
   constraint PK_BSE_PRODUCT_CATEGORY primary key (CATEGORY_ID)
);

alter table MBI.BSE_PRODUCT_CATEGORY
   add constraint FK_BSE_PROD_REFERENCE_BSE_PROD foreign key (TOP_CATEGORY_ID)
      references MBI.BSE_PRODUCT_CATEGORY (CATEGORY_ID);
