exp mbi/mbi##321
--create table space and datafile together
CREATE TABLESPACE MBI_TBLS DATAFILE
'G:\ora_data\ntnet01.dbf' SIZE 150M
AUTOEXTEND ON
BLOCKSIZE 8192
FORCE LOGGING
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 256K
FLASHBACK ON;

--drop user NES cascade

create user mbi
  identified by "mbi"
  default tablespace MBI_TBLS
  temporary tablespace TEMP
  profile DEFAULT;
--  password expire;
-- Grant/Revoke role privileges 

--revoke dba from nes;
grant connect to mbi;
--grant dba to ntnet;
grant create table to mbi;
grant create synonym to mbi;
grant unlimited tablespace to mbi;
--alter user <user_name> quota unlimited on <tablespace_name>


CREATE TABLE "ntnet"."CO_COMBO_VAL"
(
   COMBO_VAL_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CODE varchar2(100),
   CREATE_BY varchar2(50),
   CREATE_TIME timestamp,
   IS_ACTIVE varchar2(1),
   NAME varchar2(50),
   UPDATE_BY varchar2(50),
   UPDATE_TIME timestamp,
   VAL varchar2(20),
   PARENT_ID decimal(19,0)
)
;
CREATE TABLE "ntnet"."CORE_SEQ"
(
   ID decimal(10,0),
   TABLE_NAME varchar2(30)
)
;
CREATE TABLE "ntnet"."CORE_USER"
(
   USER_ID decimal(20,0),
   FIRST_NAME varchar2(30),
   LAST_NAME varchar2(30),
   USER_NAME varchar2(30),
   USER_PASSWORD decimal(30,0),
   IS_ACTIVE decimal(1,0),
   CUSTOMER_ID decimal(30,0)
)
;
ALTER TABLE "ntnet"."CO_COMBO_VAL"
ADD CONSTRAINT FK_CO_COMBO_VAL
FOREIGN KEY (PARENT_ID)
REFERENCES "ntnet"."CO_COMBO_VAL"(COMBO_VAL_ID)
;
CREATE UNIQUE INDEX SYS_C008651 ON "ntnet"."CO_COMBO_VAL"(COMBO_VAL_ID)
;
CREATE UNIQUE INDEX UK_REXIUC9DD4KUI9I8MWJD04929 ON "ntnet"."CO_COMBO_VAL"(NAME)
;




INSERT INTO "ntnet"."CORE_SEQ" (ID,TABLE_NAME) VALUES (1,'test_merchant');
INSERT INTO "ntnet"."CORE_SEQ" (ID,TABLE_NAME) VALUES (3,'Merchant');
INSERT INTO "ntnet"."CORE_SEQ" (ID,TABLE_NAME) VALUES (14,'PUB_PERSON');


INSERT INTO "ntnet"."CORE_USER" (USER_ID,FIRST_NAME,LAST_NAME,USER_NAME,USER_PASSWORD,IS_ACTIVE,CUSTOMER_ID) VALUES (10001,'مهدی','گلناری','golnari',123,1,null);

CREATE TABLE "ntnet"."PUB_PERSON"
(
   PERSON_ID decimal(19,0) PRIMARY KEY NOT NULL,
   BIRTH_DATE varchar2(10),
   BIRTH_PLACE varchar2(50),
   BLOOD_TYPE varchar2(5),
   FATHER_NAME varchar2(50),
   FIRST_NAME varchar2(50),
   LAST_NAME varchar2(50),
   NATIONAL_ID varchar2(10)
)
;
CREATE UNIQUE INDEX SYS_C008632 ON "ntnet"."PUB_PERSON"(PERSON_ID)
;


INSERT INTO "ntnet"."PUB_PERSON" (PERSON_ID,BIRTH_DATE,BIRTH_PLACE,BLOOD_TYPE,FATHER_NAME,FIRST_NAME,LAST_NAME,NATIONAL_ID) VALUES (10009,'1920/05/20','تهران','سایر','صادق','علی','جوادی','0480015264');
INSERT INTO "ntnet"."PUB_PERSON" (PERSON_ID,BIRTH_DATE,BIRTH_PLACE,BLOOD_TYPE,FATHER_NAME,FIRST_NAME,LAST_NAME,NATIONAL_ID) VALUES (100012,'1358/05/12','تهارن','B+','علی','مهدی','گلناری آذر','0067871925');


alter index MBI.PK_CO_USER rebuild

