alter table MBI.PRODUCT
   drop constraint FK_PRODUCT_REFERENCE_BSE_CURR;

drop table MBI.BSE_CURRENCY_TYPE cascade constraints;

/*==============================================================*/
/* Table: BSE_CURRENCY_TYPE                                     */
/*==============================================================*/
create table MBI.BSE_CURRENCY_TYPE 
(
   CURRENCY_TYPE_ID     number(10)           not null,
   TITLE                NVARCHAR2(200),
   RATE                 decimal(5,2),
   IS_ACTIVE            NUMBER(1),
   CURRENCY_ABBREVIATION NVARCHAR2(5),
   IS_BASE_CURRENCY     NUMBER(1),
   CODE                 VARCHAR2(10 BYTE),
   IMPORTED             NUMBER(1,0)          default 0,
   CREATED              TIMESTAMP (6),
   UPDATED              TIMESTAMP (6),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   DESCRIPTION          nvarchar(500),
   ACCESS_KEY           NVARCHAR2(110)       not null,
   constraint PK_BSE_CURRENCY_TYPE primary key (CURRENCY_TYPE_ID)
);
