    window.onload = function () {
    	var loginPage =location.href.substring(0, location.href.indexOf('?'));
    	
		setCookie('loginPage', loginPage,99999999)   	
        hideLoading();
		clearForms();
       if(location.href.indexOf('?x=') > -1){
			showActivation();
			loadActivationData();
		}else 
			showLogin();
    }
    var userInfos;
	/* =========================================== UI Function(s) ====================================================*/
    function hideLoading() { $('#loading').addClass('hide'); }
    function showLoading(msg) {
    	if(msg) $('#loadingMsg').text(msg);
    	else $('#loadingMsg').text("Please wait...");
    	$('#loading').removeClass('hide');
    }

    function toggleLockPage() { $('.lock-div').toggleClass('show'); }
    function showLockPage() { $('.lock-div').addClass('show'); }
    function hideLockPage() { $('.lock-div').removeClass('show'); }

    function hideRegister(){ $('#register').removeClass('show');$('#register').removeClass('compact');}
    function compactRegister() {
        $('#register').removeClass('show').addClass('compact');
    }
    function showRegister(){ $('#register').addClass('show') }

    function showLogin() {
        $('#login').removeClass('compact').addClass('show');
        $("#forget-activation-div").hide();
		$("#activation").hide();
    }
	function showActivation(){
		$("#activation").show();
		hideLogin();
	}
    function compactLogin() {
        $('#login').removeClass('show').addClass('compact');
    }
    function hideLogin() {
        $('#login').removeClass('show compact');
    }

    function showForget() {
        $('#forget').addClass('show');
		$("#forget-username-div").show();
		//$("#forget-email-div").show();
    }
    function compactForget() {
        $('#forget').removeClass('show').addClass('compact');
    }
    function hideForget() {
        $('#forget').removeClass('show');$('#forget').removeClass('compact');
    }

    function showRole(list) {
        $('.toast').css({"z-index": "3"});
        userInfos = list;
        if(userInfos.length == 1) {
            selectRole(0);
            return;
        }
        $('#role').find('.role-item').remove();
        $('#role').addClass('show');
        userInfos.forEach(function (item, index) {
            addRole(item.roleName + ' - ' + item.orgName, index);
        })
    }
    function hideRole() {
        $('#role').removeClass('show');
        $('.toast').removeAttr('style')
    }
    function addRole(title, index) {
        var div = document.createElement('div');
        div.classList.add('role-item');
        div.setAttribute('id', index);
        div.setAttribute('onclick', 'selectRole(' + index + ')');
        var span = document.createElement('span');
        var text = document.createTextNode(title);
        span.appendChild(text);
        div.appendChild(span);
        document.getElementById('role').appendChild(div);
    }
    function selectRole(index) {
        userInfos[index].username = $("#username").val();
        userInfos[index].userPassword = $("#password").val();
        var dto = JSON.stringify(userInfos[index]);
        $.ajax({
                    url: servicePath + "/service/security/selectUserRole",
                    type: "POST",
                    data: dto,
                    contentType: "application/json",
                    cache: false,
                    dataType: "json",
                })
                .done(function (result) {
                    if (result.done) {
                        logedIn(result.result);
                    } else {
                        showToast('Reuest rejected: ' + result.errorDesc)
                    }
                })
                .fail(function (jqXHR, textStatus) {
                    showToast('Reuest rejected: ' + textStatus)
                })
                .always(function () {
                });
    }

    function showToast(msg) {
        showLockPage();
        $('#toast-msg').html(msg);
        setTimeout($('.toast').addClass('show') , 300);
    }
    function hideToast() {
       hideLockPage();
        $('.toast').removeClass('show');
    }

    function handleSelectLang() {
        if($('#select-language').attr('data-state') == 'close')
            $('#select-language').css({"margin-top" : "5px","opacity" : 1, "z-index": 2}).attr("data-state", "open");
        else
            closeSelectLang()
    }
    function closeSelectLang() {
        if($('#select-language').attr('data-state') == 'open')
            $('#select-language').css({"margin-top" : "-10px","opacity" : 0, "z-index": -1}).attr("data-state", "close");
    }

    function clearForms(){
        $('#login').find('input').not('[type=button]').val('');
        $('#login').find('input[type=checkbox]').prop("checked", false);
        //$('.select').html(selectLanguage.find('li:first-child span').html())
        $('#register').find('input').not('[type=button]').val('');
        $('#register').find('input[type=checkbox]').prop("checked", false);
        $('#forget').find('input[type=email]').val('');
        $('#forget').find('input[type=text]').val('');
        $('#activation-password').val('');
        $('#forget-newpassword').val('');
        $('#forget-repassword').val('');
    }

    /* =========================================== Listener(s) =======================================================*/
    var lang = 'ir';
    $('.select').on('click', function () {
        handleSelectLang();
    })
    $('input').on('click', function () {
        closeSelectLang()
    })
    $('#select-language li:not(.disable-li)').on('click', function () {
        lang = $(this).attr('data-value');
        $('.select').html($(this).find('span').html())
        closeSelectLang();
    })

    $('#login-btn').on('click', function () {
        if(validateForm('login')) {
            hideLogin();
            showLoading();
            login();
        }
    })
    $('#forget-password').on('click', function () {
        hideLogin();
		$('#active-user-div').hide();
		$('#forget-pass-div').show();
		$('#send-forget-btn').show();
		$('#send-lock-btn').hide();
		$('#forget-activation').val("");
        setTimeout(function () {
            showForget();
        }, 200)
    })
	
    $('#registr-btn').on('click', function () {
	    compactRegister();
		if($("#fullName").val().length < 6){
        	showToast('Full name must be at least 6 letters');
        	return false;
        }
		if($("#companyName").val().length < 3){
        	showToast('Company name must be at least 3 letters');
        	return false;
        }
/*		if($("#reg-username").val().length < 6){
        	showToast('User name must be at least 6 letters');
        	return false;
        }
*/		if($("#reg-password").val() != $("#reg-re-password").val()){
			showToast('Password and retyped is not same');
			return false;
		}
		if(!checkPassword($("#reg-password").val())){
			showToast('Choose strong password such this: sometext#$number');
			return false;
		}
		
        var femail = $("#email").val();
        if(femail.length < 6 || !(femail.lastIndexOf('.')  > femail.indexOf('@') + 2 )){
        	showToast('Complete email');
        	return false;
        } 
        if(!$("#remember-reg").prop("checked")){
        	showToast('First check "I agree site rules"');
        	return false;
        }
        if(validateForm('registr')) {
            return register();
        }      
    })
    $('#send-forget-btn').on('click', function () {
 		if($("#forget-username").val().length < 6){
			showToast('User name must be at least 6 letters');
			return false;
		}
        var femail = $("#forget-email").val();
        if(femail.length < 6 || !(femail.lastIndexOf('.')  > femail.indexOf('@') + 2 )){
        	showToast('Complete email');
        	return false;
        } 
        if(validateForm('forget')) {
            return sendForget();
        }
        //compactForget();
    })
    $('#go-register-btn').on('click', function () {
        hideLogin();
        setTimeout(function () {
            showRegister();
            clearForms();
        }, 300)
    })
    $('#back-btn').on('click', function () {
        hideRegister();
        setTimeout(function () {
            showLogin();
            clearForms();
        }, 300)
    })
    $('#forget-back-btn').on('click', function () {
        hideForget();
        setTimeout(function () {
            showLogin();
            clearForms();
        }, 300)
    })
    $('#close-toast').on('click', function () {
        $('.compact').each(function () {
            console.log($(this))
            $(this).removeClass('compact').addClass('show');
        });
        hideToast();
    })
    $('#close-role').on('click', function () {
        hideRole();
        showLogin();
    })

	 $('#password').on('keypress', function (e) {
         if(e.which === 13){

           if(validateForm('login')) {
				hideLogin();
				showLoading();
				login();
			}
         }
	});
	$('#send-activation-btn').on('click', function () {
		if($("#activation-password").val().length < 8){
			showToast('Complete password');
			return false;
		}
		return sendActivationData();
	});
	$('#rule-link').on('click',function(){
		window.open('/mbi/ui/viewRules.html', 'view rules', 'width=800,height=400,scrollbars=yes,top=200,left=300');
	});
	
	$('#lock-user').on('click', function () {
		hideLogin();
		$('#active-user-div').show();
		$('#forget-pass-div').hide();
		$('#send-forget-btn').hide();
		$('#send-lock-btn').show();
		$('#forget-activation').val("");
        setTimeout(function () {
            showForget();
        }, 200)
	});
	$('#send-lock-btn').on('click',function(){
		if($("#forget-username").val() != 'admin'){
			if($("#forget-username").val().length < 6){
				showToast('User name must be at least 6 letters');
				return false;
			}
		}
        var femail = $("#forget-email").val();
        if(femail.length < 6 || !(femail.lastIndexOf('.')  > femail.indexOf('@') + 2 )){
        	showToast('Complete email');
        	return false;
        } 
        if(validateForm('forget')) {
            return sendLockUser();
        }
	});
    /* ===================================== Business Function(s) ====================================================*/
    function login() {
        var formData = $("#login").serializeObject();
        formData.lang = lang;
        var dto = JSON.stringify(formData);
        try {
            $.ajax({
                        url: servicePath + "/service/security/login",
                        type: "POST",
                        data: dto,
                        contentType: "application/json",
                        cache: false,
                        dataType: "json",
                    })
                    .done(function (result) {
                        if (result.done) {
                            if(result.result) {
                                hideLoading();
                                showRole(result.result)
                            } else {
                                hideLoading()
                                showLogin()
                                showToast('Try again')
                            }
                        } else {
                            hideLoading();
                            showLogin();
							if(result.errorDesc == "User Locked"){
								$('#lock-user').show();
							}else $('#lock-user').hide();
                            showToast('Reuest rejected: ' + result.errorDesc)
                        }
                    })
                    .fail(function (jqXHR, textStatus) {
                        hideLoading();
                        showToast('Reuest rejected: ' + textStatus)
                    })

        } catch (e) {
            hideLoading();
            showToast('Reuest rejected: ' + e)
        }
    }
    function logedIn(u) {
        user = u;//user defined in mega.js
        setLocalStorageItem('user', u, u.expireMinute * 60 * 1000);
        if (user.firstPageURL)
            setWin(user.firstPageURL);
        else
            setWin('./ui/desktop.html');
    }
    function validateForm(id) {
        var result = true;
        $('#' + id).find('.mandatory').each(function (item) {
            var item = $(this).get(0);
            if(item.value.trim().length == 0 && item.value.trim() == '') {
                if (item.getAttribute('placeholder')) {
                    compactLogin();
                    showToast('Fill ' + item.getAttribute('placeholder'))
                    result = false;
                    return false; // Exit From Loop
                } else {
                    compactLogin()
                    showToast('Fill mandatory fields')
                    result = false;
                    return false; // Exit From Loop
                }
            }
        })
        return result;
    }
    
    function sendForget(){
    	var forgotData;
		if(byId('forget-activation-div').style.display == '' && $("#forget-activation").val().length ==0){
    		return false;
    	}
    	if($("#forget-activation").val().length >0){
    		if($("#forget-activation").val().length <6){
    			showToast('Activation code isnt true');
    			return false;
    		}
    		if($("#forget-newpassword").val() != $("#forget-repassword").val()){
    			showToast('Password and retyped is not same');
    			return false;
    		}
    		if(!checkPassword($("#forget-newpassword").val())){
    			showToast('Choose strong password such this: somestext#$number');
    			return false;
    		}
    		forgotData = '{"email":"'+$("#forget-email").val()+'","userName":"'+$("#forget-username").val()+'","activeCode":"'+$("#forget-activation").val()+'","password":"'+$("#forget-newpassword").val()+'","repassword":"'+$("#forget-repassword").val()+'"}';
    		showLoading('Change password...');
    	}
    	else{
    		forgotData = '{"email":"'+$("#forget-email").val()+'","userName":"'+$("#forget-username").val()+'"}';
    		showLoading('Sending email...');
    	}
    	
    	$.ajax({
            method: "POST", dataType: "json",  contentType: "application/json", cache: false,
            data: forgotData,
            url: servicePath + '/service/security/forgetPassword',
            success: function (result, textStatus, jqXHR) {
            	hideLoading();
            	if(result.done){
            		if(result.result == 2){
	            		hideForget();
	                    setTimeout(function () {
	                    	showLogin();
	                        clearForms();
	                    }, 300)
	                    showToast('Password changed. You can login now.');
            		}
            		if(result.result == 1){
            			$("#forget-username-div").hide();
            			$("#forget-email-div").hide();
            			$("#forget-activation-div").show();
            			showToast('Check your email and fill form');
            		}
            	}else{
            		if(result.errorDesc == 'WRONG_ACTIVATION'){
            			
            		}else{
            			$("#forget-activation-div").hide();
            			$("#forget-activation").text('');
            		}
            		showToast(result.errorTrace);
            	}
            },
            complete: function (jqXHR) {
            },
            error: function (jqXHR) {
        		hideLoading();
                showForget();
                showToast('Error in sending email. Try again. Error:' + jqXHR.status);
            }
    	});
    }
    
    function checkPassword(pass){
    	if(pass == null || pass.length < 8)
    		return false;
    	return true;
    }
    
	function register(){
		var registerData;
		registerData = '{"fullName":"'+$("#fullName").val()+'","companyName":"'+$("#companyName").val()+'","username":"'+$("#reg-username").val()+'","password":"'+$("#reg-password").val()+'","rePassword":"'+$("#reg-re-password").val()+'","email":"'+$("#email").val()+'"}';
		showLoading('Registering...');
		try {
            $.ajax({
                        url: servicePath + "/service/security/register",
                        type: "POST",
                        data: registerData,
                        contentType: "application/json",
                        cache: false,
                        dataType: "json",
                    })
                    .done(function (result) {
                        if (result.done) {
                           	hideLoading();
							hideRegister();
							setTimeout(function () {
								showLogin();
								clearForms();
							}, 300);
							showToast('Your account registered. Check your email for activation');
                            
                        } else {
                           hideLoading();
                            //showLogin();
                            showToast('Reuest rejected: ' + result.errorTrace)
                        }
                    })
                    .fail(function (jqXHR, textStatus) {
                        hideLoading();
                        showToast('Reuest rejected: ' + textStatus)
                    })

        } catch (e) {
            hideLoading();
            showToast('Reuest rejected: ' + e)
        }
	}
	
function loadActivationData(){
	hideLoading();
	clearForms();
	var ret = window.location.href.split('?x=')[1];
	var id = ret.split("O")[0];
	var code = ret.split("O")[1];
	$("#activation-userId").val(id);
	$("#activation-code").val(code);
	$("#activation-password").val('');
	
}

function sendActivationData(){
	var activationData = '{"userId":"'+$("#activation-userId").val()+'","activeCode":"'+$("#activation-code").val()+'","password":"'+$("#activation-password").val()+'"}';
	showLoading('Account activation...');
	try {
		$.ajax({
					url: servicePath + "/service/security/activationCode",
					type: "POST",
					data: activationData,
					contentType: "application/json",
					cache: false,
					dataType: "json",
				})
				.done(function (result) {
					if (result.done) {
						hideLoading();
						clearForms();
						setTimeout(function () {
							showLogin();
						}, 300);
						showToast('Your account activated. You can login now.');
					} else {
					   hideLoading();
                       showToast('Try again');
					}
				})
				.fail(function (jqXHR, textStatus) {
					hideLoading();
                    showToast('Reuest rejected: ' + textStatus)
				})

	} catch (e) {
		hideLoading();
		showToast('Reuest rejected: ' + e)
	}
}

function sendLockUser(){
	var forgotData;
		if(byId('forget-activation-div').style.display == '' && $("#forget-activation").val().length ==0){
    		return false;
    	}
    	if($("#forget-activation").val().length >0){
    		if($("#forget-activation").val().length <6){
    			showToast('Activation code isnt true');
    			return false;
    		}
    		if($("#forget-newpassword").val() != $("#forget-repassword").val()){
    			showToast('Password and retyped is not same');
    			return false;
    		}
    		if(!checkPassword($("#forget-newpassword").val())){
    			showToast('Choose strong password such this: somestext#$number');
    			return false;
    		}
    		forgotData = '{"email":"'+$("#forget-email").val()+'","userName":"'+$("#forget-username").val()+'","activeCode":"'+$("#forget-activation").val()+'","password":"'+$("#forget-newpassword").val()+'","repassword":"'+$("#forget-repassword").val()+'"}';
    		showLoading('Change password...');
    	}
    	else{
    		forgotData = '{"email":"'+$("#forget-email").val()+'","userName":"'+$("#forget-username").val()+'"}';
    		showLoading('Sending email...');
    	}
    	
    	$.ajax({
            method: "POST", dataType: "json",  contentType: "application/json", cache: false,
            data: forgotData,
            url: servicePath + '/service/security/unLockUser',
            success: function (result, textStatus, jqXHR) {
            	hideLoading();
            	if(result.done){
            		if(result.result == 2){
	            		hideForget();
						$('#lock-user').hide();
	                    setTimeout(function () {
	                    	showLogin();
	                        clearForms();
	                    }, 300)
	                    showToast('Actived User. You can login now.');
            		}
            		if(result.result == 1){
            			$("#forget-username-div").hide();
            			$("#forget-email-div").hide();
            			$("#forget-activation-div").show();
            			showToast('Check your email and fill form');
            		}
            	}else{
            		if(result.errorDesc == 'WRONG_ACTIVATION'){
            			
            		}else{
            			$("#forget-activation-div").hide();
            			$("#forget-activation").text('');
            		}
            		showToast(result.errorTrace);
            	}
            },
            complete: function (jqXHR) {
            },
            error: function (jqXHR) {
        		hideLoading();
                showForget();
                showToast('Error in sending email. Try again. Error:' + jqXHR.status);
            }
    	});
}
    