/*----------------------------------------------------------------------------- Utility ------------------------------*/
var user = getUser();
var isPC = isPC();
var iosVersion = iOSversion();
var orderField ='updated desc';

$(document).ready(function () {
    if ($("#pageNo").length > 0) {
        $("#pageNo").keyup(function (event) {
            if (event.keyCode == 13) {
                pageNo = $("#pageNo").val();
                search();
            }
        });
    }
    if ($("#pageSize").length > 0) {
        $("#pageSize").keyup(function (event) {
            if (event.keyCode == 13) {
                pageSize = $("#pageSize").val();
                pageNo = 1;
                $("#pageNo").val("1");
                search();
            }
        });
    }

    $.fn.serializeObject = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
});

//if modal be true show message for mandatories else only focus to element
function checkMandatories(formId, modal) {
    var mandatories = '';
    var exportList = "<ul>";
    $("#" + formId).find('.mandatory').not(':hidden').each(function () {
        Log(this)
        if (!$(this).val()) {
            if (modal) {
                if ($(this).attr('Label'))
                    mandatories += ('<li>' + $(this).attr('Label') + '</li>');
                else if ($(this).closest('td').prev().find('label').length > 0)
                    mandatories += ('<li>' + $(this).closest('td').prev().find('label').html() + '</li>');
                else
                    mandatories += ('<li>' + $(this).attr("id") + '</li>');
            } else {
                $(this).focus();
                Log(this);
                throw new Error('Empty mandatory filed' + mandatories);
            }
        }
    });
    if (mandatories.length > 0) {
        exportList += mandatories + "</ul>";
        dialog("Check mandatories", "Please fill these items:" + exportList);
        throw new Error('Empty mandatory filed' + mandatories);
    }
    return true;
}

function checkSize(formId, modal) {
    var item = '';
    $("#" + formId).find("[checksize]").each(function () {
        if ($(this).val().length < $(this).attr("checksize")) {
            if ($(this).attr('Label'))
            	item = $(this).attr('Label');
            if ($(this).attr('placeholder'))
            	item = $(this).attr('placeholder');
            else if ($(this).closest('div').prev().find('label').length > 0)
            	item = $(this).closest('div').prev().find('label').html();
            else
            	item = $(this).attr("id");
            $(this).focus();
            dialog("Check length", "\"" + item + "\" must be at least " + $(this).attr("checksize") + " characters");
            throw new Error('Size not valid');
        }
    });
//    return true;
}
function cancelEvent(e) {
    var evt = e ? e : window.event;
    if (evt.stopPropagation)    evt.stopPropagation();
    if (evt.cancelBubble != null) evt.cancelBubble = true;
}

function submitForm() {
    var formData = $("#MyForm").serializeObject();
    console.log(formData);
    $.post(url, formData,
        function (data, status) {
            alert("Data: " + data + "\nStatus: " + status);
        });
}

function toJSON() {
    var formdata = $("#MyForm").serializeObject();
    $("#json").text(formdata);
}

function byId(id) {
    return document.getElementById(id);
}

function Log(msg) {
    console.log(msg)
}

function hide(id) {
    $('#' + id).hide('slow');
}

function errorHandle(searchResult) {
    switch (searchResult.errorCode) {
        case 'USER_EXPIRED':
            if (confirm(msg('USER_EXPIRED'))) {
                showLoginPage();
            }
            //delCookie('user');
            removeLocalStorageItem('user');
            break;
        case 'IS_NULL' :
        case "BUSINESS_MESSAGE" :
        case "INVALID_FILTER_PARAMETER":
            dialog('Message', searchResult.errorDesc);
            break;
       	case 'DUPLICATE':
        	dialog("Warrning", searchResult.errorDesc);
        	break;
        default:
        	dialog('Error', searchResult.errorDesc);
    }
}

function getUser() {
    var user = getLocalStorageItem('user');
    if (user == null) {
        if (location.href.indexOf('login.html') == -1) {//اگر در صفحه لاگین نباشیم صفحه لاگین را نشان بدهد
            showLoginPage();
            return null;
        }
        else
            return null;
    }
    var currentDate = new Date().getTime();

    if (!diffTime(currentDate, user.timestamp, user.expireMinute)) {
        try {
            removeLocalStorageItem(key);
        } catch (e) {
            Log('************')
        }
        return null;
    }
    // Action codes to check
    user.action_insert = 1;
    user.action_update = 2;
    user.action_delete = 3;
    user.action_search = 4;
    user.action_view = 5;
    user.action_print = 6;
    user.action_export_excel = 7;
    user.action_export_PDF = 8;
    user.action_view_count_all = 9;
    user.action_approve = 10;
    user.action_reject = 11;
    user.action_show_in_menu = 12;

    user.hasAccess = function (usecase, action) {
        var act = user.access[usecase];
        return act != null && (act | action) == act;
    }
    return user;
}

function setWin(winPath) {
    top.location.href = progPath + '/' + winPath;
}

function showLoginPage() {
    if (getCookie("loginPage") != null && getCookie("loginPage") != '')
        top.location.href = getCookie("loginPage");
    else
        top.location.href = progPath + '/ui/login.html';
}

function lockPage() {
    if ($("#lockDiv").length > 0) {
        $("#lockDiv").show();
    } else {
        if (top.location.href != location.href)
            top.lockPage();
    }
}

function unlockPage() {
    if ($("#lockDiv").length > 0) {
        $("#lockDiv").hide();
    } else {
        if (top.location.href != location.href)
            top.unlockPage();
    }
}

var pageNo = 1;
var pageSize = 10
function nextPage() {
    if ($("#pageNo").length > 0) {
        pageNo = $("#pageNo").val();
        $("#pageNo").val(++pageNo)
    } else {
        pageNo++;
    }
    pageState = PageState.NEXT;
    search();
}

function prevPage() {
    if ($("#pageNo").length > 0) {
        pageNo = $("#pageNo").val();
        if (pageNo == 1)
            return;
        $("#pageNo").val(--pageNo)
    } else {
        if (pageNo == 1)
            return;
        pageNo--;
    }
    pageState = PageState.PREV;
    search();
}

function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}

/*----------------------------------------------------------------------------- Storage Management -------------------*/
var storageManagement = (function () {
    var
        /**
         * @param {String}  key    Data name
         * @param {Object}  value  Data value
         */
        write = function (key, value) {
            value.timestamp = new Date().getTime();
            localStorage.setItem(key, JSON.stringify(value));
        },

        /**
         * @param {String}  key           Data name
         * @param {Number}  userTimeOut   Session timeOut value (Minute)
         * @return {Object} Data
         */
        read = function (key, timeout) {
            var obj = JSON.parse(localStorage.getItem(key));
            if (obj == null)
                return null;
            if (!isExpired(obj.timestamp, timeout)) {
                remove(key);
                return null;
            }
            return obj;
        },

        /**
         * @param {String}  key   Data name
         */
        remove = function (key) {
            localStorage.removeItem(key)
        },

        /**
         * @param {Number}     pastTime
         * @param {Number}     timeOut
         * @return {boolean}   True/False
         */
        isExpired = function (pastTime, timeOut) {
            var currTime = new Date().getTime();
            timeOut *= 60000;
            if (currTime - pastTime > timeOut)
                return false;
            return true;
        }

    return {
        write: write,
        read: read,
        remove: remove
    };
})();

/*----------------------------------------------------------------------------- User Management ----------------------*/
var userManagement = (function () {
    var
        /**
         * @param {Object}  userInfo    User Live Info
         */
        setUser = function (userInfo) {
            storageManagement.write("USER", userInfo);
        },

        /**
         * @return {Object} User Info
         */
        getUser = function () {
            var userInfo = storageManagement.read("USER", user.expireMinute);
            if (userInfo == null) {
                if (location.href.indexOf('/login.html') == -1) {
                    setWin(progPath + 'ui/login.html');
                    return null;
                }
            } else {
                storageManagement.write("USER", userInfo);
                return userInfo;
            }
        },

        /**
         * Remove user
         */
        removeUser = function () {
            localStorage.removeItem("USER")
        };

    return {
        setUser: setUser,
        getUser: getUser,
        removeUser: removeUser
    };
})();

/*----------------------------------------------------------------------------- Filter -------------------------------*/
function Filter() {
    var params = [];

    /**
     * @param {String}                key           Filed name
     * @param {String}                value         Filed value
     * @param {Condition}             condition     condition in where class ()
     */
    this.addParameter = function (key, value, condition) {
        var parameter = {"key": key, "value": value, "condition": condition};
        params.push(parameter);
    }

    /**
     * @param paramsArr => Array[parameter]
     */
    this.addParams = function (paramsArr) {
        for (var i = 0; i < paramsArr.length; i++) {
            var parameter = {"key": paramsArr[i].key, "value": paramsArr[i].value, "condition": paramsArr[i].condition};
            params.push(parameter);
        }
    }

    /**
     * @param {String}                key           Filed name
     */
    this.removeParameter = function (key) {
        params = $.grep(params, function (e) {
            return e.key != key;
        });
    }

    /**
     * Remove all params
     */
    this.clearParams = function () {
        params.length = 0;
    }

    /**
     * @return {String} filter
     */
    this.getFilters = function (orderField) {
        var result = '{"params":[ ';
        $.each(params, function (i, p) {
            if(p.key == Condition.WHERE) {
                result += '{"key": "' + p.key + '"'
                    + ', "value": "' + p.value + '"'
                    + ', "condition": "' + p.condition + '"'
                    + '},';
            } else {
                result += '{"key": "' + p.key + '"'
                    + ', "value": "' + eval(p.value) + '"'
                    + ', "condition": "' + p.condition + '"'
                    + '},';
            }
        });

        //Add order by
        if (orderField && orderField.length > 0) {
            result += '{"key": "order"'
                + ', "value": "' + orderField + '"'
                + ', "condition": "' + Condition.ORDER + '"'
                + '}';
        } else {
            result = result.substr(0, (result.lastIndexOf(",") != -1 ? result.lastIndexOf(",") : result.length));
        }
        result += '], "ticket": "' + user.ticket + '", "pageNo":"' + pageNo + '", "pageSize":"' + pageSize + '"}';
        return result;
    }
}

/*----------------------------------------------------------------------------- Service Invoker ----------------------*/
var ServiceInvoker = (function () {
    /**
     * @param {String}             data
     * @param {Handler}            handler
     * @param {String}             url
     */
    var call = function (data, handler, url) {
        try {
            $.ajax({
                method: "POST",
                dataType: "json",
                contentType: "application/json",
                data: data,
                url: servicePath + '/service' + url,
                cache: false,
                beforeSend: function () {
                    handler.beforeSend();
                },
                success: function (data, textStatus, jqXHR) {
                    handler.success(data, textStatus, jqXHR);
                },
                complete: function (jqXHR) {
                    handler.complete(jqXHR);
                },
                error: function (jqXHR) {
                    handler.error(jqXHR);
                }
            });
        } catch (e) {
            hideLoading();
            setTimeout(function () {
                showError("Error: " + e);
            }, 300)
        }
    }

    /**
     * @param {Object}              files
     * @param {FormData}            formData
     * @param {Handler}             handler
     */
    var upload = function (files, formData, handler) {

        $.each(files, function (i, file) {
            formData.append('file', file);
            formData.append('file-' + file.name + "-size", file.size);
        });
        formData.append("ticket", user.ticket);

        try {
            $.ajax({
                url: servicePath + '/service/file/save',
                type: 'POST',
                data: formData,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    handler.beforeSend();
                },
                success: function (data, textStatus, jqXHR) {
                    handler.success(data, textStatus, jqXHR);
                },
                complete: function (jqXHR) {
                    handler.complete(jqXHR);
                },
                error: function (jqXHR) {
                    handler.error(jqXHR);
                }
            });
        } catch (e) {
            hideLoading();
            setTimeout(function () {
                showError("ٍError: " + e);
            }, 300)
        }
    }

    /**
     * @param {Object}              filter
     * @param {String}              url
     */
    var download = function (filter, url) {
        url = servicePath + '/service' + url;
        try {
            if (window.XMLHttpRequest) {
                http = new XMLHttpRequest();
            } else {
                http = new ActiveXObject("Microsoft.XMLHTTP");
            }
            var http = new XMLHttpRequest();
            http.open("POST", url, true);
            http.setRequestHeader("Content-type", "application/json");
            http.responseType = 'blob';
            http.onload = function (e) {
                if (http.status == 200) {
                    window.URL = window.URL || window.webkitURL;
                    var fileURL = URL.createObjectURL(http.response);
                    window.open(fileURL);
                } else {
                    alert('Error:' + http.status);
                }
            }
            http.send(filter);
        } catch (e) {
            hideLoading();
            setTimeout(function () {
                showError("Error: " + e);
            }, 300)
        }
    }

    return {
        call: call,
        upload: upload,
        download: download
    }
})();

/*----------------------------------------------------------------------------- Custom Autocomplete ------------------*/
function CustomAutocomplete() {

    /**
     * @param  {AutocompleteParameter}   params
     */
    this.dynamicConfig = function (params) {
        var dataResult = {};
        var lastSelected = "";
        var autocompleteButton = $('#' + params.targetElementId).siblings('label.autocomplete-icon');

        var handler = new Handler();
        handler.beforeSend = function () {
            // Handling Button Autocomplete Status
            autocompleteButton.toggleClass('ion-load-c ion-ios-search-strong rotate');
            autocompleteButton.siblings('input').attr('disabled', true);
        }
        handler.success = function (data) {
            // Handling Button Autocomplete Status
            autocompleteButton.toggleClass('ion-load-c ion-ios-search-strong rotate');
            autocompleteButton.siblings('input').removeAttr('disabled');

            if (data.result != undefined) {
                dataResult = $.map(data.result, function (item) {
                    var resultItem = {};
                    for (var mp in params.mapPattern) {
                        resultItem[mp] = item[params.mapPattern[mp]];
                    }
                    return resultItem;
                });
            } else {
                dataResult = [{entityId: -1, label: "[no things]", value: "[no things]"}];
            }
            $('#' + params.targetElementId).trigger('keydown')
            $('#' + params.targetElementId).focus()

        }
        handler.error = function (jqXHR) {
        }

        $('#' + params.targetElementId).autocomplete({
            autoFocus: true,
            source: function (request, response) {
                if (dataResult != undefined) {
                    var result = $.grep(dataResult, function (element) {
                        var currentValue = $('#' + params.targetElementId).val();
                        return element.label.toLowerCase().indexOf(currentValue.toLowerCase()) > -1;
                    });
                    /* if (result.length == 0) {
                     result.push({entityId: -1, label: "ندارد", value: "ندارد"});
                     }*/
                    response(result);
                }
            },
            select: function (event, ui) {
                for (var it in ui.item) {
                    if (it == "label") {
                        $(this).html(ui.item.label);
                    } else if (it == "value") {
                        $(this).val(ui.item.value);
                    } else {
                        $(this).attr(it, ui.item[it]);
                    }
                }
                lastSelected = ui.item.label;
                return false;
            },
            minLength: 0,
        }).keyup(function (event) {
            if (event.keyCode == KeyCodes.Enter && ( $(this).val() != lastSelected || lastSelected == "")) {
                dataResult = {};
                ServiceInvoker.call(params.filter.getFilters(), handler, params.serviceUrl);
            } else if (event.keyCode == KeyCodes.BackSpace || event.keyCode == KeyCodes.Delete) {
                $(this).attr("entityId", "");
            }
        });
    }

    /**
     * @param  {AutocompleteParameter}   params
     */
    this.staticConfig = function (params) {
        var dataResult = {};
        var lastSelected = "";
        var autocompleteButton = $('#' + params.targetElementId).siblings('label');

        var handler = new Handler();
        handler.beforeSend = function () {
            // Handling Button Autocomplete Status
            autocompleteButton.toggleClass('ion-load-c ion-ios-search-strong rotate');
            autocompleteButton.siblings('input').attr('disabled', true);
        }
        handler.success = function (data) {
            // Handling Button Autocomplete Status
            autocompleteButton.toggleClass('ion-load-c ion-ios-search-strong rotate');
            autocompleteButton.siblings('input').removeAttr('disabled');

            dataResult = $.map(data.result, function (item) {
                var resultItem = {};
                for (var mp in params.mapPattern) {
                    resultItem[mp] = item[params.mapPattern[mp]];
                }
                return resultItem;
            });
            storageManagement.write(params.storageName, dataResult);
        }
        handler.error = function (jqXHR) {
        }

        $('#' + params.targetElementId).autocomplete({
            source: function (request, response) {
                if ($.isEmptyObject(dataResult)) {
                    dataResult = storageManagement.read(params.storageName);
                }
                if ($.isEmptyObject(dataResult)) {
                    ServiceInvoker.call(params.filter.getFilters(), handler, params.serviceUrl);
                }
                if (!$.isEmptyObject(dataResult)) {
                    var hiddenIdList = params.getHiddenIdList();
                    response(dataResult.filter(function (el) {
                        return (hiddenIdList.indexOf(el.id) == -1);
                    }));
                }
            },
            select: function (event, ui) {
                for (var it in ui.item) {
                    if (it == "label") {
                        $(this).html(ui.item.label);
                    } else if (it == "value") {
                        $(this).val(ui.item.value);
                    } else {
                        $(this).attr(it, ui.item[it]);
                    }
                }
                lastSelected = ui.item.label;
                return false;
            },
            minLength: 0,
        }).keyup(function (event) {
            if (event.keyCode == KeyCodes.BackSpace || event.keyCode == KeyCodes.Delete) {
                $(this).attr("entityId", "");
            }
        }).focus(function () {
            $(this).trigger($.Event("keydown", {which: KeyCodes.Enter}));
        })
    }
}//End of CustomAutocomplete

function onAutocompleteBtn(element) {
    if (element.hasClass('ion-ios-search-strong')) {
        var e = jQuery.Event("keyup");
        e.keyCode = KeyCodes.Enter;
        element.siblings('input').trigger(e);
    }
}

/*--------------------------------------------------------------------------------------- Get Param Value ------------*/
function getParamValue(paramName) {
    var url = window.location.search.substring(1);
    var qArray = url.split('&');
    for (var i = 0; i < qArray.length; i++) {
        var pArr = qArray[i].split('=');
        if (pArr[0] == paramName)
            return pArr[1];
    }
}
/*----------------------------------------------------------------------------- Other --------------------------------*/
/*
 * Show dialog
 * if okFunc set, after ok click this method called
 * if nokFunc set, Button Cancle will shown and after Cancel click this method called
 */
function dialog(title, msg, okFunc, nokFunc) {
    if ($("#mega-dialog").length == 0) {
        $("body").append('<div id="mega-dialog" title="Message" style="direction:ltr"><div style="direction:ltr" id="mega-dialog-msg"></div></div>');
    }
    //$("#mega-dialog").attr("title", title);
    $("#mega-dialog-msg").html(msg);

    var btns = [
        {
            text: 'Ok',
            click: function () {
                $(this).dialog("close");
                if (okFunc != null) {
                    okFunc.call();
                }
            }
        }
    ];
    if (nokFunc != null) {
        btns.push(
            {
                text: 'Cancel',
                click: function () {
                    $(this).dialog("close");
                    if (nokFunc != null) {
                        nokFunc.call();
                        throw new Error("Cancel");
                    }
                }
            }
        );
    }

    $("#mega-dialog").dialog({
        modal: true,
        closeOnEscape: true,
        buttons: btns,
        show: {
            effect: "fadeIn",
            duration: 300
        },
        hide: {
            effect: "fadeOut",
            duration: 500
        },
        position: {
            my: "center", at: "center", of: window
        }
    });


}

//download image by its code in server
function imageLoad(fileId, imgElmId) {
    if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
        http = new XMLHttpRequest();
    } else {// code for IE6, IE5
        http = new ActiveXObject("Microsoft.XMLHTTP");
    }

    var http = new XMLHttpRequest();
    var url = servicePath + "/ImageLoader";
    var params = "ticket=" + user.ticket + "&fileId=" + fileId;
    http.open("POST", url, true);

    //Send the proper header information along with the request
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.responseType = 'blob';

    http.onload = function (e) {
        if (http.status == 200) {

            window.URL = window.URL || window.webkitURL;

            var img = byId(imgElmId);
            if (img == null) {
                img = document.createElement('img')
                document.body.appendChild(img);
            }
            img.src = window.URL.createObjectURL(http.response);
        } else {
            alert('Error:' + http.status);
        }
    }
    http.send(params);
}

(function (a) {
    (jQuery.browser = jQuery.browser || {}).mobile = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))
})(navigator.userAgent || navigator.vendor || window.opera);

/* === Set Listeners === */
$('input[type=file]').each(function (index, item) {
    var spanContainer = $(item).find(" ~ div.file-details");
    $(item).on('change', function () {
        var filesArray = [].slice.call(this.files);
        filesArray.forEach(function (file) {
            var fileName = file.name.shortenFileName(25);
            spanContainer.append($('<div/>').addClass('file-caption-row').html('<span class="file-caption">' + fileName + '</span><span id="' + file.name + '" class="ion-close-round remove-file"></span>'));
        })
    })
})

/* ====== Util Function(s) ====== */

/**
 * Agar Te'dad Charachter-haye Name File Bishtar Az Count Bashad, Mian-e Name File & Extenstion-ash ... Mi'andazad
 * @param count
 * @returns {*}
 */
String.prototype.shortenFileName = function (count) {
    if (this.length > count) {
        return this.substr(0, count) + ' ... ' + this.substr(this.lastIndexOf('.'), this.length - 1);
    } else
        return this;
}
String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.split(search).join(replacement)
}
String.prototype.removeItem = function (item) {
    return this.split(item).join('');
}
Array.prototype.diff = function (a) {
    return this.filter(function (i) {
        return a.indexOf(i) < 0;
    });
};
String.prototype.urlParameter = function (name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(this);
    if (results == null) {
        return null;
    }
    else {
        return results[1] || 0;
    }
}


// Device Type
function isPC() {
    if (window.outerWidth < 780) {
        $('#main-container').html('<iframe name="handheld-device-win"></iframe>');
        return false;
    }
    return true;
}

function iOSversion() {
    if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
        if (!!window.indexedDB) {
            return 'iOS 8 and up';
        }
        if (!!window.SpeechSynthesisUtterance) {
            return 'iOS 7';
        }
        if (!!window.webkitAudioContext) {
            return 'iOS 6';
        }
        if (!!window.matchMedia) {
            return 'iOS 5';
        }
        if (!!window.history && 'pushState' in window.history) {
            return 'iOS 4';
        }
        return 'iOS 3 or earlier';
    }
    return false;
}

/**
 * Call this in scroll event
 * @param elem eg. #test, .test, ...
 * @returns {boolean}
 */
function isScrolledIntoView(elem) {
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}

/**
 * Is element visible on window (Horizontally)
 * @param elem: can be jQueryObject, #elementID, .elementClass, ...
 * @param window: window object
 * @returns {boolean}
 */
function isVisibleOnScreen(window, elem) {
    var winWidth = $(window).width();
    var element = (elem instanceof jQuery) ? elem : $(elem);
    
    var leftOffset = 0;
    try{
    	leftOffset = element.offset().left;
    }catch(e){}    var width = element.width();
    return (leftOffset + width <= winWidth);
}

/**
 * Convert String to HTML Element (HTML5 Feature)
 * @param html
 * @returns {*|Node}
 */
function htmlToElement(html) {
    var template = document.createElement('template');
    template.innerHTML = html;
    return template.content.firstChild;
}
/**
 * Convert String to HTML Elements (HTML5 Feature)
 * @param html
 * @returns {NodeList}
 */
function htmlToElements(html) {
    var template = document.createElement('template');
    template.innerHTML = html;
    return template.content.childNodes;
}


/* ================================= Common CRUD Listener(s) & Method(s) ============================================ */
// INDEX
function setIndexListeners() {
    $('.error-container').on('click', function () {
        hideError()
    })
    $('#refresh-grid').on('click', function () {
        refreshGrid()
    });
    if (isPC) {
        var entityDetail = [];
        $('.win-content-body th > span:first-child').each(function (index, item) {
            if (index > 0) {
                entityDetail.push($(this).html())
            }
        })
        if (!isVisibleOnScreen(window, $('.simple-search').first())) {
            $('.win-content-header').addClass('compact');
            handleUISize();
        }
        $('.collapse-header').on('click', function () {
            /*if ($('#collapse-btn').hasClass('rotateX')) {
                $(this).removeAttr('style');
                $('#collapse-btn').removeClass('rotateX');
                $('.win-content-header').removeAttr('style');
                $('.action-container').removeAttr('style');
                $('.search-container').removeAttr('style');
                $('.collapse-title').removeAttr('style');
                handleUISize();
            } else {
                $(this).css({'bottom': "3px"});
                $('#collapse-btn').addClass('rotateX');
                $('.win-content-header').css({'height': '20px', 'background-color': '#193175'});
                $('.action-container').css({'display': 'none'});
                $('.search-container').css({'display': 'none'});
                $('.collapse-title').css({'display': 'inline-block'});
                handleUISize();
            }*/
            $('.win-content-header').removeClass('compact full-search')
        })

        var thArray = [].slice.call(document.querySelectorAll('.win-content-body thead tr > th'));
        thArray.forEach(function (item, index, array) {
            if (item.getAttribute('orderField') && index != thArray.length - 1) {
                $(item).on('click', function () {
                    var elem = $(this).find('span:last-child');
                    if (elem.attr('style')) {
                        elem.removeAttr('style');
                        if ($(this).attr('orderField'))
                            search($(this).attr('orderField') + ' asc');
                        else
                            search();
                    }
                    else {
                        if ($(this).attr('orderField'))
                            search($(this).attr('orderField') + ' desc');
                        else
                            search();

                        elem.css({
                            'transform': 'rotate(180deg)',
                            '-webkit-transform': 'rotate(180deg)',
                            '-moz-transform': 'rotate(180deg)',
                            '-ms-transform': 'rotate(180deg)',
                            '-o-transform': 'rotate(180deg)',
                            'line-height': '1.7'
                        })
                    }
                })
            }
        })
        $(window).on('click', function () {
            hideRowAction();
        })
        $('.action-item').on('click', function () {
            var id = $(this).closest('ul').parent().attr('data-id');
            switch ($(this).attr('id')) {
                case 'edit' :
                    hideRowAction()
                    showRow(id)
                    break;
                case 'remove' :
                    hideRowAction();
                    var temp = '<br><br>';
                    $('td#' + id).siblings().not('td#entityId-' + id).each(function (index, item) {
                        temp += (
                            '<span>' + entityDetail[index] + ': </span><span style="color: darkgrey">' + $(this).find('span:first-child').html() + '</span><br>'
                        );
                    })
                    dialog('Confirm', 'Are you sure for delete ' + temp, function () {
                        frames["editFrame"].deleteRow(id);
                    }, function () {

                    })
                    break;
            }

        })
        $('.win-content-body').on('scroll', function () {
            if ($('.win-content-header').hasClass('compact')) {
                $('#collapse-btn').addClass('rotateX');
                $('.win-content-header').css({'height': '20px', 'background-color': '#193175'});
                $('.action-container').css({'display': 'none'});
                $('.search-container').css({'display': 'none'});
                $('.collapse-title').css({'display': 'inline-block'});
                handleUISize();
            }
        })

        /* === Action Btn(s) Listener === */
        $('.action-btn').on('click', function (e) {
            // Disable Closing Detail Frame
            if (parent.location.toString().indexOf('masterdetail.html') > 0) {
                var masterFrame = parent.document.getElementById('master-frame');
                var detailFrame = parent.document.getElementById('detail-frame');
                var masterClassList = masterFrame.classList;
                var detailClassList = detailFrame.classList;
                if (detailClassList.contains('maximize')) {
                    e.stopPropagation()
                }
                // If Clicked btn owner is master, we must hide detail
                if ($(window.frameElement, window.parent.document).attr('id') == 'master-frame' &&
                    (masterClassList.contains('maximize') || masterClassList.contains('minimize'))) {
                    detailFrame.removeAttribute('class');
                    masterFrame.removeAttribute('class');
                }
            }
            hideRowAction()

            var id = $(this).closest('ul').parent().attr('data-id');
            switch ($(this).attr('id')) {
                case 'new-entity' :
                    showLoading();
                    hideLoading();
                    setTimeout(function () {
                        showEdit();
                    }, 300);
                    $('#action-row').css({'display': 'none'});
                    break;
                case 'delete-entity' :
                    var temp = '<br>';
                    $('td#' + id).siblings().not('td#entityId-' + id).each(function (index, item) {
                        temp += (
                            '<span>' + entityDetail[index] + ': ' + $(this).find('span:first-child').html() + '</span>' + ' | '
                        );
                    })
                    dialog('Confirm', 'Do you sure for delete ' + temp, function () {
                        frames["editFrame"].deleteRow(id);
                    }, function () {
                    })
                    break;
                case 'advance-search':
                    var currentFrame = $('iframe[name=' + window.name +']', parent.document);
                    var initialWinWidth = 0;
                    var isCompacted = false;
                    if(parent.location.toString().indexOf('desktop.html') > -1) { // Common Window
                        initialWinWidth = currentFrame.closest('div[id*=win]').attr('firstwidth');
                    } else if (parent.location.toString().indexOf('masterdetail.html') > -1) { // Master Detail Window
                        initialWinWidth = currentFrame.get(0).contentWindow.$('iframe', parent.parent.document).closest('div[id*=win]').attr('firstwidth');
                    }
                    var header = $('.win-content-header');
                    //$('.win-content-header').addClass('compact').toggleClass('full-search');
                    $('.win-content-header').toggleClass('full-search compact');

                    break
            }
        });


    } else {
        if (iosVersion) {
            $('body').addClass('ios')
        }
        $('.fab').on('click', function () {
            $('.fab-child-container').toggleClass('show')
        })
        $('#refresh-grid-fab').on('click', function () {
            top.refreshWin('handheld-device-win', true);
        });
        $('#new-entity-fab').on('click', function () {
            $('.fab-child-container').toggleClass('show');
            showLoading();
            setTimeout(function () {
                hideLoading();
                showEdit();
            }, 300);
        })
        $('.sort-column').on('click', function () {
            $('.sort-list').toggleClass('show')
        });
        $('.sort-list > li').on('click', function () {
            $(this).addClass('active').siblings().each(function (item) {
                $(this).removeClass('active')
            })
            $('.sort-column').html($(this).html());
            $('.sort-list').toggleClass('show')
        })
        $('.sort-container .ion-arrow-down-c').on('click', function () {
            if (!$(this).hasClass('active')) {
                $(this).addClass('active');
                $(this).next('.ion-arrow-up-c').removeClass('active')
            }
        })
        $('.sort-container .ion-arrow-up-c').on('click', function () {
            if (!$(this).hasClass('active')) {
                $(this).addClass('active');
                $(this).prev('.ion-arrow-down-c').removeClass('active')
            }
        })
        $('.window-title > span:first-child').html(top.document.querySelector('[name="handheld-device-win"]').getAttribute('data-title'))
        $('.win-content-body').on('scroll', function () {
            if (isScrolledIntoView('.pagination-container')) {
                $('.fab').addClass('hide');
                $('.fab-child-container').addClass('hide')
            } else {
                $('.fab').removeClass('hide')
                $('.fab-child-container').removeClass('hide')
            }
        })
    }
}
function fillGrid(result) {
    $('#page-number').val(pageNo);
    $('#item-per-page').val(pageSize);
    if (result.length > 0) {
        if (isPC)
            fillTable(result)
        else
            fillCard(result)
    } else {
        console.log("Not Exist ...")
    }
}
function showRow_(id) {
    try {
        showLoading();
        $.ajax({
            url: servicePath + "/service/location/load",
            type: "POST",
            data: '{"params": [{"key": "rowId","value": "' + id + '","condition": "EQUAL"}], "ticket":"' + user.ticket + '"}',
            contentType: "application/json",
            cache: false,
            dataType: "json",
        }).done(function (result) {
            if (result.done) {
                if (!result.result) {
                    hideLoading();
                    setTimeout(function () {
                    	dialog('Confirm', 'Do you sure for delete ' + temp, function () { })}, 300);
                } else {
                    hideLoading();
                    setTimeout(function () {
                        showEdit(result.result[0]);
                    }, 300);
                }
            } else {
                errorHandle(result);
            }
        }).fail(function (jqXHR, textStatus) {
            //alert("خطا: " + textStatus + ' ' + jqXHR.status);
            hideLoading();
            setTimeout(function () {
                showError("Error: " + textStatus + ' ' + jqXHR.status);
            }, 300);
        }).always(function () {
            // alert( "complete" );
        });
    } catch (e) {
        hideLoading();
        setTimeout(function () {
            showError(e);
        }, 300);
        //alert(e);
    }
}
function fillEdit(location) {
    window.frames['editFrame'].fillEdit(location);
}
function showLoading() {
    if ($('.win-content-body').hasClass('animated')) {
        hideGrid();
        setTimeout(function () {
            $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
        }, 300)
        return;
    }
    if ($('.edit-container').hasClass('animated')) {
        hideEdit();
        setTimeout(function () {
            $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
        }, 300)
        return;
    }
    if ($('.error-container').hasClass('animated')) {
        hideError();
        setTimeout(function () {
            $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
        }, 300)
        return;
    }
    $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
}
function hideLoading() {
    $('.loading-container').addClass('animated fadeOut');
    setTimeout(function () {
        $('.loading-container').removeClass('animated fadeOut fadeIn').css({'display': 'none'});
    }, 300)
}
function showGrid() {
    $('.win-content-body').addClass('animated fadeIn').css({'display': 'block'});
}
function hideGrid() {
    $('.win-content-body').addClass('animated fadeOut');
    setTimeout(function () {
        $('.win-content-body').removeClass('animated fadeOut fadeIn').css({'display': 'none'});
    }, 300)
}
function showEdit(result) {
    $('.edit-container').addClass('animated fadeIn').css({'display': 'block'})
    if (result != undefined)
        fillEdit(result);
    else
        document.getElementsByClassName('edit-frame')[0].contentWindow.clearForm();
}
function hideEdit() {
    $('.edit-container').addClass('animated fadeOut');
    setTimeout(function () {
        $('.edit-container').removeClass('animated fadeOut fadeIn').css({'display': 'none'});
    }, 300)
}
function showError(content) {
    $('.error-container #error-content').html(content);
    $('.error-container').addClass('animated fadeIn').css({'display': 'block'})
    switch (pageState) {
        case PageState.NEXT:
            pageNo--;
            $("#page-number").val(pageNo);
            pageState = PageState.READY;
            break;
        case PageState.REFRESH:
            break;
        default:
            pageState = PageState.READY;
    }
}
function hideError() {
    $('.error-container').addClass('animated fadeOut');
    setTimeout(function () {
        $('.error-container').removeClass('animated fadeOut fadeIn').css({'display': 'none'});
    }, 300);
    if ($('.win-content-body table tbody tr').length > 1) {
        showGrid();
    }
}
function nextPage() {
    pageNo++;
    $("#page-number").val(pageNo);
    $("#item-per-page").val(pageSize);
    pageState = PageState.NEXT;
    search();
    $('.pagination-arrow:first-child').removeClass('disable');
}
function prevPage() {
    if (pageNo == 1)
        return;
    pageNo--;
    if (pageNo == 1)
        $('.pagination-arrow:first-child').addClass('disable');
    $("#page-number").val(pageNo);
    $("#item-per-page").val(pageSize);
    pageState = PageState.PREV;
    search();
}
function refreshGrid() {
    pageSize = $('#item-per-page').val();
    pageNo = $('#page-number').val();
    pageState = PageState.REFRESH;
    search();
}
function handleUISize() {
    var headerHeight = $('.win-content-header').height();
    var bodyHeight = 'calc(100% - ' + (headerHeight + 30) + 'px)';
    var editHeight = 'calc(100% - ' + (headerHeight + 10) + 'px)';
    $('.win-content-body').css({'height': bodyHeight})
    $('.edit-container').css({'height': editHeight})
}
function hideRowAction() {
    $('#item-action-container').removeClass('show');
}
function showRowAction(elem) {
    elem = $(elem);
    var id = elem.closest('td').attr('id').split('-')[1];
    try {
        customizeRowAction(elem.closest('td').parent());
    } finally {
        if (elem.hasClass('animate')) {
            elem.removeClass('animate');
        }
        var leftOffset = elem.offset().left;
        var topOffset = elem.offset().top;
        $('#item-action-container').removeClass('show').css({
            'left': (leftOffset - 130) + 'px',
            'top': topOffset + 'px'
        }).removeAttr('data-id');
        setTimeout(function () {
            $('#item-action-container').addClass('show').attr('data-id', id)
            elem.addClass('animate');
        }, 100)
    }
}
function showAction(elem, id) {
    elem = $(elem);
    if (elem.hasClass('animate')) {
        elem.removeClass('animate');
    }
    var leftOffset = elem.offset().left;
    var topOffset = elem.offset().top;
    $('#item-action-container').removeClass('show').css({
        'left': (leftOffset - 80) + 'px',
        'top': topOffset + 'px'
    }).removeAttr('data-id');
    setTimeout(function () {
        $('#item-action-container').addClass('show').attr('data-id', id)
        elem.addClass('animate');
    }, 100)

}
// Edit
function setEditListeners() {
    if (!isPC) {
        $('.scroll').on('scroll', function () {
            if (isScrolledIntoView('.btn-container')) {

            } else {

            }
        })
        if (iosVersion) {
            $('body').addClass('ios')
        }
    }
    $('.autocomplete-icon').on('click', function () {
        onAutocompleteBtn($(this));
    })
    $('#return-btn').on('click', function () {
        if (parent.parent.location.toString().indexOf('masterdetail.html') > 0) {
            parent.parent.document.getElementById('detail-frame').classList.remove('minimize')
            parent.parent.document.getElementById('master-frame').classList.remove('maximize')
        }
        backToGrid()
    })
    /*$('#save-btn').on('click', function () {
     checkMandatories('edit-form')
     })*/
    $('#refresh-btn').on('click', function () {
        if ($('#rowId').val() !='' && showRow) {
            showRow($('#rowId').val());
        }
        clearForm();
        if (entity != undefined) {
            fillEdit(entity)
        }
    })
}
function backToGrid() {
    entity = undefined;
    parent.hideEdit();
    parent.search();
}
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    /* if(CKEDITOR) {
     for(var editor in CKEDITOR.instances) {
     CKEDITOR.instances[editor].setData('');
     }
     }*/
}
function saveRow(formID, handler, url) {
    checkMandatories(formID)
    checkSize(formID);
    var formData = {};

    function SaveEntity(id, value, entityID) {
        if (entityID !== undefined) {
            formData[id] = {};
            formData[id]['rowId'] = entityID;
        } else {
            formData[id] = value;
        }
    }

    $('#' + formID).find('.input-container').not('.ignored').each(function (index, item) {
        if (item.firstElementChild) {
            item = item.firstElementChild;
            var value = item.value;
            var id = item.id;
            if (item.classList.contains('autocomplete') || item.classList.contains('file')) {
                if (item.getAttribute('entityId') && item.getAttribute('entityId').trim().length >= 5)
                    new SaveEntity(id, value, item.getAttribute('entityId'));
            } else {
                if (item.type == 'checkbox')
                    new SaveEntity(id, item.checked);
                else if (item.nodeName == 'TEXTAREA') {
                    if (item.style.visibility == 'hidden') { // CKEditor
                        if (CKEDITOR) {
                            for (var editor in CKEDITOR.instances) {
                                new SaveEntity(editor, CKEDITOR.instances['' + editor].getData())
                            }
                        }
                    } else {
                        value = value.replaceAll('\n', '|.|');
                        new SaveEntity(id, value);
                    }
                } else {
                    new SaveEntity(id, value);
                }
            }
        }
    })

    formData.ticket = user.ticket;
    ServiceInvoker.call(JSON.stringify(formData), handler, url);
}
/* ================================================ Tab(s) ========================================================== */
/**
 * @param paramsObj => {Window: window, String: src, String: title, Array: filter}
 */
function addTab(paramsObj) {
    var parentID = getWinId(paramsObj.window);
    var parent = top.$('#' + parentID);
    var tabList = parent.find('.tab');
    tabList.css({"justify-content":"flex-start"});
    
    if(tabList.children().length <= 7) {
        var title = paramsObj.title;
        var src = paramsObj.src;
        var id = new Date().getTime();
        top.tabFilter[id] = paramsObj.filter;
        tabList = parent.find('.tab');
        var tabItem = document.createElement('div');
        tabItem.setAttribute('class', 'tablinks');
        tabItem.innerHTML = '<span class="tab-title">' +  title + '</span>';
        var closeIcon = document.createElement('span');
        closeIcon.setAttribute('class', 'ion-close-round close-tab');
        $(closeIcon).on('click', function (e) {
            e.stopPropagation();
            var param = { id: id, parentID: parentID };
            closeTab(param);
        })
        tabItem.appendChild(closeIcon);
        tabItem.setAttribute('id', id);
        $(tabItem).on('click', function () {
            openTab(id, src, parentID);
        })
        tabList.append(tabItem);
        $(tabItem).trigger('click');
    } else {
        dialog('Warning', 'Close some tabs then try again')
    }
}
function openTab(id, src, parentID) {
    var parent = top.$('#' + parentID);
    // Hide All Iframse(s)
    var tabContentContainer = parent.find('#tab-content');
    tabContentContainer.find('iframe').css({'display' : 'none'})
    // Remove Active Class
    var tabList =  parent.find('.tab');
    tabList.find('.tablinks').removeClass('active').removeAttr('style');

    tabList.find('#' + id).addClass('active');

    // width: 900px Baraye Nameyesh-e Sahih Dar Resize
    if(tabList.find('#' + id).parent().width() < 585) {
        tabList.find('#' + id).css({'width' : '900px'});
    }

    if(id == 'default') {
        tabContentContainer.find('iframe').first().css({'display' : 'block'})
    } else {
        var targetIframe = tabContentContainer.find('iframe[data-id=' + id + ']');
        if(targetIframe.length == 0) {
            var iframe = document.createElement('iframe');
            iframe.src = progPath + src + '?tabID=' + id;
            iframe.setAttribute('class', 'tabcontent');
            iframe.setAttribute('name', 'frame' + id);
            iframe.setAttribute('data-parent-id', parentID);
            iframe.setAttribute('data-id', id);
            iframe.setAttribute('style', 'display: block');
            tabContentContainer.append(iframe);
        } else {
            targetIframe.css({'display' : 'block'})
        }
    }
}
/**
 * @param paramsObj : { id , parentID }
 */
function closeTab(paramsObject) {
    var id = paramsObject.id;
    var parentID = paramsObject.parentID;
    var tabItem = top.$('#' + parentID).find('div.tablinks#' + id);
    var tabList = tabItem.parent();
    // Active Previous Sibling
    if(tabItem.hasClass('active')) {
        tabItem.prev().addClass('active');
        tabItem.prev().trigger('click');
    }
    // Remove Tab Item
    tabItem.remove();
    // Remove IFrame Item
    var iframe = top.$('#' + parentID).find('iframe[data-id=' + id + ']').get(0);
    iframe.parentNode.removeChild(iframe);
    
    if(tabList.children().length == 1)
    	tabList.css({"justify-content":"center"});

}
function closeCurrentTab() {
    var iFrame;
    if(window.name != 'editFrame') {
        iFrame = top.document.querySelector('iframe[name="' + window.name + '"]');
    } else {
        iFrame = top.document.querySelector('iframe[name="' + parent.window.name + '"]');
    }
    var parentID = iFrame.getAttribute('data-parent-id');
    var id = iFrame.getAttribute('data-id');
    if(id != 'default') { // If tab isn't original one
        var param = {id: id, parentID: parentID};
        closeTab(param);
    }
}
/* ================================================ Close Current Window ============================================ */
function closeCurrentWin() {
    var windowID = getWinId(window)
    windowID = windowID.removeItem('win');
    top.closeWin(windowID);
}
/**
 * Call this inside index or edit
 * @param window
 */
function getWinId(window) {
    var iFrame;
    if(window.name != 'editFrame') {
        iFrame = top.document.querySelector('iframe[name="' + window.name + '"]');
    } else {
        iFrame = top.document.querySelector('iframe[name="' + parent.window.name + '"]');
    }
    // parentElement(0) -> div.tab-content
    // parentElement(1) -> div.win-body
    // parentElement(2) -> window
    var windowID = iFrame.parentElement.parentElement.parentElement.id;
    return windowID;
}

function firstCapital(str){
	if(str == null)
		return null;
	if(str.length == 0)
		return '';
	return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
}
var searchResultEntities;
function getSearchResultValue(entityId, fieldName){
	for(var i=0; i < searchResultEntities.length; i++){
		if(searchResultEntities[i].rowId == entityId){
			return searchResultEntities[i][fieldName];
		}
	}
}