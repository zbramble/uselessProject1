/*------------------------------------------------------------------------------ Condition ---------------------------*/
/**
 * Enum for Condition values.
 * @readonly
 * @enum {String}>
 */
Condition = {
    /** * =  */
    EQUAL: "EQUAL",
    /** * &lt;&gt  */
    NOT_EQUAL: "NOT_EQUAL",
    /** * &gt  */
    GREATER: "GREATER",
    /** * &lt;  */
    LESS: "LESS",
    /** * &gt=  */
    GREATER_OR_EQUAL: "GREATER_OR_EQUAL",
    /** * &lt;=  */
    LESS_OR_EQUAL: "LESS_OR_EQUAL",
    /** * like  */
    CONTAINS: "CONTAINS",
    /** * %like  */
    START_WITH: "START_WITH",
    /** * like%  */
    END_WITH: "END_WITH",
    /** * IN  */
    IN: "IN",
    /** * NOT IN  */
    NOT_IN: "NOT_IN",
    /** * BETWEEN  */
    BETWEEN: "BETWEEN",
    /** * NAN  */
    NAN: "NAN",
    /** this is not condition user for order by */
    ORDER:"ORDER",
    /* this will use as advanced search key & condition */
    WHERE:"WHERE"

}
/*------------------------------------------------------------------------------ Autocomplete Type -------------------*/
/**
 * Enum for Autocomplete Type values.
 * @readonly
 * @enum {String}
 */
AutocompleteType = {
    STATIC: 'STATIC',
    DYNAMIC: 'DYNAMIC',
};
/*------------------------------------------------------------------------------ Key Codes ----------------------------*/
/**
 * Enum for Key Codes values.
 * @readonly
 * @enum {String}
 */
KeyCodes = {
    BackSpace: 8,
    Tab: 9,
    Enter: 13,
    Shift: 16,
    Ctrl: 17,
    Alt: 18,
    PauseBreak: 19,
    CapsLock: 20,
    Esc: 27,
    PageUp: 33,
    PageDown: 34,
    End: 35,
    Home: 36,
    ArrowLeft: 37,
    ArrowUp: 38,
    ArrowRight: 39,
    ArrowDown: 40,
    Insert: 45,
    Delete: 46,
    Digit0: 48,
    Digit1: 49,
    Digit2: 50,
    Digit3: 51,
    Digit4: 52,
    Digit5: 53,
    Digit6: 54,
    Digit7: 55,
    Digit8: 56,
    Digit9: 57,
    A: 65,
    B: 66,
    C: 67,
    D: 68,
    E: 69,
    F: 70,
    G: 71,
    H: 72,
    I: 73,
    J: 74,
    K: 75,
    L: 76,
    M: 77,
    N: 78,
    O: 79,
    P: 80,
    Q: 81,
    R: 82,
    S: 83,
    T: 84,
    U: 85,
    V: 86,
    W: 87,
    X: 88,
    Y: 89,
    Z: 90,
    WindowLeft: 91,
    WindowRight: 92,
    SelectKey: 93,
    Numpad0: 96,
    Numpad1: 97,
    Numpad2: 98,
    Numpad3: 99,
    Numpad4: 100,
    Numpad5: 101,
    Numpad6: 102,
    Numpad7: 103,
    Numpad8: 104,
    Numpad9: 105,
    Multiply: 106,
    Add: 107,
    Subtract: 109,
    DecimalPoint: 110,
    Divide: 111,
    F1: 112,
    F2: 113,
    F3: 114,
    F4: 115,
    F5: 116,
    F6: 117,
    F7: 118,
    F8: 119,
    F9: 120,
    F10: 121,
    F11: 122,
    F12: 123,
    NumLock: 144,
    ScrollLock: 145,
    SemiColon: 186,
    Equal: 187,
    Comma: 188,
    Dash: 189,
    Period: 190,
    ForwardSlash: 191,
    GraveAccent: 192,
    BracketOpen: 219,
    BackSlash: 220,
    BracketClose: 221,
    SingleQuote: 222
};

/*------------------------------------------------------------------------------ Page State --------------------------*/
PageState = {
    READY: 'ready',
    REFRESH: 'refresh',
    NEXT: 'next',
    PREV: 'prev'
}

/*-------------------------------------------------------------------  Response Code ---------------------------------*/
ResponseCode = {
    200: "Successful",
    201: "Created",
    202: "Accepted",
    204: "No Content",
    205: "Reset Content",
    206: "Partial Content",
    301: "Moved Permanently",
    302: "Found",
    303: "See Other",
    304: "Not Modified",
    305: "Use Proxy",
    307: "Temporary Redirect",
    400: "Sent data is wrong",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "The requested page could not be found",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Request Entity Too Large",
    414: "Request-URI Too Long",
    415: "Unsupported Media Type",
    416: "Requested Range Not Satisfiable",
    417: "Expectation Failed",
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported"
}

/*--------------------------------------------------------------------------- Property Type --------------------------*/
SearchPropertyType = {
    TEXT: 'TEXT' ,
    NUMBER: 'NUMBER',
    AUTOCOMPLETE: 'AUTOCOMPLETE',
    DATE: 'DATE'
}
SearchPropertyCondition = {
    TEXT:   '<option selected disabled>Select one</option>' +
            '<option value=' + Condition.EQUAL + '>Equal</option>' +
            '<option value=' + Condition.NOT_EQUAL + '>Not equal</option>' +
            '<option value=' + Condition.CONTAINS + '>Contains</option>' +
            '<option value=' + Condition.START_WITH + '>Starts with</option>' +
            '<option value=' + Condition.END_WITH + '>Ends with</option>' ,

    NUMBER: '<option selected disabled>Select one</option>' +
            '<option value=' + Condition.EQUAL + '>Equal</option>' +
            '<option value=' + Condition.NOT_EQUAL + '>Not equal</option>' +
            '<option value=' + Condition.CONTAINS + '>Contains</option>' +
            '<option value=' + Condition.LESS + '>Less than</option>' +
            '<option value=' + Condition.LESS_OR_EQUAL + '>Less or equal</option>' +
            '<option value=' + Condition.GREATER_OR_EQUAL + '>Greater</option>' +
            '<option value=' + Condition.GREATER_OR_EQUAL + '>Greater or equal </option>' ,

   AUTOCOMPLETE: '<option selected disabled>Select one</option>' +
            '<option value=' + Condition.EQUAL + '>Equal</option>' +
            '<option value=' + Condition.NOT_EQUAL + '>Not Equal</option>',

    DATE: '<option selected disabled>Select one</option>' +
           '<option value=' + Condition.EQUAL + '>Equal</option>' +
           '<option value=' + Condition.NOT_EQUAL + '>Not equal</option>' +
	       '<option value=' + Condition.BETWEEN + '>Between</option>'
            
}

/*------------------------------------------------------------------------------ End ---------------------------------*/