/* ======================================= Tab Filter(s) =============================================================*/
var tabFilter = {};

var menuData = JSON.parse(user.menuData);
var menuTreeJson = JSON.parse(user.menuTree);

/* === Variables === */
var winCount = 0;
var zIndex = 1;
var topWin;
var winWidth;
var winHeight;

var startX = 0;
var endX = 0;
var menuStatus = 1; // 1: Open | 0: Close
var pinMode = 1; // 1: Pinned | 0: Unpinned


function init() {
	initializeJSTree();
    $("#user-detail-fullname").html(user.fullName);
    $("#user-detail-modal-fullname").html(user.fullName);
    $("#user-detail-modal-role").html(user.roleName + ' <br> ' + user.orgName);
    $('#loading').fadeOut('slow');
    $('#loading').remove();

}
function initializeJSTree() {
    if (iosVersion) {
        $('body').addClass('ios');
    }
    $.jstree.defaults.core.dblclick_toggle = false;
    $('#jsTree').jstree({
        'core': {
            "themes": {
                "dots": false // no connecting dots between dots
            },
            /*'data' : {
             "url" :  progPath + '/MenuTreeJson',
             "dataType" : "json" // needed only if you do not supply JSON headers
             }*/
            data: menuTreeJson
        }
    });
    $('#jsTree').on('click', '.jstree-anchor', function () {
        menuClickEvent($(this));
    })


}
function menuClickEvent(anchorObject) {
    $(anchorObject).addClass('waves-effect');
    var LIElement = anchorObject.parent();
    if (LIElement.hasClass('jstree-leaf')) { // Agar Item-e Click Shod-e Child Nadashte Bashad
        var dataName = LIElement.attr('data-name');
        var menuObject = menuData[dataName];
        // Mobile Checking ...
        if (!isPC) {
            closeMenu();
            setTimeout(function () {
                showWin(menuObject);
            }, 260)
            return
        } else {
            if (LIElement.find('span').length == 0) {
                LIElement.append('<span class="menu-badges"></span>');
                LIElement.append('<span class="ion-plus-round menu-new-win"></span>');
                /*LIElement.find('span.menu-badges').on('click', function () {
                 reShowWin(dataName)
                 })*/
                LIElement.find('span.menu-new-win').on('click', function () {
                    showWin(menuObject);
                })
            }
            if (menuObject.COUNT > 0) {
                reShowWin(dataName);
                focusWins(dataName);
            }
            else {
                showWin(menuObject);
            }
            return;
        }
    } else { // Agar Item-e Click Shod-e Child Dashte Bashad
        $('#jsTree').jstree(true).toggle_node(anchorObject);
        LIElement.find('li').each(function () {
            if (this.classList.contains('jstree-leaf')) {
                dataName = this.getAttribute('data-name');
                menuObject = menuData[dataName];
                if(menuObject && menuObject.COUNT > 0) {
                    if ($(this).find('span').length == 0) {
                        $(this).append('<span class="menu-badges">' + menuObject.COUNT + '</span>');
                        /*$(this).find('span.menu-badges').on('click', function () {
                         reShowWin($(this).parent().attr('data-name'))
                         });*/
                        $(this).append('<span class="ion-plus-round menu-new-win"></span>');
                        $(this).find('span.menu-new-win').on('click', function () {
                            showWin(menuObject);
                        })
                    }
                    $(this).find('span.menu-badges').css({'display': 'block'});
                }
            }
        })
    }
}
/**
 * Hengami Ke Rooye Window Focus Mishav, Menu-e Mortabet Ba An Baz Mishavad
 * @param dataName = Atrribute data-name Ke Moshakhas Konandey-e <li data-name> Dar Menu Mibashad
 */
function openMenuItem(dataName) {
    var id;
    var instance = $("#jsTree").jstree(true);
    var m = instance._model.data;
    for (var key in m) {
        // skip loop if the property is from prototype
        if (!m.hasOwnProperty(key)) continue;
        var obj = m[key];
        if (obj.id != "#") {
            if (obj.li_attr['data-name'] == dataName)
                id = obj.id;
        }
    }
    var node = $('#jsTree').jstree().get_node(id);
    node.parents.forEach(function (item, index) {
        var pNode = $('#jsTree').jstree().get_node(item);
        if (item != '#' && $('#' + pNode.id).hasClass('jstree-closed')) {
            $('#' + pNode.id).find(' > a.jstree-anchor').trigger('click');
        } else {
            $('#jsTree').jstree('open_node', pNode);
        }
    })
    var selectedNode = $('#jsTree').jstree('get_selected');
    $('#jsTree').jstree('deselect_node', selectedNode);
    $('#jsTree').jstree('select_node', node);
}
function showWinByName(menuName) {
    showWin(menuData[menuName]);
}
function showWinPopup(menuName, url, title) {
    var currentWin = $.extend(true, {}, menuData[menuName]);
    currentWin.PATH = url;
    if (title) {
        currentWin.FA = title;
    }
    showWin(currentWin);
}
function showWin(menuObject) {
    if(isPC) {
        winWidth = menuObject.WIDTH && menuObject.WIDTH != '-1' ? menuObject.WIDTH : '100%';
        winHeight = menuObject.HEIGHT && menuObject.HEIGHT != '-1' ? menuObject.HEIGHT : '100%';
        if (!menuObject.CREATE_NEW) {
            if ($("div[data-name='" + menuObject.EN + "']").length > 0) {
                var id = $("div[data-name='" + menuObject.EN + "']").attr('id');
                maxWin(id.substring(3));
                reShowWin(menuObject.EN)
                return;
            }
        } else {
            if (menuObject.COUNT >= 10) {
                dialog('Warning','Max number of open windows is 10');
                return;
            }
        }
        setMenuBadges(menuObject);
        
        var html =
            '<div id="win' + ++winCount + '" data-name="' + menuObject.EN + '" class="ui-widget-content win animated zoomInUp " onmousedown="focusWin(id)" onkeydown="focusWin(id)">'
            + '<!-- Header Bar Start -->'
                + '<div class="win-header" ondblclick="maximizeWin(' + winCount + ')">'
                    + '<div class="win-title">'
                        /*+ '<span>' + menuObject.FA + '</span>'
                        + '<div class="win-sub-title">'
                            + '<span class="ion-ios-arrow-forward"></span>'
                            + '<span style=" margin: 0 3px">شماره ' + menuObject.COUNT + '</span>'
                            + '<span class="ion-ios-arrow-back"></span>'
                        + '</div>'*/
                        + '<!-- Tab Bar Start -->'
                        + '<div class="tab">'
                            + '<div class="tablinks active" id="default" onclick="openTab(' + '\'default\'' + ',\'' + progPath + '/' + menuObject.PATH + '\', \'win' + winCount + '\')">'
                                + '<span class="tab-title">' +  menuObject.FA + '</span>'
                                /*+ '<span class="ion-close-round close-tab"></span>'*/
                            + '</div>'
                        + '</div>'
                        + '<!-- Tab Bar End -->'
                    + '</div>'
            + '<div class="win-action-container">'
            + '<div class="win-header-action-btn" onclick="refreshWin(' + menuObject.EN + winCount + ', false)" ondblclick="event.stopPropagation();" title="Refresh">'
            + '<span class="ion-android-refresh"></span>'
            + '</div>'
            + '<div class="win-header-action-btn" onclick="minWin(' + winCount + ')" title="Minimize">'
            + '<span class="ion-minus-round"></span>'
            + '</div>'
            + '<div class="win-header-action-btn" onclick="maximizeWin(' + winCount + ')" title="Maximize">'
            + '<span class="ion-android-checkbox-outline-blank maximize-icon"></span>'
            + '</div>'
            + '<div class="win-header-action-btn" onclick="closeWin(' + winCount + ')" title="Close">'
           + '<span class="ion-close-round"></span>'
            + '</div>'
            + '</div>'
            + '</div>'
            + '<!-- Header Bar End -->'
            + '<!-- Content Body Start -->'
            + '<div class="win-body">'
            + '<!-- Tab(s) Content -->'
                + '<div id="tab-content">'
                + '<iframe name="' + menuObject.EN + winCount + '" data-parent-id="win' + winCount + '" data-id="default" id="frame' + winCount + '" src="' + progPath + '/' + menuObject.PATH + '"></iframe>'
                + '</div>'
                + '</div>'
            + '</div>';

        $('#main-container').append(html);
        $("#win" + winCount).draggable({
            containment: '#main-container'
        });
        $("#win" + winCount).resizable({
            animate: false,
            helper: "ui-resizable-helper",
            minWidth: 700,
            minHeight: 300,
            start: function (event, ui) {
                // Change Full Screen Icon and state
                var elem = $(this);
                if (elem.attr('maximized')) {
                    elem.removeAttr('maximized');
                }

                // Hide Action Menu
                elem.find('.win-body iframe:first-child').contents().find('#item-action-container').removeClass('show');
            },
            stop: function (event, ui) {
                // Change Full Screen Icon and state
                var elem = $(this);

                // Koochak & Bozorg Kardan-e Tab
                if(elem.width() > 700) {
                    Log(elem.find('.tab'))
                }

                elem.find('.win-header-action-btn > span').each(function (index, item) {
                    if (item.classList.contains('ion-ios-browsers-outline'))
                        item.classList.remove('ion-ios-browsers-outline');
                    item.classList.add('ion-android-checkbox-outline-blank');
                })

                // Change style of window header (Simple Search)
                var frameContent = elem.find('iframe').contents();
                var firstSearchBox, winContentHeader, winContentBody, winEditContainer;
                if (frameContent.find('.win-content-header').length > 0 || frameContent.find('#master-frame').contents().find('.win-content-header').length > 0) {
                    if (frameContent.find('.simple-search').first().length != 0) {
                        firstSearchBox = frameContent.find('.simple-search').first();
                        winContentHeader = frameContent.find('.win-content-header');
                        winContentBody = frameContent.find('.win-content-body');
                        winEditContainer = frameContent.find('.edit-container');
                    } else { // Master Detail
                        firstSearchBox = frameContent.find('#master-frame').contents().find('.simple-search').first();
                        winContentHeader = frameContent.find('#master-frame').contents().find('.win-content-header');
                        winContentBody = frameContent.find('#master-frame').contents().find('.win-content-body');
                        winEditContainer = frameContent.find('#master-frame').contents().find('.edit-container');
                    }

                    if (winContentHeader.hasClass('compact')) {
                        if (elem.width() >= new Number(winWidth.split('px')[0]))
                            winContentHeader.removeClass('compact');
                    } else {
                        if (!isVisibleOnScreen(elem, firstSearchBox)) {
                            winContentHeader.addClass('compact');
                        }
                    }
                    // Change Body Height
                    var headerHeight = winContentHeader.height();
                    var bodyHeight = 'calc(100% - ' + (headerHeight + 30) + 'px)';
                    var editHeight = 'calc(100% - ' + (headerHeight + 10) + 'px)';
                    winContentBody.css({'height': bodyHeight})
                    winEditContainer.css({'height': editHeight})
                }


            }
        });
        zIndex = zIndex > 13 ? 1 : zIndex + 1;
        var top = 0;
        var left = 0;
        if (menuObject.WIDTH && menuObject.WIDTH != '-1') {
            top = ($('#main-container').height() - winHeight) / 2;
            left = ($('#main-container').width() - winWidth) / 2 + zIndex * 16;
            top = top > 100 ? 100 : top;
            top += zIndex * 10;
            $("#win" + winCount).attr("firstHeight", winHeight);
            $("#win" + winCount).attr("firstWidth", winWidth);
            winHeight = winHeight + "px";
            winWidth = winWidth + "px";
        } else {
            winHeight = "100%";
            winWidth = "100%";
            $("#win" + winCount).attr("firstHeight", "500");
            $("#win" + winCount).attr("firstWidth", "700");
            $("#win" + winCount).attr("maximized", "true")
        }
        $("#win" + topWin).css({"z-index": 1});
        topWin = 'win' + winCount;
        $("#win" + winCount).css({
            "height": winHeight,
            "width": winWidth,
            "z-index": 2,
            "position": "absolute",
            "top": top,
            "left": left
        });
        $("#win" + winCount).show("fast");
        if (!menuObject.CREATE_NEW) {
            $("#win" + winCount).find('div.win-header').find('div.win-title').css('line-height', '1.9').find('div.win-sub-title').hide('fast');
        }
    } else {
        var frame = document.querySelector('iframe[name="handheld-device-win"]');
        frame.src = progPath + '/' + menuObject.PATH;
        frame.setAttribute('data-title', menuObject.FA);
    }
}
function reShowWin(dataName) {
    [].slice.call(document.querySelectorAll('div[minimized=true][data-name=' + dataName + ']')).forEach(function (item) {
        item.removeAttribute('minimized')
        $('#' + topWin).css({'z-index': 1});
        topWin = item.id;
        item.style.zIndex = 2;
        item.classList.remove('minimizeAnim');
        item.classList.remove('animated');
        item.style.display = 'block';
        item.classList.add('animated');
        item.classList.add('zoomInUp');
    })
}
/**
 * When Click On Menu Items, Window with Same Data-Name will be Focused
 * @param dataName
 */
function focusWins(dataName) {
    [].slice.call(document.querySelectorAll('div[data-name=' + dataName + ']')).forEach(function (item) {
        $('#' + topWin).css({'z-index': 1});
        topWin = item.id;
        item.style.zIndex = 2;
    })
}
function closeWin(winC) {
    removeMenuBadges(winC);
    setTimeout(function () {
        $("#win" + winC).addClass('zoomOut');
        setTimeout(function () {
            $("#win" + winC).remove();
        }, 700);
    }, 5);
}

function maximizeWin(winC) {
    var maximized = $("#win" + winC).attr("maximized");
    if (!maximized || maximized == "false") {
        $("#win" + winC).css({
            "height": "100%",
            "width": "100%",
            "top": "0",
            "left": "0"
        });
        $("#win" + winC).attr("maximized", "true");
    } else {
        winHeight = $("#win" + winCount).attr("firstHeight");
        winWidth = $("#win" + winCount).attr("firstWidth");
        var vCenter = ($(document).height() - winHeight) / 2;
        var hCenter = ($(document).width() - winWidth) / 2;
        var top = Math.random() * vCenter + 50;
        var left =  Math.random() * hCenter  + 50;
        $("#win" + winC).css({
            "height": winHeight,
            "width": winWidth,
            "top": top,
            "left": left
        });
        $("#win" + winC).removeAttr("maximized");
    }
    $("#win" + winC + ' .maximize-icon').toggleClass('ion-android-checkbox-outline-blank').toggleClass('ion-ios-browsers-outline');
}
function focusWin(winId) {
    $("div[id^='win']").css({
        "z-index": 1
    })
    topWin = winId;
    $("#" + winId).css({
        "z-index": 2
    });
    openMenuItem(byId(winId).getAttribute('data-name'));
}
function minWin(winC) {
    $("#win" + winC).removeAttr("maximized").attr("minimized", "true");
    setTimeout(function () {
        $("#win" + winC).removeClass('zoomInUp').addClass('animated minimizeAnim')
        setTimeout(function () {
            $("#win" + winC).hide();
        }, 700);
    }, 5);
}
function maxWin(winC) {
    $("#" + topWin).css({
        "z-index": 1
    });
    $("#win" + winC).css({
        "z-index": 2
    })
    $("#win" + winC).show("slow");
    topWin = 'win' + winC;
}
function refreshWin(frameName, isSmartphone) {
    if (isSmartphone)
        frames['' + frameName].location.reload(true);
    else
        frames['' + frameName.name].location.reload(true);
}
function setMenuBadges(menuObject) {
    menuObject.COUNT++;
    var badgesElem = document.querySelector('li[data-name=' + menuObject.EN + '] > span.menu-badges');
    if (badgesElem) {
        badgesElem.innerHTML = '' + menuObject.COUNT;
        badgesElem.style.display = 'block';
    }
}
function removeMenuBadges(winId) {
    var dataNameValue = $('#win' + winId).attr('data-name');
    var LIElement = document.querySelector('li[data-name=' + dataNameValue + ']');
    var badgesElem = $(LIElement).find('span.menu-badges');
    var addBtnElem = $(LIElement).find('span.menu-new-win');
    menuData[dataNameValue].COUNT--;
    if (badgesElem) { //در صورتی که منو باز باشد عدد را به روز کند
        if (menuData[dataNameValue].COUNT == 0) {
            badgesElem.remove();
            addBtnElem.remove();
        } else {
            badgesElem.html(menuData[dataNameValue].COUNT);
        }
    }
}
function logout() {
    $("#loginMsg").html('Exit ...');
    try {
        lockPage();
        $.ajax({
            url: servicePath + "/service/security/logout",
            type: "POST",
            data: '{"key":"ticket", "value":"' + user.ticket + '"}',
            contentType: "application/json",
            cache: false,
            dataType: "json",
        }).done(function (result) {
            if (result.done) {
                dialog("Message", "Log out done successfully.", showLoginPage);
                removeLocalStorageItem('user');
                user = null;
            } else {
                dialog("Error", result.errorDesc);
            }
        }).fail(function (jqXHR, textStatus) {
        	 dialog("Error", textStatus);
        }).always(function () {
            unlockPage();
        });
    } catch (e) {
        alert(e);
    }
}

/* === Pin Handling === */
$('#pin-menu').on('click', function () {
    var anchorElement = this.firstElementChild;
    if (pinMode == 1) {
        $('#menu-helper').on('mouseover', function () {
            openMenu()
        })
        pinMode = 0;
        anchorElement.style.transform = 'rotate(30deg)';
        anchorElement.style.webkitTransform = 'rotate(30deg)';
        anchorElement.style.color = '#c3c3c3';
        handleMenuOnMouseOutEvent(true);
        if (menuStatus == 1)
            closeMenu();
    } else {
        $('#menu-helper').off('mouseover')
        pinMode = 1;
        anchorElement.style.transform = 'rotate(0deg)';
        anchorElement.style.webkitTransform = 'rotate(0deg)';
        anchorElement.style.color = 'whitesmoke';
        handleMenuOnMouseOutEvent(false);
        if (menuStatus == 0)
            openMenu();
    }
});
function handleMenuOnMouseOutEvent(state) {
    if (state) {
        $('#jsTree').on('mouseleave', function (e) {
            if (menuStatus == 1)
                closeMenu();
        })
    } else {
        $('#jsTree').unbind('mouseleave');
    }
}

$('#menu-icon').on('click', function () {
    if (menuStatus == 1) {
        closeMenu();
    } else {
        openMenu();
    }
})
function openMenu() {
    menuStatus = 1;
    $('#jsTree').css({'left' : '0'})
    if(isPC)
        $('#main-container').css({'width' : 'calc(100vw - 300px)'})
}
function closeMenu() {
    menuStatus = 0;
    $('#jsTree').css({'left' : '-300px'})
    if(isPC)
        $('#main-container').css({'width' : '100vw'});
}
/* === Touch Events === */
var mainContainer = document.getElementById('main-container');
mainContainer.addEventListener('touchstart', function (e) {
    var touchObj = e.changedTouches[0] // reference first touch point (ie: first finger)
    startX = parseInt(touchObj.clientX) // get x position of touch point relative to left edge of browser
    e.preventDefault();
}, true);
mainContainer.addEventListener('touchend', function (e) {
    var touchObj = e.changedTouches[0] // reference first touch point (ie: first finger)
    endX = parseInt(touchObj.clientX) // get x position of touch point relative to left edge of browser
    e.preventDefault();
    if ((endX - startX) > 0) {
        closeMenu();
    } else if ((startX - endX) > 0) {
        openMenu();
    }
}, true);


/*$("#jsTree").on("touchstart", function(e) {
 var touchStart = touchEnd = e.originalEvent.touches[0].pageX;

 var touchExceeded = false;

 $(this).on("touchmove", function(e) {
 touchEnd = e.originalEvent.touches[0].pageX;

 if(touchExceeded || touchStart - touchEnd > 50 || touchEnd - touchStart > 50) {
 e.preventDefault();

 touchExceeded = true;

 // Execute your custom function.
 closeMenu();
 }
 });

 $(this).on("touchend", function(e) {
 $(this).off("touchmove touchend");
 });
 });*/




/*var menuContainer = document.getElementById('jsTree');
 menuContainer.addEventListener('touchstart', function (e) {
 var touchObj = e.changedTouches[0] // reference first touch point (ie: first finger)
 startX = parseInt(touchObj.clientX) // get x position of touch point relative to left edge of browser
 e.preventDefault();
 }, true);
 menuContainer.addEventListener('touchend', function (e) {
 var touchObj = e.changedTouches[0] // reference first touch point (ie: first finger)
 endX = parseInt(touchObj.clientX) // get x position of touch point relative to left edge of browser
 e.preventDefault();
 if( (endX - startX)  > 0) {
 closeMenu();
 } else {
 openMenu();
 }
 }, true);*/



/* =============================================== Shortkey(s) =======================================================*/
Mousetrap.bind('ctrl+m', function () {
    var wins = getOpenWins();
    wins.forEach(function (item) {
        var index = item.id.match(/\d/);
        var id = item.id;
        minWin(id.substr(id.indexOf(index), id.length - 1));
    })
});
Mousetrap.bind('ctrl+x', function () {
    var wins = getOpenWins();
    wins.forEach(function (item) {
        reShowWin(item.getAttribute('data-name'));
    })
});
Mousetrap.bind('ctrl+c', function () {
    var wins = getOpenWins();
    wins.forEach(function (item) {
        var index = item.id.match(/\d/);
        var id = item.id;
        closeWin(id.substr(id.indexOf(index), id.length - 1));
    })
});
function getOpenWins() {
    return [].slice.call(document.querySelectorAll('div[data-name]'));
}
