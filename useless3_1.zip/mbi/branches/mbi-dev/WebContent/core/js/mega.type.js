/*----------------------------------------------------------------------------- Filter Parameter ---------------------*/
/**
 * Object for Filter Parameter.
 */
FilterParameter = (function () {
    var
        /**
         @type {String}
         */
        key = "",
        /**
         @type {ValueObject}
         */
        value = ValueObject,
        /**
         @type {Condition}
         */
        condition = Condition,
        /**
         @type {String}
         */
        type = ""
    return {
        key: key,
        value: value,
        condition: condition,
        type: type
    }
});
/*----------------------------------------------------------------------------- Autocomplete Parameter ---------------*/
/**
 * Object for Autocomplete Parameter.
 */
AutocompleteParameter = {
    /**
     @type {AutocompleteType}
     */
    type: Object,
    /**
     @type {Filter}
     */
    filter: Object,
    /**
     @type {String}
     */
    targetElementId: "",
    /**
     @type {String}
     */
    serviceUrl: "",
    /**
     @type {Object}
     */
    mapPattern: {
        label: "",
        value: "",
        id: ""
    },
    /**
     @type {String}
     */
    storageName: "",
    /**
     @type {Function}
     */
    getHiddenIdList: function () {
        return [];
    }
};
/*----------------------------------------------------------------------------- Handler Type -------------------------*/
/**
 * Object for Handler.
 */
Handler = (function () {
    var
        /**
         @type {Function}
         */
        beforeSend = function () {
            showLoading();
        },
        /**
         @type {Function}
         */
        success = function (data, textStatus, jqXHR) {
            if (data.done) {
                if (data.result) {
                    fillGrid(data.result);
                } else {
                    hideLoading();
                    setTimeout(function () {
                        switch (pageState) {
                            case PageState.READY:
                                debugger;
                                $('.error-container').off('click');
                                $('.error-container').find('.close-error-container').off('click');
                                break
                            case PageState.NEXT:
                                break
                            case PageState.PREV:
                                break
                            case PageState.REFRESH:
                                break
                        }
                        showError("No things exists for show");
                    }, 300)
                }
            } else {
                hideLoading();
                setTimeout(function () {
                    errorHandle(data);
                }, 300)
            }
        },
        /**
         @type {Function}
         */
        complete = function (jqXHR) {
            hideLoading();
        },
        /**
         @type {Function}
         */
        error = function (jqXHR) {
            hideLoading();
            setTimeout(function () {
                showError("Error: " + ResponseCode[jqXHR.status]);
            }, 300)
        };
    return {
        beforeSend: beforeSend,
        success: success,
        complete: complete,
        error: error
    }
});
/*----------------------------------------------------------------------------- Set Structure Type -------------------*/
/**
 * Set Structure.
 */
function Set() {
    var setObj = {}, val = {};
    /**
     * @type {Function}
     * @param {String}      value
     */
    this.add = function (value) {
        setObj[value] = val;
    };
    /**
     * @type {Function}
     * @param {String}      value
     */
    this.remove = function (value) {
        delete setObj[value];
    };
    /**
     * @type {Function}
     */
    this.clear = function () {
        setObj = {};
    };
    /**
     * @type {Function}
     * @param {String}      value
     * @return {boolean}
     */
    this.contains = function (value) {
        return setObj[value] === val;
    };
    /**
     * @type {Function}
     * @return {number}
     */
    this.size = function () {
        var size = 0;
        $.each(setObj, function () {
            size++;
        })
        return size;
    };
    /**
     @type {Function}
     @return {Array}
     */
    this.values = function () {
        var values = [];
        for (var i in setObj) {
            if (setObj[i] === val) {
                values.push(i);
            }
        }
        return values;
    };
}
/*----------------------------------------------------------------------------- Map Structure Type -------------------*/
/**
 * Map Structure.
 */
function Map() {
    var setObj = {};
    /**
     * @type {Function}
     * @param {String}      key
     * @param {Object}      value
     */
    this.put = function (key, value) {
        setObj[key] = value;
    };
    /**
     * @type {Function}
     * @param {String}      key
     * @return {Object}
     */
    this.get = function (key) {
        return setObj[key];
    };
    /**
     * @type {Function}
     * @param {String}      value
     */
    this.remove = function (key) {
        delete setObj[key];
    };
    /**
     * @type {Function}
     */
    this.clear = function () {
        setObj = {};
    };
    /**
     * @type {Function}
     * @param {String}      key
     * @return {boolean}
     */
    this.contains = function (key) {
        return setObj[key] != undefined;
    };
    /**
     * @type {Function}
     * @return {number}
     */
    this.size = function () {
        var size = 0;
        $.each(setObj, function () {
            size++;
        });
        return size;
    };
    /**
     @type {Function}
     @return {Array}
     */
    this.values = function () {
        var values = [];
        $.each(setObj, function (index, value) {
            values.push(value);
        });
        return values;
    };
}
/*------------------------------------------------------------------------------ End ---------------------------------*/