/*--------------------------------------------------------------------------------------- Document ready -------------*/
$(document).ready(function () {
    var urlPath = getParamValue("urlPath");
    var pageName = getParamValue("pageName");

    $("#master-frame").attr("src", progPath + urlPath + "?isMaster=1&pageName=" + pageName);
});

/*--------------------------------------------------------------------------------------- Show detail ----------------*/
function showDetail(url, filterMethodName, paramsMethodName) {
    var src;
    if (url.indexOf("?") > 0) {
        src = progPath + url + "&isDetail=1" + "&params=" + paramsMethodName + "&filter=" + filterMethodName;
    } else {
        src = progPath + url + "?isDetail=1" + "&params=" + paramsMethodName + "&filter=" + filterMethodName;
    }
    $("#detail-frame").attr("src", src);
}

/*--------------------------------------------------------------------------------------- Hide detail ----------------*/
function hideDetail() {
    try {
        window.frames['detail-frame'].hideEdit();
    } catch (err) {
    }
}

/*--------------------------------------------------------------------------------------- End ------------------------*/