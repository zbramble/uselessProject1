var AdvanceSearch = {
	searchValue :'', searchValueFrom :'', searchValueTo :'',searchField:'',searchCondition:'',container:'' , 
	
	removeAutocomplete : function(jqueryElem) {
        if(jqueryElem.attr('autocomplete')) {
            jqueryElem.autocomplete('destroy')
            jqueryElem.removeAttr('class');
            jqueryElem.removeAttr('entityid');
            jqueryElem.attr('placeholder', 'Enter value');
        }
    }
    ,

	init : function() {
	    /* ========================================================== Advanced Search ====================================*/
	    searchValue = $('#text-input-container #search-value');
	    searchValueFrom = $('#date-input-container #search-value-from');
	    searchValueTo = $('#date-input-container #search-value-to');
	    searchField = $('#search-field');
	    searchCondition = $('#search-condition');
	    container = $('#filter-item-container');
	    $('#advance-search').on('click', function (e) {
	        searchField.html('');
	        searchCondition.html('');
	        var searchFieldTemp = '<option selected disabled>Select field to filter</option>';
	        searchFields.forEach(function (item) {
	            searchFieldTemp += '<option value=' + item.propName + ' data-type=' + item.type +'>' + item.title + '</option>';
	        })
	        searchField.html(searchFieldTemp)
	        searchValue.val('');
	        // Remove Autocomplete Functionality from Input
	        AdvanceSearch.removeAutocomplete(searchValue);
	        $('#date-input-container').hide();
	        $('#text-input-container').show();
	        // Remove DatePicker Functionality from Input
	        AdvanceSearch.removeDatePicker(searchValue);
	    })
	    searchField.on('change', function () {
	        var value = this.value;
	        $('#date-input-container').hide();
	        $('#text-input-container').show();
	        searchValue.val('');
	        searchValueFrom.val('');
	        searchValueTo.val('');
	        searchFields.forEach(function (item) {
	            if(item.propName == value) {
	                // Remove DatePicker Functionality from Input
	            	AdvanceSearch.removeDatePicker(searchValue)
	                // Remove Autocomplete Functionality from Input
	                AdvanceSearch.removeAutocomplete(searchValue);
	
	                if(item.type == SearchPropertyType.DATE) {
	                    searchValue.addClass('date');
	                    searchValue.mask('0000/00/00', {placeholder: "____/__/__"});
	                    $('.pdp-default').css({'z-index': 'auto'})
	                    searchValue.persianDatepicker();
	                } else {
	                    searchValue.attr('maxlength', item.maxlength)
	                    searchValue.attr('placeholder','Enter value');
	                    searchValue.unmask('0000/00/00');
	                    if(item.type == SearchPropertyType.AUTOCOMPLETE) {
	                        searchValue.addClass('autocomplete');
	                        searchValue.attr('placeholder','Enter value + Enter');
	                        var filter = new Filter();
	                        filter.addParameter(item.propName, '$("#search-value").val()', Condition.CONTAINS);
	                        eval(item.autocompleteInstance + '("search-value", filter)');
	                    }
	                }
	                searchCondition.html(SearchPropertyCondition[item.type]);
	            }
	        })
	    })
	    searchCondition.on('change', function () {
	        searchValue.val('');
	        searchValueFrom.val('');
	        searchValueTo.val('');
	   if(this.value == Condition.BETWEEN) {
	            $('#date-input-container').show();
	            $('#text-input-container').hide();
	            searchValueFrom.mask('0000/00/00', {placeholder: "____/__/__"});
	            searchValueFrom.persianDatepicker();
	            searchValueTo.mask('0000/00/00', {placeholder: "____/__/__"});
	            searchValueTo.persianDatepicker();
	        } else {
	            $('#date-input-container').hide();
	            $('#text-input-container').show();
	        }
	    })
	    $('#add-filter').on('click', function () {
	    	AdvanceSearch.addFilter();
	    })
    }
	,
    addFilter : function() {
        if($('#text-input-container').css('display') == 'block') {
            if(searchValue.val().trim().length > 0) {
                if(searchField.val()) {
                    if (searchCondition.val()) {
                        var searchItem =
                            '<div class="search-item-container">' +
                                '<select class="open-parentheses">' +
                                    '<option value="-1">Parenthesis</option>' +
                                    '<option value="1">(</option>' +
                                    '<option value="2">((</option>' +
                                    '<option value="3">(((</option>' +
                                '</select>' ;
                        if(searchValue.attr('class') && searchValue.attr('class').indexOf('autocomplete') == 0) {
                            if(searchValue.attr('entityid') === undefined || searchValue.attr('entityid') == '') {
                                searchValue.val('');
                                return;
                            }
                            // component is autocomplete
                            searchItem +=
                                '<div class="search-item" ' +
                                    'data-search-field="' + searchField.val() + '" ' +
                                    'data-rowId="' + searchValue.attr('entityid') + '" ' +
                                    'data-search-condition="' + searchCondition.val() + '">' ;
                        } else if(searchValue.attr('class') && searchValue.hasClass('date')) {
                            // component is date
                            searchItem +=
                                '<div class="search-item" ' +
                                'data-search-field="' + searchField.val() + '" ' +
                                'is-date = true ' +
                                'data-search-condition="' + searchCondition.val() + '">' ;
                        }
                        else {
                            searchItem +=
                                '<div class="search-item" ' +
                                    'data-search-field="' + searchField.val() + '" ' +
                                    'data-search-condition="' + searchCondition.val() + '">';
                        }
                        searchItem +=
                                    '<span class="ion-close-round remove-item"></span>' +
                                    '<span class="search-field">' + searchField.find('option:selected').text() + ':</span>&nbsp;<span>' + searchValue.val() + '</span>' +
                                    '<br>' +
                                    '<span class="search-condition">Condition:</span>&nbsp;<span>' + searchCondition.find('option:selected').text() + '</span>' +
                                '</div>' +
                                '<select class="close-parentheses">' +
                                    '<option value="-1">Parenthes</option>' +
                                    '<option value="1">)</option>' +
                                    '<option value="2">))</option>' +
                                    '<option value="3">)))</option>' +
                                '</select>' +
                                '<select class="operator-type">' +
                                    '<option value="and">And</option>' +
                                    '<option value="or">Or</option>' +
                                '</select>' +
                            '</div>';
                        container.append(searchItem)
                        $('.remove-item').on('click', function () {
                            $(this).closest('.search-item-container').remove();
                            /*== Disable close-parentheses for First Item AND  open-parentheses for Last Item ==*/
                            $('#filter-item-container').find('.search-item-container').first().find('.close-parentheses').attr('disabled', true)
                            $('#filter-item-container').find('.search-item-container').last().find('.open-parentheses').attr('disabled', true)
                            $('#filter-item-container').find('.search-item-container').last().find('.operator-type').attr('disabled', true)
                        })
                        /*== Disable close-parentheses for First Item AND  open-parentheses for Last Item ==*/
                        var item = container.find('.search-item-container');
                        var firstItem = item.first();
                        var lastItem = item.last();
                        item.find('.open-parentheses').removeAttr('disabled');
                        firstItem.find('.close-parentheses').attr('disabled', true);
                        lastItem.find('.open-parentheses').attr('disabled', true);
                        item.find('.operator-type').removeAttr('disabled');
                        lastItem.find('.operator-type').attr('disabled', true);
                        searchValue.val('')
                    }
                }
            }
        }
        // if search field is Date and condition is between
        else if($('#date-input-container').css('display') == 'block') {
            if(searchValueFrom.val().trim().length >= 8 && searchValueTo.val().trim().length >= 8) {
                if(searchField.val()) {
                    if (searchCondition.val()) {
                        var searchItem =
                            '<div class="search-item-container">' +
                                '<select class="open-parentheses">' +
                                    '<option value="-1">parenthesis</option>' +
                                    '<option value="1">(</option>' +
                                    '<option value="2">((</option>' +
                                    '<option value="3">(((</option>' +
                                '</select>' +
                                '<div class="search-item" data-search-field="' + searchField.val() + '" data-search-condition="' + searchCondition.val() + '">' +
                                    '<span class="ion-close-round remove-item"></span>' +
                                    '<span class="search-field">' + searchField.find('option:selected').text() + ':</span>&nbsp;<span>' +
                                    '&nbsp;&nbsp;' + 'از:' + '&nbsp;&nbsp;' +
                                    '<span class="search-value-from">' + searchValueFrom.val() + '</span>' +
                                    '&nbsp;&nbsp;' + 'تا:' + '&nbsp;&nbsp;' +
                                    '<span class="search-value-to">' + searchValueTo.val() + '</span>' +
                                    '</span>' +
                                    '<br>' +
                                    '<span class="search-condition">Condition:</span>&nbsp;<span>' + searchCondition.find('option:selected').text() + '</span>' +
                                '</div>' +
                                '<select class="close-parentheses">' +
                                    '<option value="-1">parenthesis</option>' +
                                    '<option value="1">)</option>' +
                                    '<option value="2">))</option>' +
                                    '<option value="3">)))</option>' +
                                '</select>' +
                                '<select class="operator-type">' +
                                    '<option value="AND">و</option>' +
                                    '<option value="OR">یا</option>' +
                                '</select>' +
                            '</div>';
                        container.append(searchItem)
                        $('.remove-item').on('click', function () {
                            $(this).closest('.search-item-container').remove();
                        })
                        /*== Disable close-parentheses for First Item AND  open-parentheses for Last Item ==*/
                        var item = container.find('.search-item-container');
                        var firstItem = item.first();
                        var lastItem = item.last();
                        item.find('.open-parentheses').removeAttr('disabled');
                        firstItem.find('.close-parentheses').attr('disabled', true);
                        lastItem.find('.open-parentheses').attr('disabled', true);
                        item.find('.operator-type').removeAttr('disabled');
                        lastItem.find('.operator-type').attr('disabled', true);
                        searchValueFrom.val('')
                        searchValueTo.val('')
                    }
                }
            }
            else {
                dialog("Mandatories checking", "Fill (from), (to) values");
            }
        }
    }
	,
    checkParenthesesCount : function(){
        var openParenthesesCount = 0, closeParenthesesCount = 0;
        $('#filter-item-container').find('.open-parentheses').each(function () {
            if(this.value == 1)
                openParenthesesCount++
            else if(this.value == 2)
                openParenthesesCount += 2
            else if(this.value == 3)
                openParenthesesCount += 3
        })
        $('#filter-item-container').find('.close-parentheses').each(function () {
            if(this.value == 1)
                closeParenthesesCount++
            else if(this.value == 2)
                closeParenthesesCount += 2
            else if(this.value == 3)
                closeParenthesesCount += 3
        })
        if(openParenthesesCount != closeParenthesesCount) {
            dialog('Error'
            		, '[Open and Close parenthesis count must be equal!'
            		+' | '+'Open parenthesis count: '+
            		openParenthesesCount+' | '+
            		'Close parenthesis count: ' + closeParenthesesCount )
            throw new Error('ParenthesesCount')
        }
    }
	,
    initializeFilter : function() {
    	AdvanceSearch.checkParenthesesCount();
        var query = '';
        var item = container.find('.search-item-container');
        item.each(function () {
            var openParentheses = $(this).find('.open-parentheses > option:selected');
            var operatorType = $(this).find('.operator-type').not('[disabled]').find('> option:selected');
            var closeParentheses = $(this).find('.close-parentheses > option:selected');
            var dataSearchField = $(this).find('.search-item').attr('data-search-field')
            var dataSearchCondition = $(this).find('.search-item').attr('data-search-condition')
            if(openParentheses.val() != -1)
                query += openParentheses.html()
            var searchValue = {};
            if($(this).find('[is-date]').length > 0) {
                searchValue.date = { value: $(this).find('.search-field + span').html()};
                query += replaceQuery(dataSearchField, dataSearchCondition, searchValue);
            } else if($(this).find('.search-value-from').length > 0 && $(this).find('.search-value-to').length > 0) {
                searchValue.date = {};
                searchValue.date.from = $(this).find('.search-value-from').html()
                searchValue.date.to = $(this).find('.search-value-to').html()
                query += replaceQuery(dataSearchField, dataSearchCondition, searchValue);
            } else {
                if ($(this).find('[data-rowid]').length == 1) { // Autocomplete
                    searchValue.simple = $(this).find('.search-item').attr('data-rowid');
                } else {
                    searchValue.simple = $(this).find('.search-field + span').html();
                }
                query += AdvanceSearch.replaceQuery(dataSearchField, dataSearchCondition, searchValue);
            }
            if(closeParentheses.val() != -1) {
                query += closeParentheses.html()
                if ( operatorType.length > 0 )
                    query += (' ' + operatorType.val() + ' ');
            } else {
                if ( operatorType.length > 0 )
                    query += (' ' + operatorType.val() + ' ');
            }
        })
        return query;
    }
    ,
    replaceQuery : function(field, condition, value) {
        var result = '';
        var dateFrom;
        var dateTo;
        var type = SearchPropertyType.TEXT;
        if(value.simple) {
            value = value.simple;
        } else if(value.date) {
            type = SearchPropertyType.DATE;
            if(value.date.value) {
                value = "to_date('" + value.date.value + " 00:00:00','yyyy/mm/dd hh24:mi:ss','NLS_CALENDAR=''PERSIAN''')"
            }
            else {
                dateFrom = "to_date('" + value.date.from + " 00:00:00','yyyy/mm/dd hh24:mi:ss','NLS_CALENDAR=''PERSIAN''')"
                dateTo = "to_date('" + value.date.to + " 00:00:00','yyyy/mm/dd hh24:mi:ss','NLS_CALENDAR=''PERSIAN''')"
            }
        }
        switch (condition) {
            case Condition.EQUAL:
                if(type == SearchPropertyType.DATE)
                    result = (field + " " + "=" + value);
                else
                    result = (field + " " + "=" + " '" + value + "'");
                break;
            case Condition.NOT_EQUAL:
                if(type == SearchPropertyType.DATE)
                    result = (field + " " + "<>" + value);
                else
                    result = (field + " " + "<>" + " '" + value + "'");
                break;
            case Condition.GREATER:
                if(type == SearchPropertyType.DATE) {
                    value = value.replace('00:00:00', '23:59:59')
                    result = (field + " " + ">" + value);
                }
                else
                    result = (field + " " + ">" + " '" + value + "'");
                break;
            case Condition.LESS:
                if(type == SearchPropertyType.DATE)
                    result = (field + " " + "<" + value);
                else
                    result = (field + " " + "<" + " '" + value + "'");
                break;
            case Condition.GREATER_OR_EQUAL:
                if(type == SearchPropertyType.DATE)
                    result = (field + " " + ">=" + value);
                else
                    result = (field + " " + ">=" + " '" + value + "'");
                break;
            case Condition.LESS_OR_EQUAL:
                if(type == SearchPropertyType.DATE) {
                    value = value.replace('00:00:00', '23:59:59')
                    result = (field + " " + "<=" + value);
                }
                else
                    result = (field + " " + "<=" + " '" + value + "'");
                break;
            case Condition.CONTAINS:
                result = (field + " " + "LIKE" + " '%" + value + "%'");
                break;
            case Condition.START_WITH:
                result = (field + " " + "LIKE" + " '%" + value + "'");
                break;
            case Condition.END_WITH:
                result = (field + " " + "LIKE" + " '" + value + "%'");
                break;
            case Condition.BETWEEN:
                result = ( "(" + field + " " + condition + " " + dateFrom + " AND " + dateTo + ")");
                break;
        }
        return result;
    }
    ,
    
    removeDatePicker : function(jqueryElem) {
        jqueryElem.removeClass('date')
        jqueryElem.removeClass('pdp-el')
        jqueryElem.removeAttr('pdp-id')
        jqueryElem.attr('placeholder', 'Enter value');
        $('.pdp-default').css({'z-index': -1})

    }
};
    /* ========================================================== Advanced Search ====================================*/