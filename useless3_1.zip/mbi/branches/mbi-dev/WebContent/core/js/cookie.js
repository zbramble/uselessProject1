function setCookie(cname, cvalue, exMinute) {
    var d = new Date();
    d.setTime(d.getTime() + (exMinute*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
} 
function delCookie(cname) {
    var d = new Date();
    d.setTime(d.getTime() - 10000);
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=empty;" + expires + ";path=/";
} 

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
} 

function checkCookie(cname) {
    var val = getCookie(cname);
    if (val != "") {
        return true;
    } else {
    	return false;
    }
}

function setLocalStorageItem(key, value) {
    value.timestamp = new Date().getTime();
    localStorage.setItem(key, JSON.stringify(value));
}
function getLocalStorageItem(key, userTimeOut) {
    var currentDate = new Date().getTime();
    var obj = JSON.parse(localStorage.getItem(key));
    if(obj == null)
        return null;
    if(userTimeOut != null &&!diffTime(currentDate, obj.timestamp, userTimeOut)) {
        removeLocalStorageItem(key);
        return null;
    }
    obj.timestamp = currentDate;
    setLocalStorageItem(key, obj);
    return obj;
}
function removeLocalStorageItem(key) { localStorage.removeItem(key) }
function diffTime(now, past, userTimeOut) {
    userTimeOut *= 60000;
    if(now - past > userTimeOut)
        return false;
    return true;
}

