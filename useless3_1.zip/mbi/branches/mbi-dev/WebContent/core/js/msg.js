function msg(name, param1, param2){
	var m = bundle(name);
	return m.replace('$1' , param1).replace('$2' , param2);
}

function bundle(name){
	switch(name){
	case 'USER_EXPIRED': return 'Login again?';
	case 'ERROR_USER_EXPIRED': return 'Error:$1، Please login agian';
	
		default:
			return name;
	}
}