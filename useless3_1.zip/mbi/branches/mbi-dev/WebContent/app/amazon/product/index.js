var searchFields = "name,isActive,parent";

 
	function search() {
		try {
			lockPage();
			$.ajax({
				url : servicePath + "/service/AmazonProducts/list",
				type : "POST",
				data : getFilter(),
				contentType : "application/json",
				cache : false,
				dataType : "json",
			}).done(function(result) {
				if (result.done) {
					fillGrid(result);
					$("#gridDiv").show('slow');

				}else{
					errorHandle(result);
				}
				
			}).fail(function(jqXHR, textStatus) {
				alert("Error: " + textStatus + ' ' + jqXHR.status);
			}).always(function() {
				unlockPage();
			});
		} catch (e) {
			alert(e);
			unlockPage();
		}
	}
	function importData() {
		try {
			lockPage();
			$.ajax({
				url : servicePath + "/service/AmazonProducts/import",
				type : "POST",
				data : getFilter(),
				contentType : "application/json",
				cache : false,
				dataType : "json",
			}).done(function(result) {
				if (result.done) {
					search();
				}else{
					errorHandle(result);
				}
				
			}).fail(function(jqXHR, textStatus) {
				alert("Error: " + textStatus + ' ' + jqXHR.status);
			}).always(function() {
				unlockPage();
			});
		} catch (e) {
			alert(e);
			unlockPage();
		}
	}


	function downloadExcel() {
		$.ajax({
			url : servicePath + "/service/ReportService/downloadExcel",
			type : "POST",
			data : getFilter(),
			contentType : "application/json",
			xhrFields : {
				responseType : 'blob'
			},
			success : function(data) {
				if(data){
				var blob = new Blob([ data ]);
				var link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);
				link.download = "report_reward_" + new Date().getTime() + ".xls";
				link.click();
				}else{
					alert(' Error!');
				}
			},
			fail: function(data){
				alert(data);
			}
		});
	}


	function getFilter(){
		var f=  '{"params": [' + 
					'{"key": "asin1",	"value": "'+ $("#asin1").val() +'","condition": "EQUAL"},' +
		 			'{"key": "seller_sku","value": "'+  $("#seller_sku").val() +'","condition": "EQUAL"}' +
		 		'], "ticket":"' + user.ticket + '" , "pageNo":"'+pageNo+'", "pageSize":"'+pageSize+'"}';
		 console.log(f);
		 return f;
	}
	
	function fillGrid(result){
		$("#grid").empty();
		if(!result.result){
			$("#dataGrid").css({"display":"none"});
			//alert('No things found');
			return;
		}else{
			$("#dataGrid").css({"display":""});
		}
		var grid = '<thead><tr>';
		
		for(var i = 0 ; result.result[0] && i < result.result[0].length; i++){
			grid+= '<th>' + result.result[0][i] + '</th>';
		}
		grid+='</tr></thead><tbody id="grid">';
		for(var i = 1 ; result.result && i < result.result.length; i++){
			grid+='<tr>';
			for(var j = 0 ; result.result[i] && j < result.result[0].length; j++){
				if(j == 1)//item name
					grid+='<td style="width:400px;text-align:left">';
				else if(j == 3)//SKU
					grid+='<td nowrap="nowrap">';
				else
					grid+='<td>';
				
				if(j==1)
					grid +='<a href="javascript:{}" onclick="showRow(\''+ result.result[i][3] +'\')">' + result.result[i][j] +'</a>' ;
				else if(j == 2)//asin
					grid += '<a target="_blank" href="http://www.amazon.com/dp/' + result.result[i][j] + '">'+result.result[i][j]+'</a>' ;
				else if(j == 7)//product_id
					grid+=result.result[i][j];
				else
					grid+= ($.isNumeric(result.result[i][j]) ? numberWithCommas(result.result[i][j]) : (result.result[i][j] == null ? '' :result.result[i][j])) + '</td>';
			}
			grid+='</tr>';			
		}
		grid+='</tbody>';				
		$("#dataGrid").html(grid);
		$("#gridDiv").show('slow');
	}
	function showRow(sellerSKU) {
		addTab({
            window: window,
            src: '/app/amazon/product/edit.html',
            title: 'SKU: ' + sellerSKU,
            filter: [
                {
                    filterTitle: 'Product sku:' + sellerSKU,
                    key: 'SELLER_SKU',
                    value: '\'' + sellerSKU + '\'',//Must be string for avoid eval function error
                    condition: Condition.EQUAL
                }
            ]
        })
	}