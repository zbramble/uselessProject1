/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;


/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#productDTO").attr("id", 'productDTO-' + id).find('span').html(item.productDTO.sku);
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);

        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#productDTO").attr("id", 'productDTO-' + id).find('span').html(item.productDTO ? item.productDTO.sku : '');
        patternRow.find("#note").attr("id", 'note-' + id).find('span').html(item.note);
        patternRow.find('#price').attr("id", 'price-' + id).find('span').html(item.price);
        patternRow.find('#leadTimeDays').attr("id", 'leadTimeDays-' + id).find('span').html(item.leadTimeDays);
        patternRow.find('#companyDTO').attr("id", 'companyDTO-' + id).find('span').html(item.companyDTO ? item.companyDTO.companyName : '');
       
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
        if (result.result) {
            fillGrid(result.result);
        } else {
            hideLoading();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("note", '$("#note_Searcher").val()', Condition.CONTAINS);


function search(){
    ServiceInvoker.call(fSearch.getFilters(), hSearch, "/productSupplier/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
    window.frames['editFrame'].showRow(id)
}


$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    $('#search').on('click', function () {
        search();
    })
    /*----------------------------------------------------------------------------------- Initialization -------------*/
    setIndexListeners();
    
    var tabID = window.location.href.urlParameter('tabID');
    if(tabID != null && tabID != 0) { // is opened as tab
 	   var filterArray = top.tabFilter[tabID];
 	   filterArray.forEach(function (item) {
 		   fSearch.addParameter(item.key, item.value, item.condition);
 	   });
    }

    search();

});

/*--------------------------------------------------------------------------------------- End ------------------------*/