/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicProduct(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/product/list",
        mapPattern: {
            label: "productTitle",
            value: "productTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicLocation(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/location/list",
        mapPattern: {
            label: "name",
            value: "name",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};

function AutocompleteDynamicComboVal(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/combo/list",
        mapPattern: {
            label: "name",
            value: "name",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
