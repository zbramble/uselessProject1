var entity;
var id,title;
$(document).ready(function () {
    setEditListeners();
    var tabID = window.location.href.urlParameter('tabID');
    if(tabID != null && tabID != 0) { // is opened as tab
 	   var filterArray = top.tabFilter[tabID];
 	  title = filterArray[0].productTitle;
 	  id = filterArray[0].value;
   }
    clearForm();
    showRowByProductId(id);
    $("#firdAvailableDate" ).datepicker();
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/productStandard/save");
    });

	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
var fProduct = new Filter();
    fProduct.addParameter("productTitle", '$("#productDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicProduct("productDTO", fProduct);

var fLocation = new Filter();
    fLocation.addParameter("name", '$("#locationDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicLocation("locationDTO",fLocation);
	
var fColor = new Filter();
	fColor.addParameter("parent.name", '"product color"', Condition.CONTAINS);
	AutocompleteDynamicLocation("colorDTO",fColor);
});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/productStandard/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    
    $("#rowId").val(dto.rowId);
    if(dto.productDTO){
		$("#productDTO").val(dto.productDTO.productTitle);
		$("#productDTO").attr("entityId", dto.productDTO.rowId);
	}
    $("#productCetifications").val(dto.productCetifications);
    $("#manufacturer").val(dto.manufacturer);
    $("#model").val(dto.model);
	$("#hsCode").val(dto.hsCode);
	$("#htsCode").val(dto.htsCode);
	$("#model").val(dto.model);
	$("#firdAvailableDate").val(dto.firdAvailableDate);
	$("#model").val(dto.model);
	$("#description").val(dto.description);
	$("#dangerous").prop("checked",dto.dangerous);
	$("#fdaRegulated").prop("checked",dto.fdaRegulated);
	$("#usdaLaceyAct").prop("checked",dto.usdaLaceyAct);
	
	if(dto.locationDTO)
		$("#locationDTO").val(dto.locationDTO.name);
	if(dto.colorDTO)
		$("#colorDTO").val(dto.colorDTO.name);

    $("#created").val(dto.created);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    $("#createdBy").val(dto.createdBy.fullTitle);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $("#productDTO").val(title);
	$("#productDTO").attr("entityId", id);
    
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
        	fillEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/productStandard/list");
    pageNo = oldPageNo;
}
/*---------------------------------------------------------------------------------------------------------------------*/
function showRowByProductId(productId){
	fShrSearche.clearParams();
    fShrSearche.addParameter("product.rowId", productId, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/productStandard/list");
    pageNo = oldPageNo;
}
/*--------------------------------------------------------------------------------------- End ------------------------*/