/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicProduct(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/product/list",
        mapPattern: {
            label: "productTitle",
            value: "productTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicSite(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/site/list",
        mapPattern: {
            label: "siteName",
            value: "siteName",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};