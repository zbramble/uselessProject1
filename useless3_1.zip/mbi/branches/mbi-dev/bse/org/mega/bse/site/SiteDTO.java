package org.mega.bse.site;

import org.mega.bse.channel.ChannelDTO;
import org.mega.core.base.BaseDTO;

public class SiteDTO extends BaseDTO{

	private long rowId;
	private String accessKey;
	private String description;
	private String siteName;;
	private ChannelDTO channelDTO;
	
	public ChannelDTO getChannelDTO() {
		return channelDTO;
	}
	
	public void setChannelDTO(ChannelDTO channelDTO) {
		this.channelDTO = channelDTO;
	}
	
	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

}
