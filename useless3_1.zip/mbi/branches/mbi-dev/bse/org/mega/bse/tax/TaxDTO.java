package org.mega.bse.tax;

import org.mega.core.base.BaseDTO;

public class TaxDTO extends BaseDTO {

	private long rowId;
	private String taxClassTitle;
	private long rate;
	private String description;
	private boolean enable;
	private String accessKey;

	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getTaxClassTitle() {
		return taxClassTitle;
	}

	public void setTaxClassTitle(String taxClassTitle) {
		this.taxClassTitle = taxClassTitle;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

}
