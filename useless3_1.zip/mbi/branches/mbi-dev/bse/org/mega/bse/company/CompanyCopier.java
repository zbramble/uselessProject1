package org.mega.bse.company;

import org.mega.core.base.BaseCopier;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;

public class CompanyCopier extends BaseCopier<Company, CompanyDTO>{

	@Override
	public CompanyDTO copyFromEntity(Company company) {
		CompanyDTO companyDTO = new CompanyDTO();
		companyDTO.setAccessKey(company.getAccessKey());
		companyDTO.setRowId(company.getRowId());
		companyDTO.setAddress1(company.getAddress1());
		companyDTO.setAddress2(company.getAddress2());
		if(company.getCity() != null){
			LocationDTO lDTO = new LocationDTO();
			lDTO.setRowId(company.getCity().getRowId());
			
			companyDTO.setCityDTO(lDTO);
		}
		if(company.getProvince() != null){
			LocationDTO lDTO = new LocationDTO();
			lDTO.setRowId(company.getProvince().getRowId());
			
			companyDTO.setProvinceDTO(lDTO);
		}
		if(company.getCountry() != null){
			LocationDTO lDTO = new LocationDTO();
			lDTO.setRowId(company.getCountry().getRowId());
			
			companyDTO.setCountryDTO(lDTO);
		}
		companyDTO.setCompanyEmail(company.getCompanyEmail());
		companyDTO.setCompanyLogo(company.getCompanyLogo());
		companyDTO.setCompanyName(company.getCompanyName());
		companyDTO.setCompanyPersonName(company.getCompanyPersonName());
		companyDTO.setCompanyPhone(company.getCompanyPhone());
		companyDTO.setCompanyWebsite(company.getCompanyWebsite());
		companyDTO.setDescription(company.getDescription());
		companyDTO.setPersonRole(company.getPersonRole());
		companyDTO.setZipcode(company.getZipcode());
		return companyDTO;
	}

	@Override
	public Company copyToEntity(CompanyDTO companyDTO) throws Exception {
		Company company = new Company();
		company.setAccessKey(companyDTO.getAccessKey());
		company.setRowId(companyDTO.getRowId());
		company.setAddress1(companyDTO.getAddress1());
		company.setAddress2(companyDTO.getAddress2());
		if(companyDTO.getCityDTO() != null){
			Location l = new Location();
			l.setRowId(companyDTO.getCityDTO().getRowId());
			
			company.setCity(l);
		}
		if(companyDTO.getProvinceDTO() != null){
			Location l = new Location();
			l.setRowId(companyDTO.getProvinceDTO().getRowId());
			
			company.setProvince(l);
		}
		if(companyDTO.getCountryDTO() != null){
			Location l = new Location();
			l.setRowId(companyDTO.getCountryDTO().getRowId());
			
			company.setCountry(l);
		}
		company.setCompanyEmail(companyDTO.getCompanyEmail());
		company.setCompanyLogo(companyDTO.getCompanyLogo());
		company.setCompanyName(companyDTO.getCompanyName());
		company.setCompanyPersonName(companyDTO.getCompanyPersonName());
		company.setCompanyPhone(companyDTO.getCompanyPhone());
		company.setCompanyWebsite(companyDTO.getCompanyWebsite());
		company.setDescription(companyDTO.getDescription());
		company.setPersonRole(companyDTO.getPersonRole());
		company.setZipcode(companyDTO.getZipcode());
		return company;
	}

}
