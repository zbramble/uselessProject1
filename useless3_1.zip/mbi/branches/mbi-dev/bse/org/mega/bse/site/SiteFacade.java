package org.mega.bse.site;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class SiteFacade extends BaseFacade{
	private static SiteCopier copier = new SiteCopier();
	private static SiteFacade facade = new SiteFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static SiteFacade getInstace() {
		return facade;
	}

}
