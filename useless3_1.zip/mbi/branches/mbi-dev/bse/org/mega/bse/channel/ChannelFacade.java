package org.mega.bse.channel;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class ChannelFacade extends BaseFacade{
	private static ChannelCopier copier = new ChannelCopier();
	private static ChannelFacade facade = new ChannelFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ChannelFacade getInstace() {
		return facade;
	}
}
