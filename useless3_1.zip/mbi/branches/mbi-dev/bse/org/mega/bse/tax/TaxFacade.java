package org.mega.bse.tax;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class TaxFacade extends BaseFacade {

	private static TaxCopier copier = new TaxCopier();
	private static TaxFacade facade = new TaxFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static TaxFacade getInstace() {
		return facade;
	}

}
