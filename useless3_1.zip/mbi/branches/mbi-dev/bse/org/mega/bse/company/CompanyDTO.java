package org.mega.bse.company;

import org.mega.core.base.BaseDTO;
import org.mega.core.location.LocationDTO;

public class CompanyDTO extends BaseDTO{
	
	private long rowId;
	private String accessKey;
	private String description;
	private LocationDTO countryDTO;
	private LocationDTO provinceDTO;
	private LocationDTO cityDTO;
	private String companyName;
	private String companyPersonName;
	private String companyWebsite;
	private String companyPhone;
	private String companyEmail;
	private String personRole;
	private byte[] companyLogo;
	private String address1;
	private String address2;
	private String zipcode;
	public long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocationDTO getCountryDTO() {
		return countryDTO;
	}
	public void setCountryDTO(LocationDTO countryDTO) {
		this.countryDTO = countryDTO;
	}
	public LocationDTO getProvinceDTO() {
		return provinceDTO;
	}
	public void setProvinceDTO(LocationDTO provinceDTO) {
		this.provinceDTO = provinceDTO;
	}
	public LocationDTO getCityDTO() {
		return cityDTO;
	}
	public void setCityDTO(LocationDTO cityDTO) {
		this.cityDTO = cityDTO;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyPersonName() {
		return companyPersonName;
	}
	public void setCompanyPersonName(String companyPersonName) {
		this.companyPersonName = companyPersonName;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}
	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	public String getCompanyPhone() {
		return companyPhone;
	}
	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}
	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public String getPersonRole() {
		return personRole;
	}
	public void setPersonRole(String personRole) {
		this.personRole = personRole;
	}
	public byte[] getCompanyLogo() {
		return companyLogo;
	}
	public void setCompanyLogo(byte[] companyLogo) {
		this.companyLogo = companyLogo;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	
	
}
