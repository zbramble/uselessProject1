package org.mega.bse.tax;

import org.mega.core.base.BaseCopier;

public class TaxCopier extends BaseCopier<Tax, TaxDTO>{

	@Override
	public TaxDTO copyFromEntity(Tax tax) {
		TaxDTO taxDTO = new TaxDTO();
		taxDTO.setRowId(tax.getRowId());
		taxDTO.setTaxClassTitle(tax.getTaxClassTitle());
		taxDTO.setRate(tax.getRate());
		taxDTO.setDescription(tax.getDescription());
		taxDTO.setAccessKey(tax.getAccessKey());
		taxDTO.setEnable(tax.isEnable());
		copyFromEntityBaseField(tax, taxDTO);
		return taxDTO;
	}

	@Override
	public Tax copyToEntity(TaxDTO taxDTO) throws Exception {
		Tax tax = new Tax();
		tax.setRowId(taxDTO.getRowId());
		tax.setTaxClassTitle(taxDTO.getTaxClassTitle());
		tax.setRate(taxDTO.getRate());
		tax.setDescription(taxDTO.getDescription());
		tax.setAccessKey(taxDTO.getAccessKey());
		tax.setEnable(taxDTO.isEnable());
		copyToEntityBaseField(tax, taxDTO);
		return tax;
	}

}
