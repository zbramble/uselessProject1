package org.mega.bse.currency;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_CURRENCY_TYPE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_CURRENCY_TYPE", columnNames = "CURRENCY_TYPE_ID") )
public class Currency extends BaseEntity {

	@Id
	@Column(name = "CURRENCY_TYPE_ID")
	private long rowId;

	@Column(name = "TITLE", length = 200)
	private String title;

	@Column(name = "RATE", length = 52)
	private int rate;

	@Column(name = "CURRENCY_ABBREVIATION", length = 5)
	private String currencyAbbreviation;

	@Column(name = "IS_BASE_CURRENCY")
	private boolean isBaseCurrency;

	@Column(name = "DESCRIPTION", length = 500)
	private String description;

	@Column(name = "ACCESS_KEY", length = 110)
	private String accessKey;

	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public String getCurrencyAbbreviation() {
		return currencyAbbreviation;
	}

	public void setCurrencyAbbreviation(String currencyAbbreviation) {
		this.currencyAbbreviation = currencyAbbreviation;
	}

	public boolean isBaseCurrency() {
		return isBaseCurrency;
	}

	public void setBaseCurrency(boolean isBaseCurrency) {
		this.isBaseCurrency = isBaseCurrency;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = title;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = title;
    }
}
