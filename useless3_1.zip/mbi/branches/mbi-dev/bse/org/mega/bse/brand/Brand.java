package org.mega.bse.brand;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_BRAND", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_BRAND", columnNames = "BRAND_ID"))
public class Brand extends BaseEntity{
	
	@Id
    @Column(name = "BRAND_ID")
    private long rowId;
	
	@Column(name = "BRAND_TITLE", length = 300)
	private String brandTitle;
	
	@Column(name = "SLOGAN", length = 1000)
	private String slogan;
	
	@Column(name = "DESCRIPTION", length = 500)
	private String description;
	
	@Column(name = "ACCESS_KEY", length = 110,updatable=false)
	private String accessKey;
	
	
	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getBrandTitle() {
		return brandTitle;
	}

	public void setBrandTitle(String brandTitle) {
		this.brandTitle = brandTitle;
	}

	public String getSlogan() {
		return slogan;
	}

	public void setSlogan(String slogan) {
		this.slogan = slogan;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = brandTitle;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = brandTitle;
    }
}
