package org.mega.product.weightdimension;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductWeightDimensionCopier extends BaseCopier<ProductWeightDimension, ProductWeightDimensionDTO>{

	@Override
	public ProductWeightDimensionDTO copyFromEntity(ProductWeightDimension productWeightDimension) {
		ProductWeightDimensionDTO productWeightDimensionDTO = new ProductWeightDimensionDTO();
		productWeightDimensionDTO.setAccessKey(productWeightDimension.getAccessKey());
		productWeightDimensionDTO.setCartonDepth(productWeightDimension.getCartonDepth());
		productWeightDimensionDTO.setCartonheight(productWeightDimension.getCartonheight());
		productWeightDimensionDTO.setCartonVolume(productWeightDimension.getCartonVolume());
		productWeightDimensionDTO.setCartonWidth(productWeightDimension.getCartonWidth());
		productWeightDimensionDTO.setDepth(productWeightDimension.getDepth());
		productWeightDimensionDTO.setDescription(productWeightDimension.getDescription());
		if(productWeightDimension.getDimensionUnit() != null){
			ComboValDTO unitDTO = new ComboValDTO();
			unitDTO.setRowId(productWeightDimension.getDimensionUnit().getRowId());
			unitDTO.setName(productWeightDimension.getDimensionUnit().getName());
			productWeightDimensionDTO.setDimensionUnitDTO(unitDTO);
		}
		productWeightDimensionDTO.setHeight(productWeightDimension.getHeight());
		if(productWeightDimension.getProduct() != null){
			ProductDTO productDTO = new ProductDTO();
			productDTO.setRowId(productWeightDimension.getProduct().getRowId());
			productDTO.setProductTitle(productWeightDimension.getProduct().getProductTitle());
			productWeightDimensionDTO.setProductDTO(productDTO);
		}
		productWeightDimensionDTO.setRowId(productWeightDimension.getRowId());
		productWeightDimensionDTO.setUnitsInCarton(productWeightDimension.getUnitsInCarton());
		productWeightDimensionDTO.setVolume(productWeightDimension.getVolume());
		if(productWeightDimension.getVolumeUnit() != null){
			ComboValDTO unitDTO = new ComboValDTO();
			unitDTO.setRowId(productWeightDimension.getVolumeUnit().getRowId());
			unitDTO.setName(productWeightDimension.getVolumeUnit().getName());
			productWeightDimensionDTO.setVolumeUnitDTO(unitDTO);
		}
		
		
		productWeightDimensionDTO.setWeight(productWeightDimension.getWeight());
		if(productWeightDimension.getWeightUnit() != null){
			ComboValDTO unitDTO = new ComboValDTO();
			unitDTO.setRowId(productWeightDimension.getWeightUnit().getRowId());
			unitDTO.setName(productWeightDimension.getWeightUnit().getName());
			productWeightDimensionDTO.setWeightUnitDTO(unitDTO);
		}
				
		productWeightDimensionDTO.setWidth(productWeightDimension.getWidth());
		return productWeightDimensionDTO;
	}

	@Override
	public ProductWeightDimension copyToEntity(ProductWeightDimensionDTO productWeightDimensionDTO) throws Exception {
		ProductWeightDimension productWeightDimension = new ProductWeightDimension();
		productWeightDimension.setAccessKey(productWeightDimensionDTO.getAccessKey());
		productWeightDimension.setCartonDepth(productWeightDimensionDTO.getCartonDepth());
		productWeightDimension.setCartonheight(productWeightDimensionDTO.getCartonheight());
		productWeightDimension.setCartonVolume(productWeightDimensionDTO.getCartonVolume());
		productWeightDimension.setCartonWidth(productWeightDimensionDTO.getCartonWidth());
		productWeightDimension.setDepth(productWeightDimensionDTO.getDepth());
		productWeightDimension.setDescription(productWeightDimensionDTO.getDescription());
		if(productWeightDimensionDTO.getDimensionUnitDTO() != null){
			ComboVal unit = new ComboVal();
			unit.setRowId(productWeightDimensionDTO.getDimensionUnitDTO().getRowId());
			unit.setName(productWeightDimensionDTO.getDimensionUnitDTO().getName());
			productWeightDimension.setDimensionUnit(unit);
		}
		productWeightDimension.setHeight(productWeightDimensionDTO.getHeight());
		if(productWeightDimensionDTO.getProductDTO() != null){
			Product product = new Product();
			product.setRowId(productWeightDimensionDTO.getProductDTO().getRowId());
			product.setProductTitle(productWeightDimensionDTO.getProductDTO().getProductTitle());
			productWeightDimension.setProduct(product);
		}
		productWeightDimension.setRowId(productWeightDimensionDTO.getRowId());
		productWeightDimension.setUnitsInCarton(productWeightDimensionDTO.getUnitsInCarton());
		productWeightDimension.setVolume(productWeightDimensionDTO.getVolume());
		if(productWeightDimensionDTO.getVolumeUnitDTO() != null){
			ComboVal unit = new ComboVal();
			unit.setRowId(productWeightDimensionDTO.getVolumeUnitDTO().getRowId());
			unit.setName(productWeightDimensionDTO.getVolumeUnitDTO().getName());
			productWeightDimension.setVolumeUnit(unit);
		}
		
		productWeightDimension.setWeight(productWeightDimensionDTO.getWeight());
		if(productWeightDimensionDTO.getWeightUnitDTO() != null){
			ComboVal unit = new ComboVal();
			unit.setRowId(productWeightDimensionDTO.getWeightUnitDTO().getRowId());
			unit.setName(productWeightDimensionDTO.getWeightUnitDTO().getName());
			productWeightDimension.setWeightUnit(unit);
		}
		
		productWeightDimension.setWidth(productWeightDimensionDTO.getWidth());
		return productWeightDimension;
	}

}
