package org.mega.product.standardproperties;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;
import org.mega.product.Product;
import org.mega.product.ProductDTO;
import org.mega.util.DateUtil;

public class ProductStandardPropertiesCopier extends BaseCopier<ProductStandardProperties, ProductStandardPropertiesDTO>{

	@Override
	public ProductStandardPropertiesDTO copyFromEntity(ProductStandardProperties productStandard) {
		ProductStandardPropertiesDTO productStandardDTO = new ProductStandardPropertiesDTO();
		productStandardDTO.setRowId(productStandard.getRowId());
		productStandardDTO.setAccessKey(productStandard.getAccessKey());
		productStandardDTO.setDangerous(productStandard.isDangerous());
		if(productStandard.getColor() != null){
			ComboValDTO colorDTO = new ComboValDTO();
			colorDTO.setRowId(productStandard.getColor().getRowId());
			colorDTO.setName(productStandard.getColor().getName());
			productStandardDTO.setColorDTO(colorDTO);
		}
		productStandardDTO.setDescription(productStandard.getDescription());
		productStandardDTO.setFdaRegulated(productStandard.isFdaRegulated());
		productStandardDTO.setFirdAvailableDate(DateUtil.getDateString(productStandard.getFirdAvailableDate(), "en"));
		productStandardDTO.setHsCode(productStandard.getHsCode());
		productStandardDTO.setHtsCode(productStandard.getHtsCode());
		if(productStandard.getLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(productStandard.getLocation().getRowId());
			locationDTO.setName(productStandard.getLocation().getName());
			productStandardDTO.setLocationDTO(locationDTO);
		}
		productStandardDTO.setManufacturer(productStandard.getManufacturer());
		productStandardDTO.setModel(productStandard.getModel());
		if(productStandard.getProduct() != null){
			ProductDTO product = new ProductDTO();
			product.setRowId(productStandard.getProduct().getRowId());
			product.setProductTitle(productStandard.getProduct().getProductTitle());
			productStandardDTO.setProductDTO(product);
		}
		productStandardDTO.setProductCetifications(productStandard.getProductCetifications());
		productStandardDTO.setUsdaLaceyAct(productStandard.isUsdaLaceyAct());
		return productStandardDTO;
	}

	@Override
	public ProductStandardProperties copyToEntity(ProductStandardPropertiesDTO productStandardDTO) throws Exception {
		ProductStandardProperties productStandard = new ProductStandardProperties();
		productStandard.setRowId(productStandardDTO.getRowId());
		productStandard.setAccessKey(productStandardDTO.getAccessKey());
		productStandard.setDangerous(productStandardDTO.isDangerous());
		if(productStandard.getColor() != null){
			ComboVal color = new ComboVal();
			color.setRowId(productStandardDTO.getColorDTO().getRowId());
			color.setName(productStandardDTO.getColorDTO().getName());
			productStandard.setColor(color);
		}
		productStandard.setDescription(productStandardDTO.getDescription());
		productStandard.setFdaRegulated(productStandardDTO.isFdaRegulated());
		productStandard.setFirdAvailableDate(DateUtil.getDate(productStandardDTO.getFirdAvailableDate(), "en"));
		productStandard.setHsCode(productStandardDTO.getHsCode());
		productStandard.setHtsCode(productStandardDTO.getHtsCode());
		if(productStandardDTO.getLocationDTO() != null){
			Location location = new Location();
			location.setRowId(productStandardDTO.getLocationDTO().getRowId());
			productStandard.setLocation(location);
		}
		productStandard.setManufacturer(productStandardDTO.getManufacturer());
		productStandard.setModel(productStandardDTO.getModel());
		if(productStandardDTO.getProductDTO() != null){
			Product product = new Product();
			product.setRowId(productStandardDTO.getProductDTO().getRowId());
			product.setProductTitle(productStandardDTO.getProductDTO().getProductTitle());
			productStandard.setProduct(product);
		}
		productStandard.setProductCetifications(productStandardDTO.getProductCetifications());
		productStandard.setUsdaLaceyAct(productStandardDTO.isUsdaLaceyAct());
		return productStandard;
	}

}
