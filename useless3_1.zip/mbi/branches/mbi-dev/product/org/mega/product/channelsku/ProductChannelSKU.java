package org.mega.product.channelsku;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.site.Site;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.product.Product;

@Entity
@Table(name = "PRODUCT_CHANNEL_SKU", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_CHANNEL_SKU", columnNames = "PRODUCT_CHANNEL_SKU_ID") )
public class ProductChannelSKU extends BaseEntity{
	
	@Id
	@Column(name = "PRODUCT_CHANNEL_SKU_ID")
	private long rowId;
	
	@ManyToOne()
	@JoinColumn(name = "BSE_SITE_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_BSE_SITE") , nullable = true)
	private Site site;
	
	@ManyToOne()
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_PRODUCT2") , nullable = true)
	private Product product;
		
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;

	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Column(name = "NOTES", length = 300,nullable = true)
	private String notes;
	
	public long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	
	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = notes;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = notes;
    }
}
