package org.mega.product.extendedpropertie;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.file.File;
import org.mega.product.Product;

@Entity
@Table(name = "PRODUCT_EXTENDED_PROPERTIES", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_EXTENDED_PROPERTIES", columnNames = "PRODUCT_EXTENDED_PROPERTIE_ID") )
public class ProductExtendedPropertie extends BaseEntity{

	@Id
	@Column(name = "PRODUCT_EXTENDED_PROPERTIE_ID")
	private long rowId;
	
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;

	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@ManyToOne()
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERE_PRODUCT_EX") , nullable = true)
	private Product product;
	
	@ManyToOne()
	@JoinColumn(name = "EXTENDED_PROPERTY_DATA_TYPE", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERE_CO_COMBO_EX") , nullable = true)
	private ComboVal dataType;
	
	@ManyToOne()
	@JoinColumn(name = "EXTENDED_PROPERTY_FILE", nullable = true)
	private File propertyFile;
	
	@Column(name = "EXTENDED_PROPERTY_NAME", length = 300,nullable = true)
	private String propertyName;
	
	@Column(name = "EXTENDED_PROPERTY_VALUE", length = 1000,nullable = true)
	private String propertyValue;
	
	public long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ComboVal getDataType() {
		return dataType;
	}

	public void setDataType(ComboVal dataType) {
		this.dataType = dataType;
	}

	public File getPropertyFile() {
		return propertyFile;
	}

	public void setPropertyFile(File propertyFile) {
		this.propertyFile = propertyFile;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = propertyName;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = propertyName;
    }
}
