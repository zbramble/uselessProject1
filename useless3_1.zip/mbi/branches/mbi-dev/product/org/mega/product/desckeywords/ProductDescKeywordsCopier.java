package org.mega.product.desckeywords;

import org.mega.core.base.BaseCopier;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductDescKeywordsCopier extends BaseCopier<ProductDescKeywords, ProductDescKeywordsDTO>{

	@Override
	public ProductDescKeywordsDTO copyFromEntity(ProductDescKeywords d) {
		ProductDescKeywordsDTO pDTO = new ProductDescKeywordsDTO();
		pDTO.setRowId(d.getRowId());
		pDTO.setAccessKey(d.getAccessKey());
		pDTO.setDefaultFullDescription(d.getDefaultFullDescription());
		pDTO.setDefaultShortDescription(d.getDefaultShortDescription());
		pDTO.setDefaultSlogan(d.getDefaultSlogan());
		pDTO.setDefaultTagline(d.getDefaultTagline());
		pDTO.setDescription(d.getDescription());
		if(d.getProduct() != null){
			ProductDTO productDTO = new ProductDTO();
			productDTO.setRowId(d.getProduct().getRowId());
			productDTO.setProductTitle(d.getProduct().getProductTitle());
			pDTO.setProductDTO(productDTO);
		}
		pDTO.setFeature1(d.getFeature1());
		pDTO.setFeature2(d.getFeature2());
		pDTO.setFeature3(d.getFeature3());
		pDTO.setFeature4(d.getFeature4());
		pDTO.setFeature5(d.getFeature5());
		pDTO.setKeyword1(d.getKeyword1());
		pDTO.setKeyword2(d.getKeyword2());
		pDTO.setKeyword3(d.getKeyword3());
		pDTO.setKeyword4(d.getKeyword4());
		pDTO.setMajorKeyword(d.getMajorKeyword());

		return pDTO;
	}
	
	@Override
	public ProductDescKeywords copyToEntity(ProductDescKeywordsDTO d) throws Exception {
		ProductDescKeywords productKey = new ProductDescKeywords();
		productKey.setRowId(d.getRowId());
		productKey.setAccessKey(d.getAccessKey());
		productKey.setDefaultFullDescription(d.getDefaultFullDescription());
		productKey.setDefaultShortDescription(d.getDefaultShortDescription());
		productKey.setDefaultSlogan(d.getDefaultSlogan());
		productKey.setDefaultTagline(d.getDefaultTagline());
		productKey.setDescription(d.getDescription());
		if(d.getProductDTO() != null){
			Product product = new Product();
			product.setRowId(d.getProductDTO().getRowId());
			product.setProductTitle(d.getProductDTO().getFullTitle());
			productKey.setProduct(product);
		}
		productKey.setFeature1(d.getFeature1());
		productKey.setFeature2(d.getFeature2());
		productKey.setFeature3(d.getFeature3());
		productKey.setFeature4(d.getFeature4());
		productKey.setFeature5(d.getFeature5());
		productKey.setKeyword1(d.getKeyword1());
		productKey.setKeyword2(d.getKeyword2());
		productKey.setKeyword3(d.getKeyword3());
		productKey.setKeyword4(d.getKeyword4());
		productKey.setMajorKeyword(d.getMajorKeyword());
		return productKey;
	}
}
