package org.mega.product.desckeywords;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.product.ProductDTO;

public class ProductDescKeywordsFacade extends BaseFacade{

	private static ProductDescKeywordsCopier copier = new ProductDescKeywordsCopier();
	private static ProductDescKeywordsFacade facade = new ProductDescKeywordsFacade();

	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductDescKeywordsDTO productDescDTO = (ProductDescKeywordsDTO) baseDTO;
		if(productDescDTO.getRowId() == 0)
			productDescDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		
		return super.save(baseDTO, businessParam);
	}
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductDescKeywordsFacade getInstace() {
		return facade;
	}

}
