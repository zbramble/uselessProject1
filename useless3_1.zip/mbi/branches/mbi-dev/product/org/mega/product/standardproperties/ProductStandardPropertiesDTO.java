package org.mega.product.standardproperties;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.LocationDTO;
import org.mega.product.ProductDTO;

public class ProductStandardPropertiesDTO extends BaseDTO{
	
	private long rowId;
	private ProductDTO productDTO;
	private LocationDTO locationDTO;
	private ComboValDTO colorDTO;
	private String description;
	private String firdAvailableDate;
	private String productCetifications;
	private boolean dangerous;
	private boolean fdaRegulated;
	private boolean usdaLaceyAct;
	private String hsCode;
	private String htsCode;
	private String manufacturer;
	private String model;
	private String accessKey;
	public long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public LocationDTO getLocationDTO() {
		return locationDTO;
	}
	public void setLocationDTO(LocationDTO locationDTO) {
		this.locationDTO = locationDTO;
	}
	public ComboValDTO getColorDTO() {
		return colorDTO;
	}
	public void setColorDTO(ComboValDTO colorDTO) {
		this.colorDTO = colorDTO;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFirdAvailableDate() {
		return firdAvailableDate;
	}
	public void setFirdAvailableDate(String firdAvailableDate) {
		this.firdAvailableDate = firdAvailableDate;
	}
	public String getProductCetifications() {
		return productCetifications;
	}
	public void setProductCetifications(String productCetifications) {
		this.productCetifications = productCetifications;
	}
	public boolean isDangerous() {
		return dangerous;
	}
	public void setDangerous(boolean dangerous) {
		this.dangerous = dangerous;
	}
	public boolean isFdaRegulated() {
		return fdaRegulated;
	}
	public void setFdaRegulated(boolean fdaRegulated) {
		this.fdaRegulated = fdaRegulated;
	}
	public boolean isUsdaLaceyAct() {
		return usdaLaceyAct;
	}
	public void setUsdaLaceyAct(boolean usdaLaceyAct) {
		this.usdaLaceyAct = usdaLaceyAct;
	}
	public String getHsCode() {
		return hsCode;
	}
	public void setHsCode(String hsCode) {
		this.hsCode = hsCode;
	}
	public String getHtsCode() {
		return htsCode;
	}
	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
}
