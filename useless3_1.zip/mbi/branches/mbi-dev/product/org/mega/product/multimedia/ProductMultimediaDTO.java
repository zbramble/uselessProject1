package org.mega.product.multimedia;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.product.ProductDTO;

public class ProductMultimediaDTO extends BaseDTO{
	
	private long rowId;
	private ProductDTO productDTO;
	private ComboValDTO multimediaTypeDTO;
	private String accessKey;
	private String description;
	private int multimediaPriority;
	private String multimediaDesc;
	private FileDTO multimediaFile;
	private boolean defaultMultimedia;
	public long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public ComboValDTO getMultimediaTypeDTO() {
		return multimediaTypeDTO;
	}
	public void setMultimediaTypeDTO(ComboValDTO multimediaTypeDTO) {
		this.multimediaTypeDTO = multimediaTypeDTO;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getMultimediaPriority() {
		return multimediaPriority;
	}
	public void setMultimediaPriority(int multimediaPriority) {
		this.multimediaPriority = multimediaPriority;
	}
	public String getMultimediaDesc() {
		return multimediaDesc;
	}
	public void setMultimediaDesc(String multimediaDesc) {
		this.multimediaDesc = multimediaDesc;
	}
	
	public FileDTO getMultimediaFile() {
		return multimediaFile;
	}
	public void setMultimediaFile(FileDTO multimediaFile) {
		this.multimediaFile = multimediaFile;
	}
	public boolean isDefaultMultimedia() {
		return defaultMultimedia;
	}
	public void setDefaultMultimedia(boolean defaultMultimedia) {
		this.defaultMultimedia = defaultMultimedia;
	}
	
	

}
