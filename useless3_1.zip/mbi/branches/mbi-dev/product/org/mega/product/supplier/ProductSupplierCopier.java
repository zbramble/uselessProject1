package org.mega.product.supplier;

import org.mega.bse.company.Company;
import org.mega.bse.company.CompanyDTO;
import org.mega.core.base.BaseCopier;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductSupplierCopier extends BaseCopier<ProductSupplier, ProductSupplierDTO>{

	@Override
	public ProductSupplierDTO copyFromEntity(ProductSupplier supplier) {
		ProductSupplierDTO supplierDTO = new ProductSupplierDTO();
		supplierDTO.setRowId(supplier.getRowId());
		supplierDTO.setAccessKey(supplier.getAccessKey());
		if(supplier.getCompany() != null){
			CompanyDTO cDTO = new CompanyDTO();
			cDTO.setRowId(supplier.getCompany().getRowId());
			supplierDTO.setCompanyDTO(cDTO);
		}
		if(supplier.getProduct() != null){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(supplier.getProduct().getRowId());
			supplierDTO.setProductDTO(pDTO);
		}
		supplierDTO.setDefaultSupplier(supplier.isDefaultSupplier());
		supplierDTO.setDescription(supplier.getDescription());
		supplierDTO.setLeadTimeDays(supplier.getLeadTimeDays());
		supplierDTO.setMinOrderQty(supplier.getMinOrderQty());
		supplierDTO.setNote(supplier.getNote());
		supplierDTO.setPrice(supplier.getPrice());
		return supplierDTO;
	}

	@Override
	public ProductSupplier copyToEntity(ProductSupplierDTO supplierDTO) throws Exception {
		ProductSupplier supplier = new ProductSupplier();
		supplier.setRowId(supplierDTO.getRowId());
		supplier.setAccessKey(supplierDTO.getAccessKey());
		if(supplierDTO.getCompanyDTO() != null){
			Company c = new Company();
			c.setRowId(supplierDTO.getCompanyDTO().getRowId());
			supplier.setCompany(c);
		}
		if(supplierDTO.getProductDTO() != null){
			Product p = new Product();
			p.setRowId(supplierDTO.getProductDTO().getRowId());
			supplier.setProduct(p);
		}
		supplier.setDefaultSupplier(supplierDTO.isDefaultSupplier());
		supplier.setDescription(supplierDTO.getDescription());
		supplier.setLeadTimeDays(supplierDTO.getLeadTimeDays());
		supplier.setMinOrderQty(supplierDTO.getMinOrderQty());
		supplier.setNote(supplierDTO.getNote());
		supplier.setPrice(supplierDTO.getPrice());
		return supplier;
	}

}
