package org.mega.product.multimedia;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.file.File;
import org.mega.product.Product;

@Entity
@Table(name = "PRODUCT_MULTIMEDIA", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_MULTIMEDIA", columnNames = "PRODUCT_MULTIMEDIA_ID") )
public class ProductMultimedia extends BaseEntity{
	@Id
	@Column(name = "PRODUCT_MULTIMEDIA_ID")
	private long rowId;

	@ManyToOne()
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFEREN_PRODUCT") , nullable = true)
	private Product product;
			
	@ManyToOne()
	@JoinColumn(name = "MULTIMEDIA_TYPE", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFEREN_CO_COMBO") , nullable = true)
	private ComboVal multimediaType;
		
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;

	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
		
	@Column(name = "MULTIMEDIA_PRIORITY")
	private int multimediaPriority;
	
	@Column(name = "MULTIMEDIA_DESCRIPTION", length = 1000,nullable = true)
	private String multimediaDesc;
	
	@ManyToOne()
	@JoinColumn(name = "MULTIMEDIA_FILE", nullable = true)
	private File multimediaFile;
	
	@Column(name = "IS_DEFAULT_MULTIMEDIA")
	private boolean defaultMultimedia;

	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ComboVal getMultimediaType() {
		return multimediaType;
	}

	public void setMultimediaType(ComboVal multimediaType) {
		this.multimediaType = multimediaType;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMultimediaPriority() {
		return multimediaPriority;
	}

	public void setMultimediaPriority(int multimediaPriority) {
		this.multimediaPriority = multimediaPriority;
	}

	public String getMultimediaDesc() {
		return multimediaDesc;
	}

	public void setMultimediaDesc(String multimediaDesc) {
		this.multimediaDesc = multimediaDesc;
	}

	public File getMultimediaFile() {
		return multimediaFile;
	}

	public void setMultimediaFile(File multimediaFile) {
		this.multimediaFile = multimediaFile;
	}

	public boolean isDefaultMultimedia() {
		return defaultMultimedia;
	}

	public void setDefaultMultimedia(boolean defaultMultimedia) {
		this.defaultMultimedia = defaultMultimedia;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle =  product.getFullTitle()+ " props";
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = product.getFullTitle()+ " props";
    }
}
