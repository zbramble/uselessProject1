package org.mega.product.desckeywords;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.product.Product;

@Entity
@Table(name = "PRODUCT_DESC_KEYWORDS_FEATURES", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_DESC_KEYWORDS_FEATU", columnNames = "PRODUCT_DESC_ID") )
public class ProductDescKeywords extends BaseEntity{
	
	@Id
	@Column(name = "PRODUCT_DESC_ID")
	private long rowId;
	
	@ManyToOne()
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_PRODUCT") , nullable = true)
	private Product product;
	
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;
	
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Column(name = "DEFAULT_SHORT_DESCRIPTION", length = 1000,nullable = true)
	private String defaultShortDescription;
	
	@Column(name = "DEFAULT_FULL_DESCRIPTION", length = 1000,nullable = true)
	private String defaultFullDescription;
	
	@Column(name = "DEFAULT_TAGLINE", length = 1000,nullable = true)
	private String defaultTagline;
	
	@Column(name = "DEFAULT_SLOGAN", length = 1000,nullable = true)
	private String defaultSlogan;
	
	@Column(name = "FEATURE_1", length = 1000,nullable = true)
	private String feature1;
	
	@Column(name = "FEATURE_2", length = 1000,nullable = true)
	private String feature2;
	
	@Column(name = "FEATURE_3", length = 1000,nullable = true)
	private String feature3;
	
	@Column(name = "FEATURE_4", length = 1000,nullable = true)
	private String feature4;
	
	@Column(name = "FEATURE_5", length = 1000,nullable = true)
	private String feature5;
	
	@Column(name = "MAJOR_KEYWORD", length = 2000,nullable = true)
	private String majorKeyword;
	
	@Column(name = "KEYWORD1", length = 1000,nullable = true)
	private String 	keyword1;
	
	@Column(name = "KEYWORD2", length = 1000,nullable = true)
	private String 	keyword2;
	
	@Column(name = "KEYWORD3", length = 1000,nullable = true)
	private String 	keyword3;
	
	@Column(name = "KEYWORD4", length = 1000,nullable = true)
	private String 	keyword4;
	
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDefaultShortDescription() {
		return defaultShortDescription;
	}

	public void setDefaultShortDescription(String defaultShortDescription) {
		this.defaultShortDescription = defaultShortDescription;
	}

	public String getDefaultFullDescription() {
		return defaultFullDescription;
	}

	public void setDefaultFullDescription(String defaultFullDescription) {
		this.defaultFullDescription = defaultFullDescription;
	}

	public String getDefaultTagline() {
		return defaultTagline;
	}

	public void setDefaultTagline(String defaultTagline) {
		this.defaultTagline = defaultTagline;
	}

	public String getDefaultSlogan() {
		return defaultSlogan;
	}

	public void setDefaultSlogan(String defaultSlogan) {
		this.defaultSlogan = defaultSlogan;
	}

	public String getFeature1() {
		return feature1;
	}

	public void setFeature1(String feature1) {
		this.feature1 = feature1;
	}

	public String getFeature2() {
		return feature2;
	}

	public void setFeature2(String feature2) {
		this.feature2 = feature2;
	}

	public String getFeature3() {
		return feature3;
	}

	public void setFeature3(String feature3) {
		this.feature3 = feature3;
	}

	public String getFeature4() {
		return feature4;
	}

	public void setFeature4(String feature4) {
		this.feature4 = feature4;
	}

	public String getFeature5() {
		return feature5;
	}

	public void setFeature5(String feature5) {
		this.feature5 = feature5;
	}

	public String getMajorKeyword() {
		return majorKeyword;
	}

	public void setMajorKeyword(String majorKeyword) {
		this.majorKeyword = majorKeyword;
	}

	

	public String getKeyword1() {
		return keyword1;
	}

	public void setKeyword1(String keyword1) {
		this.keyword1 = keyword1;
	}

	public String getKeyword2() {
		return keyword2;
	}

	public void setKeyword2(String keyword2) {
		this.keyword2 = keyword2;
	}

	public String getKeyword3() {
		return keyword3;
	}

	public void setKeyword3(String keyword3) {
		this.keyword3 = keyword3;
	}

	public String getKeyword4() {
		return keyword4;
	}

	public void setKeyword4(String keyword4) {
		this.keyword4 = keyword4;
	}

	public long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = getDefaultFullDescription();
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = getDefaultFullDescription();
    }

}
