package org.mega.product.multimedia;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductMultimediaCopier extends BaseCopier<ProductMultimedia, ProductMultimediaDTO>{

	@Override
	public ProductMultimediaDTO copyFromEntity(ProductMultimedia multimedia) {
		ProductMultimediaDTO multimediaDTO = new ProductMultimediaDTO(); 
		multimediaDTO.setRowId(multimedia.getRowId());
		if(multimedia.getProduct() != null){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(multimedia.getProduct().getRowId());
			pDTO.setProductTitle(multimedia.getProduct().getProductTitle());
			multimediaDTO.setProductDTO(pDTO);
		}
		if(multimedia.getMultimediaType() != null){
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(multimedia.getMultimediaType().getRowId());
			cDTO.setName(multimedia.getMultimediaType().getName());
			multimediaDTO.setMultimediaTypeDTO(cDTO);
		}
		multimediaDTO.setAccessKey(multimedia.getAccessKey());
		multimediaDTO.setDefaultMultimedia(multimedia.isDefaultMultimedia());
		multimediaDTO.setDescription(multimedia.getDescription());
		multimediaDTO.setMultimediaDesc(multimedia.getMultimediaDesc());
		if(multimedia.getMultimediaFile() != null){
			FileDTO fDTO = new FileDTO();
			fDTO.setRowId(multimedia.getMultimediaFile().getRowId());
			//fDTO.setName(multimediaDTO.getMultimediaFile().getPath());
			multimediaDTO.setMultimediaFile(fDTO);
		}
		
		multimediaDTO.setMultimediaPriority(multimedia.getMultimediaPriority());
		return multimediaDTO;
	}

	@Override
	public ProductMultimedia copyToEntity(ProductMultimediaDTO multimediaDTO) throws Exception {
		ProductMultimedia multimedia = new ProductMultimedia();
		multimedia.setRowId(multimediaDTO.getRowId());
		if(multimediaDTO.getProductDTO() != null){
			Product p =new Product();
			p.setRowId(multimediaDTO.getProductDTO().getRowId());
			p.setProductTitle(multimediaDTO.getProductDTO().getProductTitle());
			multimedia.setProduct(p);
		}
		if(multimediaDTO.getMultimediaTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(multimediaDTO.getMultimediaTypeDTO().getRowId());
			c.setName(multimediaDTO.getMultimediaTypeDTO().getName());
			multimedia.setMultimediaType(c);
		}
		multimedia.setAccessKey(multimediaDTO.getAccessKey());
		multimedia.setDefaultMultimedia(multimediaDTO.isDefaultMultimedia());
		multimedia.setDescription(multimediaDTO.getDescription());
		multimedia.setMultimediaDesc(multimediaDTO.getMultimediaDesc());
		if(multimediaDTO.getMultimediaFile() != null){
			File f = new File();
			f.setRowId(multimediaDTO.getMultimediaFile().getRowId());
//			f.setName(multimedia.getMultimediaFile().getName());
			multimedia.setMultimediaFile(f);
		}
		//multimedia.setMultimediaFile(multimediaDTO.getMultimediaFile());
		multimedia.setMultimediaPriority(multimediaDTO.getMultimediaPriority());
		return multimedia;
	}

}
