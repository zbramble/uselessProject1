package org.mega.util;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.BaseFacade;

public class BeanUtil {
	
	public static Class<?> getEntityClass(BaseFacade facade) {
		try {
			return Class.forName(facade.getClass().getName().substring(0, facade.getClass().getName().length() - 6)	+ "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Class<?> getFacadeClass(Class<?> entityClass) {
		try {
			return Class.forName(entityClass.getName() + "Facade");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static Class<?> getCopierClass(BaseEntity entity) {
		try {
			return Class.forName(entity.getClass().getName() + "Copier");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static void main(String[] args) {
		//System.out.println(getEntityClass(new MerchantFacade()).getName());
	}
}
