package org.mega.util;

import org.mega.core.base.BaseLogger;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;

public class QueryUtil {

    public enum QUERY_TYPE {
        SELECT,
        DELETE,
        UPDATE, 
        WHERE_ONLY
    }

    public static String genQuery(Class<?> EntityClass, Filter filter)
            throws NoSuchFieldException, SecurityException {

        return genQuery(EntityClass, filter, QUERY_TYPE.SELECT);
    }

    public static String genQuery(Class<?> EntityClass, Filter filter, QUERY_TYPE queryType)
            throws NoSuchFieldException, SecurityException {

        return genQuery(EntityClass, filter, queryType, null);
    }

    /**
     * @param entityClass
     * @param filter
     * @param queryType   QueryType:{SELECT,DELETE...}
     *                    WHERE_ONLY: فقط شرط را درست می کند و کاری با کلاس ندارد برای کویری نیتیو مناسب اسب در این صورت کلاس موجودیت می تواند نال باشد
     * @param constraint
     * @return
     * @throws NoSuchFieldException
     * @throws SecurityException
     */
    public static String genQuery(Class<?> entityClass, Filter filter, QUERY_TYPE queryType, String constraint)
            throws NoSuchFieldException, SecurityException {

        StringBuilder ejbql = new StringBuilder();

        String order = "e.created desc";
        if (filter != null) {
            for (PairValue pairValue : filter.getParams()) {
                if (pairValue.getValue().isEmpty())
                    continue;

                if (ejbql.length() > 0)
                    ejbql.append(" and ");

                switch (pairValue.getCondition()) {
                    case CONTAINS:
                        ejbql.append(" e.").append(pairValue.getKey()).append(" like '%").append(pairValue.getValue()).append("%'");
                        break;
                    case START_WITH:
                        ejbql.append(" e.").append(pairValue.getKey()).append(" like '%").append(pairValue.getValue()).append("'");
                        break;
                    case END_WITH:
                        ejbql.append(" e.").append(pairValue.getKey()).append(" like '").append(pairValue.getValue()).append("%'");
                        break;
                    case IN:
                        ejbql.append(" e.").append(pairValue.getKey()).append(" in (").append(pairValue.getValue()).append(")");
                        break;
                    case NOT_IN:
                        ejbql.append(" e.").append(pairValue.getKey()).append(" not in (").append(pairValue.getValue()).append(")");
                        break;
                    case ORDER:
                    	order = "e." + pairValue.getValue();
                    	break;
                    case NAN://Dont use for filtering. This is for business be came from client such as report name.
                        break;
                    case WHERE:
                        ejbql.append(pairValue.getValue());
                        break;
                    case EQUAL:
                    default:
                        ejbql.append(" e.").append(pairValue.getKey()).append("='").append(pairValue.getValue()).append("'");
                        break;
                }
            }
        }

        if (constraint != null) {
            if (ejbql.length() > 0)
                ejbql.append(" and ");
            ejbql.append(" (").append(constraint).append(") ");
        }
        if (ejbql.length() > 0)
            ejbql.insert(0, " WHERE ");

        String result = "";
        switch (queryType) {
            case WHERE_ONLY:
                result = ejbql.toString();
                break;
            case SELECT:
			result = "SELECT e FROM " + entityClass.getSimpleName() + " e " + ejbql.toString() +
                        (ejbql.length() > 0 ? " AND " : " WHERE ") +
                        " e.deleted = 0 ORDER BY " + order;
                break;
            case UPDATE:
                result = "";
                break;
            case DELETE:
                result = "UPDATE " + entityClass.getSimpleName() + " e SET e.deleted = e.rowId , " +
                        "e.updated = sysdate " + ejbql.toString();
        }

        BaseLogger.getLogger().debug("EJBQL for list:" + result);
        return result;
    }
}