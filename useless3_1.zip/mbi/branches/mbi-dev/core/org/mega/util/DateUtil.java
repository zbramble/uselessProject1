package org.mega.util;

import org.apache.log4j.Logger;
import org.mega.core.base.BaseLogger;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

public class DateUtil {
    private static final String DATE_IDENTIFIER = "#d#";
    private static final String PATTERN = "yyyy/MM/dd";
    private static Logger logger = BaseLogger.getLogger(DateUtil.class);

    // public static int SolarYear = 0, SolarMonth = 0, SolarDay = 0;
    // public static int GregorianYear = 0, GregorianMonth = 0, GregorianDay =
    // 0;
    public static final int dkSolar = 0;
    public static final int dkGregorian = 1;
    public static final int[] LeapMonth = {12, 2};
    public static final int[][] DaysOfMonths = {
            {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29},
            {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}};
    // { Far, Ord, Kho, Tir, Mor, Sha, Meh, Aba, Aza, Day, Bah, Esf },
    // { Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec });
    public static final int[][] DaysToMonth = {
            {0, 31, 62, 93, 124, 155, 186, 216, 246, 276, 306, 336, 365},
            {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365}};
    // { Far, Ord, Kho, Tir, Mor, Sha, Meh, Aba, Aza, Day, Bah,^Esf, *** },
    // { Jan,^Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, *** });
    public static String[] solarMonthName = {
            "\u0641\u0631\u0648\u0631\u062f\u064a\u0646",
            "\u0627\u0631\u062f\u064a\u0628\u0647\u0634\u062a",
            "\u062e\u0631\u062f\u0627\u062f", "\u062a\u064a\u0631",
            "\u0645\u0631\u062f\u0627\u062f",
            "\u0634\u0647\u0631\u064a\u0648\u0631", "\u0645\u0647\u0631",
            "\u0622\u0628\u0627\u0646", "\u0622\u0630\u0631", "\u062f\u064a",
            "\u0628\u0647\u0645\u0646", "\u0627\u0633\u0641\u0646\u062f"};
    public static String[] gregorianMonthName = {"Jan", "Feb", "Mar", "Apr",
            "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

    public static boolean IsLeapYear(int DateKind, int Year) {
        if (DateKind == dkSolar)
            return ((((Year + 38) * 31) % 128) <= 30);
        return ((Year % 4) == 0)
                && (((Year % 100) != 0) || ((Year % 400) == 0));
    }

    public static int DaysOfMonth(int DateKind, int Year, int Month) {
        int Result = 0;
        if ((Year != 0) && ((Month >= 1) && (Month <= 12))) {
            Result = DaysOfMonths[DateKind][Month - 1];
            if ((Month == LeapMonth[DateKind]) && (IsLeapYear(DateKind, Year)))
                Result = Result + 1;
        }
        return Result;
    }

    public static int getGregorianMonthNumber(String monthStr) {
        java.text.DateFormatSymbols dfs = new java.text.DateFormatSymbols();
        String[] months = dfs.getShortMonths();
        for (int i = 0; i <= 11; i++)
            if (monthStr.equalsIgnoreCase(months[i]))
                return ++i;
        return -1;
    }

    public static boolean IsDateValid(int DateKind, int Year, int Month, int Day) {
        return (Year != 0) && (Month >= 1) && (Month <= 12) && (Day >= 1)
                && (Day <= DaysOfMonth(DateKind, Year, Month));
    }

    public static int DaysToDate(int DateKind, int Year, int Month, int Day) {
        int Result = 0;
        if (IsDateValid(DateKind, Year, Month, Day)) {
            Result = DaysToMonth[DateKind][Month - 1] + Day;
            if ((Month > LeapMonth[DateKind]) && IsLeapYear(DateKind, Year))
                Result = Result + 1;
        }
        return Result;
    }

    public static int[] DateOfDay(int DateKind, int Days, int Year) {
        int[] MonthDay = new int[2];
        int LeapDay = 0;
        int m = 0;
        int Month = 0;
        int Day = 0;
        for (m = 2; m <= 13; m++) {
            if ((m > LeapMonth[DateKind]) && IsLeapYear(DateKind, Year))
                LeapDay = 1;
            if (Days <= (DaysToMonth[DateKind][m - 1] + LeapDay)) {
                Month = m - 1;
                if (Month <= LeapMonth[DateKind])
                    LeapDay = 0;
                Day = Days - (DaysToMonth[DateKind][Month - 1] + LeapDay);
                MonthDay[0] = Month;
                MonthDay[1] = Day;
                return MonthDay;
            }
        }
        return null;
    }

    public static int[] GregorianToSolar(int Year, int Month, int Day) {
        int LeapDay = 0;
        int Days = 0;
        boolean PrevGregorianLeap = false;
        if (IsDateValid(dkGregorian, Year, Month, Day)) {

            int[] gDaysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int[] jDaysInMonth = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};

            Year = Year - 1600;


            Month = Month - 1;
            Day = Day - 1;

            int gDayNo = 365 * Year + div(Year + 3, 4) - div(Year + 99, 100) + div(Year + 399, 400);
            int i;
            for (i = 0; i < Month; ++i)
                gDayNo += gDaysInMonth[i];
            if (Month > 1 && ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0)))
                  /* leap and after Feb */
                gDayNo++;
            gDayNo += Day;
            int jDayNo = gDayNo - 79;
            int j_np = div(jDayNo, 12053); /* 12053 = 365*33 + 32/4 */
            jDayNo = jDayNo % 12053;
            int jy = 979 + 33 * j_np + 4 * div(jDayNo, 1461); /* 1461 = 365*4 + 4/4 */
            jDayNo %= 1461;
            if (jDayNo >= 366) {
                jy += div(jDayNo - 1, 365);
                jDayNo = (jDayNo - 1) % 365;
            }


            for (i = 0; i < 11 && jDayNo >= jDaysInMonth[i]; ++i)
                jDayNo -= jDaysInMonth[i];
            int jm = i + 1;
            int jd = jDayNo + 1;

            if (jd < 10) {
                jd = jd;
            }
            if (jm < 10) {
                jm = jm;
            }
            int result[] = {jy, jm, jd};
            return result;
        }
        return null;
    }

    public static boolean useSolarDate(String language) {
        return "fa".equals(language);
    }

    public static String getDateString(java.util.Date date, String lang) {
        try {
            String result;
            if (DateUtil.useSolarDate(lang)) {
                String sol = DateUtil.gerToSolar((1900 + date.getYear()) + "/"
                        + (date.getMonth() + 1) + "/" + date.getDate(), new SimpleDateFormat(PATTERN));
                String[] res = sol.split("/");
                result = res[0] + "/"
                        + (res[1].length() < 2 ? "0" + res[1] : res[1]) + "/"
                        + (res[2].length() < 2 ? "0" + res[2] : res[2]);
            } else {
                Calendar calendar = Calendar.getInstance();
                calendar.setTimeInMillis(date.getTime());
                int month = calendar.get(Calendar.MONTH) + 1;
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                result = calendar.get(Calendar.YEAR) + "/"
                        + ((month < 10) ? "0" + month : month) + "/"
                        + ((day < 10) ? "0" + day : day);
            }
            String time = new SimpleDateFormat("HH:mm:ss").format(date);
            if (!time.equals("00:00:00")) {
                result += " " + time;
            }
            return result;
        } catch (Exception e) {
            return "";
        }
    }

    public static String getTimeStampString(java.util.Date date, String lang, boolean... showSecond) {
        String result = getDateString(date, lang);
        try {
            result += "  " + (date.getHours() < 10 ? "0" : "") + date.getHours() + ":" +
                    (date.getMinutes() < 10 ? "0" : "") + date.getMinutes() +
                    (showSecond.length > 0 && showSecond[0] ? ":" + (date.getSeconds() < 10 ? "0" : "") + date.getSeconds() : "");
        } catch (Exception e) {
            return result;

        }
        return result;

    }

    public static Date getDate(String dateString, String lang) {
        Date date;
        if (DateUtil.useSolarDate(lang)) {
            date = solarToDate(dateString);
        } else {
            date = gerToDate(dateString);
        }
        try {
            String[] s = dateString.substring(11).split(":");
            DateUtil.setTime(date, Integer.parseInt(s[0]), Integer.parseInt(s[1]), s.length == 3 ? Integer.parseInt(s[2]) : 0);
        } catch (Exception e) {
        }
        return date;
    }

    public static String convertGregorianToSolarString(Date date) {
        return getDateString(date, "fa");
    }

    public static int[] convertGregorianToSolar(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(date.getTime());
        return convertGregorianToSolar(c.get(Calendar.YEAR), c
                .get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
    }

    public static String convertGregorianToSolarStringReplaceSlash(Date date) {
        return getDateString(date, "fa").replaceAll("/", "");

    }

    // Golnari:this method not work properly if used alone
    private static int[] convertGregorianToSolar(int Year, int Month, int Day) {
        int LeapDay = 0;
        int Days = 0;
        boolean PrevGregorianLeap = false;
        if (IsDateValid(dkGregorian, Year, Month, Day)) {

            int[] gDaysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int[] jDaysInMonth = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};

            Year = Year - 1600;


            Month = Month - 1;
            Day = Day - 1;

            int gDayNo = 365 * Year + div(Year + 3, 4) - div(Year + 99, 100) + div(Year + 399, 400);
            int i;
            for (i = 0; i < Month; ++i)
                gDayNo += gDaysInMonth[i];
            if (Month > 1 && ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0)))
                  /* leap and after Feb */
                gDayNo++;
            gDayNo += Day;
            int jDayNo = gDayNo - 79;
            int j_np = div(jDayNo, 12053); /* 12053 = 365*33 + 32/4 */
            jDayNo = jDayNo % 12053;
            int jy = 979 + 33 * j_np + 4 * div(jDayNo, 1461); /* 1461 = 365*4 + 4/4 */
            jDayNo %= 1461;
            if (jDayNo >= 366) {
                jy += div(jDayNo - 1, 365);
                jDayNo = (jDayNo - 1) % 365;
            }

            for (i = 0; i < 11 && jDayNo >= jDaysInMonth[i]; ++i)
                jDayNo -= jDaysInMonth[i];
            int jm = i + 1;
            int jd = jDayNo + 1;

            if (jd < 10) {
                jd = jd;
            }
            if (jm < 10) {
                jm = jm;
            }
            int result[] = {jy, jm, jd};
            return result;
        }
        return null;
    }

    private static int div(int a, int b) {
        return (int) (a / b);
    }

    public static int[] SolarToGregorian(int Year, int Month, int Day) {
        int LeapDay = 0;
        int Days = 0;
        boolean PrevSolarLeap = false;
        if (IsDateValid(dkSolar, Year, Month, Day)) {

            Year = Year - 979;
            Month = Month - 1;
            Day = Day - 1;
            //System.out.println(jy + " /"+ jm +" /"+jd);
            int[] gDaysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int[] jDaysInMonth = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
            int jDayNo = 365 * Year + div(Year, 33) * 8 + div(Year % 33 + 3, 4);
            for (int i = 0; i < Month; ++i)
                jDayNo += jDaysInMonth[i];
            jDayNo += Day;
            int gDayNo = jDayNo + 79;
            int gy = 1600 + 400 * div(gDayNo, 146097); /* 146097 = 365*400 + 400/4 - 400/100 + 400/400 */
            gDayNo = gDayNo % 146097;
            Boolean leap = true;
            if (gDayNo >= 36525) /* 36525 = 365*100 + 100/4 */ {
                gDayNo--;
                gy += 100 * div(gDayNo, 36524); /* 36524 = 365*100 + 100/4 - 100/100 */
                gDayNo = gDayNo % 36524;

                if (gDayNo >= 365)
                    gDayNo++;
                else


                    leap = false;
            }

            gy += 4 * div(gDayNo, 1461); /* 1461 = 365*4 + 4/4 */
            gDayNo %= 1461;

            if (gDayNo >= 366) {
                leap = false;
                gDayNo--;
                gy += div(gDayNo, 365);
                gDayNo = gDayNo % 365;
            }
            int i;
            for (i = 0; gDayNo >= gDaysInMonth[i] + ((i == 1 && leap) ? 1 : 0); i++)
                gDayNo -= gDaysInMonth[i] + ((i == 1 && leap) ? 1 : 0);
            int gm = i + 1;
            int gd = gDayNo + 1;

            if (gd < 10) {
                gd = gd;
            }
            if (gm < 10) {
                gm = 0 + gm;
            }
            int[] result = {gy, gm, gd};
            return result;
        }
        return null;
    }

    // public static void ConvertSolarToGregorian(int Year, int Month, int Day)
    // {
    // int LeapDay = 0;
    // int Days = 0;
    // boolean PrevSolarLeap = false;
    // if (IsDateValid(dkSolar, Year, Month, Day)) {
    // PrevSolarLeap = IsLeapYear(dkSolar, Year - 1);
    // Days = DaysToDate(dkSolar, Year, Month, Day);
    // Year = Year + 621;
    // if (IsLeapYear(dkGregorian, Year))
    // LeapDay = 1;
    // else
    // LeapDay = 0;
    // if (PrevSolarLeap && (LeapDay == 1))
    // Days = Days + 80;
    // else
    // Days = Days + 79;
    // if (Days > (365 + LeapDay)) {
    // Year = Year + 1;
    // Days = Days - (365 + LeapDay);
    // }
    // int[] MonthDay = DateOfDay(dkGregorian, Days, Year);
    //
    // GregorianYear = Year;
    // GregorianMonth = MonthDay[0];
    // GregorianDay = MonthDay[1];
    // }
    // }
    public static int[] convertSolarToGregorian(int Year, int Month, int Day) {

        boolean PrevSolarLeap = false;
        if (IsDateValid(dkSolar, Year, Month, Day)) {

            Year = Year - 979;
            Month = Month - 1;
            Day = Day - 1;
            //System.out.println(jy + " /"+ jm +" /"+jd);
            int[] gDaysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
            int[] jDaysInMonth = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
            int jDayNo = 365 * Year + div(Year, 33) * 8 + div(Year % 33 + 3, 4);
            for (int i = 0; i < Month; ++i)
                jDayNo += jDaysInMonth[i];
            jDayNo += Day;
            int gDayNo = jDayNo + 79;
            int gy = 1600 + 400 * div(gDayNo, 146097); /* 146097 = 365*400 + 400/4 - 400/100 + 400/400 */
            gDayNo = gDayNo % 146097;
            Boolean leap = true;
            if (gDayNo >= 36525) /* 36525 = 365*100 + 100/4 */ {
                gDayNo--;
                gy += 100 * div(gDayNo, 36524); /* 36524 = 365*100 + 100/4 - 100/100 */
                gDayNo = gDayNo % 36524;

                if (gDayNo >= 365)
                    gDayNo++;
                else


                    leap = false;
            }


            gy += 4 * div(gDayNo, 1461); /* 1461 = 365*4 + 4/4 */
            gDayNo %= 1461;

            if (gDayNo >= 366) {
                leap = false;
                gDayNo--;
                gy += div(gDayNo, 365);
                gDayNo = gDayNo % 365;
            }
            int i;
            for (i = 0; gDayNo >= gDaysInMonth[i] + ((i == 1 && leap) ? 1 : 0); i++)
                gDayNo -= gDaysInMonth[i] + ((i == 1 && leap) ? 1 : 0);
            int gm = i + 1;
            int gd = gDayNo + 1;

            if (gd < 10) {
                gd = gd;
            }
            if (gm < 10) {
                gm = 0 + gm;
            }
            int[] result = {gy, gm, gd};
            return result;
        }
        return null;
    }

    public static int getMaximumSolarMonthDays(int year, int month) {
        if (month <= 6)
            return 31;
        if ((month >= 7) && (month <= 11))
            return 30;
        if (month == 12) {
            if (IsLeapYear(dkSolar, year))
                return 30;
            else
                return 29;
        }
        return 30;
    }

    public static boolean isValidSolar(int year, int month, int day) {
        if ((year >= 1000) && (year <= 1600))
            return IsDateValid(0, year, month, day);
        return false;
    }

    public static boolean isValidGrigor(int year, int month, int day) {
        if ((year >= 1000) && (year <= 2500))
            return IsDateValid(1, year, month, day);
        return false;
    }

    public static int[] getGrigorFromSolarDateString(String dateStr) {
        // System.out.println("dateStr: " + dateStr);
        StringTokenizer st = new StringTokenizer(dateStr, " -/");
        int year = 0, month = 0, day = 0;
        if (st.hasMoreTokens())
            year = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            month = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            day = Integer.parseInt(st.nextToken());
        int[] result = new int[3];
        if (isValidSolar(year, month, day)) {
            result = SolarToGregorian(year, month, day);
            return result;
        }
        if (isValidSolar(day, month, year)) {
            result = SolarToGregorian(day, month, year);
            return result;
        }
        return null;
    }

    public static String ConverToGregorianFromSolarDateString(String dateStr) {
        String time = "00:00";
        if (dateStr.indexOf(" ") != -1) {
            time = dateStr.substring(dateStr.indexOf(" "), dateStr.length());
        }
        // System.out.println("Solar dateStr: " + dateStr);
        StringTokenizer st = new StringTokenizer(dateStr, " -/");
        int year = 0, month = 0, day = 0;
        if (st.hasMoreTokens())
            year = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            month = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            day = Integer.parseInt(st.nextToken());
        if (isValidSolar(year, month, day)) {
            int temp[] = convertSolarToGregorian(year, month, day);
            return temp[0] + "/" + align2(temp[1]) + "/" + align2(temp[2]) + " " + time;
        }
        if (isValidSolar(day, month, year)) {
            int temp[] = convertSolarToGregorian(day, month, year);
            return temp[0] + "/" + align2(temp[1]) + "/" + align2(temp[2]) + " " + time;
        }
        return null;
    }

    public static int[] getSolarFromGrigorDateString(String dateStr) {
        // System.out.println("dateStr: " + dateStr);
        StringTokenizer st = new StringTokenizer(dateStr, " -/");
        int year = 0, month = 0, day = 0;
        if (st.hasMoreTokens())
            year = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            month = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            day = Integer.parseInt(st.nextToken());
        int[] result = new int[3];
        if (isValidGrigor(year, month, day)) {
            result = GregorianToSolar(year, month, day);
            return result;
        }
        if (isValidGrigor(day, month, year)) {
            result = GregorianToSolar(day, month, year);
            return result;
        }
        return null;
    }

    public static String solarToGer(String dateStr, String format) {
        Date date = getDate(dateStr, "fa");
        return dateToGer(date, format);
    }

    public static java.util.Date gerToDate(String dateStr, String format) {
        try {
            DateFormat formatter = new SimpleDateFormat(format);
            Date date = formatter.parse(dateStr);
            try {//Set time
                String[] s = dateStr.substring(12).split(":");
                DateUtil.setTime(date, Integer.parseInt(s[0]), Integer.parseInt(s[1]), s.length == 3 ? Integer.parseInt(s[2]) : 0);
            } catch (Exception e) {
            }
            return date;

        } catch (ParseException e) {
            logger.error("fail to parse gerogorain date format " + dateStr);
        }
        return null;
    }

    public static java.util.Date gerToDate(String dateStr) {
    	if(dateStr == null)
    		return null;
        try {
            DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
            return (java.util.Date) formatter.parse(dateStr);
        } catch (ParseException e) {
            logger.error("fail to parse gerogorain date format " + dateStr);
        }
        return null;
    }

    public static java.util.Date solarToDate(String dateStr) {
        try {
            return gerToDate(ConverToGregorianFromSolarDateString(dateStr), "yyyy/MM/dd HH:mm");
        } catch (Exception e) {
            return null;
        }
    }

    public static String solarToGerDateTime(String dateStr) {
        // System.out.println("Solar dateStr: " + dateStr);
        StringTokenizer st = new StringTokenizer(dateStr, " -/:");
        int year = 0, month = 0, day = 0;
        int hour = 0, minute = 0, second = 0;
        String PMorAM = "AM";
        if (st.hasMoreTokens())
            year = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            month = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            day = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            hour = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            minute = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            second = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            PMorAM = st.nextToken();
        if (PMorAM.equalsIgnoreCase("\u0635\u0628\u062d"))
            PMorAM = "AM";
        else
            PMorAM = "PM";
        String hhour, mminute, ssecond;
        hhour = (hour <= 9) ? "0" + hour : hour + "";
        mminute = (minute <= 9) ? "0" + minute : minute + "";
        ssecond = (second <= 9) ? "0" + second : second + "";
        // if(PMorAM.equalsIgnoreCase("PM"))
        // hour += 12;
        // SimpleDateFormat format = new
        // SimpleDateFormat("MMM dd,yyyy hh:mm:ss a");
        if (isValidSolar(year, month, day)) {
            int temp[] = convertSolarToGregorian(year, month, day);
            String date = gregorianMonthName[temp[1] - 1] + " " + temp[2]
                    + ", " + temp[0] + " " + hhour + ":" + mminute + ":"
                    + ssecond + " " + PMorAM + " " + "IRST";
            // Timestamp ts = new
            // Timestamp(temp[1],temp[2],temp[3],hour,minute,second,0);
            // String date = format.format(ts);
            return date;
            // return temp[1] + "-" + temp[2] + "-" + temp[0];
        }
        if (isValidSolar(day, month, year)) {
            int temp[] = convertSolarToGregorian(day, month, year);
            return temp[1] + "/" + temp[2] + "/" + temp[0];
        }
        return null;
    }

    // // farshid Updated
    // // added to have month First
    public static String gerToSolar(String dateStr, SimpleDateFormat sdf) {
        try {
            java.util.Date date = sdf.parse(dateStr);
            GregorianCalendar gc = new GregorianCalendar();
            gc.setTime(date);
            int year = gc.get(GregorianCalendar.YEAR);
            int month = gc.get(GregorianCalendar.MONTH) + 1;
            int day = gc.get(GregorianCalendar.DATE);
            if (isValidGrigor(year, month, day)) {
                int[] temp = convertGregorianToSolar(year, month, day);
                String m, d;
                m = (temp[1] <= 9) ? "0" + String.valueOf(temp[1]) : ""
                        + temp[1];
                d = (temp[2] <= 9) ? "0" + String.valueOf(temp[2]) : ""
                        + temp[2];
                // farshid updated - correcting sequence in date fields
                return temp[0] + "/" + m + "/" + d;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String dateTimeGerToSolar(String dateTimeStr,
                                            SimpleDateFormat sdf) {
        try {
            java.util.Date date = (java.util.Date) sdf.parse(dateTimeStr);
            GregorianCalendar gc = new GregorianCalendar();
            gc.setTime(date);
            int year = gc.get(GregorianCalendar.YEAR);
            int month = gc.get(GregorianCalendar.MONTH);
            int day = gc.get(GregorianCalendar.DATE);
            int hour = gc.get(GregorianCalendar.HOUR);
            int minute = gc.get(GregorianCalendar.MINUTE);
            if (isValidGrigor(year, month, year)) {
                int[] temp = convertGregorianToSolar(year, month, day);
                String m, d;
                if ((temp[1] <= 9))
                    m = "0" + String.valueOf(temp[1]);
                else
                    m = String.valueOf(temp[1]);
                if ((temp[2] <= 9))
                    d = "0" + String.valueOf(temp[2]);
                else
                    d = String.valueOf(temp[2]);
                return temp[0] + "/" + m + "/" + d + " " + hour + ":" + minute;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


      /*public static String gerToSolar(String dateStr, int pattern) {
        String year = "";
        String month = "";
        String day = "";
        if (pattern == PATTERNS1) {
            year = dateStr.substring(0, 4);
            month = dateStr.substring(dateStr.indexOf('/'), dateStr
                    .lastIndexOf('/'));
            day = dateStr.substring(dateStr.lastIndexOf('/'));
        } else if (pattern == PATTERNS2) {
            year = dateStr.substring(0, 4);
            month = dateStr.substring(dateStr.indexOf('-'), dateStr
                    .lastIndexOf('-'));
            day = dateStr.substring(dateStr.lastIndexOf('-'));
        } else if (pattern == PATTERNS3) {
            year = dateStr.substring(0, 4);
            day = dateStr.substring(dateStr.indexOf('-'), dateStr
                    .lastIndexOf('-'));
            month = dateStr.substring(dateStr.lastIndexOf('-'));
        }

        String str = year + "/" + month + "/" + day;

        return ConvertToSolarFromGregorianDateString(str);
    }*/

    public static int[] gerToSolar(Timestamp ts) {
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTimeInMillis(ts.getTime());
        return convertGregorianToSolar(gc.get(GregorianCalendar.YEAR), gc
                .get(GregorianCalendar.MONTH) + 1, gc
                .get(GregorianCalendar.DATE));
    }

    /**
     * @param year
     * @param month  : 1,2,3
     * @param day
     * @param minute
     * @param second
     * @return
     */
    public static Timestamp solToGer(int year, int month, int day, int minute,
                                     int second) {
        int[] gd = convertSolarToGregorian(year, month, day);
        GregorianCalendar gc = new GregorianCalendar(gd[0], gd[1] - 1, gd[2],
                minute, second);
        return new Timestamp(gc.getTimeInMillis());
    }

    /**
     * @param year
     * @param month : : 1,2,3
     * @param day
     * @return
     */
    public static Timestamp solToGer(int year, int month, int day) {
        return solToGer(year, month, day, 0, 0);

    }

    public static String gerToSolTimestamp(Timestamp ts) {
        int[] fd = gerToSolar(ts);
        return fd[0] + "/" + fd[1] + "/" + fd[2];
    }
    /**
     * public static String greToSolmmDDyyyy(String dateStr){
     * //System.out.println("Gregorian dateStr: " + dateStr); StringTokenizer st
     * = new StringTokenizer(dateStr, " -/"); int year = 0, month = 0, day = 0;
     * if(st.hasMoreTokens()) month = Integer.parseInt(st.nextToken());
     * if(st.hasMoreTokens()) day = Integer.parseInt(st.nextToken());
     * if(st.hasMoreTokens()) year = Integer.parseInt(st.nextToken());
     *
     * if(isValidGrigor(year, month, day)){ int[] temp =
     * convertGregorianToSolar(year, month, day); String m,d; if((temp[1]<=9)) m
     * = "0" + String.valueOf(temp[1]); else m = String.valueOf(temp[1]);
     * if((temp[2]<=9)) d = "0" + String.valueOf(temp[2]); else d =
     * String.valueOf(temp[2]); return temp[0] + "-" + m + "-" + d; }
     *
     * return null; }
     */
    /**
     * @param dateStr : Format yyyy/mm/dd
     * @return
     * @deprecated use gerToSol instead.
     */
    private static String ConvertToSolarFromGregorianDateString(String dateStr) {
        // System.out.println("Gregorian dateStr: " + dateStr);
        StringTokenizer st = new StringTokenizer(dateStr, " -/");
        int year = 0, month = 0, day = 0;
        if (st.hasMoreTokens())
            year = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            month = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            day = Integer.parseInt(st.nextToken());
        if (isValidGrigor(year, month, day)) {
            int[] temp = convertGregorianToSolar(year, month, day);
            String m, d;
            if ((temp[1] <= 9))
                m = "0" + String.valueOf(temp[1]);
            else
                m = String.valueOf(temp[1]);
            if ((temp[2] <= 9))
                d = "0" + String.valueOf(temp[2]);
            else
                d = String.valueOf(temp[2]);
            return temp[0] + "/" + m + "/" + d;
        }
        if (isValidGrigor(day, month, year)) {
            int[] temp = convertGregorianToSolar(day, month, year);
            String m, d;
            if ((temp[1] <= 9))
                m = "0" + String.valueOf(temp[1]);
            else
                m = String.valueOf(temp[1]);
            if ((temp[2] <= 9))
                d = "0" + String.valueOf(temp[2]);
            else
                d = String.valueOf(temp[2]);
            return temp[0] + "/" + m + "/" + d;
        }
        return null;
    }

    /**
     * @param dateStr
     * @return
     * @deprecated use dateTimeGerToSolar
     */
    public static String ConvertToSolarFromGregorianDateTimeString(
            String dateStr) {
        // System.out.println("Gregorian dateTimeStr: " + dateStr);
        if (dateStr == null || dateStr == "")
            return null;
        // // farshid Updated
        // // Adding a '/' Character to method
        // // StringTokenizer st = new StringTokenizer(dateStr, " -,");
        StringTokenizer st = new StringTokenizer(dateStr, " /-,");
        // // end of adding
        // StringTokenizer st = new StringTokenizer(dateStr, " /-,");
        int year = 0, month = 0, day = 0;
        String monthStr = null, time = null, PMorAM = null;
        if (st.hasMoreTokens())
            monthStr = st.nextToken();
        if (st.hasMoreTokens())
            day = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            year = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            time = st.nextToken();
        if (st.hasMoreTokens())
            PMorAM = st.nextToken();
        month = getGregorianMonthNumber(monthStr);
        if (isValidGrigor(year, month, day)) {
            int temp[] = convertGregorianToSolar(year, month, day);
            String m, d;
            if ((temp[1] <= 9))
                m = "0" + String.valueOf(temp[1]);
            else
                m = String.valueOf(temp[1]);
            if ((temp[2] <= 9))
                d = "0" + String.valueOf(temp[2]);
            else
                d = String.valueOf(temp[2]);
            return temp[0]
                    + "-"
                    + m
                    + "-"
                    + d
                    + " "
                    + ConvertToSolarFromGregorianTimeString(time + " " + PMorAM);
        }
        if (isValidGrigor(day, month, year)) {
            int[] temp = convertGregorianToSolar(day, month, year);
            String m, d;
            if ((temp[1] <= 9))
                m = "0" + String.valueOf(temp[1]);
            else
                m = String.valueOf(temp[1]);
            if ((temp[2] <= 9))
                d = "0" + String.valueOf(temp[2]);
            else
                d = String.valueOf(temp[2]);
            return temp[0]
                    + "-"
                    + m
                    + "-"
                    + d
                    + ConvertToSolarFromGregorianTimeString(time + " " + PMorAM);
        }
        return null;
    }

    public static String ConvertToSolarFromGregorianTimeString(String timeStr) {
        // System.out.println("Gregorian TimeStr: " + timeStr);
        if (timeStr == null || timeStr == "")
            return null;
        StringTokenizer st = new StringTokenizer(timeStr, " :");
        int hour = 0, minute = 0, second = 0;
        String PMorAM = null, SolarPMorAM = null;
        if (st.hasMoreTokens())
            hour = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            minute = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            second = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            PMorAM = st.nextToken();
        SolarPMorAM = getGregorianPMorAM(PMorAM);
        return (hour <= 9 ? "0" + hour : hour) + ":"
                + (minute <= 9 ? "0" + minute : minute) + ":"
                + (second <= 9 ? "0" + second : second) + " " + SolarPMorAM;
    }

    public static String getGregorianPMorAM(String PMorAM) {
        return PMorAM.equalsIgnoreCase("AM") ? "\u0635\u0628\u062d"
                : "\u0639\u0635\u0631";
    }

    public static String persianAlphaDate(String PersianDate) {
        int fd = 0, fm = 0, fy = 0, ty1, ty2;
        String fmonth;
        StringTokenizer st = new StringTokenizer(PersianDate, " -/");
        if (st.hasMoreTokens())
            fy = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            fm = Integer.parseInt(st.nextToken());
        if (st.hasMoreTokens())
            fd = Integer.parseInt(st.nextToken());
        fmonth = "";
        String[] monthes = {"U??أ‚آ±Uأ‹â€ ?أ‚آ±?أ‚آ¯Uأ…â€™Uأ¢â‚¬آ ", "?أ‚آ§?أ‚آ±?أ‚آ¯Uأ…â€™?أ‚آ¨Uأ¢â‚¬آ،?أ‚آ´??", "?أ‚آ®?أ‚آ±?أ‚آ¯?أ‚آ§?أ‚آ¯", "??Uأ…â€™?أ‚آ±", "Uأ¢â‚¬آ¦?أ‚آ±?أ‚آ¯?أ‚آ§?أ‚آ¯",
                "?أ‚آ´Uأ¢â‚¬آ،?أ‚آ±Uأ…â€™Uأ‹â€ ?أ‚آ±", "Uأ¢â‚¬آ¦Uأ¢â‚¬آ،?أ‚آ±", "?أ‚آ¢?أ‚آ¨?أ‚آ§Uأ¢â‚¬آ ", "?أ‚آ¢?أ‚آ°?أ‚آ±", "?أ‚آ¯Uأ…â€™", "?أ‚آ¨Uأ¢â‚¬آ،Uأ¢â‚¬آ¦Uأ¢â‚¬آ ", "?أ‚آ§?أ‚آ³U?Uأ¢â‚¬آ ?أ‚آ¯"};
        fmonth = monthes[fm - 1];
        return fd + " " + fmonth + " " + fy;
    }

    /**
     * @param lang en or fa
     * @return
     */
    public static String today(String lang, int dayOffset) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.add(Calendar.DAY_OF_MONTH, dayOffset);
        return getDateString(calendar.getTime(), lang);
    }

    public static String yesterday(String lang, int dayOffset) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return getDateString(calendar.getTime(), lang);
    }

    /*	public static String nowTime() {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
            return align2(calendar.get(Calendar.HOUR_OF_DAY)) + ":" +  align2(calendar.get(Calendar.MINUTE)) + ":" +  align2(calendar.get(Calendar.SECOND));
        }*/
    public static String nowDateTimePersian() {
        return today("fa", 0) + "  " + nowTime();
    }

    public static String nowTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int hour = calendar.get(Calendar.HOUR);
        int min = calendar.get(Calendar.MINUTE);
        int sec = calendar.get(Calendar.SECOND);
        int amOrPm = calendar.get(calendar.AM_PM);
        if (amOrPm == 1) hour += 12;
        String time = (hour <= 9 ? "0" + hour : hour) + ":" + (min <= 9 ? "0" + min : min) + ":" + (sec <= 9 ? "0" + sec : sec);

        return time;
    }

    static String align2(int num) {
        if (num < 10)
            return "0" + num;
        return "" + num;
    }

    public static String dateToGer(Date date, String format) {
        if (date == null)
            return null;
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        //dateFormat.parse(format);
        return dateFormat.format(date);
    }

    public static long DateDiff(String firstDateStr, String secondDateStr) {
        //convert to ger date fitst date string
        String toGerFirstDate = DateUtil.ConverToGregorianFromSolarDateString(firstDateStr);
        Date firstDate = DateUtil.getDate(toGerFirstDate, "en");
        //convert to ger date second date string
        String toGerSecondDate = DateUtil.ConverToGregorianFromSolarDateString(secondDateStr);
        Date secondDate = DateUtil.getDate(toGerSecondDate, "en");
        return Math.abs(firstDate.getTime() - secondDate.getTime()) / 86400000;
    }

    public static long DateDiffSigned(String firstDateStr, String secondDateStr) {
        //convert to ger date fitst date string
        String toGerFirstDate = DateUtil.ConverToGregorianFromSolarDateString(firstDateStr);
        Date firstDate = DateUtil.getDate(toGerFirstDate, "en");
        //convert to ger date second date string
        String toGerSecondDate = DateUtil.ConverToGregorianFromSolarDateString(secondDateStr);
        Date secondDate = DateUtil.getDate(toGerSecondDate, "en");
        return (firstDate.getTime() - secondDate.getTime()) / 86400000;
    }

    public static Date setTime(Date date, int houre, int minute, int second) {
        date.setHours(houre);
        date.setMinutes(minute);
        date.setSeconds(second);
        return date;
    }

    public static void main(String[] args) {
        int[] result = gerToSolar(new Timestamp(System.currentTimeMillis()));
        System.out.println(result[0] + "/" + result[1] + "/" + result[2]);
        System.out.println("solarToDate> " + solarToDate("1388/07/18"));
        System.out.println("gerToDate>" + gerToDate("17/1/2008", "dd/MM/yyyy"));
        System.out.println("getDateString fa>"
                + getDateString(new Date(System.currentTimeMillis()), "en"));
        //System.out.println("gerToSolar>" + gerToSolar("2009-10-10", PATTERNS3));
        System.out.println("persianAlphaDate>" + persianAlphaDate("1388/7/18"));
        System.out.println("getDate fa>" + getDate("1388/7/18", "fa"));
        System.out.println("getDate en>" + getDate("2009/10/10", "en"));
        System.out.println("today fa>" + today("fa", 0));
        System.out.println(dateToGer(new Date(System.currentTimeMillis()), "yyyy-MM-dd"));
        System.out.println("gerToSolar> " + gerToSolar("2013/01/15", new SimpleDateFormat("yyyy/MM/dd")));

    }

    @SuppressWarnings("deprecation")
    public static String getCurrentTime() {
        Date date = new Date(System.currentTimeMillis());
        return date.getHours() + ":" + date.getMinutes();
    }

    public static String addToDate(String strDate, long miliSecond) {
        Date tmpDate = DateUtil.getDate(strDate, "fa");
        long newLongDate = tmpDate.getTime() + miliSecond;
        Date newDate = new Date();
        newDate.setTime(newLongDate);
        return DateUtil.getTimeStampString(newDate, "fa");
    }

    static String[] weekDays = {"أ™إ أڑآ©أکآ´أ™â€ أکآ¨أ™â€،", "أکآ¯أ™ث†أکآ´أ™â€ أکآ¨أ™â€،", "أکآ³أ™â€، أکآ´أ™â€ أکآ¨أ™â€،", "أڑâ€ أ™â€،أکآ§أکآ± أکآ´أ™â€ أکآ¨أ™â€،", "أ™آ¾أ™â€ أکآ¬ أکآ´أ™â€ أکآ¨أ™â€،", "أکآ¬أ™â€¦أکآ¹أ™â€،", "أکآ´أ™â€ أکآ¨أ™â€،"};

    public static String getWeekDayName(int weekDayIndex) {
        return weekDays[weekDayIndex];
    }

    public static String getDurationString(Duration duration) {
        try {
            return String.format(String.format("%02d:%02d:%02d", duration.toHours(), duration.toMinutes() % 60, duration.getSeconds() % 60));
        } catch (Exception e) {
            return "00:00:00";
        }
    }

    public static Duration getDuration(String time) {
        Duration duration = Duration.ZERO;
        if (time.length() <= 0)
            return duration;
        String[] tm = time.split(":");
        switch (tm.length) {
            case 3:
                duration = duration.plusSeconds(Integer.parseInt(tm[2]));
            case 2:
                duration = duration.plusMinutes(Integer.parseInt(tm[1]));
            case 1:
            default:
                duration = duration.plusHours(Integer.parseInt(tm[0]));
        }
        return duration;
    }
}