package org.mega.util;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.mega.core.SystemConfig;

import com.fasterxml.jackson.databind.ObjectMapper;

public class WebUtil {
	public static enum CONTENT_TYPE {JSON, TEXT};

	public static void sendEmail(String recieverEmail,String subbject, String content) {
		String username = SystemConfig.SYSTEM_EMAIL;
		String password = SystemConfig.SYSTEM_EMAIL_PASS;
		
		Properties props = new Properties();
		/*props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		*/
		props.put("mail.smtp.host", "smtp.gmail.com");
		
		
		props.put("mail.smtp.port", "25"); 
		props.put("mail.debug", "true"); 
		props.put("mail.smtp.auth", "true"); 
		props.put("mail.smtp.starttls.enable","true"); 
		props.put("mail.smtp.EnableSSL.enable","true");

		props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");   
		props.setProperty("mail.smtp.socketFactory.fallback", "false");   
		props.setProperty("mail.smtp.port", "465");   
		props.setProperty("mail.smtp.socketFactory.port", "465");
		props.setProperty("mail.debug", "false");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {
			Message message = new MimeMessage(session);
			//message.setFrom(new InternetAddress("alaki@gmail.com"));//This didnt work true
			message.setRecipients(Message.RecipientType.TO,	InternetAddress.parse(recieverEmail));
			message.setSubject(subbject);
			message.setText(content);

			Transport.send(message);
			
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}	

	/**
	 * Call a service and return wished object  
	 * @param urlPath	service url
	 * @param jsonToReq	json to send as service input
	 * @param retClazz	return object class type
	 * @return
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public static Object restServiceCall(String urlPath, String jsonToReq, Class<?> retClazz) throws IOException {
		//Send request
		URL url = new URL(urlPath);
		URLConnection connection = url.openConnection();
		connection.setDoOutput(true);
		connection.setConnectTimeout(5000);
		connection.setReadTimeout(5000);
		connection.setRequestProperty("Content-Type", "application/json");

		OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
		if(jsonToReq != null)
			out.write(jsonToReq);
		out.close();
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(connection.getInputStream(), retClazz);
	}
	
	/**
	 * Returns page content as text 
	 * @param urlPath Page url
	 * @return	Page content as text
	 * @throws IOException
	 */
	public static String readPage(String urlPath) throws IOException{
		URL url = new URL(urlPath);       
		return IOUtil.readAndCloseStream(url.openStream(), "utf-8");
	}
}
