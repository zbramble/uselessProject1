package org.mega.core.usecase;

import org.mega.core.base.BaseDTO;
import org.mega.core.usecaseaction.UseCaseActionDTO;

import java.util.List;

public class MasterUseCaseDTO extends BaseDTO {
    private UseCaseDTO useCaseDTO;
    private List<UseCaseActionDTO> listChild;
    private List<String> listId;

    public UseCaseDTO getUseCaseDTO() {
        return useCaseDTO;
    }

    public void setUseCaseDTO(UseCaseDTO useCaseDTO) {
        this.useCaseDTO = useCaseDTO;
    }

    public List<UseCaseActionDTO> getListChild() {
        return listChild;
    }

    public void setListChild(List<UseCaseActionDTO> listChild) {
        this.listChild = listChild;
    }

    public List<String> getListId() {
        return listId;
    }

    public void setListId(List<String> listId) {
        this.listId = listId;
    }

    @Override
    public long getRowId() {
        return useCaseDTO.getRowId();
    }
}