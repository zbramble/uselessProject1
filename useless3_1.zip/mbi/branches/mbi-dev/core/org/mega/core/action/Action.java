package org.mega.core.action;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.usecaseaction.UseCaseAction;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_ACTION", uniqueConstraints = @UniqueConstraint(name = "PK_CO_ACTION", columnNames = "ACTION_ID"))
public class Action extends BaseEntity {
    @Id
    @Column(name = "ACTION_ID")
    private long rowId;

    @Column(name = "ACTION_NAME", nullable = false, length = 50)
    private String actionName;

    @Column(name = "CODE", nullable = true, length = 20)
    private String code;

    @OneToMany(mappedBy = "action")
    private List<UseCaseAction> useCaseActions;

    @Override
    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<UseCaseAction> getUseCaseActions() {
        return useCaseActions;
    }

    public void setUseCaseActions(List<UseCaseAction> useCaseActions) {
        this.useCaseActions = useCaseActions;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = actionName;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = actionName;
    }
}