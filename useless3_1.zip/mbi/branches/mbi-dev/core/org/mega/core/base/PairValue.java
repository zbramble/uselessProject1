package org.mega.core.base;

public class PairValue {

    public PairValue() {
        // TODO Auto-generated constructor stub
    }

    public PairValue(String key, String value, CONDITION condition) {
        this.key = key;
        this.value = value;
        this.condition = condition;
    }

    public PairValue(String key, String value, TYPE type) {
        this.key = key;
        this.value = value;
        this.type = type;
    }

    public enum TYPE {TEXT, DATE, TIME, LONG, FLOAT, BOOLEAN}

    public enum CONDITION {EQUAL, CONTAINS, START_WITH, END_WITH, LESS, GREATER, IN, NOT_IN, ORDER, NAN, WHERE} //NAN: Parameter with this type don't use for filtering but use as business filter.

    String key;
    String value;
    TYPE type;
    CONDITION condition;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public TYPE getType() {
        return type;
    }

    public void setType(TYPE type) {
        this.type = type;
    }

    public CONDITION getCondition() {
        return condition;
    }

    public void setCondition(CONDITION condition) {
        this.condition = condition;
    }
}
