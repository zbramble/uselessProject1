package org.mega.core.sec;

import org.apache.log4j.Logger;
import org.mega.core.base.BaseLogger;
import org.mega.util.ExpireCacheRemoveAware;

public class UserExpire implements ExpireCacheRemoveAware{
	Logger logger = BaseLogger.getLogger(this.getClass());
	
	@Override
	public void removed(String key, Object val) {
		logger.info("User expired:" + ((UserSession)val).getUserInfo().getUsername());
	}
		
}
