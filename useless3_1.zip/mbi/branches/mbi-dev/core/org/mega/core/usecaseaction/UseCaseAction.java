package org.mega.core.usecaseaction;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.accessgrp.AccessGrp;
import org.mega.core.action.Action;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.usecase.UseCase;

@Entity
@Table(name = "CO_USECASE_ACTION", uniqueConstraints = {
        @UniqueConstraint(name = "PK_CO_UseCase_ACTION", columnNames = "USECASE_ACTION_ID"),
        @UniqueConstraint(name = "UK_UseCase_ID__ACTION_ID", columnNames = {"ACTION_ID", "USECASE_ID"})
})
public class UseCaseAction extends BaseEntity {
    @Id
    @Column(name = "USECASE_ACTION_ID")
    private long rowId;

    @Column(name = "CODE", nullable = true, length = 20)
    private String code;

    @ManyToOne
    @JoinColumn(name = "ACTION_ID", foreignKey = @ForeignKey(name = "FK_USEC_ACT_2_ACT__ACTION_ID"))
    private Action action;

    @ManyToOne
    @JoinColumn(name = "USECASE_ID", foreignKey = @ForeignKey(name = "FK_USEC_ACT_2_USEC__USECAS_ID"))
    private UseCase useCase;

    @ManyToMany(mappedBy = "UseCaseActions")
    private List<AccessGrp> accessGrps;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public UseCase getUseCase() {
        return useCase;
    }

    public void setUseCase(UseCase useCase) {
        this.useCase = useCase;
    }

    public List<AccessGrp> getAccessGrps() {
        return accessGrps;
    }

    public void setAccessGrps(List<AccessGrp> accessGrps) {
        this.accessGrps = accessGrps;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = rowId + "";
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = rowId + "";
    }
}