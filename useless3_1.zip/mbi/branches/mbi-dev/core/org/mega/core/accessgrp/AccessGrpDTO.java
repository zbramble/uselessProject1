package org.mega.core.accessgrp;

import org.mega.core.base.BaseDTO;
import org.mega.core.role.RoleDTO;
import org.mega.core.usecaseaction.UseCaseActionDTO;

import java.util.List;

public class AccessGrpDTO extends BaseDTO {
    private long rowId;
    private String code;
    private String name;
    private List<UseCaseActionDTO> useCaseActions;
    private List<RoleDTO> roles;

    @Override
    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<UseCaseActionDTO> getUseCaseActions() {
        return useCaseActions;
    }

    public void setUseCaseActions(List<UseCaseActionDTO> useCaseActions) {
        this.useCaseActions = useCaseActions;
    }

    public List<RoleDTO> getRoles() {
        return roles;
    }

    public void setRoles(List<RoleDTO> roles) {
        this.roles = roles;
    }
}