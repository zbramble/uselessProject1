package org.mega.core.base;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Level;
import org.mega.core.SystemConfig;

/**
 * Servlet implementation class LoadOnStartup
 */
@WebServlet(description = "Load when app started", urlPatterns = { "/LoadOnStartup" })
public class LoadOnStartup extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		BaseLogger.getLogger().log(Level.ALL, "*** MegaCore & Application started *** \n");
		SystemConfig.init();
		
		if(SystemConfig.INFOMR_SERVER_IP)
			IPInformer.start();
	}

}
