package org.mega.core.base;
import java.util.Date;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.mega.util.WebUtil;
public class IPInformer implements Runnable{
	static String lastIP = "";
	public static void start(){
		Thread thread = new Thread(new IPInformer());
		thread.start();
	}

	@Override
	public void run() {
		Logger logger =  BaseLogger.getLogger(IPInformer.class);
		while(true){
			try{
				String urlPath = "https://api.ipify.org/?format=text";
				String IP = (String)WebUtil.readPage(urlPath);
				if(lastIP.equals(IP))
					return;
				lastIP = IP;
				WebUtil.sendEmail("golnari@gmail.com", "ntnet last ip", 
						"Ip:" + IP + "\n"
						+ "https://www.dlinkddns.com/\n"
						+ "http://ntnet.dlinkddns.com:9090\n"
						+ new Date().toString());
				logger.log(Level.INFO, "Email Ip :" + IP);
				Thread.sleep(60 * 1 * 60 * 1000);// ! hour
			}catch (Exception e) {
				logger.log(Level.INFO, "Email Ip error!", e);				
			}
			
		}
		
	}
	
}
