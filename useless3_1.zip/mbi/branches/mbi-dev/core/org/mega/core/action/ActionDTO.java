package org.mega.core.action;

import org.mega.core.base.BaseDTO;
import org.mega.core.usecaseaction.UseCaseActionDTO;

import java.util.List;

public class ActionDTO extends BaseDTO {
	
	public enum ACTION {nan,insert,update,delete,search,view,print,exportExcel,exportPDF,viewCountAll,confirm,reject,showInMenu}	//nan added for start actions from index=1
    private long rowId;
    private String actionName;
    private String code;
    private List<UseCaseActionDTO> useCaseActions;

    @Override
    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<UseCaseActionDTO> getUseCaseActions() {
        return useCaseActions;
    }

    public void setUseCaseActions(List<UseCaseActionDTO> useCaseActions) {
        this.useCaseActions = useCaseActions;
    }
}