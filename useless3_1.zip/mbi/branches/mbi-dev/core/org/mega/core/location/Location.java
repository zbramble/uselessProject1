package org.mega.core.location;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_LOCATION", uniqueConstraints = @UniqueConstraint(name = "PK_CO_LOCATION_ID", columnNames = "LOCATION_ID"))
public class Location extends BaseEntity {
    @Id
    @Column(name = "LOCATION_ID")
    private long rowId;

    @Column(name = "NAME", length = 50)
    private String name;

    @ManyToOne()
    @JoinColumn(name = "TYPE_ID", foreignKey = @ForeignKey(name = "FK_LOC_2_COM__TYP_ID"), nullable = false)
    private ComboVal type;

    @ManyToOne()
    @JoinColumn(name = "PARENT_ID", foreignKey = @ForeignKey(name = "FK_LOC_2_LOC__PARENT_ID"))
    private Location parent;

    @OneToMany(mappedBy = "parent")
    private List<Location> locations;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ComboVal getType() {
        return type;
    }

    public void setType(ComboVal type) {
        this.type = type;
    }

    public Location getParent() {
        return parent;
    }

    public void setParent(Location parent) {
        this.parent = parent;
    }

    public List<Location> getLocations() {
        return locations;
    }

    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = (parent.getFullTitle() == null ||  parent.getFullTitle().equals("-")) ? name : parent.getFullTitle() + "/" + name;
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = (parent.getFullTitle() == null ||  parent.getFullTitle().equals("-")) ? name : parent.getFullTitle() + "/" + name;
    }
}