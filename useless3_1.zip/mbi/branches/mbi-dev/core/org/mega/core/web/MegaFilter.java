package org.mega.core.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.mega.core.base.BaseLogger;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Servlet Filter implementation class MegaFilter
 */
@WebFilter("/MegaFilter")
public class MegaFilter implements Filter {
	Logger logger = BaseLogger.getLogger(this.getClass());
    /**
     * Default constructor. 
     */
    public MegaFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("flow end");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// Log request url
		if (request instanceof HttpServletRequest) {
			String url = ((HttpServletRequest)request).getRequestURL().toString();
			String queryString = ((HttpServletRequest)request).getQueryString();
			Level level = Level.INFO;
			if(url.endsWith(".js") || url.endsWith(".css") || url.endsWith(".png") || url.endsWith(".jpg")||url.endsWith(".woff")||
					url.endsWith(".ttf") || url.endsWith(".gif") || url.endsWith(".svg") ) 
				 level = Level.DEBUG;

			logger.log(level, url + (queryString==null ? "" : "?" + queryString));
		}
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
