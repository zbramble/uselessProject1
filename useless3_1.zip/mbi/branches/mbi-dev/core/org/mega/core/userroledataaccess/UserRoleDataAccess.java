package org.mega.core.userroledataaccess;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.userrole.UserRole;

import javax.persistence.*;

@Entity
@Table(name = "CO_USER_ROLE_DATA_ACCESS", uniqueConstraints = @UniqueConstraint(name = "PK_CO_USER_ROLE_DATA_ACCESS",
        columnNames = "USER_ROLE_ACCESS_ID"))
public class UserRoleDataAccess extends BaseEntity {
    @Id
    @Column(name = "USER_ROLE_ACCESS_ID")
    private long rowId;

    @ManyToOne
    @JoinColumn(name = "USER_ROL_ID", foreignKey = @ForeignKey(name = "FK_URDA_2_USRL"))
    private UserRole userRole;

    @Column(name = "NAME", length = 40)
    private String name;

    @Column(name = "FILTER", length = 4000)
    private String filter;

    @Column(name = "TYPE", length = 2)
    private byte type;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = name;
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = name;
    }
}
