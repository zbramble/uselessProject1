package org.mega.core.userroledataaccess;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseEntity;
import org.mega.core.userrole.UserRole;
import org.mega.core.userrole.UserRoleDTO;

import javax.persistence.*;

public class UserRoleDataAccessCopier extends BaseCopier<UserRoleDataAccess, UserRoleDataAccessDTO> {
    @Override
    public UserRoleDataAccessDTO copyFromEntity(UserRoleDataAccess userRoleDataAccess) {
        UserRoleDataAccessDTO userRoleDataAccessDTO = new UserRoleDataAccessDTO();

        userRoleDataAccessDTO.setRowId(userRoleDataAccess.getRowId());
        if (userRoleDataAccess.getUserRole() != null) {
            UserRoleDTO userRoleDTO = new UserRoleDTO();
            userRoleDTO.setRowId(userRoleDataAccess.getUserRole().getRowId());
            userRoleDataAccessDTO.setUserRole(userRoleDTO);
        }
        userRoleDataAccessDTO.setName(userRoleDataAccess.getName());
        userRoleDataAccessDTO.setFilter(userRoleDataAccess.getFilter());
        userRoleDataAccessDTO.setType(userRoleDataAccess.getType());

        copyFromEntityBaseField(userRoleDataAccess, userRoleDataAccessDTO);

        return userRoleDataAccessDTO;
    }

    @Override
    public UserRoleDataAccess copyToEntity(UserRoleDataAccessDTO userRoleDataAccessDTO) {
        UserRoleDataAccess userRoleDataAccess = new UserRoleDataAccess();

        userRoleDataAccess.setRowId(userRoleDataAccessDTO.getRowId());
        if (userRoleDataAccessDTO.getUserRole() != null) {
            UserRole userRole = new UserRole();
            userRole.setRowId(userRoleDataAccessDTO.getUserRole().getRowId());
            userRoleDataAccess.setUserRole(userRole);
        }
        userRoleDataAccess.setName(userRoleDataAccessDTO.getName());
        userRoleDataAccess.setFilter(userRoleDataAccessDTO.getFilter());
        userRoleDataAccess.setType(userRoleDataAccessDTO.getType());

        copyToEntityBaseField(userRoleDataAccess, userRoleDataAccessDTO);

        return userRoleDataAccess;
    }
}
