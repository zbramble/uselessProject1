package org.mega.core.userroledataaccess;

import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseEntity;
import org.mega.core.userrole.UserRole;
import org.mega.core.userrole.UserRoleDTO;

import javax.persistence.*;

public class UserRoleDataAccessDTO extends BaseDTO {
    private long rowId;
    private UserRoleDTO userRole;
    private String name;
    private String filter;
    private byte type;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public UserRoleDTO getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRoleDTO userRole) {
        this.userRole = userRole;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }
}