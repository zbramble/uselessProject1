package org.mega.core.base;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseTanentEntity extends BaseEntity implements Serializable {

    @Column(name = "ACCESS_KEY", nullable = false, length = 40, updatable = false)
    private String accessKey;

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

}