package org.mega.core.usecase;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.usecaseaction.UseCaseAction;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_USECASE", uniqueConstraints = @UniqueConstraint(name = "PK_CO_UseCase", columnNames = "UseCase_ID"))
public class UseCase extends BaseEntity {
    @Id
    @Column(name = "USECASE_ID")
    private long rowId;

    @Column(name = "CLAZZ", nullable = true, length = 100)
    private String clazz;

    @Column(name = "CODE", nullable = true, length = 20)
    private String code;

    @Column(name = "TABLE_NAME", nullable = true, length = 100)
    private String tableName;

    @Column(name = "USECASE_NAME", nullable = false, length = 50)
    private String useCaseName;

    @Column(name = "HAS_CHILD", nullable = false, length = 1)
    private boolean hasChild;

    @ManyToOne
    @JoinColumn(name = "PARENT_ID", foreignKey = @ForeignKey(name = "FK_USEC_2_USEC__PARENT_ID"))
    private UseCase parent;

    @OneToMany(mappedBy = "parent")
    private List<UseCase> children;

    @OneToMany(mappedBy = "useCase", cascade = CascadeType.REMOVE)
    private List<UseCaseAction> useCaseActions;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getClazz() {
        return clazz;
    }

    public void setClazz(String clazz) {
        this.clazz = clazz;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getUseCaseName() {
        return useCaseName;
    }

    public void setUseCaseName(String useCaseName) {
        this.useCaseName = useCaseName;
    }

    public UseCase getParent() {
        return parent;
    }

    public void setParent(UseCase parent) {
        this.parent = parent;
    }

    public boolean getHasChild() {
        return hasChild;
    }

    public void setHasChild(boolean hasChild) {
        this.hasChild = hasChild;
    }

    public List<UseCase> getChildren() {
        return children;
    }

    public void setChildren(List<UseCase> children) {
        this.children = children;
    }

    public List<UseCaseAction> getUseCaseActions() {
        return useCaseActions;
    }

    public void setUseCaseActions(List<UseCaseAction> useCaseActions) {
        this.useCaseActions = useCaseActions;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = rowId + " " + useCaseName;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = rowId + " " + useCaseName;
    }
}