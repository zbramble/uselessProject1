package org.mega.core.usecase;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BusinessParam;
import org.mega.core.usecaseaction.UseCaseActionFacade;

import java.util.List;

public class UseCaseCopier extends BaseCopier<UseCase, UseCaseDTO> {

    @Override
    public UseCaseDTO copyFromEntity(UseCase usecase) {
        UseCaseDTO usecaseDTO = new UseCaseDTO();

        usecaseDTO.setRowId(usecase.getRowId());
        usecaseDTO.setClazz(usecase.getClazz());
        usecaseDTO.setCode(usecase.getCode());
        usecaseDTO.setTableName(usecase.getTableName());
        usecaseDTO.setUseCaseName(usecase.getUseCaseName());
        usecaseDTO.setHasChild(usecase.getHasChild());
        if (usecase.getParent() != null) {
            UseCaseDTO parent = new UseCaseDTO();
            parent.setRowId(usecase.getParent().getRowId());
            parent.setUseCaseName(usecase.getParent().getUseCaseName());
            usecaseDTO.setParent(parent);
        }
        if (usecase.getUseCaseActions() != null) {
            usecaseDTO.setUseCaseActions(
                    UseCaseActionFacade.getInstance().getCopier().copyFromEntity(usecase.getUseCaseActions()));
        }
        copyFromEntityBaseField(usecase, usecaseDTO);

        return usecaseDTO;
    }

    @Override
    public UseCase copyToEntity(UseCaseDTO usecaseDTO) throws Exception {
        UseCase usecase = new UseCase();
        if (usecaseDTO.getRowId() != 0)
            usecase = UseCaseFacade.getInstance().findEntityById(UseCase.class, usecaseDTO.getRowId(), BusinessParam.getSystemBusinessParam());
        usecase.setRowId(usecaseDTO.getRowId());
        usecase.setClazz(usecaseDTO.getClazz());
        usecase.setCode(usecaseDTO.getCode());
        usecase.setTableName(usecaseDTO.getTableName());
        usecase.setUseCaseName(usecaseDTO.getUseCaseName());
        usecase.setHasChild(usecaseDTO.isHasChild());
        if (usecaseDTO.getParent() != null) {
            UseCase parent = UseCaseFacade.getInstance().findEntityById(UseCase.class, usecaseDTO.getParent().getRowId(), BusinessParam.getSystemBusinessParam());
            usecase.setParent(parent);
        }
        if (usecaseDTO.getUseCaseActions() != null) {
            List newUsecaseActions = UseCaseActionFacade.getInstance().getCopier().copyToEntity(usecaseDTO.getUseCaseActions());
            usecase.getUseCaseActions().addAll(newUsecaseActions);
        }
        copyToEntityBaseField(usecase, usecaseDTO);

        return usecase;
    }
}