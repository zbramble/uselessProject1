package org.mega.core.userroledataaccess;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class UserRoleDataAccessFacade extends BaseFacade {
    private static UserRoleDataAccessCopier copier = new UserRoleDataAccessCopier();
    private static UserRoleDataAccessFacade facade = new UserRoleDataAccessFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static UserRoleDataAccessFacade getInstance() {
        return facade;
    }
}