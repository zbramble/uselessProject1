
package org.mega.core.organization;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;

@Entity
@Table(name = "CO_ORGANIZATION", uniqueConstraints = @UniqueConstraint(name = "PK_CO_ORGANIZATION", columnNames = "ORGANIZATION_ID"))
public class Organization extends BaseEntity {
    @Id
    @Column(name = "ORGANIZATION_ID")
    private long rowId;

    @Column(name = "NAME", length = 160)
    private String name;

    @Column(name = "ESTABLISHING_YEAR")
    private long establishingYear;

    @ManyToOne()
    @JoinColumn(name = "PARENT_ORG_ID", foreignKey = @ForeignKey(name = "FK_ORG_2_ORG__PARENT_ORG_ID"))
    private Organization parentOrg;

    @ManyToOne()
    @JoinColumn(name = "ORG_STATUS_ID", foreignKey = @ForeignKey(name = "FK_ORG_2_COM__ORGSTATUS_ID"))
    private ComboVal orgStatus;

    @ManyToOne()
    @JoinColumn(name = "TYPE_ID", foreignKey = @ForeignKey(name = "FK_ORG_2_COM__TYPE_ID"))
    private ComboVal type;

    @ManyToOne()
    @JoinColumn(name = "ORG_GRADE_ID", foreignKey = @ForeignKey(name = "FK_ORG_2_COM__ORG_GRADE_ID"))
    private ComboVal orgGrade;

    @Column(name = "ORDERR")
    private long orderr;

    @Column(name = "LONGITUDE")
    private long longitude;

    @Column(name = "LATITUDE")
    private long latitude;

    @Column(name = "IMAGENAME", length = 100)
    private String imageName;

    @Column(name = "TEL", length = 15)
    private String tel;

    @Column(name = "FAX", length = 15)
    private String fax;

    @Column(name = "ADDRESS", length = 400)
    private String address;

    @Column(name = "DESCRIPTION", length = 400)
    private String description;

    @Column(name = "ACCESS_KEY", length = 50, updatable=false)
    private String accessKey;

    @Column(name = "CODE", length = 50)
    private String code;

    @ManyToOne()
    @JoinColumn(name = "OWNERSHIP_TYPE_ID", foreignKey = @ForeignKey(name = "FK_ORG_2_COM__OWNERSHI_TYPE_ID"))
    private ComboVal ownershipType;

    @ManyToOne()
    @JoinColumn(name = "ROAD_TYPE_ID", foreignKey = @ForeignKey(name = "FK_ORG_2_COM__ROAD_TYPE_ID"))
    private ComboVal roadType;

    @Column(name = "FULL_NAME", length = 800)
    private String fullName;

    @Column(name = "LOGO_IMAGE")
    @Lob
    private byte[] logoImage;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getEstablishingYear() {
        return establishingYear;
    }

    public void setEstablishingYear(long establishingYear) {
        this.establishingYear = establishingYear;
    }

    public Organization getParentOrg() {
        return parentOrg;
    }

    public void setParentOrg(Organization parentOrg) {
        this.parentOrg = parentOrg;
    }

    public ComboVal getOrgStatus() {
        return orgStatus;
    }

    public void setOrgStatus(ComboVal orgStatus) {
        this.orgStatus = orgStatus;
    }

    public ComboVal getType() {
        return type;
    }

    public void setType(ComboVal type) {
        this.type = type;
    }

    public ComboVal getOrgGrade() {
        return orgGrade;
    }

    public void setOrgGrade(ComboVal orgGrade) {
        this.orgGrade = orgGrade;
    }

    public long getOrderr() {
        return orderr;
    }

    public void setOrderr(long orderr) {
        this.orderr = orderr;
    }

    public long getLongitude() {
        return longitude;
    }

    public void setLongitude(long longitude) {
        this.longitude = longitude;
    }

    public long getLatitude() {
        return latitude;
    }

    public void setLatitude(long latitude) {
        this.latitude = latitude;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAccessKey() {
        return accessKey == null ? "" : accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ComboVal getOwnershipType() {
        return ownershipType;
    }

    public void setOwnershipType(ComboVal ownershipType) {
        this.ownershipType = ownershipType;
    }

    public ComboVal getRoadType() {
        return roadType;
    }

    public void setRoadType(ComboVal roadType) {
        this.roadType = roadType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public byte[] getLogoImage() {
        return logoImage;
    }

    public void setLogoImage(byte[] logoImage) {
        this.logoImage = logoImage;
    }

    @PrePersist
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = name;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = name;
    }
}