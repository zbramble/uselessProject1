package org.mega.core.person;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "CO_PERSON", uniqueConstraints = @UniqueConstraint(name = "PK_CO_PERSON", columnNames = "PERSON_ID"))
public class Person extends BaseEntity {
    @Id
    @Column(name = "PERSON_ID")
    private long rowId;

    @Column(name = "NATIONAL_ID", length = 10, unique = true)
    private String nationalId;

    @Column(name = "FIRST_NAME", length = 50)
    private String firstName;

    @Column(name = "LAST_NAME", length = 50)
    private String lastName;

    @Column(name = "FATHER_NAME", length = 50)
    private String fatherName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "BIRTH_DATE")
    private Date birthDate;

    @Column(name = "BIRTH_PLACE", length = 50)
    private String birthPlace;

    @Column(name = "BLOOD_TYPE", length = 5)
    private String bloodType;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = firstName + " " + lastName + " (" + nationalId + ")";
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = firstName + " " + lastName + " (" + nationalId + ")";
    }
}