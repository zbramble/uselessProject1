package org.mega.core.role;

import org.mega.core.accessgrp.AccessGrpDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.userrole.UserRoleDTO;

import java.util.List;

public class RoleDTO extends BaseDTO {
    private long rowId;
    private String code;
    private String roleName;
    private long expireMinute;
    private List<UserRoleDTO> userRoles;
    private List<AccessGrpDTO> accessGrps;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public long getExpireMinute() {
        return expireMinute;
    }

    public void setExpireMinute(long expireMinute) {
        this.expireMinute = expireMinute;
    }

    public List<UserRoleDTO> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRoleDTO> userRoles) {
        this.userRoles = userRoles;
    }

    public List<AccessGrpDTO> getAccessGrps() {
        return accessGrps;
    }

    public void setAccessGrps(List<AccessGrpDTO> accessGrps) {
        this.accessGrps = accessGrps;
    }
}