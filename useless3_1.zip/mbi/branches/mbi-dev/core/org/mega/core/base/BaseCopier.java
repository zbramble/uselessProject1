package org.mega.core.base;

import org.mega.core.user.UserDTO;
import org.mega.util.DateUtil;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseCopier<E extends BaseEntity, D extends BaseDTO> {

    public abstract D copyFromEntity(E e);

    public abstract E copyToEntity(D d) throws Exception;

    public E copyToEntity(D d, BusinessParam businessParam) throws Exception {
        E e = copyToEntity(d);
        return e;
    }

    public List<D> copyFromEntity(List<E> es) {
        List<D> list = new ArrayList<>(es.size());
        for (E e : es) {
        	if(e.getDeleted() == 0 && e.isActive())
        		list.add(copyFromEntity(e));
        }
        return list;
    }

    public List<E> copyToEntity(List<D> ds) throws Exception {
        List<E> list = new ArrayList<>(ds.size());
        for (D d : ds) {
       		list.add(copyToEntity(d));
        }
        return list;
    }

    protected void copyFromEntityBaseField(BaseEntity e, BaseDTO d) {
        UserDTO userDtoCB = new UserDTO();
        userDtoCB.setRowId(e.getCreatedBy().getRowId());
        userDtoCB.setUsername(e.getCreatedBy().getUsername());
        userDtoCB.setFullName(e.getCreatedBy().getFullName());
        userDtoCB.setCompanyName(e.getCreatedBy().getCompanyName());
        d.setCreatedBy(userDtoCB);

        UserDTO userDtoUB = new UserDTO();
        userDtoUB.setRowId(e.getUpdatedBy().getRowId());
        userDtoUB.setUsername(e.getUpdatedBy().getUsername());
        userDtoUB.setFullName(e.getUpdatedBy().getFullName());
        userDtoUB.setCompanyName(e.getUpdatedBy().getCompanyName());
        d.setUpdatedBy(userDtoUB);

        d.setCreated(DateUtil.getDateString(e.getCreated(), "en"));
        d.setUpdated(DateUtil.getDateString(e.getUpdated(), "en"));
        d.setActive(e.isActive());
        d.setFullTitle(e.getFullTitle());
    }

    protected void copyToEntityBaseField(BaseEntity e, BaseDTO d) {
        //UpdateBy, Updated sets in facade
        e.setActive(d.isActive());
    }
}