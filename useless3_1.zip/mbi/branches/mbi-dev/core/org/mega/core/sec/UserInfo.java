package org.mega.core.sec;

import java.util.Map;

public class UserInfo {
    private static UserMenuCreatorI userMenuCreator = null;

    private long userId;
    private long orgId;
	private String orgName;
    private String fullName;
    private boolean active;
    private String companyName;
    private String userPassword;
    private String username;
    private long roleId;
    private String roleName;
    private String accessKey;
    private String firstPageURL;
    private String ticket;
    private String lang;
    private long expireMinute;
    private long userRoleId;
	private Map<String, Integer> access;
	private String menuTree;
	private String menuData;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }
    public long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(long userRoleId) {
		this.userRoleId = userRoleId;
	}

    public long getOrgId() {
        return orgId;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public long getRoleId() {
        return roleId;
    }

    public void setRoleId(long roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getAccessKey() {
        return accessKey == null ? "" : accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getFirstPageURL() {
        return firstPageURL;
    }

    public void setFirstPageURL(String firstPageURL) {
        this.firstPageURL = firstPageURL;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public long getExpireMinute() {
        return expireMinute;
    }

    public void setExpireMinute(long expireMinute) {
        this.expireMinute = expireMinute;
    }

	public void setAccess(Map<String, Integer> access, UserMenuCreatorI userMenuCreator) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		this.access = access;
        
		UserMenuCreatorI userMenuCreatorFilled = userMenuCreator.init(this);
		this.setMenuTree(userMenuCreatorFilled.getMenuTree());
		this.setMenuData(userMenuCreatorFilled.getMenuData());
	}

	public Map<String, Integer> getAccess() {
		return access;
	}

	public String getMenuTree() {
		return menuTree;
	}

	private void setMenuTree(String menuTree) {
		this.menuTree = menuTree;
	}

	public String getMenuData() {
		return menuData;
	}

	private void setMenuData(String menuData) {
		this.menuData = menuData;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
}
