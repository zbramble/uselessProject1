package org.mega.core.userrole;

import org.mega.core.base.BaseDTO;
import org.mega.core.organization.OrganizationDTO;
import org.mega.core.role.RoleDTO;
import org.mega.core.user.UserDTO;

public class UserRoleDTO extends BaseDTO {
    private long rowId;
    private String code;
    private OrganizationDTO organization;
    private RoleDTO role;
    private UserDTO user;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public OrganizationDTO getOrganization() {
        return organization;
    }

    public void setOrganization(OrganizationDTO organization) {
        this.organization = organization;
    }

    public RoleDTO getRole() {
        return role;
    }

    public void setRole(RoleDTO role) {
        this.role = role;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }
}