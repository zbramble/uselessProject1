package org.mega.core.role;

import org.mega.core.base.BaseDTO;


import java.util.List;

public class MasterRoleDTO extends BaseDTO {
    private RoleDTO role;
    private List<String> listChild;
    private List<String> listId;

    public RoleDTO getRole() {
        return role;
    }

    public void setRole(RoleDTO role) {
        this.role = role;
    }

    public List<String> getListChild() {
        return listChild;
    }

    public void setListChild(List<String> listChild) {
        this.listChild = listChild;
    }

    public List<String> getListId() {
        return listId;
    }

    public void setListId(List<String> listId) {
        this.listId = listId;
    }

    @Override
    public long getRowId() {
        return 0;
    }
}