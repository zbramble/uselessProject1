package org.mega.core.accessgrp;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.role.Role;
import org.mega.core.usecaseaction.UseCaseAction;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_ACCESS_GRP", uniqueConstraints = @UniqueConstraint(name = "PK_CO_ACCESS_GRP", columnNames = "ACCESS_GRP_ID"))
public class AccessGrp extends BaseEntity {
    @Id
    @Column(name = "ACCESS_GRP_ID")
    private long rowId;

    @Column(name = "CODE", nullable = true)
    private String code;

    @Column(name = "NAME", nullable = false, length = 100)
    private String name;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "CO_ACCESS_GRP_UseCase_ACT"
            , joinColumns = {@JoinColumn(name = "ACCESS_GRP_ID", foreignKey = @ForeignKey(name = "FK_ACC_GRP_USE_ACT__ACC_GRP_I"))}
            , inverseJoinColumns = {@JoinColumn(name = "UseCase_ACTION_ID", foreignKey = @ForeignKey(name = "FK_ACC_GRP_USE_ACT__USE_ACT_I"))})
    private List<UseCaseAction> UseCaseActions;

    @ManyToMany
    @JoinTable(name = "CO_ROLE_ACCESS_GRP"
            , joinColumns = {@JoinColumn(name = "ACCESS_GRP_ID", foreignKey = @ForeignKey(name = "FK_ACC_GR_2_ROL_ACC_GR__A_G_I"))}
            , inverseJoinColumns = {@JoinColumn(name = "ROLE_ID", foreignKey = @ForeignKey(name = "FK_ROL_2_ROL_ACC_GRP__ROLE_ID"))})
    private List<Role> roles;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<UseCaseAction> getUseCaseActions() {
        return UseCaseActions;
    }

    public void setUseCaseActions(List<UseCaseAction> useCaseActions) {
        UseCaseActions = useCaseActions;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = name;
    }

	@Override
	public void preUpdate() throws Exception {
        fullTitle = name;
	}
}