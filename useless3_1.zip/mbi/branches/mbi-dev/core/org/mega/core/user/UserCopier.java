package org.mega.core.user;

import org.mega.core.base.BaseCopier;
import org.mega.core.person.Person;
import org.mega.core.person.PersonDTO;
import org.mega.core.userrole.UserRoleFacade;

public class UserCopier extends BaseCopier<User, UserDTO> {
    @Override
    public UserDTO copyFromEntity(User user) {
        UserDTO userDTO = new UserDTO();

        userDTO.setRowId(user.getRowId());
        userDTO.setFullName(user.getFullName());
        userDTO.setCompanyName(user.getCompanyName());
        userDTO.setUsername(user.getUsername());
        userDTO.setActive(user.isActive());
        userDTO.setAccessKey(user.getAccessKey());
        userDTO.setEmail(user.getEmail());
        userDTO.setEmailIsConfirmed(user.isEmailIsConfirmed());
        copyFromEntityBaseField(user, userDTO);

        return userDTO;
    }

    @Override
    public User copyToEntity(UserDTO userDTO) {
        User user = new User();

        user.setRowId(userDTO.getRowId());
        user.setAccessKey(userDTO.getAccessKey());
        user.setFullName(userDTO.getFullName());
        user.setCompanyName(userDTO.getCompanyName());
        user.setUsername(userDTO.getUsername());
        if (userDTO.getUserPassword() != "") {
            user.setUserPassword(userDTO.getUserPassword());
        }
        user.setEmail(userDTO.getEmail());
        user.setEmailIsConfirmed(userDTO.isEmailIsConfirmed());
        copyToEntityBaseField(user, userDTO);

        return user;
    }
}