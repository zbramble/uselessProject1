package org.mega.core.sec;

import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.ServiceResult;
import org.mega.util.ExpireCache;

public class UserSessionManager {
    static ExpireCache sessions;

    static {
        sessions = ExpireCache.getInstance("Sessions", 15 * 60, new UserExpire());
        sessions.setMaxSize(0);//Infinite size
    }

    /**
     * After login and select user role; user Info and its accesses add to UserSessionManager
     * @param userInfo
     */
    public static void add(UserInfo userInfo) {
        StringBuilder ticket = new StringBuilder("t").append(userInfo.getUsername()).append("|").append(System.nanoTime());
        userInfo.setTicket(ticket.toString());
        sessions.put(userInfo.getUsername(), new UserSession(userInfo));
    }

    /**
     * Remove user session
     *
     * @param ticket
     * @param callRemoveAwares Call remove awares or not
     * @return
     */
    public static UserSession del(String ticket, boolean callRemoveAwares) {
        String userName = ticket.substring(1, ticket.indexOf("|"));
        if (callRemoveAwares)
            return (UserSession) sessions.removeAndCallAwares(userName);
        else
            return (UserSession) sessions.removeWithoutCallAwares(userName);
    }

    public static UserSession getUserSession(String ticket) throws Exception {
        UserSession userSession = (UserSession) sessions.get(ticket.substring(1, ticket.indexOf("|")));
        if (userSession == null)
            throw new Exception("" + ServiceResult.ERROR_CODE.USER_EXPIRED);
        return userSession;
    }

    public static boolean hasAccess(String ticket, String entityPoorName, ACTION action) {
        UserSession userSession = (UserSession) sessions.get(ticket.substring(1, ticket.indexOf("|")));
        return userSession.hasAccess(entityPoorName, action.ordinal());
    }

    /**
     * Check access of user to a action on an entity.
     * If UserSession object in a program can be use, do not use this method.
     *
     * @param ticket
     * @param entityPoorName
     * @param action
     * @throws Exception
     */
    public static void checkAccess(String ticket, String entityPoorName, ACTION action) throws Exception {
        UserSession userSession = (UserSession) sessions.get(ticket.substring(1, ticket.indexOf("|")));
        if (!userSession.hasAccess(entityPoorName, action.ordinal()))
            throw new Exception("Access denied:" + entityPoorName + ':' + action);
    }
}