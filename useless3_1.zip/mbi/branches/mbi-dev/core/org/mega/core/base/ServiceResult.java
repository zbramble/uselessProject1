package org.mega.core.base;

import java.io.Serializable;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.mega.core.util.ExceptionUtil;

public class ServiceResult implements Serializable {
    private static final long serialVersionUID = -7995464602079701679L;

    public ServiceResult() {
    }

    public static enum ERROR_CODE {
        DB_GENERAL,
        DB_TRANSACTION,
        UNKNOWN,
        IS_NULL,
        USER_EXPIRED,
        DUPLICATE,
        INVALID_FILTER_PARAMETER,
        BUSINESS_MESSAGE,
        DIDNOT_MATCH_PASSWORD,
        LOCK_USER, CONSTRAINT_VIOLATION, ACCESS_DENIED, EMAIL_IS_INVLID,
        IMPORT_ERROR
    }

    boolean done = true;
    ERROR_CODE errorCode;
    long resultCountAll;

    String errorDesc;
    String errorTrace;
    Object result;

    public ServiceResult(Object result, long resultCountAll) {
        this.done = true;
        this.result = result;
        this.resultCountAll = resultCountAll;
    }

    public ServiceResult(ERROR_CODE errorCode, String errorDesc, String errorTrace) {
        this.done = false;
        this.errorCode = errorCode;
        this.errorDesc = errorDesc;
        this.errorTrace = errorTrace;
    }

    public ServiceResult(ERROR_CODE errorCode, String errorDesc, Exception e) {
        this.done = false;
        this.errorCode = ExceptionUtil.getErrorCode(errorCode, e);
        this.errorDesc = ExceptionUtil.getMessage(e);
        this.errorTrace = ExceptionUtils.getStackTrace(e);
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public ERROR_CODE getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(ERROR_CODE errorCode) {
        this.errorCode = errorCode;
    }

    public long getResultCountAll() {
        return resultCountAll;
    }

    public void setResultCountAll(long resultCountAll) {
        this.resultCountAll = resultCountAll;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }

    public String getErrorTrace() {
        return errorTrace;
    }

    public void setErrorTrace(String errorTrace) {
        this.errorTrace = errorTrace;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }


}
