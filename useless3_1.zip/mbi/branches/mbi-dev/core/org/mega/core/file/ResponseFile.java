package org.mega.core.file;

import javax.ws.rs.core.StreamingOutput;

public class ResponseFile {
    StreamingOutput fileStream;
    String type;

    public ResponseFile() {
    }

    public ResponseFile(StreamingOutput fileStream, String type) {
        this.fileStream = fileStream;
        this.type = type;
    }

    public StreamingOutput getFileStream() {
        return fileStream;
    }

    public void setFileStream(StreamingOutput fileStream) {
        this.fileStream = fileStream;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
