package org.mega.core.userrole;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.organization.Organization;
import org.mega.core.role.Role;
import org.mega.core.user.User;
import org.mega.core.userroledataaccess.UserRoleDataAccess;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "CO_USER_ROLE", uniqueConstraints = @UniqueConstraint(name = "PK_CO_USER_ROLE", columnNames = "USER_ROLE_ID"))
public class UserRole extends BaseEntity {
    @Id
    @Column(name = "USER_ROLE_ID")
    private long rowId;

    @Column(name = "CODE", nullable = true, length = 20)
    private String code;

    @Column(name = "ORGS_ACCESS", nullable = true, length = 1000)
    private String orgAccess;

    @ManyToOne
    @JoinColumn(name = "ORGANIZATION_ID", foreignKey = @ForeignKey(name = "FK_USE_ROL_2_ORG__ORG_ID"), nullable=false)
    private Organization organization;

    @ManyToOne
    @JoinColumn(name = "ROLE_ID", foreignKey = @ForeignKey(name = "FK_USER_ROLE_2_ROLE__ROLE_ID"), nullable=false)
    private Role role;

    @ManyToOne
    @JoinColumn(name = "USER_ID", foreignKey = @ForeignKey(name = "FK_USER_ROLE_2_USER__USER_ID"), nullable=false)
    private User user;

    @OneToMany(mappedBy = "userRole")
    private List<UserRoleDataAccess> userRoleDataAccesses;

    public long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getOrgAccess() {
        return orgAccess;
    }

    public void setOrgAccess(String orgAccess) {
        this.orgAccess = orgAccess;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<UserRoleDataAccess> getUserRoleDataAccesses() {
        return userRoleDataAccesses;
    }

    public void setUserRoleDataAccesses(List<UserRoleDataAccess> userRoleDataAccesses) {
        this.userRoleDataAccesses = userRoleDataAccesses;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = rowId + "";
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = rowId + "";
    }
}