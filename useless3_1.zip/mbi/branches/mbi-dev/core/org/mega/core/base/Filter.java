package org.mega.core.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Filter implements Serializable {
    private static final long serialVersionUID = 9093450507907276969L;
    int pageSize = 10;
    int pageNo = 1;
    String ticket;

    List<PairValue> params = new ArrayList<PairValue>();

    public List<PairValue> getParams() {
        return params;
    }

    public void setParams(List<PairValue> params) {
        this.params = params;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }
}