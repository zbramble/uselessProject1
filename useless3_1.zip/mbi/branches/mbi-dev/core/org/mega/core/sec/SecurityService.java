package org.mega.core.sec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BaseService;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.user.UserDTO;
import org.mega.core.user.UserFacade;
import org.mega.util.TextUtil;
import org.mega.util.WebUtil;


@Path("/security")
public class SecurityService extends BaseService {
    Logger logger = BaseLogger.getLogger(SecurityService.class);
	private UserMenuCreatorI userMenuCreator;
    /**
     * @param loginDTO
     * @return List of user roles, Each role related to only one organization
     */
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult login(LoginDTO loginDTO) {
        //System.out.println( request.getHeader("Refere"));
        try {
            BaseLogger.getLogger().info("Try to login:" + loginDTO.getUsername());
            BaseDB db = null;
            try {
                db = BaseDB.open("SecurityService.login");
                String pass = TextUtil.encryptPass(loginDTO.getPassword());
                /*
                 * userName exist but password is invalid
                 * lock user
                 */
                Query query = db.createNativeQuery("select USER_PASSWORD,FAILED_LOGIN,is_active from co_user where username=:name ");
                query.setParameter("name", loginDTO.getUsername());
                if(query.getResultList().size() > 0){
                	List<Object[]> list = (List<Object[]>) query.getResultList();
                	for (Object[] row2 : list) {
                		String password = (String) row2[0];
                		long number = ((BigDecimal) row2[1]).longValue();
                		long isActive = ((BigDecimal) row2[2]).longValue();
                		if(!pass.equals(password)){
                    		//lock user
                			if(number >= 3){
                				db.runNativeQuery("update co_user set is_active = 0 where username='"+loginDTO.getUsername()+"'");
                				db.commitAndclose();
                        		return new ServiceResult(ServiceResult.ERROR_CODE.LOCK_USER, "User Locked","User Locked");

                			}else{
                				db.runNativeQuery("update co_user set FAILED_LOGIN = "+(number+1)+" where username='"+loginDTO.getUsername()+"'");
                				db.commitAndclose();
                				return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Invalid User Name Or Password", "");
                			}
                		}else if(isActive == 1){
                			db.runNativeQuery("update co_user set FAILED_LOGIN = 0 where username='"+loginDTO.getUsername()+"'");
                			query = db.createNativeQuery(
                                    new StringBuilder().append(
                                            "select u.USER_ID,u.FULL_NAME,u.COMPANY_NAME,u.USERNAME, ur.ROLE_ID as role_id, r.role_name, org.ORGANIZATION_ID,org.name, org.access_key, org.RICH_USER_URL, org.POOR_USER_URL from ")
                                            .append("	(select USER_ID,FULL_NAME,COMPANY_NAME,USERNAME from CO_USER where USERNAME =:name and user_password=:pass and is_active=1 and is_deleted=0) u ")
                                            .append("	join CO_USER_ROLE ur on (u.USER_ID = ur.USER_ID and ur.is_active=1 and ur.is_deleted=0) ")
                                            .append("	join CO_ROLE r on (ur.ROLE_ID = r.ROLE_ID  and r.is_active=1 and r.is_deleted=0) ")
                                            .append("	join CO_ORGANIZATION org on(org.ORGANIZATION_ID = ur.ORGANIZATION_ID and org.is_active=1 and org.is_deleted=0) ")
                                            .append("	--where rownum = 1 ").toString()
                            );
                            
                            query.setParameter("name", loginDTO.getUsername());
                            query.setParameter("pass", pass);
                
                            List<Object[]> ret = (List<Object[]>) query.getResultList();
                            //if(ret.size() == 0)
                                //return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Login fail", "");
                            
                            List<UserInfo> userInfos = new ArrayList<UserInfo>(ret.size());

                            for (Object[] row : ret) {
                                UserInfo userInfo = new UserInfo();
                                userInfo.setUserId(((BigDecimal) row[0]).longValue());
                                userInfo.setUsername("???");
                                userInfo.setUserPassword("???");
                                userInfo.setRoleId(((BigDecimal) row[4]).longValue());
                                userInfo.setRoleName((String) row[5]);
                                userInfo.setOrgId(((BigDecimal) row[6]).longValue());
                                userInfo.setOrgName((String) row[7]);
                                userInfo.setLang(loginDTO.getLang());
                                userInfos.add(userInfo);
                            }
                            db.commitAndclose();
                             return new ServiceResult(userInfos, 1);
                		}else if(isActive == 0){
                			db.commitAndclose();
                    		return new ServiceResult(ServiceResult.ERROR_CODE.LOCK_USER, "User Locked","User Locked");
                		}
                	}
                	
                }
            	db.commitAndclose();
            	 return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Login fail", "");
                	
                	
            } catch (Exception e) {
                db.finalize();
                if (e instanceof javax.persistence.NoResultException)
                    return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Login fail", "");

                logger.error("Error: saveEntity ", e);
                throw new Exception("Error in login", e);
            }
        } catch (Exception e) {
            BaseLogger.getLogger().info("Error in login MerchantDTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Login fail", e);
        }

    }

    /**
     * After login method call, selected user info passed to this method to finalizing login process.
     * This method can use individually for login. These fields of userInfo is mandatory for login: userId, name, pass, roleId, orgId
     *
     * @param userInfo
     * @return
     */
    @POST
    @Path("/selectUserRole")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult selectUserRole(UserInfo userInfo) {
        try {
            BaseLogger.getLogger().info("Select User role:" + userInfo.getUsername());
            BaseDB db = null;
            try {
                db = BaseDB.open("SecurityService.login");

                Query query = db.createNativeQuery(
                        new StringBuilder().append(
                                "select u.USER_ID,u.FULL_NAME,u.COMPANY_NAME,u.USERNAME, ur.ROLE_ID as role_id, r.role_name, org.ORGANIZATION_ID,org.name, org.access_key, org.RICH_USER_URL, org.POOR_USER_URL, r.expire_minute, ur.user_role_id  from ")
                                .append("	(select USER_ID,FULL_NAME,COMPANY_NAME,USERNAME,person_id from CO_USER where USER_ID=:userId and USERNAME =:name and user_password=:pass and is_active=1 and is_deleted=0) u ")
                                .append("	join CO_USER_ROLE ur on (ur.ROLE_ID =:roleId and u.USER_ID = ur.USER_ID and ur.is_active=1 and ur.is_deleted=0) ")
                                .append("	join CO_ROLE r on (ur.ROLE_ID = r.ROLE_ID and r.is_active=1 and r.is_deleted=0) ")
                                .append("	join CO_ORGANIZATION org on(org.ORGANIZATION_ID =:orgId and org.ORGANIZATION_ID = ur.ORGANIZATION_ID and org.is_active=1 and org.is_deleted=0) ")
                                .append("	 ")
                                .append("	where rownum =1 ").toString()
                );
                String pass= TextUtil.encryptPass(userInfo.getUserPassword());
                query.setParameter("userId", userInfo.getUserId());
                query.setParameter("name", userInfo.getUsername());
                query.setParameter("pass", pass);
                query.setParameter("roleId", userInfo.getRoleId());
                query.setParameter("orgId", userInfo.getOrgId());

                Object[] row = (Object[]) query.getSingleResult();

                userInfo.setUserId(((BigDecimal) row[0]).longValue());
                userInfo.setFullName((String) row[1]);
                userInfo.setCompanyName((String) row[2]);
                userInfo.setUsername((String) row[3]);
                userInfo.setRoleId(((BigDecimal) row[4]).longValue());
                userInfo.setRoleName((String) row[5]);
                userInfo.setOrgId(((BigDecimal) row[6]).longValue());
                userInfo.setOrgName((String) row[7]);
                userInfo.setAccessKey((String) row[8]);
                userInfo.setLang(userInfo.getLang());

                String richUserURL = (String) row[9];
                String poorUserURL = (String) row[10];
                if (userInfo.getRoleId() == SystemConfig.POOR_USER_ROLE_ID)
                    userInfo.setFirstPageURL(poorUserURL);
                else
                    userInfo.setFirstPageURL(richUserURL);

                BigDecimal expireMinute = (BigDecimal) row[11];
                if(expireMinute== null || expireMinute.longValue() == 0)
                	userInfo.setExpireMinute(SystemConfig.USER_EXPIRE_MINUTE);
                else
                	userInfo.setExpireMinute(expireMinute.longValue());
                userInfo.setUserRoleId(((BigDecimal) row[12]).longValue());
                userInfo.setUserPassword("");

                setUserInfoAccessFields(db, userInfo);

                UserSessionManager.add(userInfo);
                
                db.commitAndclose();
                return new ServiceResult(userInfo, 1);
            } catch (Exception e) {
                db.finalize();
                if (e instanceof javax.persistence.NoResultException)
                    return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Login failed", "");

                logger.error("Error: saveEntity ", e);
                throw new Exception("Error in login", e);
            }
        } catch (Exception e) {
            BaseLogger.getLogger().info("Error in login MerchantDTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Login fail", e);
        }

    }

    /**
     * @param db
     * @param userInfo
     * @return  User accesses to Use cases and its actions
     * @throws Exception
     */
	private void setUserInfoAccessFields(BaseDB db, UserInfo userInfo) throws Exception {
	    //If system configed that dont check any things all usecase and actions loaded 
	    String  userRoleFilter = SystemConfig.CHECK_ACCESSES ? " and ur.USER_ROLE_ID = '"+ userInfo.getUserRoleId() + "' " : "";

	    String sql = "select CLAZZ, USECASE_NAME,USECASE_ID, sum(p) as accesses " +
			  " from ( " +
				"select distinct u.CLAZZ,u.USECASE_NAME, u.USECASE_ID, ua.ACTION_ID, power(2,ua.ACTION_ID) as p from CO_USER_ROLE ur " +
					" join CO_ROLE_ACCESS_GRP rg on(rg.ROLE_ID = ur.ROLE_ID and  ur.IS_ACTIVE = 1 and ur.IS_DELETED = 0 " + userRoleFilter +") " +
					" join CO_ACCESS_GRP_USECASE_ACT g on(g.ACCESS_GRP_ID = rg.ACCESS_GRP_ID)" +
					" join CO_USECASE_ACTION ua on(ua.USECASE_ACTION_ID = g.USECASE_ACTION_ID and ua.is_active = 1 and ua.IS_DELETED = 0) " +
					" join CO_USECASE u on(u.USECASE_ID = ua.USECASE_ID and u.is_active = 1 and u.IS_DELETED = 0)" +
				" )	group by CLAZZ, USECASE_NAME,USECASE_ID";
		
		Query query = db.createNativeQuery(sql);
		List<Object[]> rows = (List<Object[]>) query.getResultList();
		Map<String, Integer> access = new HashMap<String, Integer>();
		for(Object[] row : rows){
			access.put((String)row[0], ((BigDecimal)row[3]).intValue());
		}
		
        if(userMenuCreator == null)
        	userMenuCreator = (UserMenuCreatorI)Class.forName("org.mega.core.sec.UserMenuCreator").newInstance();
			
		userInfo.setAccess(access, userMenuCreator);
	}

    @POST
    @Path("/logout")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult logout(PairValue ticketPair) {
        String ticket = ticketPair.getValue();
        try {
            String userName = ticket.substring(1, ticket.indexOf("|"));

            BaseLogger.getLogger().info("Try to logout:" + userName);
            UserSessionManager.del(ticket, true);
            return new ServiceResult(true, 1);
        } catch (Exception e) {
            BaseLogger.getLogger().error("Error in loginout ticket:" + ticket, e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Logout failed", e);
        }
    }
    
    /**
     * Get user use case accesses and menu data
     * @param db
     * @param userInfo
     * @return
     */
    private Map<String, Object> getAccess(BaseDB db, UserInfo userInfo) {
    	
    	Map<String,Object> ret = new HashMap<String, Object>(3);
    	try {
    		UserSession userSession =  UserSessionManager.getUserSession(userInfo.getTicket());
    		Map<String, Integer> usercaseAction = getUsercaseAction(db, userInfo);
    		ret.put("access" , usercaseAction);
    		if(userMenuCreator == null)
    			userMenuCreator = (UserMenuCreatorI)Class.forName("org.mega.core.sec.UserMenuCreator").newInstance();
			String menuTree = userMenuCreator.getMenuTree();//(userInfo, usercaseAction);
    		String menuData = userMenuCreator.getMenuData();//IOUtil.readAndCloseStream(getClass().getClassLoader().getResourceAsStream("/org/mega/core/sec/menuData.json"), "utf-8");
    		ret.put("menuData" ,menuData);
    		ret.put("menuTree" ,menuTree);
    		return ret;
    	} catch (Exception e) {
    		BaseLogger.getLogger().error("Error in access method:" + userInfo.getTicket(), e);
    		ret.put("error", e.getMessage());
    		return ret;
    	}
    }

    /**
     * @param db
     * @param userInfo
     * @return User access to Use case and its actions
     * @throws Exception
     */
	private HashMap<String, Integer> getUsercaseAction(BaseDB db, UserInfo userInfo) throws Exception {
		String sql = "select CLAZZ, USECASE_NAME,USECASE_ID, sum(p) as accesses " +
			  " from ( " +
				"select distinct u.CLAZZ,u.USECASE_NAME, u.USECASE_ID, ua.ACTION_ID, power(2,ua.ACTION_ID) as p from CO_USER_ROLE ur " +
					" join CO_ROLE_ACCESS_GRP rg on(rg.ROLE_ID = ur.ROLE_ID and ur.USER_ROLE_ID = '"+ userInfo.getUserRoleId() + "' ) " +
					" join CO_ACCESS_GRP_USECASE_ACT g on(g.ACCESS_GRP_ID = rg.ACCESS_GRP_ID)" +
					" join CO_USECASE_ACTION ua on(ua.USECASE_ACTION_ID = g.USECASE_ACTION_ID and ua.is_active = 1 and ua.IS_DELETED = 0) " +
					" join CO_USECASE u on(u.USECASE_ID = ua.USECASE_ID and u.is_active = 1 and u.IS_DELETED = 0)" +
				" )	group by CLAZZ, USECASE_NAME,USECASE_ID";
			Query query = db.createNativeQuery(sql);
			List<Object[]> row = (List<Object[]>) query.getResultList();
		return new HashMap<String, Integer>();
	}
	
    @POST
    @Path("/forgetPassword")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult forgetPassword(Map<String,String> params) {
    	String userName= null;
    	BaseDB db = null;
        try {
        	userName = params.get("userName");
        	String email = params.get("email");
        	String activeCode = params.get("activeCode");
        	String password = params.get("password");
        	String repassword = params.get("repassword");
        	
        	BaseLogger.getLogger().info("Forgot password:" + userName);
        	db=BaseDB.open("forgot password");
        	if(activeCode != null && activeCode.length() >5){//reset password
        		password = TextUtil.encryptPass(params.get("password"));
	        	int ret = db.runNativeQuery("update co_user set USER_PASSWORD='"+password+"' where username='" + userName + "' and ACTIVE_CODE='" + activeCode + "' and email='"+ email+"' and ACTIVE_CODE_TIME>sysdate - (1/96)");
	    		
	        	db.commitAndclose();
	        	if(ret > 0)
	        		return new ServiceResult(2, 1);//password changed
	        	else
	        		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_ACTIVATION", "Data isnt valid");
        	}
        	Query query = db.createNativeQuery("select email from co_user where username=:username");
        	query.setParameter("username", userName);
        	String rm = (String) query.getSingleResult();
        	
        	if(rm.isEmpty() || !rm.equals(email)){
            	db.commitAndclose();
                return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email doesnt extists");
        	}else{
        		long actCode = (long) (Math.random() * 100000 + 100000);
        		int ret = db.runNativeQuery("update co_user set active_code='"+actCode+"', active_code_time=sysdate where username='" + userName + "'");
        		db.commitAndclose();
            	if(ret > 0 ){
            		WebUtil.sendEmail(email, "Activation code for MIX", "Hi,\nThis EMail sent from MILO Co.\nFor reset your MIX password use this activation code: "+actCode+"\nThis code invalidate after 15 minutes");
            		return new ServiceResult(1, 1);
            	}else{
                    return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Internal error", "Try again");
            	}
        	}
        } catch (Exception e) {
			try {db.rollbackAndClose();} catch (Exception e1) {}
           // BaseLogger.getLogger().error("Error in forgat password, user name:" + userName, e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email doesnt extists");
        }
    }

    
    @POST
    @Path("/register")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult register(Map<String,String> params) {
    	String userName,password,rePassword;
    	String fullName,companyName;
    	fullName = params.get("fullName");
    	companyName = params.get("companyName");
    	userName = params.get("username");
    	password = params.get("password");
    	   	
    	rePassword = params.get("rePassword");
    	String email = params.get("email");
		UserDTO userDTO = new UserDTO();
		userDTO.setActive(false);
		userDTO.setCompanyName(companyName);
		userDTO.setFullName(fullName);
		userDTO.setEmail(email);
		userDTO.setUserPassword(password);
		userDTO.setUsername(email);
		ServiceResult result = UserFacade.getInstace().registerRichUser(userDTO, BusinessParam.getSystemBusinessParam());
		return result;
		
  /*  	BaseDB db = null;
    	try {
			
		 	db=BaseDB.open("registeration");
	    	//exist userName & Email
			Query query = db.createNativeQuery("select email from co_user where username='"+userName+"'");
	    	if(query.getResultList().size() == 0){
	    		query = db.createNativeQuery("select email from co_user where email='"+email+"'");
	    		if(query.getResultList().size() == 0){
		    		BaseLogger.getLogger().info("Register:" + fullName+" "+companyName+" userName :"+userName);
		        	if(password.equals(rePassword)){
		        		password = TextUtil.encryptPass(password); 
		        		
		        		//insert user
		        		long userId = IDGenerator.genId(User.class);
		        		String insert = "insert into co_user (user_id,full_name,company_name,username,user_password,email,is_active,is_deleted,created,created_by,updated,updated_by,email_is_confirmed) values('"+
		        				 userId + "','"+fullName+"','"+companyName+"','"+userName+"','"+password+"','"+email+"',0,0,"
		        				 +"sysdate,"+SystemConfig.SYSTEM_USER_ID+",sysdate,10001,0)";
		        		
		        		int ret = db.runNativeQuery(insert);
		        		
		        		//insert oragn for user company
		        		long orgId = IDGenerator.genId(Organization.class);
		        		db.runNativeQuery("INSERT INTO CO_ORGANIZATION(ORGANIZATION_ID,CREATED,CREATED_BY,IS_ACTIVE,UPDATED,UPDATED_BY,ACCESS_KEY,FULL_NAME,NAME,IS_DELETED) values " +
							"("+orgId+",sysdate,10000,0	,sysdate   ," + SystemConfig.SYSTEM_USER_ID+"	,	'@A' ,'"+companyName+"', '"+companyName+"' ,0)");
		        		
						//insert role for user
		        		long userRoleId = IDGenerator.genId(UserRole.class);
		            	db.runNativeQuery("insert into CO_USER_ROLE (USER_ROLE_ID,CREATED,CREATED_BY,IS_ACTIVE,UPDATED,UPDATED_BY,CODE,ORGANIZATION_ID,ROLE_ID,USER_ID,ORGS_ACCESS,IS_DELETED)"+
		            			"VALUES('"+ userRoleId +"',sysdate,"+ SystemConfig.SYSTEM_USER_ID +",1,sysdate,"+ SystemConfig.SYSTEM_USER_ID +",0,"+orgId+","+ SystemConfig.POOR_USER_ROLE_ID +",'"+ userId +"','10002:AA_',0)");
		        		
		        		//sent email active code
		        		long actCode = (long) (Math.random() * 100000 + 100000);
		        		db.runNativeQuery("update co_user set active_code='"+actCode+"', active_code_time=sysdate where username='" + userName + "'");
		            	WebUtil.sendEmail(email,"Activation code for MIX", "Hi,\nThis EMail sent from MILO Co. For activate your user account. \nTo activate account Click link: " +
		            			SystemConfig.SERVER_URL + "/ui/login.html?x="+ userId +"O"+actCode);
		            	db.commitAndclose();
	            		return new ServiceResult(true, 1);
		        	}else{
	    				db.rollbackAndClose();
		        		return new ServiceResult(ServiceResult.ERROR_CODE.DIDNOT_MATCH_PASSWORD ,"Password and retype isn't same","Password and retype isn't same");
	    			}
	    		}else{
	    			db.rollbackAndClose();
		            return new ServiceResult(ServiceResult.ERROR_CODE.DUPLICATE, "Email already in use", "Email already in use");
	    		}
	    			
	    	}else{
	    		db.rollbackAndClose();
	            return new ServiceResult(ServiceResult.ERROR_CODE.DUPLICATE, "This user name already is used", "This user name already is used");
	    	}
    	} catch (Exception e) {e.printStackTrace();
    		try {
				db.rollbackAndClose();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			// TODO: handle exception
    		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email or user name didnt match");
		}*/
    }
    
    @POST
    @Path("/changePassword")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult changePassword(Map<String,String> params) {
    	BaseDB db = null;
    	try {
    		String oldPass = params.get("oldPass");
    		String newPass = params.get("newPass");
    		String ticket = params.get("ticket");
            String userName = ticket.substring(1, ticket.indexOf("|"));
            BaseLogger.getLogger().info("Change password:" + userName);

            UserSessionManager.getUserSession(ticket);
    		db = BaseDB.open("Change password");
    		newPass = TextUtil.encryptPass(newPass);
    		oldPass = TextUtil.encryptPass(oldPass);
        	int ret = db.runNativeQuery("update co_user set USER_PASSWORD='"+newPass+"',EMAIL_IS_CONFIRMED=1 where username='" + userName + "' and USER_PASSWORD='" + oldPass + "'");
    		
        	db.commitAndclose();
        	if(ret > 0)
        		return new ServiceResult(true, 1);//password changed
        	else
        		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_ACTIVATION", "Data isnt valid");

    	} catch (Exception e) {
    		try {db.rollbackAndClose();} catch (Exception e1) {}
    		if(e.getMessage().equals("USER_EXPIRED"))
    			return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "USER_EXPIRED", "Your account is expired. Login first");
    		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email or user name didnt match");
    	}
    }
 
    @POST
    @Path("/activationCode")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult activationCode(Map<String,String> params) {
    	String userId,activeCode,password;
    	userId = params.get("userId");
    	activeCode = params.get("activeCode");
    	password = TextUtil.encryptPass(params.get("password"));
    	BaseDB db = null;
    	try {
    		db=BaseDB.open("Active code for registeration ");
			Query query = db.createNativeQuery("select email from co_user where user_id='"+userId+"' and active_code='"+activeCode+"'");
			String rm = (String) query.getSingleResult();
			if(rm.isEmpty()){
				db.commitAndclose();
				return new ServiceResult(ServiceResult.ERROR_CODE.IS_NULL,"USER_NOT_FOUND","User not found");
			}else{
				//Active user
				int ret = db.runNativeQuery("update co_user set is_active = 1,EMAIL_IS_CONFIRMED=1 where user_id='" + userId + "' and active_code='" + activeCode + "' and USER_PASSWORD='" + password+"'");
				//Active organization of user
				db.runNativeQuery("update CO_ORGANIZATION set IS_ACTIVE = 1 where ORGANIZATION_ID = (select min(ORGANIZATION_ID) as orgId from CO_USER_ROLE where USER_ID='" + userId + "')");
				
	    		db.commitAndclose();
	    		if(ret > 0)
	    			return new ServiceResult(true,1);
	    		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email or user name didnt match");
			}
    	}catch(Exception e){
    		try {db.rollbackAndClose();} catch (Exception e1) {}
       		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email or user name didnt match");
    	}
    }
    
    
    @POST
    @Path("/unLockUser")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult unLockUser(Map<String,String> params) {
    	String userName= null;
    	BaseDB db = null;
        try {
        	userName = params.get("userName");
        	String email = params.get("email");
        	String activeCode = params.get("activeCode");
        	String password = params.get("password");
        	String repassword = params.get("repassword");
        	
        	BaseLogger.getLogger().info("Locked User:" + userName);
        	db=BaseDB.open("unlock user");
        	if(activeCode != null && activeCode.length() >5){//reset password , unlock user name
        		password = TextUtil.encryptPass(params.get("password"));
	        	int ret = db.runNativeQuery("update co_user set USER_PASSWORD='"+password+"',is_active=1 where username='" + userName + "' and ACTIVE_CODE='" + activeCode + "' and email='"+ email+"' and ACTIVE_CODE_TIME>sysdate - (1/96)");
	    		
	        	db.commitAndclose();
	        	if(ret > 0)
	        		return new ServiceResult(2, 1);//Actived user
	        	else
	        		return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_ACTIVATION", "Data isnt valid");
        	}
        	Query query = db.createNativeQuery("select email from co_user where username=:username");
        	query.setParameter("username", userName);
        	String rm = (String) query.getSingleResult();
        	
        	if(rm.isEmpty() || !rm.equals(email)){
            	db.commitAndclose();
                return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email or user name didnt match");
        	}else{
        		long actCode = (long) (Math.random() * 100000 + 100000);
        		int ret = db.runNativeQuery("update co_user set active_code='"+actCode+"', active_code_time=sysdate where username='" + userName + "'");
        		db.commitAndclose();
            	if(ret > 0 ){
            		WebUtil.sendEmail(email, "Activation code for MBI", "Hi,\nThis EMail sent from MILO Co.\nFor active user name your MBI use this activation code: "+actCode+"\nThis code invalidate after 15 minutes");
            		return new ServiceResult(1, 1);
            	}else{
                    return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Internal error", "Try again");
            	}
        	}
        } catch (Exception e) {
			try {db.rollbackAndClose();} catch (Exception e1) {}
           // BaseLogger.getLogger().error("Error in forgat password, user name:" + userName, e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "WRONG_DATA", "Email or user name didnt match");
        }
    }

    
}