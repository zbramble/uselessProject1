package org.mega.core.util;

import org.mega.core.base.ServiceResult.ERROR_CODE;

public class ExceptionUtil {

	public static String getMessage(Exception e) {
		if(e.getCause() != null && e.getCause().getMessage() != null && e.getCause().getMessage().startsWith("not-null"))
			return "Fill mandatory fields";
		else
			return "Error";
	}

	public static ERROR_CODE getErrorCode(ERROR_CODE errorCode, Exception e) {
		if(e.getCause() != null && e.getCause().getMessage() != null && e.getCause().getMessage().startsWith("not-null"))
			return ERROR_CODE.IS_NULL;
		return errorCode;
	}

}
