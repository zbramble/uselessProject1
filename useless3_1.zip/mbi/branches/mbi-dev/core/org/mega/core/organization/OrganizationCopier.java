package org.mega.core.organization;

import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.beanutils.BeanUtils;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BusinessParam;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.util.TextUtil;

public class OrganizationCopier extends BaseCopier<Organization, OrganizationDTO> {
    @Override
    public OrganizationDTO copyFromEntity(Organization organization) {
        OrganizationDTO organizationDTO = new OrganizationDTO();

        organizationDTO.setRowId(organization.getRowId());
        organizationDTO.setName(organization.getName());
        organizationDTO.setEstablishingYear(organization.getEstablishingYear());
        if (organization.getParentOrg() != null) {
            OrganizationDTO parentOrgDTO = new OrganizationDTO();
            parentOrgDTO.setRowId(organization.getParentOrg().getRowId());
            organizationDTO.setParentOrg(parentOrgDTO);
        }
        if (organization.getOrgStatus() != null) {
            ComboValDTO orgStatusDTO = new ComboValDTO();
            orgStatusDTO.setRowId(organization.getOrgStatus().getRowId());
            organizationDTO.setOrgStatus(orgStatusDTO);
        }
        if (organization.getType() != null) {
            ComboValDTO typeDTO = new ComboValDTO();
            typeDTO.setRowId(organization.getType().getRowId());
            organizationDTO.setType(typeDTO);
        }
        if (organization.getOrgGrade() != null) {
            ComboValDTO orgGradeDTO = new ComboValDTO();
            orgGradeDTO.setRowId(organization.getOrgGrade().getRowId());
            organizationDTO.setOrgGrade(orgGradeDTO);
        }
        organizationDTO.setOrderr(organization.getOrderr());
        organizationDTO.setLongitude(organization.getLongitude());
        organizationDTO.setLatitude(organization.getLatitude());
        organizationDTO.setImageName(organization.getImageName());
        organizationDTO.setTel(organization.getTel());
        organizationDTO.setFax(organization.getFax());
        organizationDTO.setAddress(organization.getAddress());
        organizationDTO.setDescription(organization.getDescription());
        organizationDTO.setAccessKey(organization.getAccessKey());
        organizationDTO.setCode(organization.getCode());
        if (organization.getOwnershipType() != null) {
            ComboValDTO ownershipTypeDTO = new ComboValDTO();
            ownershipTypeDTO.setRowId(organization.getOwnershipType().getRowId());
            organizationDTO.setOwnershipType(ownershipTypeDTO);
        }
        if (organization.getRoadType() != null) {
            ComboValDTO roadTypeTDO = new ComboValDTO();
            roadTypeTDO.setRowId(organization.getRoadType().getRowId());
            organizationDTO.setRoadType(roadTypeTDO);
        }
        organizationDTO.setFullName(organization.getFullName());
        organizationDTO.setLogoImage(organization.getLogoImage());

        copyFromEntityBaseField(organization, organizationDTO);

        return organizationDTO;
    }

    @Override
    public Organization copyToEntity(OrganizationDTO organizationDTO) throws Exception {
        Organization organization = new Organization();
        if(organizationDTO.getRowId() != 0)
        	organization = OrganizationFacade.getInstance().findEntityById(Organization.class, organizationDTO.getRowId(),BusinessParam.getSystemBusinessParam());
        //Check if is new or parent changed set AccessKey
        if(organizationDTO.getRowId() == 0 || organizationDTO.getParentOrg().getRowId() != organization.getParentOrg().getRowId()){
        	setAccessKey(organizationDTO, organizationDTO.getParentOrg().getRowId(), BusinessParam.getSystemBusinessParam());
        }
        
        
        organization.setRowId(organizationDTO.getRowId());
        organization.setName(organizationDTO.getName());
        organization.setEstablishingYear(organizationDTO.getEstablishingYear());
        if (organizationDTO.getParentOrg() != null) {
            Organization parentOrg = new Organization();
            parentOrg.setRowId(organizationDTO.getParentOrg().getRowId());
            organization.setParentOrg(parentOrg);
        }
        if (organizationDTO.getOrgStatus() != null) {
            ComboVal orgStatus = new ComboVal();
            orgStatus.setRowId(organizationDTO.getOrgStatus().getRowId());
            organization.setOrgStatus(orgStatus);
        }
        if (organizationDTO.getType() != null) {
            ComboVal type = new ComboVal();
            type.setRowId(organizationDTO.getType().getRowId());
            organization.setType(type);
        }
        if (organizationDTO.getOrgGrade() != null) {
            ComboVal orgGrade = new ComboVal();
            orgGrade.setRowId(organizationDTO.getOrgGrade().getRowId());
            organization.setOrgGrade(orgGrade);
        }
        organization.setOrderr(organizationDTO.getOrderr());
        organization.setLongitude(organizationDTO.getLongitude());
        organization.setLatitude(organizationDTO.getLatitude());
        organization.setImageName(organizationDTO.getImageName());
        organization.setTel(organizationDTO.getTel());
        organization.setFax(organizationDTO.getFax());
        organization.setAddress(organizationDTO.getAddress());
        organization.setDescription(organizationDTO.getDescription());
        organization.setAccessKey(organizationDTO.getAccessKey());
        organization.setCode(organizationDTO.getCode());
        if (organizationDTO.getOwnershipType() != null) {
            ComboVal ownershipType = new ComboVal();
            ownershipType.setRowId(organizationDTO.getOwnershipType().getRowId());
            organization.setOwnershipType(ownershipType);
        }
        if (organizationDTO.getRoadType() != null) {
            ComboVal roadType = new ComboVal();
            roadType.setRowId(organizationDTO.getRoadType().getRowId());
            organization.setRoadType(roadType);
        }
        organization.setFullName(organizationDTO.getFullName());
        organization.setLogoImage(organizationDTO.getLogoImage());

        copyToEntityBaseField(organization, organizationDTO);

        return organization;
    }
/*    
    //Now this method dont use. This search all children of parent to set access key that hasn't used so isn't goog for performance
 	private void setAccessKey(OrganizationDTO organizationDTO, long parentId, BusinessParam businessParam) throws Exception {
 		
 		BaseDB db = businessParam.getDB();
 		try {
			Organization parentOrganization = OrganizationFacade.getInstance().findEntityById(Organization.class, parentId, businessParam);
			Query query = db.createNativeQuery("select organization_id,ACCESS_KEY from CO_ORGANIZATION where PARENT_ORG_ID="+parentId+" and is_deleted=0 order BY ACCESS_KEY");
			List<Object[]> result = query.getResultList();
			boolean isSet = false;
			
			if(result.size()> 0){
				String nextKey = "AAA";
				for(Iterator<Object[]> iter = result.iterator(); iter.hasNext() && !isSet;){
					Object[] row = iter.next();
					try{
						String siblingLastPart = ((String)row[1]).substring( ((String)row[1]).length() - 2);
						if(nextKey.equals(siblingLastPart)){//اولين جاي خالي براي کليد را در زير شاخه هاي والد مي گردد
							nextKey = nextKey(nextKey);
							continue;
						}
						organizationDTO.setAccessKey(parentOrganization.getAccessKey() + nextKey);
						isSet = true;
					}catch (Exception e) {		}
				}
				
				if(!isSet){//هيچ جاي خالي بين بچه هاي پدر وجود ندارد
					try{organizationDTO.setAccessKey(parentOrganization.getAccessKey() + nextKey);}catch (Exception e) {		}
				}
			}else{
				try{organizationDTO.setAccessKey(parentOrganization.getAccessKey() + "AAA");}catch (Exception e) {		}
			}
		} catch (Exception e) {
			db.finalize();
			throw e;
		}
 	}*/
    
    
    //Now this method dont use. This search all children of parent to set access key that hasn't used so isn't goog for performance
 	private void setAccessKey(OrganizationDTO organizationDTO, long parentId, BusinessParam businessParam) throws Exception {
 		
 		BaseDB db = businessParam.getDB();
 		try {
			Organization parentOrganization = OrganizationFacade.getInstance().findEntityById(Organization.class, parentId, businessParam);
			Query query = db.createNativeQuery("select max(ACCESS_KEY) from CO_ORGANIZATION where PARENT_ORG_ID="+parentId+" and is_deleted=0");
			List<Object> result = query.getResultList();
			
			if(result.size()> 0){
				String ak = (String) result.get(0);
				String siblingLastPart = ak.substring(ak.length() - 3);
				String nextKey = nextKey(siblingLastPart);
				organizationDTO.setAccessKey(parentOrganization.getAccessKey() + nextKey);
			}else{
				organizationDTO.setAccessKey(parentOrganization.getAccessKey() + "AAA");
			}
			businessParam.releaseDB();
		} catch (Exception e) {
			businessParam.rolback();
			throw e;
		}
 	}
 
 	/**
 	 * Create nest access key
 	 * @param key
 	 * @return
 	 * @throws Exception
 	 */
 	public String nextKey(String key) throws Exception {
 		if(key.equals("ZZZ"))
 			throw new Exception("Organization access key last part exceed from (ZZZ). Groups organizations to smaller counts");
 		String next = base26Code((base26Number(key) + 1));
 		return "" + next;
 	}
 	
	/**
	 * Return column name; AAA for 0 and AAB for 1, AAZ for 26 and ZZZ for number = 26*26*26 = 17,575
	 * 
	 * @param i
	 * @return
	 */
	public static String base26Code(int i) {
		String ret = "";
		while(i > 25){
			ret = (char)('A' + (i % 26)) + ret;
			i = i / 26;
		}
		ret = (char)('A' + i)  + ret;
		
		return TextUtil.justify(ret, 3, 'A', true);//Fill left of code with 'A' until string be 3 characters
	}
	
	public static int base26Number(String code) {
		return (code.charAt(0) - 'A') * 26 * 26 + (code.charAt(1) - 'A') * 26 + (code.charAt(2) - 'A');
	}
	
	public static void main(String[] args) {
		OrganizationCopier o = new OrganizationCopier();
		for(int i = 0; i < 17577; i ++) {
			String base26Code = o.base26Code(i);
			System.out.println(i + "\t" + base26Code + "\t" + base26Number(base26Code));
		}
	}
}