package org.mega.core.web;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.BodyPartEntity;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.hibernate.annotations.Loader;
import org.mega.core.SystemConfig;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;
import org.mega.util.IOUtil;

@Path("/file")
public class UploadService {

	@POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @Loader
    /**
     * 
     * @param multiPart
     * @return List of object: State of files uploads. Each abject has tree field {index, sourceName(Name of file to upload), fileName(New name of uploaded file)}
     */
    public Response uploadFile(final FormDataMultiPart multiPart) {
        Map<String, List<FormDataBodyPart>> bodyParts = multiPart.getFields();
        String ticket = bodyParts.get("ticket").iterator().next().getValue();

        UserSession userSession = null;
        try {
            userSession = UserSessionManager.getUserSession(ticket);
        } catch (Exception e) {
        	return Response.ok("{\"error\":\"" + ServiceResult.ERROR_CODE.USER_EXPIRED + "\"}").build();
        }
        
        StringBuffer fileDetails = new StringBuffer("[");
        Iterator<Entry<String, List<FormDataBodyPart>>> iter =  bodyParts.entrySet().iterator();
        int i=0;
        while(iter.hasNext()){
        	Entry<String, List<FormDataBodyPart>> entry = iter.next();
        	FormDataBodyPart bodyPart = entry.getValue().iterator().next();
        	bodyPart.getContentDisposition().getType();
        	if(bodyPart.getContentDisposition().getParameters().get("name").equals("ticket")){
        		continue;
        	}
        	fileDetails.append(i > 0 ? "," : "").append("{\"index\":\"").append(i++).append("\", ");        	
            String sourceName = bodyPart.getContentDisposition().getFileName();
        	String fileName = System.nanoTime() + sourceName.substring(sourceName.indexOf(".")).toLowerCase();
        	fileDetails.append("\"sourceName\":\"").append(sourceName).append("\", ")
        				.append("\"fileCode\":\"").append(fileName).append("\"}");
        	
            try {
				IOUtil.writeToFile(((BodyPartEntity)bodyPart.getEntity()).getInputStream(), SystemConfig.UPLAUD_FOLDER + File.separator + fileName);
			} catch (IOException e) {
				return Response.ok("{\"error\":\"" + e.getMessage() + "\"}").build();				
			}
        }
        fileDetails.append("]");
        return Response.ok(fileDetails.toString()).build();
    }	

}
