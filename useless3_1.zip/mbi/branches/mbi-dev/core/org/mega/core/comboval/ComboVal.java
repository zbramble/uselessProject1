package org.mega.core.comboval;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "CO_COMBO_VAL", uniqueConstraints = @UniqueConstraint(name = "PK_CO_COMBO_VAL", columnNames = "COMBO_VAL_ID"))
public class ComboVal extends BaseEntity{

	@Id
    @Column(name = "COMBO_VAL_ID")
    private Long rowId;

    @Column(name = "NAME", length = 50, unique = true)
    private String name;

    @Column(name = "VAL", length = 20)
    private String val;

    @Column(name = "CODE", length = 100)
    private String code;

    @ManyToOne()
    @JoinColumn(name = "PARENT_ID", foreignKey = @ForeignKey(name = "FK_COM_2_COM__PARENT_ID"))
    private ComboVal parent;

    @OneToMany(mappedBy = "parent")
    private List<ComboVal> comboVals;

    @Override
    public long getRowId() {
        return rowId;
    }

    public void setRowId(Long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ComboVal getParent() {
        return parent;
    }

    public void setParent(ComboVal parent) {
        this.parent = parent;
    }

    public List<ComboVal> getComboVals() {
        return comboVals;
    }

    public void setComboVals(List<ComboVal> comboVals) {
        this.comboVals = comboVals;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = name + " " + val;
    }

	@Override
	public void preUpdate() throws Exception {
        fullTitle = name + " " + val;
	}
}
