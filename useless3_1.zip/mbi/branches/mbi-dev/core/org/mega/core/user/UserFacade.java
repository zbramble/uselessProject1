package org.mega.core.user;

import java.util.ArrayList;
import java.util.List;

import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.IDGenerator;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.organization.OrganizationDTO;
import org.mega.core.organization.OrganizationFacade;
import org.mega.core.sec.UserInfo;
import org.mega.core.sec.UserSession;
import org.mega.core.userrole.UserRole;
import org.mega.core.userrole.UserRoleDTO;
import org.mega.core.userrole.UserRoleFacade;
import org.mega.util.BeanUtil;
import org.mega.util.TextUtil;
import org.mega.util.WebUtil;

public class UserFacade extends BaseFacade {
    private static UserCopier copier = new UserCopier();
    private static UserFacade facade = new UserFacade();

    public ServiceResult manyToManySave(UserDTO userDTO,
                                        List<UserRoleDTO> addItems,
                                        List<String> removeItems,
                                        BusinessParam businessParam) {

        Class<?> entityClass = BeanUtil.getEntityClass(this);

        try {
            businessParam.getUserSession().checkAccess(User.class.getSimpleName(), ACTION.insert);

            ServiceResult resultSave = save(userDTO, businessParam);

            if (addItems != null && addItems.size() > 0) {
                for (int i = 0; i < addItems.size(); i++) {
                    UserDTO newUserDTO = new UserDTO();
                    newUserDTO.setRowId((Long) resultSave.getResult());
                    addItems.get(i).setUser(newUserDTO);
                    UserRoleFacade.getInstance().save(addItems.get(i), businessParam);
                }
            }
            if (removeItems != null && removeItems.size() > 0) {
                Filter filter = new Filter();
                List<PairValue> params = new ArrayList<>();

                PairValue ids = new PairValue();
                ids.setCondition(PairValue.CONDITION.IN);
                ids.setKey("userRoleId");
                ids.setValue(removeItems.toString().replaceAll("\\[|\\]", ""));
                params.add(ids);

                filter.setParams(params);
                filter.setTicket(userDTO.getTicket());
                businessParam.setFilter(filter);
                if (filter.getParams().size() > 0) {
                    UserRoleFacade.getInstance().delete(businessParam);
                }
            }
            return resultSave;
        } catch (Exception e) {
            BaseLogger.getLogger().info("Error saving " + User.class.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving " +User.class.getSimpleName(),
                    e.getLocalizedMessage());
        }
    }
    @Override
    public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
    	//If user is rich user only he be able to create poor users for own company
    	if(baseDTO.getRowId() == 0 && businessParam.getUserSession().getUserInfo().getRoleId() == SystemConfig.RICH_USER_ROLE_ID){
    		return savePoorUser((UserDTO) baseDTO, businessParam);
    	}
    	
		UserDTO userDTO = (UserDTO) baseDTO;
		String email = userDTO.getEmail();
		if(email.length() < 6 || !(email.lastIndexOf('.')  > email.indexOf('@') + 2 )){
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Email isnt valid", "Email isnt valid");
		}
		userDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		
        return super.save(baseDTO, businessParam);
    }
    
    /**
     * Register a rich user and his company and role and send email.
     * Registration is before of login
     * @param userDTO
     * @param businessParam
     * @return
     * @throws Exception
     */
    public ServiceResult registerRichUser(UserDTO userDTO, BusinessParam businessParam) {
			try {
				BaseDB db = businessParam.getDB();
				BusinessParam systemBusinessParam = businessParam.getUserSystemBusinessParam();
	    		String email = userDTO.getEmail();
	    		if(email.length() < 6 || !(email.lastIndexOf('.')  > email.indexOf('@') + 2 )){
	    			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Email isnt valid", "Email isnt valid");
	    		}

				//insert organ for user company
				OrganizationDTO organizationDTO = new OrganizationDTO();
				organizationDTO.setActive(false);
				organizationDTO.setName(userDTO.getCompanyName());
				organizationDTO.setFullName(userDTO.getCompanyName());
				organizationDTO.setEstablishingYear(2000);
				organizationDTO.setLatitude(0);
				organizationDTO.setLongitude(0);
				organizationDTO.setOrderr(1);
				
				OrganizationDTO parentOrgDTO = new OrganizationDTO();
				parentOrgDTO.setRowId(SystemConfig.ORGANOZATION_ROOT_ID);
				organizationDTO.setParentOrg(parentOrgDTO);
				
				//In saving organization, its accessKey sets
				ServiceResult orgResult = OrganizationFacade.getInstance().save(organizationDTO, systemBusinessParam);
				long orgId = (long) orgResult.getResult();
				String pass = userDTO.getUserPassword();
				userDTO.setAccessKey(organizationDTO.getAccessKey());
	            userDTO.setUsername(userDTO.getUsername().toLowerCase());
	            userDTO.setEmail(userDTO.getEmail().toLowerCase());
	            userDTO.setUserPassword(TextUtil.encryptPass(userDTO.getUserPassword()));

				ServiceResult ret = super.save(userDTO, businessParam);		
				long userId = (long) ret.getResult();
				//insert role for user
				//TODO set org access later
				long userRoleId = IDGenerator.genId(UserRole.class);
				db.runNativeQuery("insert into CO_USER_ROLE (USER_ROLE_ID,CREATED,CREATED_BY,IS_ACTIVE,UPDATED,UPDATED_BY,CODE,ORGANIZATION_ID,ROLE_ID,USER_ID,ORGS_ACCESS,IS_DELETED)"+
						"VALUES('"+ userRoleId +"',sysdate,"+ SystemConfig.SYSTEM_USER_ID +",1,sysdate,"+ SystemConfig.SYSTEM_USER_ID +",0," + orgId + ","+ SystemConfig.RICH_USER_ROLE_ID +",'"+ userId +"','10002:AA_',0)");
				
				//sent email active code
				long actCode = (long) (Math.random() * 100000 + 100000);
				db.runNativeQuery("update co_user set active_code='"+actCode+"', active_code_time=sysdate where USER_ID='" +  userId + "'");
				
            	WebUtil.sendEmail(userDTO.getEmail(),"Activation code for MBI", "Hi,\nThis EMail sent from MILO Co. For activate your user account. \nTo activate account Click link: " +
            		SystemConfig.SERVER_URL + "/ui/login.html?x="+ userId +"O"+actCode);
				businessParam.releaseDB();
				return ret;
			} catch (Exception e) {
	    		businessParam.rolback();
	    		if(e.getCause() instanceof javax.mail.SendFailedException)
	    			return new ServiceResult(ServiceResult.ERROR_CODE.EMAIL_IS_INVLID, "Email isnt valid", "Email isnt valid");
	            return new ServiceResult(ServiceResult.ERROR_CODE.DUPLICATE, "Email already in use", "Email already in use");

			}
	}
    /**
     * Save a poor user and his role and send email by rich user
     * @param userDTO
     * @param businessParam
     * @return
     * @throws Exception
     */
    public ServiceResult savePoorUser(UserDTO userDTO, BusinessParam businessParam) {
    	try {
    		BaseDB db = businessParam.getDB();
    		BusinessParam systemBusinessParam = businessParam.getUserSystemBusinessParam();
    		String email = userDTO.getEmail();
    		if(email.length() < 6 || !(email.lastIndexOf('.')  > email.indexOf('@') + 2 )){
    			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Email isnt valid", "Email isnt valid");
    		}
    		
    		UserInfo currUserInfo = businessParam.getUserSession().getUserInfo();
    		String pass = userDTO.getUserPassword();
			userDTO.setAccessKey(currUserInfo.getAccessKey());
    		userDTO.setUsername(userDTO.getUsername().toLowerCase());
    		userDTO.setEmail(userDTO.getEmail().toLowerCase());
    		userDTO.setUserPassword(TextUtil.encryptPass(userDTO.getUserPassword()));
    		
    		ServiceResult ret = super.save(userDTO, businessParam);		
    		long userId = (long) ret.getResult();
    		//insert role for user
    		//TODO set org access later
    		long userRoleId = IDGenerator.genId(UserRole.class);
    		db.runNativeQuery("insert into CO_USER_ROLE (USER_ROLE_ID,CREATED,CREATED_BY,IS_ACTIVE,UPDATED,UPDATED_BY,CODE,ORGANIZATION_ID,ROLE_ID,USER_ID,ORGS_ACCESS,IS_DELETED)"+
    				"VALUES('"+ userRoleId +"',sysdate,"+ currUserInfo.getUserId() +",1,sysdate,"+ currUserInfo.getUserId() +",0," + currUserInfo.getOrgId() + ","+ SystemConfig.POOR_USER_ROLE_ID +",'"+ userId +"','10002:AA_',0)");
    		
    		//sent email active code
    		long actCode = (long) (Math.random() * 100000 + 100000);
    		db.runNativeQuery("update co_user set active_code='"+actCode+"', active_code_time=sysdate where USER_ID='" +  userId + "'");
    		

			WebUtil.sendEmail(userDTO.getEmail(),"Activation code for MBI", "Hi,\nThis EMail sent from MILO Co. For activate your user account that created by (" +
					currUserInfo.getFullName()+") use this password:("+pass+") and link: " + SystemConfig.SERVER_URL + "/ui/login.html?x="+ userId +"O"+actCode);
    		businessParam.releaseDB();
    		return ret;
    	} catch (Exception e) {
    		businessParam.rolback();
    		if(e.getCause() instanceof javax.mail.SendFailedException)
    			return new ServiceResult(ServiceResult.ERROR_CODE.EMAIL_IS_INVLID, "Email isnt valid", "Email isnt valid");
    		return new ServiceResult(ServiceResult.ERROR_CODE.DUPLICATE, "Email already in use", "Email already in use");
    		
    	}
    }

	@Override
    public BaseCopier getCopier() {
        return copier;
    }

	@Override
	public String getConstraint(BusinessParam businessParam) {
		UserSession userSession = businessParam.getUserSession();
		if(userSession.dontCheckAccess())
			return null;
		return "e.accessKey like '" + userSession.getUserInfo().getAccessKey() +"%' and e.rowId<>"+userSession.getUserInfo().getUserId();//User dont access to your data
	}
    public static UserFacade getInstace() {
        return facade;
    }
/*    
    public ServiceResult list(BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);
        Filter filter = businessParam.getFilter();
        if (filter == null)
            return new ServiceResult(ServiceResult.ERROR_CODE.IS_NULL, "filter is null", "");

        try {
            BaseDB db = businessParam.getDB();
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), UserSession.ACTION.search);

            StringBuilder sql = new StringBuilder();
            sql.append(QueryUtil.genQuery("co_user", filter, QueryUtil.QUERY_TYPE.SELECT, getConstraint(businessParam)));
//			if(sql.indexOf("where") == 0)
//				sql.append(" where ");
//            
			
			Query query = db.createNativeQuery(sql.toString());
            
            query.setFirstResult((filter.getPageNo() - 1) * filter.getPageSize());
            query.setMaxResults(filter.getPageSize());
            List<Object[]> result = query.getResultList();

            List<BaseDTO> ret = new ArrayList<>(result.size());

            for (Object[] entity : result) {
                UserDTO dto = new UserDTO();
                dto.setRowId(1);
                dto.setFullName("kkkk");
                ret.add(dto);
            }
            businessParam.releaseDB();
            return new ServiceResult(ret, ret.size());
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error getList " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error getList LocationDTO", e);
        }
    }*/
}
