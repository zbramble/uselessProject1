package org.mega.core.user;

import org.mega.core.base.BaseDTO;
import org.mega.core.userrole.UserRoleDTO;

import java.util.List;

public class MasterUserDTO extends BaseDTO {
    private UserDTO user;
    private List<UserRoleDTO> listChild;
    private List<String> listId;

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public List<UserRoleDTO> getListChild() {
        return listChild;
    }

    public void setListChild(List<UserRoleDTO> listChild) {
        this.listChild = listChild;
    }

    public List<String> getListId() {
        return listId;
    }

    public void setListId(List<String> listId) {
        this.listId = listId;
    }

    @Override
    public long getRowId() {
        return user.getRowId();
    }
}
