
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

import org.mega.core.base.ServiceResult;
import org.mega.util.IOUtil;
import org.mega.util.WebUtil;

import com.fasterxml.jackson.databind.ObjectMapper;


public class ClientTest {
	
	public static void main(String[] args) throws IOException {
		//test1RetObject();
		test2RetText();
	}

	private static void test1RetObject() throws MalformedURLException, IOException {
		String urlPath = "http://192.168.1.10:8080/ntnet/service/security/login";
		String jsonToReq = "{\"username\":\"golnari\",\"password\":\"123\",\"lang\":\"fa\"}";
		
		Object object = WebUtil.restServiceCall(urlPath, jsonToReq, ServiceResult.class);
		
		ServiceResult serviceResult = (ServiceResult) object;
		if(serviceResult.isDone()){
			ArrayList<Map> userInfos = (ArrayList<Map>)serviceResult.getResult();
			if(userInfos.size() > 0){
				System.out.println(((Map)userInfos.get(0)).get("orgId"));
				ObjectMapper mapper = new ObjectMapper();
			}
			else
				System.out.println("Dont find");
		}
	}
	
	
	private static void test2RetText() throws MalformedURLException, IOException {
		String urlPath = "https://api.ipify.org/?format=text";
		String ret = (String)WebUtil.readPage(urlPath);
		System.out.println(ret);
	}

}
