var entity;
var id,title;
//var tabID = window.location.href.urlParameter('tabID');
var imageContent;
var fileIsSave = false;
$(document).ready(function () {
    setEditListeners();
    
    
    
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
    	
    	var fileRowId;
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        
        //******************
        var hImageSave = new Handler;
        hImageSave.success = function (result) {
            if (result.done) {
            	
                fileRowId = result.result[0];
                $("#documentFileDTO").attr('entityId', result.result);
                saveRow('edit-form', hSave, "/rfqRelatedDoc/save");
            }
            else {
                errorHandle(result);
            }
        }
        hImageSave.error = function (jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ');
        }
        var formData = new FormData;
        formData.append('rowId', $("#documentFileDTO").attr("entityId"));
        formData.append('title', $("#relatedDocumentTitle").val());
        formData.append('description', "Document File")
        formData.append('useTitle', "Document Form");
        formData.append('useEntity', "RfqRelatedDocument");
        formData.append('path', $("#documentFileDTO").attr("path"));
        formData.append('active', $("#active").prop("checked"));

        var files = $('#documentFileDTO')[0].files;
        if ($("#documentFileDTO")[0].files.length > 0) {
            ServiceInvoker.upload(files, formData, hImageSave);
        } else {
        	saveRow('edit-form', hSave, "/rfqRelatedDoc/save");
        }
        //*****************
        
        
        
        //saveRow('edit-form', hSave, "/rfqRelatedDoc/save");
    });
    $('#imageContent').on('click', function () {
        $("#documentFileDTO").click();
    });

    $('#documentFileDTO').on('change', function () {
        var input = $("#documentFileDTO")[0];

        if (input.files.length > 0) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#img').attr('src', e.target.result);
                $("#imageContent").attr("src", e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    });
   /*-----------------------------------------------------------------------------------Mask-----------------------*/
    
	/*----------------------------------------------------------------------------------- Autocomplete ---------------*/
	var fquotRequest = new Filter();
	fquotRequest.addParameter("shipmentName", '$("#quotRequestDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicQuotRequest("quotRequestDTO", fquotRequest);
	
	var frelatedDocumentType = new Filter();
	frelatedDocumentType.addParameter("parent.name",'"Related Document Type"', Condition.EQUAL);
	frelatedDocumentType.addParameter("name", '$("#relatedDocumentTypeDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicComboVal("relatedDocumentTypeDTO", frelatedDocumentType);
});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/rfqRelatedDoc/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    if(dto.quotRequestDTO){
	   $("#quotRequestDTO").val(dto.quotRequestDTO.shipmentName);
	   $("#quotRequestDTO").attr('entityId',dto.quotRequestDTO.rowId);
    }
    if(dto.relatedDocumentTypeDTO){
	   $("#relatedDocumentTypeDTO").val(dto.relatedDocumentTypeDTO.name);
	   $("#relatedDocumentTypeDTO").attr('entityId',dto.relatedDocumentTypeDTO.rowId);
    }
    $("#relatedDocumentTitle").val(dto.relatedDocumentTitle);
    if (dto.documentFileDTO) {
        $("#documentFileDTO").val(dto.documentFileDTO.title);
        $("#documentFileDTO").attr("entityId", dto.documentFileDTO.rowId);
        $("#documentFileDTO").attr("path", dto.documentFileDTO.path);
        imageLoad(dto.documentFileDTO.rowId, 'imageContent');
    } else {
        $("#documentFileDTO").attr("entityId", "");
    }
    
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active);

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    //$('#qouteRequestDTO').val(title);
    //('#qouteRequestDTO').attr('entityId',id);
    $("#documentFileDTO").attr("path", "");
    $("#documentFileDTO").attr("entityId", "");
    $("#imageContent").attr("src", "../../core/img/attach-image.png");
    $('#quotRequestDTO').attr('entityId',parent.resultId[1]);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
	//debugger;
    if (result.done) {
    	//alert(result.result[0]);
        parent.hideLoading();
        setTimeout(function () {
        	
        		parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/rfqRelatedDoc/list");
    pageNo = oldPageNo;
}

/*--------------------------------------------------------------------------------------- End ------------------------*/