var app = angular.module('panel', ['ui.select', 'ngSanitize','720kb.datepicker']);
var showRow;
var fillEdit;
var clearFrom;
var qouteId;
var tabID = window.location.href.urlParameter('tabID');
var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
var fSearch = new Filter();
 if(tabID != null && tabID != 0) { // is opened as tab
     var filterArray = top.tabFilter[tabID];
     if(filterArray[0].value){
    	 fSearch.addParameter(filterArray[0].key, filterArray[0].value, filterArray[0].condition,filterArray[0].title);
	     qouteId = filterArray[0].value;
	     showRow(qouteId);
     }
  }
var panelController = app.controller(
    'panel-controller',
    function ($scope, $http) {
    	if(user.roleId == 10004 || user.roleId == 10001){//forwarder
    		$scope.customerNameDiv = true;
    		$scope.customerNameAdd = true;
    	}else{
    		$scope.customerNameDiv = false;
    		$scope.customerNameAdd = false;
    	}
        var LocUrl = servicePath + '/service/location/list';
        var companyUrl = servicePath + '/service/company/list';
        var comboUrl = servicePath + '/service/combo/list';
        var contactUrl = servicePath + '/service/contact/list';
        $scope.location = {};
        $scope.company = {};
        $scope.state = {};
        $scope.customerName = {};
        $scope.rowId =0;
        $scope.active = true;
        $scope.updated=null;
        $scope.updatedBy=null;
        $scope.created=null;
        $scope.createdBy=null;
        $scope.accessKey="";
        $scope.user = getUser();
        var locationData = {} ;
        var companyData = {};
        var stateComboData = {};
        var customerNameData = {};
        
        var params = [
            {key: "name", value: '', condition: "CONTAINS"}
        ];
        var paramsStateCombo = [
              {key: "parent.name", value: 'location type', condition: "EQUAL"}
          ];
        var paramsContact =  [
          {key: "user.rowId", value: '', condition: "EQUAL"}
          ];
        locationData.ticket = $scope.user.ticket;
        locationData.params = params;
        locationData.pageNo = 1;
        locationData.pageSize = 5;

        companyData.ticket = $scope.user.ticket;
        companyData.params = params;
        companyData.pageNo = 1;
        companyData.pageSize = 5;
        
        stateComboData.ticket = $scope.user.ticket;
        stateComboData.params = paramsStateCombo;
        stateComboData.pageNo = 1;
        stateComboData.pageSize = 5;
        
        customerNameData.ticket = $scope.user.ticket;
        customerNameData.params = paramsContact;
        customerNameData.pageNo = 1;
        customerNameData.pageSize = 5;
        
        $scope.defaultLocations = [];
        $scope.defaultCompany = [];
        $scope.defaultStateCombo = [];
        $scope.defaultContact = [];
        
        // last 5 location(s)
        $http({
            method: 'POST',
            url: LocUrl,
            data: locationData,
            headers: {
                'Content-Type': 'application/json'
            }

        }).then(function (resp) {
           if(resp.data.done) {
                var result = resp.data.result;
               Log(result);
                result.forEach(function (item) {
                    $scope.defaultLocations.push(
                        { name: item.name, rowId: item.rowId, type: item.type.name }
                    );
                });
           }
        }, function myError(response) {
            Log(response)
        });
        
        //load company
        $http({
            method: 'POST',
            url: companyUrl,
            data: companyData,
            headers: {
                'Content-Type': 'application/json'
            }

        }).then(function (resp) {
           if(resp.data.done) {
                var result = resp.data.result;
               Log(result);
                result.forEach(function (item) {
                    $scope.defaultCompany.push(
                        { name: item.companyName, rowId: item.rowId}
                    );
                });
           }
        }, function myError(response) {
            Log(response)
        });
        
        //load state combo
        $http({
            method: 'POST',
            url: comboUrl,
            data: stateComboData,
            headers: {
                'Content-Type': 'application/json'
            }

        }).then(function (resp) {
           if(resp.data.done) {
                var result = resp.data.result;
               Log(result);
                result.forEach(function (item) {
                    $scope.defaultStateCombo.push(
                        { name: item.name, rowId: item.rowId}
                    );
                });
           }
        }, function myError(response) {
            Log(response)
        });
        
      //load contact
        $http({
            method: 'POST',
            url: contactUrl,
            data: customerNameData,
            headers: {
                'Content-Type': 'application/json'
            }

        }).then(function (resp) {
           if(resp.data.done) {
                var result = resp.data.result;
               Log(result);
                result.forEach(function (item) {
                	if(item.user){
	                    $scope.defaultContact.push(
	                    		{ name: item.user.username, rowId: item.rowId}
	                    );
                	}else if(item.organization){
	               		 	$scope.defaultContact.push(
		                    		{ name: item.organization.name, rowId: item.rowId}
		                    );
                	}else{
                		$scope.defaultContact.push(
	                    		{ name: item.nameFamily, rowId: item.rowId}
	                    );
                	}
                });
           }
        }, function myError(response) {
            Log(response)
        });
        
        $scope.steps = [
            {title: 'Overview', status: ''},
            {title: 'Origin', status: ''},
            {title: 'Destination', status: ''},
            {title: 'ShipmentSize', fullTitle: 'Shipment Size and Package Details', status: ''},
            {title: 'Product Details', status: ''},
            {title: 'Memo', status: ''}
        ];
        
        $scope.checkdate=function(){
        	if($scope.origin.pickupDate < today){
        		dialog('Error','Could Not Pickup Date Prior To Today');
        		$scope.origin.pickupDate ='';
        	}
        }
        $scope.checkdateToDelivery=function(){
        	if($scope.origin.pickupDate > $scope.destination.deliveryDate){
        		dialog('Error','Could Not Delivery Date Earlier Than Pickup Date');
        		$scope.destination.deliveryDate ='';
        	}
        }
        $scope.checkProductRquire = function(id){
        	if(id == "refrigeration"){
        		$scope.productDetails.refrigeration = 'yes';
        		$scope.productDetails.freezing = 'no';
        	}else if(id == "freezing"){
        		$scope.productDetails.freezing = 'yes';
        		$scope.productDetails.refrigeration = 'no';
        	}else if(id == "no"){
        		$scope.productDetails.freezing = 'no';
        		$scope.productDetails.refrigeration = 'no';
        	}
        }
        $scope.checkContain = function(id){
        	if(id == "hasIonBatteries"){
        		$scope.productDetails.hasIonBatteries = 'yes';
        		$scope.productDetails.hasMagnetic = 'no';
        		$scope.productDetails.hasHazardous = 'no';
        	}else if(id == "hasMagnetic"){
        		$scope.productDetails.hasIonBatteries = 'no';
        		$scope.productDetails.hasMagnetic = 'yes';
        		$scope.productDetails.hasHazardous = 'no';
        	}else if(id == "hasHazardous"){
        		$scope.productDetails.hasIonBatteries = 'no';
        		$scope.productDetails.hasMagnetic = 'no';
        		$scope.productDetails.hasHazardous = 'yes';
        	}else if(id == "hNone"){
        		$scope.productDetails.hasIonBatteries = 'no';
        		$scope.productDetails.hasMagnetic = 'no';
        		$scope.productDetails.hasHazardous = 'no';
        	}
        }
      /* ================================================================== Insert New Location ==============================================================*/
        $scope.addLocation = function(){
        	 var url = servicePath + '/service/location/save';
             var data = {};
             data.ticket = $scope.user.ticket;
             data.rowId = 0;
             var stateId = $scope.dataModal.stateComboTemp.rowId;
            // if(stateId)
            	 data.type = {rowId:10008};
             data.name = $scope.dataModal.name;
            // data.fullName = $scope.dataModal.name;
             data.firstAddress = $scope.dataModal.firstAddress;
             data.country = $scope.dataModal.country;
             data.secondAddress = $scope.dataModal.secondAddress;
             data.city = $scope.dataModal.city;
             if($scope.dataModal.name == ''){
            	 angular.element('#name').focus();
            	 return false;
             }
             if( $scope.dataModal.country == ''){
            	 angular.element('#country').focus();
            	 return false;
             }
             if( $scope.dataModal.firstAddress == ''){
            	 angular.element('#firstAddress').focus();
            	 return false;
             }
             if($scope.dataModal.city == ''){
            	 angular.element('#city').focus();
            	 return false;
             }
             /*if(!$scope.dataModal.stateComboTemp.rowId){
            	 angular.element('#state').focus();
            	 return false;
             }*/
             $http({
                 method: 'POST',
                 url: url,
                 data: JSON.stringify(data),
                 headers: {
                     'Content-Type': 'application/json'
                 }
             }).then(function mySuccess(resp) {
                 if (resp.data.done) {
                     var result = resp.data.result;
                     //dialog('Save','Item Saved');
                     $('#myModal').modal('hide');
                     search();
                 }else
                 	errorHandle(resp.data);
             }, function myError(response) {
                 Log("Erro On post");
                 Log(response);

             });

        };
        
        /* ========================================================================= Inser New Contact =====================================================================*/
        $scope.addContact = function(){
        	 var url = servicePath + '/service/contact/save';
             var data = {};
             data.ticket = $scope.user.ticket;
             data.rowId = 0;
             data.mobile = $scope.dataContact.phoneNumber ;
             data.postalCode = $scope.dataContact.postalCode ;
             data.address = $scope.dataContact.address ;
             data.note = $scope.dataContact.note ;
            // data.city = {rowId: };
             data.nameFamily = $scope.dataContact.customerName;
             data.type = {rowId: 1000101};//other
             if($scope.dataContact.customerName == ''){
            	 angular.element('#contactName').focus();
            	 return false;
             }
             if($scope.dataContact.phoneNumber == ''){
            	 angular.element('#phoneNumber').focus();
            	 return false;
             }
             
             $http({
                 method: 'POST',
                 url: url,
                 data: JSON.stringify(data),
                 headers: {
                     'Content-Type': 'application/json'
                 }
             }).then(function mySuccess(resp) {
                 if (resp.data.done) {
                     var result = resp.data.result;
                     //dialog('Save','Item Saved');
                     $('#myModalContact').modal('hide');
                     search();
                 }else
                 	errorHandle(resp.data);
             }, function myError(response) {
                 Log("Erro On post");
                 Log(response);

             });
             
        }       
        /* ========================================================================= End ===================================================================================*/
        $scope.addRequest = function () {
            var url = servicePath + '/service/qoutRequest/manyToManySave';
            //debugger;
            var data = {};
            data.ticket = $scope.user.ticket;
            data.rowId = $scope.rowId;
            data.shipmentName = $scope.overview.shipmentName;
            /*----------------------------------------------------------------------------------------- START INSERT COMBOVAL ----------------------------------------------------------*/
            /*------------------------ Freight Method ---------------------------*/
            if( $scope.overview.freightMethod == 'air-freight' ){
            	data.freightMethodTypeDTO = {rowId:10002}; 
            }else if( $scope.overview.freightMethod == 'show-both' ){
            	data.freightMethodTypeDTO = {rowId:10004}; 
            }
            else if( $scope.overview.freightMethod == 'ocean-freight' ){
            	data.freightMethodTypeDTO = {rowId:10003}; 
            }
            else if( $scope.overview.freightMethod == 'truck-only' ){
            	data.freightMethodTypeDTO = {rowId:10005}; 
            }
            /*------------------------ Freight Type ---------------------------*/
            if( $scope.overview.freightType == 'door-to-door'){
            	data.freightTypeDTO = {rowId:10009};
            }else if( $scope.overview.freightType == 'port-to-door'){
            	data.freightTypeDTO = {rowId:100012};
            }else if( $scope.overview.freightType == 'door-to-port'){
            	data.freightTypeDTO = {rowId:10009};
            }else if( $scope.overview.freightType == 'port-to-port'){
            	data.freightTypeDTO = {rowId:100014};
            }
            /*------------------------- Shipment Type --------------------------*/
           // alert($scope.overview.shipmentType)
            if( $scope.overview.shipmentType == 'LCL'){
            	data.shipmentTypeDTO = {rowId:100016};
            }else if( $scope.overview.shipmentType == 'FCL'){
            	data.shipmentTypeDTO = {rowId:100017};
            }
           /*-------------------------- Incoterms -------------------------------*/
            if( $scope.overview.incoterms == 'exw'){
            	data.incotermTypeDTO = {rowId:100019};
            }else if( $scope.overview.incoterms == 'fob'){
            	data.incotermTypeDTO = {rowId:100020};
            }else if( $scope.overview.incoterms == 'otherIncoterms'){
            	data.incotermTypeDTO = {rowId:100021};
            }
            /*-------------------------- Payment Terms -------------------------------*/
            if( $scope.overview.paymentTerms == 'freight-collect'){
            	data.paymentTermsDTO = {rowId:100023};
            }else if( $scope.overview.paymentTerms == 'freight-prepaid'){
            	data.paymentTermsDTO = {rowId:100024};
            }
            /*-------------------------- Request Status -------------------------------*/
            data.qoutReqStatusTypeDTO = {rowId:100026};
            /*-------------------------- Measurement Unit -------------------------------*/
            if($scope.shipmentSize.unit == 'kg'){
            	data.rfqMeasurementUnitDTO = {rowId:100052};
            }else if($scope.shipmentSize.unit == 'lb'){
            	data.rfqMeasurementUnitDTO = {rowId:100053};
            }
            /*----------------------------------------------------------------------------------------- END INSERT COMBOVAL ----------------------------------------------------------*/
            data.totalWeight = $scope.shipmentSize.totalWeight;
            data.totalVolume = $scope.shipmentSize.totalVolume;
            data.totalPieces = $scope.shipmentSize.totalPieces;
            data.packagingDetailsKnown = ($scope.shipmentSize.knownPackDetail == 'yes' )? 1 : 0;
            data.pickupDate = $scope.origin.pickupDate;
            data.targetDeliveryDate = $scope.destination.deliveryDate;
            data.containtsLithiumIonBatteries = ($scope.productDetails.hasIonBatteries == 'yes') ? 1 : 0;
            data.containsHazardousMaterial = ($scope.productDetails.hasHazardous == 'yes') ? 1 : 0;
            data.containsMagneticProperties = ($scope.productDetails.hasMagnetic == 'yes') ? 1 : 0;
            data.descriptionOfProducts = $scope.productDetails.productsDesc;
            data.refrigeration = ($scope.productDetails.refrigeration == 'yes')? 1 : 0 ;
            data.freezing = ($scope.productDetails.freezing == 'yes') ? 1 : 0;
            data.memo = $scope.memo.information;
            data.cpscCertified = ($scope.additionalDetails.hasCPSC == 'yes') ? 1 : 0;
            data.comanyAssistedProduct = ($scope.additionalDetails.assist == 'yes') ? 1 : 0;
            data.containsWood = ($scope.additionalDetails.hasWood == 'yes') ? 1 : 0;
            data.containsEncryptionTechnologi = ($scope.additionalDetails.hasEncryption == 'yes') ? 1 : 0;
            data.companyFdaRegistered = ($scope.additionalDetails.FDA == 'yes') ? 1 : 0;
            data.fccRegistered = ($scope.additionalDetails.FCC == 'yes') ? 1 : 0;
 
            var originId = $scope.origin.originLocationTemp.rowId;
           	if(originId)
           		data.origionLocationDTO = {rowId:originId };
           	
            var id = $scope.origin.originPortTemp.rowId;
            if(id)
            	data.origionPortLocationDTO = {rowId:id };
            
           	var destinationId = $scope.destination.destinationLocationTemp.rowId;
            if(destinationId)
            	data.destinationLocationDTO = {rowId:destinationId };
            
            var portId = $scope.destination.destinationPortTemp.rowId;
            if(id)
            	data.destinationPortLocationDTO = {rowId:portId };
           /*------------------------------------------------------------------------------- Package Data ------------------------------------------------------*/
            
            var countPackage = $scope.shipmentSize.packages.length;
            var packageList={};
            var list=[];
            //debugger
            if($scope.shipmentSize.knownPackDetail == 'yes'){
            var	packegeList = [];
            for (var i = 0; i < countPackage; i++) {
            	
            	var idP="";
            	if($scope.shipmentSize.packages[i].packageId)
            		idP = $scope.shipmentSize.packages[i].packageId;
            	else idP = 0;
            	var pallet = ($scope.shipmentSize.packages[i].isPalletized == 'yes' )? true : false;
            	list += '{"packageName": "'+$scope.shipmentSize.packages[i].name+ '"' +
            	  ', "palletized"   :"'+pallet+'"'+
            	  ', "rowId" :"'+idP+'"'+
            	  ', "carrtonCount" :"'+ $scope.shipmentSize.packages[i].count+'"'+
            	  ', "cartonLength" :"'+ $scope.shipmentSize.packages[i].length+'"'+
            	  ', "cartonWidth"  :"'+ $scope.shipmentSize.packages[i].width+'"'+
            	  ', "cartonHeight" :"'+ $scope.shipmentSize.packages[i].height+'"'+
            	  ', "cartonWeight" :"'+$scope.shipmentSize.packages[i].weight+'"},';
            	packegeList[i] = $scope.shipmentSize.packages[i];
			}
            }
            if(list != '')
            	list = list.substr(0, list.lastIndexOf(","));
            //if(!originId)
            	//$scope.focus = true;
            checkMandatories('edit-form');
            $http({
                method: 'POST',
                url: url,
                data: '{"qoutRequestDTO" :  ' + JSON.stringify(data) +', "rfqPackageDTOs" : [' + list + ']}',
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function mySuccess(resp) {
                $scope.origin.originLocations = [];
                if (resp.data.done) {
                    var result = resp.data.result;
                    $scope.rowId=result[0];
                    if(result.length > 1){
                    	for (var i = 0; i < result.length-1; i++) {
             	           $scope.shipmentSize.packages[i] = {
             	        		packageId:result[i],
             	                name: packegeList[i].name,
             	                isPalletized: packegeList[i].isPalletized,
             	                count:  packegeList[i].count,
             	                type: '',
             	                length: packegeList[i].length,
             	                width:  packegeList[i].width,
             	                height: packegeList[i].height,
             	                weight: packegeList[i].weight,
             	                totalCartons: ''
             	            };
                    	}
                    }	
                    search();
                    
                    dialog('Save','Item Saved');
                }else
                	errorHandle(resp.data);
            }, function myError(response) {
                Log("Erro On post");
                Log(response);

            });

        };
        $scope.clearPanel=function(){
        	angular.element(document).find('input:text').val('');
        	angular.element(document).find('textarea').val('');
        	angular.element(document).find('input:checkbox').not('#active').prop("checked", false);
        	angular.element(document).find('input:checkbox#active').prop("checked", true);
        	angular.element(document).find('input:radio').prop("checked", false);
        	angular.element(document).find("select option:first-child").prop("selected", true);
        	angular.element(document).find("div#div-id").removeClass('.circle passed');
        	angular.element(document).find("div#div-id").addClass('.circle');
        	angular.element(document).find("label").removeClass('.freight-method active');
        	angular.element(document).find("label").addClass('.freight-method');
        		
        		
        	//angular.element(document).find("[entityId]").removeAttr('entityId');
        	//angular.element(document).find('.btn-container').find("#remove-btn").attr("disabled", true);
        	
        	$scope.rowId = 0;
        	$scope.overview.shipmentName = "";
        	$scope.overview.freightMethod = "";
        	$scope.overview.freightType ="";
        	$scope.overview.shipmentType ="";
        	$scope.overview.incoterms ="";
        	$scope.overview.paymentTerms = "";
        	$scope.shipmentSize.unit = "";
	         $scope.shipmentSize.totalWeight =0.0;
	         $scope.shipmentSize.totalVolume = 0.0;
	         $scope.shipmentSize.totalPieces = 0;
	         $scope.shipmentSize.knownPackDetail = undefined;
	         $scope.origin.pickupDate = "";
	         $scope.destination.deliveryDate = "";
	         $scope.productDetails.hasIonBatteries = undefined;
	         $scope.productDetails.hasHazardous = undefined;
	         $scope.productDetails.hasMagnetic = undefined;
	         $scope.productDetails.productsDesc = "" ;
	         $scope.productDetails.refrigeration = undefined;
	         $scope.productDetails.freezing = undefined;
	         $scope.memo.information = "";
	         $scope.additionalDetails.hasCPSC =undefined;
	         $scope.additionalDetails.assist = undefined;
	         $scope.additionalDetails.hasWood = undefined;
	         $scope.additionalDetails.hasEncryption = undefined;
	         $scope.additionalDetails.FDA = undefined;
	         $scope.additionalDetails.FCC = undefined;
	        // $scope.destination.destinationLocation.selected = {};
	         
        };
        clearFrom = $scope.clearPanel;

        /*================================== FillEdit : start ====================================*/

        
        $scope.angularFillEdit = function (dto){
  
        	$scope.clearPanel();
        	$scope.rowId = dto.rowId;
        	$scope.overview.shipmentName = dto.shipmentName;
        	/*----------------------------------------------------------------------------------------- START FILL COMBOVAL ----------------------------------------------------------*/
        	/*------------------------ Freight Method ---------------------------*/
        	if(dto.freightMethodTypeDTO){
	        	if( dto.freightMethodTypeDTO.rowId==10002){
	        		$scope.overview.freightMethod = 'air-freight'; 
	            }else if( dto.freightMethodTypeDTO.rowId==10004){
	            	$scope.overview.freightMethod = 'show-both';
	            }
	            else if( dto.freightMethodTypeDTO.rowId==10003){
	            	$scope.overview.freightMethod = 'ocean-freight';
	            }
	            else if( dto.freightMethodTypeDTO.rowId==10005 ){
	            	$scope.overview.freightMethod = 'truck-only';
	            }
            }
        	/*------------------------ Freight Type ---------------------------*/
        	if(dto.freightTypeDTO){
	            if( dto.freightTypeDTO.rowId == 10009){
	            	$scope.overview.freightType ='door-to-door';
	            }else if( dto.freightTypeDTO.rowId==100012){
	            	$scope.overview.freightType ='port-to-door';
	            }else if( dto.freightTypeDTO.rowId==10009){
	            	$scope.overview.freightType = 'door-to-port';
	            }else if( dto.freightTypeDTO.rowId==100014){
	            	$scope.overview.freightType = 'port-to-port';
	            }
        	}
            /*------------------------- Shipment Type --------------------------*/
        	 if(dto.shipmentTypeDTO){
	             if( dto.shipmentTypeDTO.rowId==100016){
	            	 $scope.overview.shipmentType = 'LCL';
	             }else if( dto.shipmentTypeDTO.rowId==100017){
	            	 $scope.overview.shipmentType = 'FCL';
	             }
        	 }
             /*-------------------------- Incoterms -------------------------------*/
        	 if(dto.incotermTypeDTO){
	             if( dto.incotermTypeDTO.rowId==100019){
	            	 $scope.overview.incoterms = 'exw';
	             }else if( dto.incotermTypeDTO.rowId==100020){
	            	 $scope.overview.incoterms = 'fob';
	             }else if( dto.incotermTypeDTO.rowId==100021){
	            	 $scope.overview.incoterms = 'otherIncoterms';
	             }
        	 }
             /*-------------------------- Payment Terms -------------------------------*/
        	 if(dto.paymentTermsDTO){
	             if( dto.paymentTermsDTO.rowId==100023){
	            	 $scope.overview.paymentTerms = 'freight-collect';
	             }else if( dto.paymentTermsDTO.rowId==100024){
	            	 $scope.overview.paymentTerms = 'freight-prepaid';
	             }
        	 }
             /*-------------------------- Request Status -------------------------------*/
             dto.qoutReqStatusTypeDTO.rowId = 100026;
             /*-------------------------- Measurement Unit -------------------------------*/
             if(dto.rfqMeasurementUnitDTO){
	             if(dto.rfqMeasurementUnitDTO.rowId==100052){
	            	 $scope.shipmentSize.unit = 'kg';
	             }else if(dto.rfqMeasurementUnitDTO.rowId==100053){
	            	 $scope.shipmentSize.unit = 'lb';
	             }
             }
             /*----------------------------------------------------------------------------------------- END FILL COMBOVAL ----------------------------------------------------------*/
             $scope.shipmentSize.totalWeight = dto.totalWeight;
             $scope.shipmentSize.totalVolume = dto.totalVolume;
             $scope.shipmentSize.totalPieces = dto.totalPieces;
             $scope.shipmentSize.knownPackDetail = (dto.packagingDetailsKnown==1)? 'yes' : 'no';
             if($scope.shipmentSize.knownPackDetail == 'yes'){//Load Data From RFQ Package
            	 if (dto.qouteRequests) {
            	        for (var i = 0; i < dto.qouteRequests.length; i++) {
            	          var pallet=dto.qouteRequests[i].palletized ? "yes" : "no";
            	           $scope.shipmentSize.packages[i] = {
            	        		packageId:dto.qouteRequests[i].rowId,
            	                name: dto.qouteRequests[i].packageName,
            	                isPalletized: pallet,
            	                count: dto.qouteRequests[i].carrtonCount,
            	                type: '',
            	                length: dto.qouteRequests[i].cartonLength,
            	                width: dto.qouteRequests[i].cartonWidth,
            	                height: dto.qouteRequests[i].cartonHeight,
            	                weight: dto.qouteRequests[i].cartonWeight,
            	                totalCartons: ''
            	            };
            	          
            	        }
            	    }
             }
             $scope.origin.pickupDate = dto.pickupDate;
             $scope.destination.deliveryDate = dto.targetDeliveryDate;
             if(dto.containtsLithiumIonBatteries == 1)
             	$scope.productDetails.hNone = 'hasIonBatteries';
             else if(dto.containsHazardousMaterial ==1)
             	$scope.productDetails.hNone = 'hasHazardous';
             else if(dto.containsMagneticProperties == 1)
             	$scope.productDetails.hNone ='hasMagnetic';
             else 
            	 $scope.productDetails.hNone = 'hNone';
             $scope.productDetails.productsDesc = dto.descriptionOfProducts ;
             $scope.memo.information = dto.memo;
             $scope.additionalDetails.hasCPSC =(dto.cpscCertified == 1)?'yes':'no';
             $scope.additionalDetails.assist = (dto.comanyAssistedProduct==1)?'yes':'no';
             $scope.additionalDetails.hasWood = (dto.containsWood == 1)?'yes':'no';
             $scope.additionalDetails.hasEncryption = (dto.containsEncryptionTechnologi==1)?'yes':'no';
             $scope.additionalDetails.FDA = (dto.companyFdaRegistered==1)?'yes':'no';
             $scope.additionalDetails.FCC = (dto.fccRegistered == 1)?'yes':'no';
             if(dto.freezing == 1)
            	 $scope.productDetails.fNone = 'freezing';
             else if(dto.refrigeration == 1)
            	 $scope.productDetails.fNone = 'refrigeration';
             else 
            	 $scope.productDetails.fNone = 'no';
             /*------------------------------------------------------------------------- START FILL AUTOCOMPLITE -------------------------------------------*/
             if(dto.origionLocationDTO){
            	 $scope.origin.originLocation.selected = {
            			 rowId: dto.origionLocationDTO.rowId,
            			 name: dto.origionLocationDTO.name,
            			 type: '',
            	 };
            	 $scope.origin.originLocationTemp.rowId = dto.origionLocationDTO.rowId;
          	 }
             if(dto.origionPortLocationDTO){
            	 $scope.origin.originPort.selected= {
            			 rowId: dto.origionPortLocationDTO.rowId,
            			 name: dto.origionPortLocationDTO.name,
            			 type: '',
            	 };
            	 $scope.origin.originPortTemp.rowId = dto.origionPortLocationDTO.rowId;
            	 
             }
             if(dto.destinationLocationDTO){
            	 $scope.destination.destinationLocation.selected ={
            			 rowId: dto.destinationLocationDTO.rowId,
            			 name: dto.destinationLocationDTO.name,
            			 type: '',
            	 } ;
            	 $scope.destination.destinationLocationTemp.rowId = dto.destinationLocationDTO.rowId;
          	 }
             if(dto.destinationPortLocationDTO){
            	 $scope.destination.destinationPort.selected ={
            			 rowId: dto.destinationPortLocationDTO.rowId,
            			 name: dto.destinationPortLocationDTO.name,
            			 type: '',
            	 } ;
            	 $scope.destination.destinationPortTemp.rowId = dto.destinationPortLocationDTO.rowId;
             }
             /*---------------------------------------------------------------- END FILL AUTOCOMPLITE ----------------------------------------------------*/
             
        }
        fillEdit =  $scope.angularFillEdit;
       
        /*================================== Fill Edit : end   ====================================*/
        /* ================================== Overview ===============================================================*/
        $scope.overview = {
        	
        	customerNames: $scope.defaultLocations,
        	customerName: {},
        	customerNameTemp: {},
            getCustomers: function (val) {
                if(val.length > 0) {
                	customerNameData.pageSize = 200;
                    params[0].value = val;
                    $http({
                        method: 'POST',
                        url: contactUrl,
                        data: customerNameData,
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                        .then(function mySuccess(resp) {
                            $scope.overview.customerNames = [];
                            if (resp.data.done) {
                                var result = resp.data.result;
                                result.forEach(function (item) {
                                	if(item.user){
	                                    $scope.overview.customerNames.push(
	                                        { name: item.user.username, rowId: item.rowId}
	                                    );
                                	}else if(item.organization){
                                		 $scope.overview.customerNames.push(
     	                                        { name: item.organization.name, rowId: item.rowId}
     	                                    );
                                	}else{
                                		$scope.overview.customerNames.push(
 	                                        { name: item.nameFamily, rowId: item.rowId}
 	                                    );
                                	}
                                });
                            }
                        }, function myError(response) {
                            Log("Erro On post");
                            Log(response)

                        });
                } else {
                    $scope.overview.customerNames =  $scope.defaultContact;
                }
            },
            validateCustomerName: function (item, model) {
              $scope.overview.customerNameTemp = item;
            },
            freightMethod: undefined,
            freightType: undefined,
            incoterms: undefined,
            shipmentType: undefined,
            paymentTerms : 'freight-collect',
            otherIncotermsArr: [
                {value: 'fas', title: 'FAS'},
                {value: 'fca', title: 'FCA'},
                {value: 'cpt', title: 'CPT'},
                {value: 'cfr', title: 'CFR'},
                {value: 'cif', title: 'CIF'},
                {value: 'cip', title: 'CIP'},
                {value: 'dat', title: 'DAT'},
                {value: 'dap', title: 'DAP'},
                {value: 'ddp', title: 'DDP'}
            ],
            otherIncotermsVal: undefined
        };
        $scope.$watchCollection('overview', function (newVal, oldVal) {
           if(newVal.shipmentName !== '') {
               switch(newVal.freightMethod) {
                   case 'air-freight':
                       switch(newVal.freightType) {
                           case 'door-to-door':
                               switch (newVal.incoterms) {
                                   case 'exw':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                                   default:
                                       $scope.steps[0].status = '';
                               }
                               break;
                           case 'port-to-door':
                               switch (newVal.incoterms) {
                                   case 'fob':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                                   default:
                                       $scope.steps[0].status = '';
                               }
                               break;
                           case 'door-to-port':
                               switch (newVal.incoterms) {
                                   case 'exw':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                                   default:
                                       $scope.steps[0].status = '';
                               }
                               break;
                           case 'port-to-port':
                               switch (newVal.incoterms) {
                                   case 'exw':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'fob':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                               }
                               break;
                       }
                       break;
                   case 'ocean-freight':
                       switch(newVal.freightType) {
                           case 'door-to-door':
                               switch (newVal.incoterms) {
                                   case 'exw':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                                   default:
                                       $scope.steps[0].status = '';
                               }
                               break;
                           case 'port-to-door':
                               switch (newVal.incoterms) {
                                   case 'fob':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                                   default:
                                       $scope.steps[0].status = '';
                               }
                               break;
                           case 'door-to-port':
                               switch (newVal.incoterms) {
                                   case 'exw':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                                   default:
                                       $scope.steps[0].status = '';
                               }
                               break;
                           case 'port-to-port':
                               switch (newVal.incoterms) {
                                   case 'exw':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'fob':
                                       $scope.steps[0].status = 'passed';
                                       break;
                                   case 'otherIncoterms':
                                       if(newVal.otherIncotermsVal) {
                                           $scope.steps[0].status = 'passed';
                                       } else {
                                           $scope.steps[0].status = '';
                                       }
                                       break;
                               }
                               break;
                       }
                       break;
                   case 'show-both':
                       break;
                   case 'truck-only':
                       break;
                   default:
                       $scope.steps[0].status = '';
               }
           } else {
               $scope.steps[0].status = 'primary';
           }
        });

        $scope.changeFreightType = function () {
            if($scope.overview.freightType == 'port-to-door') {
                $scope.overview.incoterms = 'fob';
            } else if($scope.overview.freightType == 'door-to-door') {
                $scope.overview.incoterms = 'exw';
            }
        };
        $scope.changeOtherIncoterms = function () {

        };
        /* ================================== dataContact ===========================================================*/
        $scope.dataContact = {
        		customerName : "",
        		unit : "",
        		address : "",
        		city : "",
        		postalCode : "",
        		phoneNumber : "",
        		note:""
        }
        /* ================================== dataModal ==============================================================*/
        $scope.dataModal = {
        		name : "",
        		country :"",
        		firstAddress :"",
        		secondAddress :"",
        		city:"",
        		locationCompanys: $scope.defaultCompany,
        		locationCompany: {},
        		locationCompanyTemp: {},
        		getCompanys: function (val) {
                    if(val.length > 0) {
                    	companyData.pageSize = 200;
                        params[0].value = val;
                        $http({
                            method: 'POST',
                            url: companyUrl,
                            data: companyData,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                            .then(function mySuccess(resp) {
                                $scope.dataModal.locationCompanys = [];
                                if (resp.data.done) {
                                    var result = resp.data.result;
                                    result.forEach(function (item) {
                                        $scope.dataModal.locationCompanys.push(
                                            { name: item.companyName, rowId: item.rowId}
                                        );
                                    });
                                }
                            }, function myError(response) {
                                Log("Erro On post");
                                Log(response)

                            });
                    } else {
                        $scope.dataModal.locationCompanys =  $scope.defaultCompany;
                    }
                },
                validateCompany: function (item, model) {
                  $scope.dataModal.locationCompanyTemp = item;
                },
        		stateCombos: $scope.defaultStateCombo,
        		stateCombo: {},
        		stateComboTemp: {},
        		getComboVals: function (val) {
                    if(val.length > 0) {
                    	stateComboData.pageSize = 200;
                        params[0].value = val;
                        $http({
                            method: 'POST',
                            url: comboUrl,
                            data: stateComboData,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                            .then(function mySuccess(resp) {
                                $scope.dataModal.stateCombos = [];
                                if (resp.data.done) {
                                    var result = resp.data.result;
                                    result.forEach(function (item) {
                                        $scope.dataModal.stateCombos.push(
                                            { name: item.name, rowId: item.rowId}
                                        );
                                    });
                                }
                            }, function myError(response) {
                                Log("Erro On post");
                                Log(response)

                            });
                    } else {
                        $scope.dataModal.stateCombos =  $scope.defaultStateCombo;
                    }
                },
                validateCombo: function (item, model) {
                  $scope.dataModal.stateComboTemp = item;
                }
        		
        };
       
        /* ================================== Origin =================================================================*/
        $scope.origin = {
                originLocations: $scope.defaultLocations,
                originLocation: {},
                originLocationTemp: {},
                originPorts: $scope.defaultLocations,
    			originPort:{},
    			originPortTemp:{},
                pickupDate: undefined,
                getLocations: function (val) {
                    if(val.length > 0) {
                        locationData.pageSize = 200;
                        params[0].value = val;
                        $http({
                            method: 'POST',
                            url: LocUrl,
                            data: locationData,
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                            .then(function mySuccess(resp) {
                                $scope.origin.originLocations = [];
    							$scope.origin.originPorts = [];
                                if (resp.data.done) {
                                    var result = resp.data.result;
                                    result.forEach(function (item) {
                                        $scope.origin.originLocations.push(
                                            { name: item.name, rowId: item.rowId, type: item.type.name }
                                        );
    									$scope.origin.originPorts.push(
                                            { name: item.name, rowId: item.rowId, type: item.type.name }
                                        );
                                    });
                                }
                            }, function myError(response) {
                                Log("Erro On post");
                                Log(response)

                            });
                    } else {
                        $scope.origin.originLocations =  $scope.defaultLocations;
    					$scope.origin.originPorts =  $scope.defaultLocations;
                    }
                },
                validateLocation: function (item, model) {
                  $scope.origin.originLocationTemp = item;
                  $scope.origin.originPortTemp = item;
                }
            };
        $scope.$watchCollection('origin', function (newVal, oldVal) {
            if (newVal.originLocation.selected) {
                $scope.steps[1].status = 'passed';
            } else {
                $scope.steps[1].status = '';
            }
            
            if (newVal.originPort.selected) {
                $scope.steps[1].status = 'passed';
            } else {
                $scope.steps[1].status = '';
            }
        });

        /* ================================== Destination ============================================================*/
        $scope.destination = {
            destinationPorts: $scope.defaultLocations,
            destinationPort : {},
            destinationPortTemp : {},
            destinationLocations: $scope.defaultLocations,
            destinationLocation: {},
            destinationLocationTemp: {},
            deliveryDate: undefined,
            getLocations: function (val) {
                if(val.length > 0) {
                    locationData.pageSize = 200;
                    params[0].value = val;
                    $http({
                        method: 'POST',
                        url: LocUrl,
                        data: locationData,
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                        .then(function mySuccess(resp) {
                            $scope.destination.destinationLocations = [];
                            $scope.destination.destinationPorts = [];
                            if (resp.data.done) {
                                var result = resp.data.result;
                                result.forEach(function (item) {
                                    $scope.destination.destinationLocations.push(
                                        { name: item.name, rowId: item.rowId, type: item.type.name }
                                    );
                                    $scope.destination.destinationPorts.push(
                                        { name: item.name, rowId: item.rowId, type: item.type.name }
                                    );
                                });
                            }
                        }, function myError(response) {
                            Log("Erro On post");
                            Log(response)

                        });
                } else {
                    $scope.destination.destinationLocations =  $scope.defaultLocations;
                    $scope.destination.destinationPorts =  $scope.defaultLocations;
                }
            },
            validateLocation: function (item, model) {
                $scope.destination.destinationLocationTemp = item;
                $scope.destination.destinationPortTemp = item;
            }
        };
        $scope.$watchCollection('destination', function (newVal, oldVal) {
            if (newVal.destinationLocation.selected) {
                $scope.steps[2].status = 'passed';
            } else {
                $scope.steps[2].status = '';
            }
            
            if (newVal.destinationPort.selected) {
                $scope.steps[2].status = 'passed';
            } else {
                $scope.steps[2].status = '';
            }
        });
        /* ================================== Shipment Size ==========================================================*/
        $scope.packageType = [ 'Bag', 'Bale', 'Barrel', 'Carton', 'Crate', 'Roll' ];
        $scope.shipmentSize = {
            knownPackDetail: 'no',
            unit: 'kg',
            totalWeight: undefined,
            totalVolume: undefined,
            chargeableWeight: '0',
            marksAndNumbers: '',
            totalPieces: 0,
            packages: [
                {
                    name: '',
                    isPalletized: 'no',
                    count: '',
                    type: $scope.packageType[3],
                    length: '',
                    width: '',
                    height: '',
                    weight: '',
                    totalCartons: ''
                }
            ]
        };
        $scope.addPackage = function () {
            $scope.shipmentSize.packages.push({
            	packageId:0,
                name: '',
                isPalletized: 'no',
                count: '',
                type: $scope.packageType[3],
                length: '',
                width: '',
                height: '',
                weight: '',
                totalCartons: ''
            });
        };
        $scope.removePackage = function (index) {
        	var rowId = $scope.shipmentSize.packages[index].packageRowId;
        	deleteRow(rowId);
            $scope.shipmentSize.packages.splice(index, 1);
            if($scope.shipmentSize.packages.length === 0) {
                $scope.shipmentSize.knownPackDetail = 'no';
            }
        };
        $scope.$watchCollection('shipmentSize', function (newVal, oldVal) {
            if (newVal.knownPackDetail === 'no') {
                if(Number(newVal.totalWeight) > 0) {
                    newVal.chargableWeight = newVal.totalWeight;
                }
                if(Number(newVal.totalVolume) > 0) {
                    if(newVal.unit === 'kg') {
                        newVal.chargableWeight = Number(newVal.totalVolume) * 166.67;
                    } else {
                        newVal.chargableWeight = Number(newVal.totalVolume) * 10.47;
                    }
                }
                if(Number(newVal.totalWeight) > 0 || Number(newVal.totalVolume) > 0) {
                    $scope.steps[3].status = 'passed';
                } else {
                    newVal.chargableWeight = 0.00;
                    $scope.steps[3].status = '';
                }
            } else {
                $scope.steps[3].status = '';
            }
        });
        $scope.$watch('shipmentSize.packages', function (newVal, oldVal) {
            var totalPieces = 0;
            var totalVolume = 0;
            var totalWeight = 0;
            var chargeableWeight = 0;
            $scope.shipmentSize.packages.forEach(function (package) {
                totalPieces += Number(package.count);
                totalWeight += (Number(package.count) * Number(package.weight));
                if(package.length !== '' && package.width !== '' && package.height !== '') {
                    totalVolume += (Number(package.height) * Number(package.width) * Number(package.length));
                    if(Number(package.count) > 0) { // Calculate Chargeable Weight

                    }
                }
            });
            $scope.shipmentSize.totalPieces = totalPieces;
            $scope.shipmentSize.totalWeight = totalWeight;
            $scope.shipmentSize.totalVolume = totalVolume;
        }, true);
        /* ================================== Compliance Details =====================================================*/
        $scope.productDetails = {
            productsDesc: '',
            hasIonBatteries: undefined,
            hasMagnetic: undefined,
            hasHazardous: undefined,
            hNone:undefined,
            refrigeration:undefined,
            freezing:undefined,
            fNone:undefined
        };
        /* ================================== Memo ===================================================================*/
        $scope.memo = {
            information: ''
        };
        /* ================================== Additional Details =====================================================*/
        $scope.additionalDetails = {
            hasCPSC: undefined,
            assist: undefined,
            hasWood: undefined,
            hasEncryption: undefined,
            FDA: undefined,
            FCC: undefined
        };
        
        $('#div-total').show();
});

/* === DIRECTIVE(s) ================================================================================================= */
app.directive('stepIndicator', function () {
    return {
  
        scope: {
            step: '='
        },
        template: 
                "<div class='step-indicator'> " +
                    "<div class='circle' ng-class='status'></div>" +
                    "<div class='line'></div>" +
                "</div>"
    }
});



/* === Service(s) ====================================================================================================*/
app.service("sharedService", function() {
    /*this.shipmentName = undefined;*/
});

