/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var entityCatch=[];
$('#quote').css('display',"none");
var searchFields = [
                    { key: 'rowId', propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'ID', maxlength: 7 },
                    { key: 'shipmentName',propName: 'e.shipmentName', type: SearchPropertyType.TEXT, title: 'Shipment Name', maxlength: 20 },
                    {
                    	key: 'createdBy',
                    	propName: 'e.createdBy.rowId',
                        autocompleteInstance: 'AutocompleteDynamicUser',
                        type: SearchPropertyType.AUTOCOMPLETE,
                        title: 'Created By',
                        maxlength: 50,
                        autocompleteProp: 'lastName',
                        autocompleteCondition: Condition.CONTAINS
                    },
                    {
                    	key: 'updatedBy',
                    	propName: 'e.updatedBy.rowId',
                        autocompleteInstance: 'AutocompleteDynamicUser',
                        type: SearchPropertyType.AUTOCOMPLETE,
                        title: 'Updated By',
                        maxlength: 50,
                        autocompleteProp: 'lastName',
                        autocompleteCondition: Condition.CONTAINS
                    },
                    { key: 'created',propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created', maxlength: 8 },
                    { key: 'updated',propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated', maxlength: 8 },
                    { key: 'active',propName: 'e.active', type: SearchPropertyType.BOOLEAN, title: 'Active', maxlength: -1}
                    
                ]
/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#shipmentName").attr("id", 'shipmentName-' + id).find('span').html(item.shipmentName);
        patternRow.find("#freightType").attr("id", 'freightType-' + id).find('span').html(item.freightType ? item.freightType.name : '');
        patternRow.find('#origionLocation').attr("id", 'origionLocation-' + id).find('span').html(item.origionLocation ? item.origionLocation.name : '');
        patternRow.find('#destinationLocation').attr("id", 'destinationLocation-' + id).find('span').html(item.destinationLocation ? item.destinationLocation.name : '');
        patternRow.find('#totalWeight').attr("id", 'totalWeight-' + id).find('span').html(item.totalWeight);
        patternRow.find('#totalVolume').attr("id", 'totalVolume-' + id).find('span').html(item.totalVolume);
        patternRow.find('#qoutReqStatusType').attr("id", 'qoutReqStatusType-' + id).find('span').html(item.qoutReqStatusType ? item.name : '');
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        
        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
   

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
	$('#quote').css('display',"none");
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');

    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);

        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#shipmentName").attr("id", 'shipmentName-' + id).find('span').html(item.shipmentName);
        if(item.freightMethodTypeDTO){
        	if(item.freightMethodTypeDTO.rowId == 10002)
        		patternRow.find("#freightMethodTypeDTO").attr("id", 'freightMethodTypeDTO-' + id).find('span').html('<span class="ion-android-plane" style="font-size:20px;"></span>');
        	if(item.freightMethodTypeDTO.rowId == 10003)
        		patternRow.find("#freightMethodTypeDTO").attr("id", 'freightMethodTypeDTO-' + id).find('span').html('<span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(item.freightMethodTypeDTO.rowId == 10004)
        		patternRow.find("#freightMethodTypeDTO").attr("id", 'freightMethodTypeDTO-' + id).find('span').html('<span class="ion-android-plane" style="font-size:20px;"></span><span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(item.freightMethodTypeDTO.rowId == 10005)
        		patternRow.find("#freightMethodTypeDTO").attr("id", 'freightMethodTypeDTO-' + id).find('span').html('<span class="ion-android-bus" style="font-size:20px;"></span>');

        }
        patternRow.find('#origionLocationDTO').attr("id", 'origionLocationDTO-' + id).find('span').html(item.origionLocationDTO ? item.origionLocationDTO.name : '');
        patternRow.find('#destinationLocationDTO').attr("id", 'destinationLocationDTO-' + id).find('span').html(item.destinationLocationDTO ? item.destinationLocationDTO.name : '');
        patternRow.find('#totalWeight').attr("id", 'totalWeight-' + id).find('span').html(item.totalWeight);
        patternRow.find('#totalVolume').attr("id", 'totalVolume-' + id).find('span').html(item.totalVolume);
        patternRow.find('#qoutReqStatusTypeDTO').attr("id", 'qoutReqStatusTypeDTO-' + id).find('span').html(item.qoutReqStatusTypeDTO ? item.qoutReqStatusTypeDTO.name : '');
        if(item.createdBy.file)
        	patternRow.find('#logoOffice').attr("id", 'logoOffice-' + id).find('span').html("<img src='data:image/png;base64,"+item.createdBy.file.imageContent+"' style='width:40px;height:40px;' title='"+item.createdBy.companyName+"'/><br>"+item.createdBy.companyName);
        else
        	patternRow.find('#logoOffice').attr("id", 'logoOffice-' + id).find('span').html("<img src='../../core/img/image01.png'  style='width:40px;height:40px;' title='"+item.createdBy.companyName+"'><br>"+item.createdBy.companyName);

        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.find('#entityId2').attr("id", 'entityId2-' + id);
        patternRow.appendTo(tableBody);
        entityCatch[id] = item;
        $(patternRow).on('dblclick', function () {
        	newWindow(id);
        	
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
    	searchResultEntities = result.result;
        if (result.result) {
            fillGrid(result.result);
        } else {
            hideLoading();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("shipmentName", '$("#shipmentName_Searcher").val()', Condition.CONTAINS);


function search(){
    ServiceInvoker.call(fSearch.getFilters(), hSearch, "/qoutRequest/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
$(document).ready(function () {
	if(user.roleId != 10001){
		if(user.roleId == 10004){//Forwarder
			$('#newQuote').show();
		}else if(user.roleId == 10005){//Shiper
			$('#newQuote').hide();
		}
	}
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    /*$('#search').on('click', function () {
        search();
    })*/
	
    $('#search').on('click', function () {
    	$('#quote').css('display','none');
    	fSearch.addParameter("shipmentName", '$("#shipmentName_Searcher").val()', Condition.CONTAINS);
        if(AdvanceSearch.initializeFilter().length > 0) {
            fSearch.removeParameter(Condition.WHERE);
            fSearch.addParameter(Condition.WHERE, AdvanceSearch.initializeFilter(), Condition.WHERE);
            $('.win-content-header').removeClass('full-search compact')
            $('#clear-filter').removeClass('hide');
        } else if($('.simple-search input').val().trim().length > 0) {
            $('#clear-filter').removeClass('hide');
        }
        search();
        $('.win-content-header').removeClass('compact full-search')

    })

    $('#clear-filter').on('click', function () {
    	$('#quote').css('display','none');
        // Remove Advance Filter Key From Filter Object & Clear Advanced Form & Clear Simple Search From
        $('#filter-item-container').empty();
        $('.simple-search input').val('');
        fSearch.removeParameter(Condition.WHERE);
        fSearch.clearParams();
        
        this.classList.add('hide');
        search()
    })
    $('#new-qout').on('click',function(){
    	newWindow();
    })
    $('#return-btn').on('click',function(){
    	//window.location.href ="panel.html";
    	backToGrid();
    })
    $('#plane').on('click',function(){
    	fSearch.addParameter("freightMethodType.rowId", '10002', Condition.EQUAL);
    	search();
    	$('#clear-filter').removeClass('hide');
    })
     $('#boat').on('click',function(){
    	fSearch.addParameter("freightMethodType.rowId", '10003', Condition.EQUAL);
    	search();
    	$('#clear-filter').removeClass('hide');
    })
     $('#bus').on('click',function(){
    	fSearch.addParameter("freightMethodType.rowId", '10005', Condition.EQUAL);
    	search();
    	$('#clear-filter').removeClass('hide');
    })
    
    $('#newQuote').on('click',function(){
    	var id = $(this).closest('ul').parent().attr('data-id');
    	if(entityCatch[id].qoutReqStatusTypeDTO.rowId == 100027){
        	addTab({
                window: window,
                src: '/app/quote/index.html',
        		title: 'Quote',
                filter: [
                    {
                        filterTitle: 'Quote',
                        key: 'qouteRequest.rowId',
                        value: id,
                        condition: Condition.EQUAL,
                        title:getSearchResultValue(id, 'shipmentName')
                    }
                ]
            })
        }else{
        	dialog('Warning', 'Warning : First Publish Request');
        }
    });
    /*----------------------------------------------------------------------------------- Initialization -------------*/
	AdvanceSearch.init();
    setIndexListeners();
    search();

});
/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
	showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        hideLoading();
        setTimeout(function () {
            showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/qoutRequest/list");
    pageNo = oldPageNo;
}
/*--------------------------------------------------------------------------- Open New Tab --------------------------------------------*/
function newWindow(id){
	var title="";
	if(entityCatch[id]){
		title = entityCatch[id].shipmentName;
		if(title.length > 15)
			title = title.substr(0,15)+" ...";
	}else{
		title="Quote Request";
	}
	addTab({
        window: window,
        src: '/app/quoterequest/panel.html',
		title: title,
        filter: [
            {
                filterTitle: 'Edit Quote Request',
                key: 'rowId',
                value: id,
                condition: Condition.EQUAL,
                title:''
            }
        ]
    })
}
/*------------------------------------------------------------------------ Delete Package -----------------------------------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            //search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/rfqPackage/delete");
}
function showFrameLog(id){
    /*if(entityCatch[id].qoutReqStatusTypeDTO.rowId == 100027){
    	//window.frames['quote'].location="../quote/edit.html?id="+id;
    	addTab({
            window: window,
            src: '/app/quote/index.html',
    		title: 'Quote',
            filter: [
                {
                    filterTitle: 'Quote',
                    key: 'qouteRequest.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    title:getSearchResultValue(id, 'shipmentName')
                }
            ]
        })
    }else{*/
    	showLoading();
        hideLoading();
        window.frames['quote'].location="../rfqlog/edit.html?id="+id;
        setTimeout(function () {
        	$('#quote').css('display','');
        }, 300);
    //}
    	
}
/*--------------------------------------------------------------------------------------- End ------------------------*/