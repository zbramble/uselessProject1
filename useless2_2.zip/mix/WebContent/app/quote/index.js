/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var id,title;
var entityCatch=[];
var searchFields = [
    
    { propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'ID', maxlength: 7 },
    {
        propName: 'e.createdBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Created by',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    {
        propName: 'e.updatedBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Updated by',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    { propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created', maxlength: 8 },
    { propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated', maxlength: 8 }
]


/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#discountAmount").attr("id", 'discountAmount-' + id).find('span').html(item.discountAmount);
        patternRow.find("#total").attr("id", 'total-' + id).find('span').html(item.total);
        patternRow.find("#carrierName").attr("id", 'carrierName-' + id).find('span').html(item.carrierName);
        
        patternRow.find("#qouteRequestDTO").attr("id", 'qouteRequestDTO-' + id).find('span').html(item.qouteRequestDTO ? item.qouteRequestDTO.shipmentName : '');
        patternRow.find("#freightMethodDTO").attr("id", 'freightMethodDTO-' + id).find('span').html(item.freightMethodDTO ? item.freightMethodDTO.name : '');
        patternRow.find("#freightTypeDTO").attr("id", 'freightTypeDTO-' + id).find('span').html(item.freightTypeDTO ? item.freightTypeDTO.name : '');
        
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
	
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);

        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#discountAmount").attr("id", 'discountAmount-' + id).find('span').html(item.discountAmount);
        patternRow.find("#total").attr("id", 'total-' + id).find('span').html(item.total);
        patternRow.find("#carrierName").attr("id", 'carrierName-' + id).find('span').html(item.carrierName);
        
        patternRow.find("#qouteRequestDTO").attr("id", 'qouteRequestDTO-' + id).find('span').html(item.qouteRequestDTO ? item.qouteRequestDTO.shipmentName : '');
        if(item.freightMethodDTO){
        	if(item.freightMethodDTO.rowId == 10002)
        		patternRow.find("#freightMethodDTO").attr("id", 'freightMethodDTO-' + id).find('span').html('<span class="ion-android-plane" style="font-size:20px;"></span>');
        	if(item.freightMethodDTO.rowId == 10003)
        		patternRow.find("#freightMethodDTO").attr("id", 'freightMethodDTO-' + id).find('span').html('<span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(item.freightMethodDTO.rowId == 10004)
        		patternRow.find("#freightMethodDTO").attr("id", 'freightMethodDTO-' + id).find('span').html('<span class="ion-android-plane" style="font-size:20px;"></span><span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(item.freightMethodDTO.rowId == 10005)
        		patternRow.find("#freightMethodDTO").attr("id", 'freightMethodDTO-' + id).find('span').html('<span class="ion-android-bus" style="font-size:20px;"></span>');

        }
        if(item.createdBy.file)
        	patternRow.find('#logoOffice').attr("id", 'logoOffice-' + id).find('span').html("<img src='data:image/png;base64,"+item.createdBy.file.imageContent+"' style='width:40px;height:40px;' title='"+item.createdBy.companyName+"'/><br>"+item.createdBy.companyName);
        else
        	patternRow.find('#logoOffice').attr("id", 'logoOffice-' + id).find('span').html("<img src='../../core/img/image01.png'  style='width:40px;height:40px;' title='"+item.createdBy.companyName+"'><br>"+item.createdBy.companyName);

        //patternRow.find("#freightMethodDTO").attr("id", 'freightMethodDTO-' + id).find('span').html(item.freightMethodDTO ? item.freightMethodDTO.name : '');
        patternRow.find("#freightTypeDTO").attr("id", 'freightTypeDTO-' + id).find('span').html(item.freightTypeDTO ? item.freightTypeDTO.name : '');
        patternRow.find("#quoteStatusTypeDTO").attr("id", 'quoteStatusTypeDTO-' + id).find('span').html(item.quoteStatusTypeDTO ? item.quoteStatusTypeDTO.name : '');
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.find('#entityId2').attr("id", 'entityId2-' + id);
        patternRow.appendTo(tableBody);
        entityCatch[id] = item;
       /* $(patternRow).on('dblclick', function () {
            showRow(id)
        });*/
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
    	searchResultEntities = result.result;
        if (result.result) {
            fillGrid(result.result);
        } else {
        	hideLoading();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("carrierName", '$("#carrierName_Searcher").val()', Condition.CONTAINS);


function search(){
    ServiceInvoker.call(fSearch.getFilters(), hSearch, "/quote/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
    window.frames['editFrame'].showRow(id)
}
var methodId,methodName;
var freightTypeId,freightTypeName;
var origionLocationId,origionLocationName;
var destinationLocationId,destinationLocationname;
function loadData(id){
	var h = new Handler();
	h.success = function success(result) {
	    if (result.done) {
	        if (result.result) {
	        	var data = result.result;
	        	data.forEach(function (item, index) {
	        		//window.frames['editFrame'].fillData(item);
	        		methodId = item.freightMethodTypeDTO.rowId;
	        		methodName = item.freightMethodTypeDTO.name;
	        		freightTypeId = (item.freightTypeDTO ? item.freightTypeDTO.rowId : '');
	        		freightTypeName = (item.freightTypeDTO ? item.freightTypeDTO.name : '');
	        		origionLocationId = (item.origionLocationDTO ? item.origionLocationDTO.rowId : '');
	        		origionLocationName = (item.origionLocationDTO ? item.origionLocationDTO.name : '');
	        		destinationLocationId = (item.destinationLocationDTO ? item.destinationLocationDTO.rowId : '');
	        		destinationLocationName= (item.destinationLocationDTO ? item.destinationLocationDTO.name : '');
	        	})
	        } else {

	        }
	    } else {
	        hideLoading();
	        setTimeout(function () {
	            errorHandle(result);
	        }, 300)
	    }
	}
	h.error = function error(jqXHR, textStatus) {

	}
	h.complete = function complete() {
	    unlockPage();
	}
	var f = new Filter();
	f.addParameter("rowId", id, Condition.EQUAL);
	ServiceInvoker.call(f.getFilters(), h, "/qoutRequest/list");
}

$(document).ready(function () {
	var tabID = window.location.href.urlParameter('tabID');
    if(tabID != null && tabID != 0) { // is opened as tab
    	$('#new-entity').show();
    	var filterArray = top.tabFilter[tabID];
    	fSearch.addParameter(filterArray[0].key, filterArray[0].value, filterArray[0].condition,filterArray[0].title);
	 	  title = filterArray[0].title;
	 	  id = filterArray[0].value;
	 	  loadData(id);
    }else
    	$('#new-entity').hide();
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    $('#search').on('click', function () {
        if(AdvanceSearch.initializeFilter().length > 0) {
            fSearch.removeParameter(Condition.WHERE);
            fSearch.addParameter(Condition.WHERE, AdvanceSearch.initializeFilter(), Condition.WHERE);
            $('.win-content-header').removeClass('full-search compact')
            $('#clear-filter').removeClass('hide');
        } else if($('.simple-search input').val().trim().length > 0) {
            $('#clear-filter').removeClass('hide');
        }
        search();
        $('.win-content-header').removeClass('compact full-search')

    })

    $('#clear-filter').on('click', function () {
        // Remove Advance Filter Key From Filter Object & Clear Advanced Form & Clear Simple Search From
        $('#filter-item-container').empty();
        $('.simple-search input').val('');
        fSearch.removeParameter(Condition.WHERE);
        this.classList.add('hide');
        search();
    })
    $('#reward').on('click',function(){
    	var id = $(this).closest('ul').parent().attr('data-id');
    	var saveHandler = new Handler();
    	saveHandler.success = function success(result) {
       	 if (result.done) {
            	searchResultEntities = result.result;
                if (result.result) {
                	search();
                } else {
                    hideLoading();
                    setTimeout(function () {
                        showError("No things to show");
                    }, 300)
                }
            }
            else {
                errorHandle(result);
            }
        }
    	saveHandler.error = function error(jqXHR, textStatus) {
       	 setTimeout(function () {
       	        showError("Error: " + ResponseCode[jqXHR.status]);
       	    }, 300)
        }
    	var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
    	var temp = '<br>';
    	temp += '<span>shipmentName :'+entityCatch[id].qouteRequestDTO.shipmentName+'</span>';
    	if(today <= entityCatch[id].expirationDate){
    	dialog('Confirm', 'Do you sure for reward ?'+temp, function () {
        		statusId = 100028 ; //Rewarded
	        		var data = '{"rowId": "' + id + '"' +
	        	    ', "quoteStatusTypeDTO" : {"rowId":' + statusId + '}'+
	        	    ', "qouteRequestDTO" : {"rowId":' + entityCatch[id].qouteRequestDTO.rowId + '}'+
	        	    ',"expirationDate" : "'+entityCatch[id].expirationDate+'"'+
	        	    ', "ticket":"' + user.ticket + '"}';
	            	ServiceInvoker.call(data , saveHandler, "/quote/updateStatus");
        }, function () {
        })
    	}else{
			dialog('Expire Date','Expiration Date');
		}
    	//}
    })
    $('#reject').on('click',function(){
    	var id = $(this).closest('ul').parent().attr('data-id');
    	var saveHandler = new Handler();
    	saveHandler.success = function success(result) {
       	 if (result.done) {
            	searchResultEntities = result.result;
                if (result.result) {
                	search();
                } else {
                    hideLoading();
                    setTimeout(function () {
                        showError("No things to show");
                    }, 300)
                }
            }
            else {
                errorHandle(result);
            }
        }
    	saveHandler.error = function error(jqXHR, textStatus) {
       	 setTimeout(function () {
       	        showError("Error: " + ResponseCode[jqXHR.status]);
       	    }, 300)
        }
    	var temp = '<br>';
    	temp += '<span>shipmentName :'+entityCatch[id].qouteRequestDTO.shipmentName+'</span>';
    	//if(entityCatch[id].qouteRequestDTO.qoutReqStatusTypeDTO.rowId == 100027 ){//Published
    	dialog('Confirm', 'Do you sure for reject ?'+temp, function () {
        		statusId = 1000126 ; //Reject
        		var data = '{"rowId": "' + id + '"' +
        	    ', "quoteStatusTypeDTO" : {"rowId":' + statusId + '}'+
        	    ', "qouteRequestDTO" : {"rowId":' + entityCatch[id].qouteRequestDTO.rowId + '}'+
        	    ', "ticket":"' + user.ticket + '"}';
            	ServiceInvoker.call(data , saveHandler, "/quote/updateStatus");
        }, function () {
        })
    	//}
    })
    $('#editBtn').on('click',function(){
    	  var hSave = new Handler();
          hSave.success = function success(result) {
              if (result.done) {
                  dialog('Save', result.resultCountAll + ' Item Edit');
                  $("#rowId").val(result.result);
                  loadQuoteToDetail();
              }
              else {
                  errorHandle(result);
              }
          }
          hSave.error = function error(jqXHR, textStatus) {
              dialog('Save', textStatus + 'Error: ')
          }
          
          saveRow('edit-form', hSave, "/quote/save");
    })
    /*----------------------------------------------------------------------------------- Initialization -------------*/
	AdvanceSearch.init();
    setIndexListeners();
    search();

});
function showFrameLog(id){
	showLoading();
    hideLoading();
    window.frames['quote'].location="../quotelog/edit.html?id="+id;
    setTimeout(function () {
    	$('#quote').css('display','');
    }, 300);
}
/* -------------------------------------------------------------------- LOAD DATA DETAIL PAGE --------------------------------------------------------*/
function loadQuoteToDetail(){
	//window.frames['quoteData'].location = "quote/view.html"
	var ret = parent.window.frames['quoteDetail'].location.toString();
	var resultId = ret.split("?id=");
	var id = resultId[1];
	var h = new Handler();
	h.beforeSend = function beforeSend() {
	    showLoading();
	}
	h.success = function success(result) {
	    if (result.done) {
	    	searchResultEntities = result.result;
	        if (result.result) {
	        	fillDetail(result.result);
	        } 
	    }
	}
	h.error = function error(jqXHR, textStatus) {
	    setTimeout(function () {
	        showError("Error: " + ResponseCode[jqXHR.status]);
	    }, 300)
	}
	h.complete = function complete() {
	    unlockPage();
	}
	fSearch.clearParams();
	fSearch.addParameter("rowId", id, Condition.EQUAL);
	ServiceInvoker.call(fSearch.getFilters(), h, "/quote/list");
}
function fillDetail(entities){
	clearForm();
	entities.forEach(function (item, index) {
        $('#view-arrivalLocationDTO').html(item.arrivalLocationDTO ? item.arrivalLocationDTO.name : '');
        $('#rowId').val(item.rowId);
        if(item.arrivalLocationDTO){
        	$('#arrivalLocationDTO').val(item.arrivalLocationDTO.name);
        	$("#arrivalLocationDTO").attr('entityId',item.arrivalLocationDTO.rowId);
        }
        $('#view-origionAddress').html(item.origionAddress);
        $('#origionAddress').val(item.origionAddress);
        
        $('#view-quoteStatusTypeDTO').html(item.quoteStatusTypeDTO ? item.quoteStatusTypeDTO.name : '');
        if(item.quoteStatusTypeDTO){
        	$('#quoteStatusTypeDTO').val(item.quoteStatusTypeDTO.name);
        	$("#quoteStatusTypeDTO").attr('entityId',item.quoteStatusTypeDTO.rowId);
        }
        $('#view-departureLocationDTO').html(item.departureLocationDTO ? item.departureLocationDTO.name : '');
        if(item.departureLocationDTO){
        	$('#departureLocationDTO').val(item.departureLocationDTO.name);
        	$('#departureLocationDTO').attr('entityId',item.departureLocationDTO.rowId);
        }
        $('#view-departureDays').html(item.departureDays);
        $('#departureDays').val(item.departureDays);
        
        $('#view-destinationAddress').html(item.destinationAddress);
        $('#destinationAddress').val(item.destinationAddress);
        
        $('#view-qouteRequestDTO').html(item.qouteRequestDTO ? item.qouteRequestDTO.shipmentName : '');
        if(item.qouteRequestDTO){
        	$('#qouteRequestDTO').val(item.qouteRequestDTO.shipmentName);
        	$('#qouteRequestDTO').attr('entityId',item.qouteRequestDTO.rowId);
        }
        $('#view-freightMethodDTO').html(item.freightMethodDTO ? item.freightMethodDTO.name : '');
        if(item.freightMethodDTO){
        	$('#freightMethodDTO').val(item.freightMethodDTO.name);
        	$('#freightMethodDTO').attr('entityId',item.freightMethodDTO.rowId);
        }
        
        $('#view-quoteReference').html(item.quoteReference);
        $('#quoteReference').val(item.quoteReference);
        
        $('#view-freightTypeDTO').html(item.freightTypeDTO ? item.freightTypeDTO.name : '');
        if(item.freightTypeDTO){
        	$('#freightTypeDTO').val(item.freightTypeDTO.name);
        	$('#freightTypeDTO').attr('entityId',item.freightTypeDTO.rowId);
        }
        
        $('#view-carrierName').html(item.carrierName);
        $('#view-transitTimeDays').html(item.transitTimeDays);
        $('#view-closingDays').html(item.closingDays);
        
        $('#view-estimatedEmisssions').html(item.estimatedEmisssions );
        $('#view-total').html(item.total);
        $('#view-discountPercentage').html(item.discountPercentage);
        
        $('#view-discountAmount').html(item.discountAmount);
        $('#view-expirationDate').html(item.expirationDate);

        $('#carrierName').val(item.carrierName);
        $('#transitTimeDays').val(item.transitTimeDays);
        $('#closingDays').val(item.closingDays);
        
        $('#estimatedEmisssions').val(item.estimatedEmisssions );
        $('#total').val(item.total);
        $('#discountPercentage').val(item.discountPercentage);
        
        $('#discountAmount').val(item.discountAmount);
        $('#expirationDate').val(item.expirationDate);

    });
}
function openPage(){
	$('#quoteView').hide();
	$('#quoteEdit').show();
	
	/*var ret = parent.window.frames['quoteDetail'].location.toString();
	var resultId = ret.split("?id=");
	var id = resultId[1];
	addTab({
        window: parent.parent.window,
		src: '/app/quote/edit.html',
		title: 'Quote',
        filter: [
            {
                filterTitle: 'Quote',
                key: 'rowId',
                value: id,
                condition: Condition.EQUAL,
                title:getSearchResultValue(id, 'qouteRequestDTO.shipmentName')
            }
        ]
    })*/
}
/*--------------------------------------------------------------------------------------- End ------------------------*/