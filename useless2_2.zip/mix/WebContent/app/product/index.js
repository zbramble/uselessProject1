/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;

var searchFields = [
    { key: 'rowId', propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'ID', maxlength: 20 },
    { key: 'sku',propName: 'e.sku', type: SearchPropertyType.TEXT, title: 'SKU', maxlength: 20 },
    { key: 'manufactureSku',propName: 'e."manufactureSku"', type: SearchPropertyType.TEXT, title: 'Manufacture SKU', maxlength: 20 },
    { key: 'productTitle',propName: 'e.productTitle', type: SearchPropertyType.TEXT, title: 'Product Name', maxlength: 20 },
    {
    	key: 'brand',
    	propName: 'e.brand.rowId',
        autocompleteInstance: 'AutocompleteDynamicBrand',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Brand',
        maxlength: 50,
        autocompleteProp: 'brandTitle',
        autocompleteCondition: Condition.CONTAINS
    },
    { key: 'barcode',propName: 'e.barcode', type: SearchPropertyType.TEXT, title: 'UPC/Barcode', maxlength: 20 },
    {
    	key: 'category',
    	propName: 'e.category.rowId',
        autocompleteInstance: 'AutocompleteDynamicCategory',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Category',
        maxlength: 50,
        autocompleteProp: 'categoryDescription',
        autocompleteCondition: Condition.CONTAINS
    },
    {
    	key: 'relatedProduct',
    	propName: 'e.relatedProduct.rowId',
        autocompleteInstance: 'AutocompleteDynamicProduct',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Related SKU',
        maxlength: 50,
        autocompleteProp: 'productTitle',
        autocompleteCondition: Condition.CONTAINS
    },
    {
    	key: 'relationShipType',
    	propName: 'e.relationShipType.rowId',
        autocompleteInstance: 'AutocompleteDynamicComboVal',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Relationship Type',
        maxlength: 50,
        autocompleteProp: 'name',
        autocompleteCondition: Condition.CONTAINS,
        initialFilter: {key: 'val', value: 'PRO_RELATION_TYPE', condition: Condition.EQUAL}
    },
    { key: 'salePrice',propName: 'e.salePrice', type: SearchPropertyType.TEXT, title: 'Wholesale/Sale Price', maxlength: 20 },
    {
    	key: 'currencyType',
    	propName: 'e.currencyType.rowId',
        autocompleteInstance: 'AutocompleteDynamicCurrency',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Currency',
        maxlength: 50,
        autocompleteProp: 'title',
        autocompleteCondition: Condition.CONTAINS
    },
    {
    	key: 'taxClass',
    	propName: 'e.taxClass.rowId',
        autocompleteInstance: 'AutocompleteDynamicTax',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Tax Class',
        maxlength: 50,
        autocompleteProp: 'taxClassTitle',
        autocompleteCondition: Condition.CONTAINS
    },
    {
    	key: 'createdBy',
    	propName: 'e.createdBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Created By',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    {
    	key: 'updatedBy',
    	propName: 'e.updatedBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Updated By',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    { key: 'created',propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created', maxlength: 8 },
    { key: 'updated',propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated', maxlength: 8 },
    { key: 'active',propName: 'e.active', type: SearchPropertyType.BOOLEAN, title: 'Active', maxlength: -1}
    
]


/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#sku").attr("id", 'sku-' + id).find('span').html(item.sku);
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);

        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#sku").attr("id", 'sku-' + id).find('span').html(item.sku);
        patternRow.find("#barcode").attr("id", 'barcode-' + id).find('span').html(item.barcode);
        patternRow.find('#manufactureSku').attr("id", 'manufactureSku-' + id).find('span').html(item.manufactureSku);
        patternRow.find('#productTitle').attr("id", 'productTitle-' + id).find('span').html(item.productTitle);
        patternRow.find('#category').attr("id", 'category-' + id).find('span').html(item.categoryDTO ? item.categoryDTO.categoryDescription : '');
       
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
    	searchResultEntities = result.result;
        if (result.result) {
            fillGrid(result.result);
        } else {
            hideLoading();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("sku", '$("#sku_Searcher").val()', Condition.CONTAINS);


function search(){
    ServiceInvoker.call(fSearch.getFilters(), hSearch, "/product/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
    window.frames['editFrame'].showRow(id)
}


$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    /*$('#search').on('click', function () {
        search();
    })*/
	$('#standard').on('click', function () {
		var id = $(this).closest('ul').parent().attr('data-id');
		addTab({
            window: window,
            src: '/app/productstandard/edit.html',
			title: 'Standard Properties',
            filter: [
                {
                    filterTitle: 'Standard Properties',
                    key: 'product.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    productTitle:getSearchResultValue(id, 'productTitle')
                }
            ]
        })
	})
	$('#weight').on('click', function () {
		var id = $(this).closest('ul').parent().attr('data-id');

		addTab({
            window: window,
            src: '/app/productweightdimension/edit.html',
			title: 'Weight & Dimension',
            filter: [
                {
                    filterTitle: 'Weight & Dimension',
                    key: 'product.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    productTitle:getSearchResultValue(id, 'productTitle')
                }
            ]
        })
	})
	$('#multimedia').on('click', function () {
		var id = $(this).closest('ul').parent().attr('data-id');

		addTab({
            window: window,
			src: '/app/productmultimedia',
			title: 'Multimedia',
            filter: [
                {
                    filterTitle: 'Multimedia',
                    key: 'product.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    productTitle:getSearchResultValue(id, 'productTitle')
                }
            ]
        })
	})
	$('#extended').on('click', function () {
		var id = $(this).closest('ul').parent().attr('data-id');

		addTab({
            window: window,
			src: '/app/productextended',
			title: 'Extended Properties',
            filter: [
                {
                    filterTitle: 'Extended Properties',
                    key: 'product.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    productTitle:getSearchResultValue(id, 'productTitle')
                }
            ]
        })
	})
			
    $('#search').on('click', function () {
        if(AdvanceSearch.initializeFilter().length > 0) {
            fSearch.removeParameter(Condition.WHERE);
            fSearch.addParameter(Condition.WHERE, AdvanceSearch.initializeFilter(), Condition.WHERE);
            $('.win-content-header').removeClass('full-search compact')
            $('#clear-filter').removeClass('hide');
        } else if($('.simple-search input').val().trim().length > 0) {
            $('#clear-filter').removeClass('hide');
        }
        search();
        $('.win-content-header').removeClass('compact full-search')

    })

    $('#clear-filter').on('click', function () {
        // Remove Advance Filter Key From Filter Object & Clear Advanced Form & Clear Simple Search From
        $('#filter-item-container').empty();
        $('.simple-search input').val('');
        fSearch.removeParameter(Condition.WHERE);
        this.classList.add('hide');
        search()
    })
    
    /*----------------------------------------------------------------------------------- Initialization -------------*/
	AdvanceSearch.init();
    setIndexListeners();
    search();

});

/*--------------------------------------------------------------------------------------- End ------------------------*/