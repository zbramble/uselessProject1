$(document).ready(function () {
        /*----------------------------------------------------------------------------------- Search -----------------*/
        var hSearch = new Handler();
        hSearch.beforeSend = function beforeSend() {
            lockPage();
        }
        hSearch.success = function success(result) {
            if (result.done) {
                $("#employeeGrid").empty();
                if (!result.result) {
                    $("#dataGrid").css({"display": "none"});
                    //alert('No things found');
                    return;
                } else {
                    $("#dataGrid").css({"display": ""});
                }
                for (var i = 0; result.result && i < result.result.length; i++) {
                    var entityId = result.result[i].employeeId;
                    var clone = $("#row").clone();
                    clone.find("[id]").add(clone).each(function () {
                        this.id = this.id + '-' + entityId;
                    });
                    clone.find("#id-" + entityId).html(i + 1 + (pageNo - 1) * pageSize);
                    clone.find("#employeeId-" + entityId).html(result.result[i].employeeId);
                    if (result.result[i].eduDuration != undefined) {
                        clone.find("#eduDuration-" + entityId).html(result.result[i].eduDuration.durationTitle);
                        clone.find("#eduDuration-" + entityId).attr("entityId", result.result[i].eduDuration.eduDurationId);
                    }
                    if (result.result[i].organization != undefined) {
                        clone.find("#organization-" + entityId).html(result.result[i].organization.name);
                        clone.find("#organization-" + entityId).attr("entityId", result.result[i].organization.organizationId);
                    }
                    if (result.result[i].person != undefined) {
                        clone.find("#person-" + entityId).html(result.result[i].person.nationalId);
                        clone.find("#person-" + entityId).attr("entityId", result.result[i].person.personId);
                    }
                    if (result.result[i].employeeType != undefined) {
                        clone.find("#employeeType-" + entityId).html(result.result[i].employeeType.name);
                        clone.find("#employeeType-" + entityId).attr("entityId", result.result[i].employeeType.comboValId);
                    }
                    if (result.result[i].employeeStatusType != undefined) {
                        clone.find("#employeeStatusType-" + entityId).html(result.result[i].employeeStatusType.name);
                        clone.find("#employeeStatusType-" + entityId).attr("entityId", result.result[i].employeeStatusType.comboValId);
                    }
                    clone.find("#isActive-" + entityId).html(result.result[i].isActive ? "Active" : "Inactive");

                    clone.appendTo("#employeeGrid");
                }

                $("#gridDiv").show('slow');

                $('tr[id^="row-"]').dblclick(function () {
                    showRow(this.id.split('-')[1]);
                });
            } else {
                errorHandle(result);
            }
        }
        hSearch.error = function error(jqXHR, textStatus) {
            alert("Error: " + textStatus + ' ' + jqXHR.status);
        }
        hSearch.complete = function complete() {
            unlockPage();
        }

        var fSearche = new Filter();
        fSearche.addParameter("optionText", '$("#employee_Searcher").val()', Condition.EQUAL);

        function search() {
            ServiceInvoker.call(fSearche.getFilters(), hSearch, "/employee/list");
            $("#gridDiv").show('slow');
        }

        /*----------------------------------------------------------------------------------- Show Row ---------------*/
        var hShowRow = new Handler();
        hShowRow.beforeSend = function beforeSend() {
            lockPage();
        }
        hShowRow.success = function success(result) {
            if (result.done) {
                $('#editDiv').show('slow');
                $('#editDiv').css({"height": "100%"});
                window.frames['editFrame'].fillEdit(result.result[0]);
            } else {
                errorHandle(result);
            }
        }
        hShowRow.error = function error(jqXHR, textStatus) {
            alert("Error: " + textStatus + ' ' + jqXHR.status);
        }
        hShowRow.complete = function complete() {
            unlockPage();
        }

        var fShrSearche = new Filter();

        function showRow(id) {
            fShrSearche.clearParams();
            fShrSearche.addParameter("employeeId", id, Condition.EQUAL)
            var oldPageNo = pageNo;
            pageNo = 1;
            ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/employee/list");
            pageNo = oldPageNo;
        }

        /*----------------------------------------------------------------------------------- Add New  ---------------*/
        function addNew() {
            $('#editDiv').show('slow');
            $('#editDiv').css({"height": "100%"});
            window.frames['editFrame'].addNew();
        }

        /*----------------------------------------------------------------------------------- Listener ---------------*/
        $('#sendBTN').click(function () {
            pageNo = 1;
            $('#pageNo').val('1');
            search();
        });

        $('#sendNewBTN').click(function () {
            addNew();
        });

        $('#next').click(function () {
            if ($("#pageNo").length > 0) {
                pageNo = $("#pageNo").val();
                $("#pageNo").val(++pageNo)
            } else
                pageNo++;
            search();
        });

        $('#prev').click(function () {
            if ($("#pageNo").length > 0) {
                pageNo = $("#pageNo").val();
                if (pageNo == 1)
                    return;
                $("#pageNo").val(--pageNo)
            } else {
                if (pageNo == 1)
                    return;
                pageNo--;
            }
            search();
        });
    }
)

/*--------------------------------------------------------------------------------------- Hide Edit ------------------*/
function hideEdit() {
    $('#editDiv').hide('slow');
}
/*--------------------------------------------------------------------------------------- End ------------------------*/