/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var ret = parent.window.frames['quoteItem'].location.toString();
var resultId = ret.split("?id=");
var searchFields = [

{
	propName : 'e.rowId',
	type : SearchPropertyType.NUMBER,
	title : 'ID',
	maxlength : 7
}, {
	propName : 'e.createdBy.rowId',
	autocompleteInstance : 'AutocompleteDynamicUser',
	type : SearchPropertyType.AUTOCOMPLETE,
	title : 'Created by',
	maxlength : 50,
	autocompleteProp : 'lastName',
	autocompleteCondition : Condition.CONTAINS
}, {
	propName : 'e.updatedBy.rowId',
	autocompleteInstance : 'AutocompleteDynamicUser',
	type : SearchPropertyType.AUTOCOMPLETE,
	title : 'Updated by',
	maxlength : 50,
	autocompleteProp : 'lastName',
	autocompleteCondition : Condition.CONTAINS
}, {
	propName : 'e.created',
	type : SearchPropertyType.DATE,
	title : 'Created',
	maxlength : 8
}, {
	propName : 'e.updated',
	type : SearchPropertyType.DATE,
	title : 'Updated',
	maxlength : 8
} ]

/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
	var cardContainer = $('.card-container');
	var patternRow = cardContainer.find('section#row');
	cardContainer.css({
		"display" : "block"
	});
	cardContainer.find('section').not(patternRow).remove();

	entities
			.forEach(function(item, index) {
				var newRow = patternRow.clone();
				var id = item.rowId;
				newRow.attr('id', 'row-' + id);
				newRow.find('.row-number').html(
						index + 1 + (pageNo - 1) * pageSize);
				patternRow.find("#rowId").attr("id", 'rowId-' + id)
						.find('span').html(item.rowId);
				patternRow.find("#quantity").attr("id", 'quantity-' + id).find(
						'span').html(item.quantity);

				patternRow.find("#quoteDTO").attr("id", 'quoteDTO-' + id).find(
						'span').html(
						item.quoteDTO ? item.quoteDTO.fullTitle : '');
				patternRow
						.find("#freightChargeTypeDTO")
						.attr("id", 'freightChargeTypeDTO-' + id)
						.find('span')
						.html(
								item.freightChargeTypeDTO ? item.freightChargeTypeDTO.chargeTypeTitle
										: '');

				patternRow.find('#createdBy').attr("id", 'createdBy-' + id)
						.find('span').html(item.createdBy.fullTitle);
				patternRow.find('#created').attr("id", 'created-' + id).find(
						'span').html(item.created);
				patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id)
						.find('span').html(item.updatedBy.fullTitle);
				patternRow.find('#updated').attr("id", 'updated-' + id).find(
						'span').html(item.updated);
				patternRow.find("#active").attr("id", 'active-' + id).find(
						'span').html(item.active ? "Active" : "Inactive");
				patternRow.find('#entityId').attr("id", 'entityId-' + id);

				newRow.appendTo(cardContainer);
			})

	// Listener(s)
	$('.row-action').on(
			'click',
			function(e) {
				e.stopPropagation()
				$('.row-action-item').not($(this).find('.row-action-item'))
						.removeClass('show');
				$(this).find('.row-action-item').toggleClass('show');
			})
	cardContainer.on('click', function() {
		$('.row-action-item').removeClass('show');
	})
	$('.row-action-item.remove').on('click', function() {
		alert('Remove');
	})
	$('.row-action-item.edit').on('click', function() {
		showRow($(this).parent().attr('id').split('-')[1]);
	})

	patternRow.css({
		'display' : 'none'
	});
	hideLoading();
	setTimeout(function() {
		showGrid();
	}, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/

function fillTable(entities) {

	var pattern = $('.table-responsive');
	pattern.find('table').remove();
	pattern.find('br').remove();
	pattern.find('hr').remove();
	pattern.find('table').removeAttr('style');
	var sumGrandPrice = 0;
	var sumGrandBuy = 0;
	
	/*
	 * load previewBody baraye preview
	 */
	var p = $('#previewBody');
	p.find('table').remove();
	
	entities.forEach(function(item, index) {
				/*
				 * ham zaman ba sakhte rate offer bayad dar jadvale preview niz por shavad
				 */
		
				/*
				 * output result in pattern QuoteItemDTO,id,title or id,title
				 */
				var idType;
				if (item[0] != '[object Object]') {
					idType = item[0][0];
					var bse = "<table style='width: 100%;padding:20px;display: none;' align='center' id='tableBse-"
							+ idType
							+ "'>"
							+ "<tr style='background-color: #d9edf7' id='rowHead' >"
							+ "	<td style='width: 40%;padding:10px;' align='left' id='chargeTypeTitle' class='tr-font'><span>"
							+ item[0][1]
							+ "</span></td>	"
							+ "	<td colspan=6 align='right'><div  style='display: flex;direction: rtl;'>"
							+ "		<a id='new-entity' style='margin-left: 0' class='action-btn bg-info' data-tooltip='New' flow='left' onclick=\"setData("+idType+","+"'"+item[0][1]+"')\" data-toggle='modal' data-target='#myModal'><span class='ion-plus-round'></span>  		</a>       	</div> "
							+ "    </td>" + "</tr>"
							+ "<tr class='tr-font' style='background-color: #f5f5f5'>"
							+ "	<td class='active'>" + "		<span>#</span>"
							+ "	</td>"
							+ "<td orderField='rowId' style='display:none'>"
							+ "<span>Identity</span>" + "</td>" 
							+ "<td orderField='freightChargeType'>"
							+ "<span>Freight Charge Type</span>" 
							+ "</td>  "
							+ "<td orderField='buy'>"
							+ "<span>Buy</span>" + "</td>       "
							+ "<td orderField='sell'>"
							+ "<span>Sell</span>" + "</td>       "
							+ "<td orderField='quantity'>"
							+ "<span>Quantity</span>" + "</td>       "
							+ "<td orderField='price'>"
							+ "<span>Price</span>" + "</td>       "
							+ "<td nowrap width='30px;'> &nbsp; </td>"
							+ "</tr>"
							+"<tr style='padding:10px;'>"
							+"	<td  colspan=2 style='color:#f00'><b>SUBTOTAL</b></td>"
							+" 	<td colspan=3 style='color:#f00'><b><span>$0.00<span></b></td>"
							+" 	<td  style='color:#f00'><b><span>$0.00<span></b></td>"
							+"</tr>"
							+ "</table><br><hr>";
					pattern.append(bse);
					pattern.append('<br/>');
				} else if (item[0] == '[object Object]') {
					var bse = "<table style='width: 100%;padding:20px;display: none;' align='center' id='tableBse-"
							+ item[0].freightChargeTypeDTO.classificatDTO.rowId
							+ "'>"
							+ "<tr style='background-color: #d9edf7' id='rowHead'><td style='width: 40%;padding:10px;' align='left' id='chargeTypeTitle' class='tr-font'><span>"
							+ item[0].freightChargeTypeDTO.classificatDTO.classificationTitle
							+ "</span></td><td colspan=6 align='right'><div  style='display: flex;direction: rtl;'>"
							+ "		<a id='new-entity' style='margin-left: 0' class='action-btn bg-info' data-tooltip='New' flow='left' onclick=\"setData("+item[0].freightChargeTypeDTO.classificatDTO.rowId+","+"'"+item[0].freightChargeTypeDTO.chargeTypeTitle+"')\" data-toggle='modal' data-target='#myModal'><span class='ion-plus-round'></span>  		</a>       	</div> "+
									"</td></tr>"
							+ "<tr class='tr-font' style='background-color: #f5f5f5'>"
							+ "	<td class='active'>" + "		<span>#</span>"
							+ "	</td>"
							+ "<td orderField='rowId' style='display:none'>"
							+ "<span>Identity</span>" + "</td>" 
							+ "<td orderField='freightChargeType'>"
							+ "<span>Freight Charge Type</span>" 
							+ "</td>  "
							+ "<td orderField='buy'>"
							+ "<span>Buy</span>" + "</td>       "
							+ "<td orderField='sell'>"
							+ "<span>Sell</span>" + "</td>       "
							+ "<td orderField='quantity'>"
							+ "<span>Quantity</span>" + "</td>       "
							+ "<td orderField='price'>"
							+ "<span>Price</span>" + "</td>       "
							+ "</tr>";

					/* ================================================================================ Start Load Preview ===========================================================================*/
					var bse2 = "<table style='width: 100%;padding:20px;display: none;' align='center' >"
						+ "<tr style='background-color: #c9c9c9'><td style='padding:10px;font-size:.8rem;font-weight: bold' align='left'colspan=5 ><span>"
						+ item[0].freightChargeTypeDTO.classificatDTO.classificationTitle
						+ "</span></td></tr>"
						+ "<tr class='tr-font' style='background-color: #f5f5f5'>"
						+ "	<td class='active'>Description</td>"
						+ "<td>Buy</td>" 
						+ "<td>Sell</td>  "
						+ "<td>Quantity</td>  "
						+ "<td>Price</td> "
						+ "</tr>";
					/* ================================================================================ End Load Preview ===========================================================================*/
					
					var sumPrice= 0.00;
					var sumBuy=0.00;
					//debugger;
					//pattern.append("<div  style='background-color:#ffffff;'><table style='width:100%'>");
					var quoteItem ="";
					var q="";
					for (var i = 0; i < item.length - 1; i++) {
						if(i%2 != 0){
							quoteItem +=
								" <tr style='background-color: #e9f5f8' id='row-"+item[i].rowId+"'>"
									+ "<td id='id-'>" + "<span>"
									+ item[i].rowId
									+ "</span>"
									+ "</td>"
									+ "<td id='rowId-' style='display:none'>"
									+ "<span>"
									+ item[i].rowId
									+ "</span>"
									+ "</td>"
									+ " <td id='freightChargeTypeDTO-'>"
									+ "<span>"
									+ item[i].freightChargeTypeDTO.chargeTypeTitle
									+ "</span>"
									+ "</td> "
									+ "<td id='buy-'>"
									+ " <span>$"
									+ item[i].buyPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='sell-'>"
									+ " <span>$"
									+ item[i].sellPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='quantity-'>"
									+ " <span>"
									+ item[i].quantity
									+ "</span>"
									+ "</td>"
									+ "<td id='price-'>"
									+ " <span>$"
									+ (item[i].quantity)*(item[i].sellPrice)
									+ "</span>"
									+ "</td> "
								+ "</tr>" ;
							q +=
								" <tr style='background-color: #e9f5f8;font-weight: bold;font-size: .8rem;' id='row-"+item[i].rowId+"'>"
									+ " <td id='freightChargeTypeDTO-'>"
									+ "<span>"
									+ item[i].freightChargeTypeDTO.chargeTypeTitle
									+ "</span>"
									+ "</td> "
									+ "<td id='buy-'>"
									+ " <span>$"
									+ item[i].buyPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='sell-'>"
									+ " <span>$"
									+ item[i].sellPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='quantity-'>"
									+ " <span>"
									+ item[i].quantity
									+ "</span>"
									+ "</td>"
									+ "<td id='price-'>"
									+ " <span>$"
									+ (item[i].quantity)*(item[i].sellPrice)
									+ "</span>"
									+ "</td> "
								+ "</tr>" ;
						}else{
						 quoteItem +=
								" <tr style='background-color: #f3e9e6;' id='row-"+item[i].rowId+"'>"
									+ "<td id='id-'>" + "<span>"
									+ item[i].rowId
									+ "</span>"
									+ "</td>"
									+ "<td id='rowId-' style='display:none'>"
									+ "<span>"
									+ item[i].rowId
									+ "</span>"
									+ "</td>"
									+ " <td id='freightChargeTypeDTO-'>"
									+ "<span>"
									+ item[i].freightChargeTypeDTO.chargeTypeTitle
									+ "</span>"
									+ "</td> "
									+ "<td id='buy-'>"
									+ " <span>$"
									+ item[i].buyPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='sell-'>"
									+ " <span>$"
									+ item[i].sellPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='quantity-'>"
									+ " <span>"
									+ item[i].quantity
									+ "</span>"
									+ "</td>"
									+ "<td id='price-'>"
									+ " <span>$"
									+ (item[i].quantity)*(item[i].sellPrice)
									+ "</span>"
									+ "</td> "
								+ "</tr>" ;
						 q +=
								" <tr style='background-color: #f3e9e6;font-weight: bold;font-size: .8rem;' id='row-"+item[i].rowId+"'>"
									+ " <td id='freightChargeTypeDTO-'>"
									+ "<span>"
									+ item[i].freightChargeTypeDTO.chargeTypeTitle
									+ "</span>"
									+ "</td> "
									+ "<td id='buy-'>"
									+ " <span>$"
									+ item[i].buyPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='sell-'>"
									+ " <span>$"
									+ item[i].sellPrice
									+ "</span>"
									+ "</td> "
									+ "<td id='quantity-'>"
									+ " <span>"
									+ item[i].quantity
									+ "</span>"
									+ "</td>"
									+ "<td id='price-'>"
									+ " <span>$"
									+ (item[i].quantity)*(item[i].sellPrice)
									+ "</span>"
									+ "</td> "
								+ "</tr>" ;
						}
						//pattern.append(quoteItem);
						sumPrice += ((item[i].quantity)*(item[i].sellPrice));
						sumBuy +=  ((item[i].quantity)*(item[i].buyPrice));
					}
					if(sumBuy != 0)
						if(sumBuy.toString().split('.')[1]){
							decimal = (sumBuy.toString().split('.')[1].substring(0,2));
							sumBuy = sumBuy.toString().split('.')[0] +"."+ decimal;
						}
					sumGrandBuy += parseFloat(sumBuy);
					sumGrandPrice += sumPrice;
					quoteItem += "<tr style='padding:10px;background-color: #ffffff;'>"
								+"	<td  colspan=2 style='color:#f00'><b>SUBTOTAL</b></td>"
								+" 	<td colspan=3 style='color:#f00'><b><span>$"
								+sumBuy
								+"<span></b></td>"
								+" 	<td  style='color:#f00'><b><span>$"
								+sumPrice
								+"<span></b></td>"
								+"</tr></table><br><hr>";
					q += "<tr style='padding:10px;background-color: #ffffff;'>"
								+"	<td   style='font-weight: bold;font-size: .8rem'><b>SUBTOTAL</b></td>"
								+" 	<td  colspan=3 style='font-weight: bold;font-size: .8rem'><b><span>$"
								+sumBuy
								+"<span></b></td>"
								+" 	<td  style='font-weight: bold;font-size: .8rem'><b><span>$"
								+sumPrice
								+"<span></b></td>"
								+"</tr></table>";
					//alert(quoteItem)
					pattern.append(bse+quoteItem);
					p.append(bse2+q);
					$('#note').val(item[0].quoteDTO ? item[0].quoteDTO.note : '');
					$('#expirationDate').val(item[0].quoteDTO ? item[0].quoteDTO.expirationDate : '');
					$('#expire-prv').html(item[0].quoteDTO ? item[0].quoteDTO.expirationDate : '');
					$('#shipment-prv').html(item[0].quoteDTO.qouteRequestDTO ? item[0].quoteDTO.qouteRequestDTO.shipmentName : '');
					$('#quote-prv').html(item[0].quoteDTO ? item[0].quoteDTO.createdBy.companyName : '');
					if(item[0].quoteDTO.createdBy.file)
						$('#img-prv').html("<img src='data:image/png;base64," + item[0].quoteDTO.createdBy.file.imageContent+"' style='width: 70px;height: 70px;'/>");
					else
						$('#img-prv').html("<img src='../../core/img/image01.png' style='width: 70px;height: 70px;'/>");
					if(item[0].quoteDTO.payMents){
						$('#paymentTerms').val(item[0].quoteDTO.payMents.name);
						$('#paymentTerms').attr("entityId",item[0].quoteDTO.payMents.rowId);
						$('#payment-prv').html(item[0].quoteDTO.payMents.name);
					}
				}
				
			});
	var ret =  "<table style='width: 100%;padding:20px;display: none;' align='center'>" +
					"<tr>"
						+"	<td  style='color:#f00;width:65%;'><b>Grand Total</b></td>"

						+" 	<td  style='color:#f00;width:15%;' ><b><span>$"
								+sumGrandBuy

						+" 	<td  style='color:#f00;width:20%;text-align:center;'><b><span>$"
								+sumGrandPrice
								+"<span></b></td>"
					+"</tr>" +
				"</table></div></div><hr>";
	var ret2 =  "<table style='width: 100%;padding:20px;display: none;' align='center'>" +
					"<tr style='padding:10px;background-color: #c9c9c9;'>"
						+"	<td  style='width:30%;color:#f00;font-weight: bold;font-size: .8rem'>Grand Total</td>"
						+" 	<td  colspan=3 style='width:52%;color:#f00;font-weight: bold;font-size: .8rem' >$"
								+sumGrandBuy
				
						+" 	<td  style='color:#f00;font-weight: bold;font-size: .8rem;'>$"
								+sumGrandPrice
								+"</td>"
					+"</tr>" +
				"</table></div></div><hr>";
	pattern.append(ret);
	p.append(ret2);
	if(entities.length > 0)
		$('#submit-quote').show();
	else
		$('#submit-quote').hide();
	pattern.find('table').css({'display': ''});
	p.find('table').css({'display': ''});
	hideLoading();
	
	/*setTimeout(function() {
		showGrid();
	}, 300)*/

}
/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
	showLoading();
}
hSearch.success = function success(result) {
	if (result.done) {
		searchResultEntities = result.result;
		if (result.result) {
			fillGrid(result.result);

		} else {
			hideLoading();
			setTimeout(function() {
				showError("No things to show");
			}, 300)
		}
	} else {
		hideLoading();
		setTimeout(function() {
			errorHandle(result);
		}, 300)
	}
}
hSearch.error = function error(jqXHR, textStatus) {
	hideLoading();
	setTimeout(function() {
		showError("Error: " + ResponseCode[jqXHR.status]);
	}, 300)
}
hSearch.complete = function complete() {
	unlockPage();
}

var fSearch = new Filter();
// fSearch.addParameter("quantity", '$("#quantity_Searcher").val()',
// Condition.CONTAINS);

function search() {
	fSearch.addParameter("quote.rowId", resultId[1], Condition.CONTAINS);
	ServiceInvoker.call(fSearch.getFilters(), hSearch, "/quoteItem/list");
	// ServiceInvoker.call(fSearch.getFilters(), hSearch, "/chargeType/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
	window.frames['editFrame'].showRow(id)
}

$(document).ready(function() {
	$('#quantity').number( true, 0, '.', ',');
	$('#buyPrice').number( true, 2, '.', ',');
	$('#sellPrice').number( true, 2, '.', ',');
    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
   
    var fComboType = new Filter();
	fComboType.addParameter("parent.name", '"Payment Terms"', Condition.CONTAINS);
	AutocompleteDynamicComboVal("paymentTerms", fComboType);
	
	var fChargeType = new Filter();
	fChargeType.addParameter("chargeTypeTitle", '$("#freightChargeTypeDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicChargeType("freightChargeTypeDTO", fChargeType);

					/*----------------------------------------------------------------------------------- Set Mask -------------------*/
					$('#search')
							.on(
									'click',
									function() {
										if (AdvanceSearch.initializeFilter().length > 0) {
											fSearch.removeParameter(Condition.WHERE);
											fSearch
													.addParameter(
															Condition.WHERE,
															AdvanceSearch
																	.initializeFilter(),
															Condition.WHERE);
											$('.win-content-header')
													.removeClass(
															'full-search compact')
											$('#clear-filter').removeClass(
													'hide');
										} else if ($('.simple-search input')
												.val().trim().length > 0) {
											$('#clear-filter').removeClass(
													'hide');
										}
										search();
										$('.win-content-header').removeClass(
												'compact full-search')

									})

					$('#clear-filter').on('click', function() {
						// Remove Advance Filter Key From Filter Object & Clear
						// Advanced Form & Clear Simple Search From
						$('#filter-item-container').empty();
						$('.simple-search input').val('');
						fSearch.removeParameter(Condition.WHERE);
						this.classList.add('hide');
						search();
					})
					$('#addBtn').on('click',function(){
						var hSave = new Handler();
					    hSave.success = function success(result) {
					        if (result.done) {
					           // dialog('Save', result.resultCountAll + ' Item saved');
					           // $("#rowId").val(result.result);
					        	$('#myModal').modal('hide');
					            search();
					        }
					        else {
					            errorHandle(result);
					        }
					    }
					    hSave.error = function error(jqXHR, textStatus) {
					        dialog('Save', textStatus + 'Error: ')
					    }
					    saveRow('edit-form', hSave, "/quoteItem/save");
					})	
					$('#return-btn').on('click',function(){
				    	if (parent.parent.location.toString().indexOf('masterdetail.html') > 0) {
				            parent.parent.document.getElementById('detail-frame').classList.remove('minimize')
				            parent.parent.document.getElementById('master-frame').classList.remove('maximize')
				        }
				        //backToGrid()
				    	parent.parent.hideEdit();
				    	parent.parent.search();
				    	parent.parent.$('#quote').css('display','none');
				    })
				    $('#save-draft').on('click',function(){
				    	var hSave = new Handler();
					    hSave.success = function success(result) {
					        if (result.done) {
					            dialog('Save', result.resultCountAll + ' Item saved');
					            //$("#rowId").val(result.result);
					            search();
					        }
					        else {
					            errorHandle(result);
					        }
					    }
					    hSave.error = function error(jqXHR, textStatus) {
					        dialog('Save', textStatus + 'Error: ')
					    }
					    /*----------------------------------------------------------------------- Start Save File -----------------------------------------------------------*/
					    var note = $('#note').val().replace("\n", "\\n");
					    var data = '{"rowId": ' + resultId[1] + '' +
		        	    ', "payMents" : {"rowId":' + $('#paymentTerms').attr('entityId') + '}'+
		        	    ',"note" : "'+note+'"'+
		        	    ',"expirationDate" : "'+$('#expirationDate').val()+'"'+
		        	    ', "ticket":"' + user.ticket + '"}';
					    var hImageSave = new Handler;
				        hImageSave.success = function (result) {
				            if (result.done) {
				                fileRowId = result.result[0];
				                $("#documentFileDTO").attr('entityId', result.result);
				                var h = new Handler();
							    h.success = function success(result) {			    }
							    h.error = function error(jqXHR, textStatus) {	    }
							    var dataItem = '{"rowId": ' + 0 + '' +
				        	    ', "quoteDTO" : {"rowId":' + resultId[1] + '}'+
				        	    ',"documnetTypeDTO" : {"rowId":1000121}'+
				        	    ',"documentName" : "'+$(".fileupload-preview").text()+'"'+
				        	    ',"documentFileDTO" : {"rowId":'+result.result+'}'+
				        	    ', "ticket":"' + user.ticket + '"}';
				                ServiceInvoker.call(dataItem, h, "/quoteDoc/save");
				                ServiceInvoker.call(data, hSave, "/quote/save");
				            }
				            else {
				                errorHandle(result);
				            }
				        }
				        hImageSave.error = function (jqXHR, textStatus) {
				            dialog('Save', textStatus + 'Error: ');
				        }
				        var formData = new FormData;
				        formData.append('rowId', $("#documentFileDTO").attr("entityId"));
				        formData.append('title', $(".fileupload-preview").text());
				        formData.append('description', "Save File Quote Doc")
				        formData.append('useTitle', "Quote Related Document");
				        formData.append('useEntity', "QuoteRelatedDocument");
				        formData.append('path', $("#documentFileDTO").attr("path"));
				        formData.append('active', $("#active").prop("checked"));

				        var files = $('#documentFileDTO')[0].files;
				        if ($("#documentFileDTO")[0].files.length > 0) {
				            ServiceInvoker.upload(files, formData, hImageSave);
				        } else {
				        	ServiceInvoker.call(data, hSave, "/quote/save");
				        } 
				    })
				    $('#save-submit').on('click',function(){
				    	var id = resultId[1];
				    	var saveHandler = new Handler();
				    	saveHandler.success = function success(result) {
				       	 if (result.done) {
				                if (result.result) {
				                	dialog('Submit', ' Item Submited');
				                }
				            }
				            else {
				                errorHandle(result);
				            }
				        }
				    	saveHandler.error = function error(jqXHR, textStatus) {
				    		dialog('Submit', textStatus + 'Error: ')
				        }

				    	dialog('Confirm', 'Do You Sure For Submit Quote ?', function () {
				        		statusId = 1000134 ; //Quote Sent
					        		var data = '{"rowId": "' + id + '"' +
					        	    ', "quoteStatusTypeDTO" : {"rowId":' + statusId + '}'+
					        	    ', "ticket":"' + user.ticket + '"}';
					            	ServiceInvoker.call(data , saveHandler, "/quote/updateStatus");
				        }, function () {
				        })
				    })
					/*----------------------------------------------------------------------------------- Initialization -------------*/
					AdvanceSearch.init();
					setIndexListeners();
					search();
					// searchFreightType();

				});
function setData(id,title){
	clearForm();
	var fChargeType = new Filter();
	fChargeType.addParameter("chargeTypeTitle", '$("#freightChargeTypeDTO").val()', Condition.CONTAINS);
	fChargeType.addParameter("classificat.rowId", id, Condition.EQUAL);
	AutocompleteDynamicChargeType("freightChargeTypeDTO", fChargeType);
	$('#quoteDTO').attr('entityId',resultId[1]);	
}
var listChargeType={};
function loadDataChargeType(classId){
	var searchType = new Handler();
	searchType.beforeSend = function beforeSend() {
		//showLoading();
	}
	searchType.success = function success(result) {
		if (result.done) {
			if (result.result) {
				entities = result.result;
				entities.forEach(function(item, index) {
					var id = item.rowId;
					var title = item.classificationTitle;
		             listChargeType[index] = item; 
				})
			} else {
				/*hideLoading();
				setTimeout(function() {
					showError("No things to show");
				}, 300)*/
			}
		} else {
			/*hideLoading();
			setTimeout(function() {
				errorHandle(result);
			}, 300)*/
		}
	}
	searchType.error = function error(jqXHR, textStatus) {
		/*hideLoading();
		setTimeout(function() {
			showError("Error: " + ResponseCode[jqXHR.status]);
		}, 300)*/
	}
	searchType.complete = function complete() {
		unlockPage();
	}
	fSearch.addParameter("classificat.rowId", classId, Condition.CONTAINS);
	ServiceInvoker.call(fSearch.getFilters(), searchType, "/chargeType/list");
}
function compareBuySell(){
	var buy = $('#buyPrice').val();
	var sell = $('#sellPrice').val();
	if(parseFloat(sell) < parseFloat(buy)){
		//alert("asas")
		dialog('Warning','Sell Less Than Buy');
		
	}
}
/*--------------------------------------------------------------------------------------- End ------------------------*/