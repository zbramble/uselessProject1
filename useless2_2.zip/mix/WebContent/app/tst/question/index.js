$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Search ---------------------*/
    var hSearch = new Handler();
    hSearch.beforeSend = function beforeSend() {
        lockPage();
    }
    hSearch.success = function success(result) {
        if (result.done) {
            $("#questionGrid").empty();
            if (!result.result) {
                $("#dataGrid").css({"display": "none"});
                //alert('موردی یافت نشد');
                return;
            } else {
                $("#dataGrid").css({"display": ""});
            }
            for (var i = 0; result.result && i < result.result.length; i++) {
                var entityId = result.result[i].questionId;
                var clone = $("#row").clone();
                clone.find("[id]").add(clone).each(function () {
                    this.id = this.id + '-' + entityId;
                });
                clone.find("#id-" + entityId).html(i + 1 + (pageNo - 1) * pageSize);
                clone.find("#questionId-" + entityId).html(result.result[i].questionId);
                clone.find("#questionTitle-" + entityId).html(result.result[i].questionTitle);
                clone.find("#questionText-" + entityId).html(result.result[i].questionText);
                clone.find("#issueDate-" + entityId).html(result.result[i].issueDate);
                if (result.result[i].questionType != undefined) {
                    clone.find("#questionType-" + entityId).html(result.result[i].questionType.name);
                    clone.find("#questionType-" + entityId).attr("entityId", result.result[i].questionType.comboValId);
                }
                if (result.result[i].course != undefined) {
                    clone.find("#course-" + entityId).html(result.result[i].course.courseTitle);
                    clone.find("#course-" + entityId).attr("entityId", result.result[i].course.courseId);
                }
                if (result.result[i].courseHeadline != undefined) {
                    clone.find("#courseHeadline-" + entityId).html(result.result[i].courseHeadline.headlineTitle);
                    clone.find("#courseHeadline-" + entityId).attr("entityId", result.result[i].courseHeadline.courseHeadlineId);
                }
                if (result.result[i].hardnessLevel != undefined) {
                    clone.find("#hardnessLevel-" + entityId).html(result.result[i].hardnessLevel.name);
                    clone.find("#hardnessLevel-" + entityId).attr("entityId", result.result[i].hardnessLevel.comboValId);
                }
                if (result.result[i].designerPerson != undefined) {
                    clone.find("#designerPerson-" + entityId).html(result.result[i].designerPerson.firstName + " " + result.result[i].designerPerson.lastName);
                    clone.find("#designerPerson-" + entityId).attr("entityId", result.result[i].designerPerson.personId);
                }
                if (result.result[i].eduDuration != undefined) {
                    clone.find("#eduDuration-" + entityId).html(result.result[i].eduDuration.durationTitle);
                    clone.find("#eduDuration-" + entityId).attr("entityId", result.result[i].eduDuration.durationId);
                }
                clone.find("#requieredTimeMinute-" + entityId).html(result.result[i].requieredTimeMinute);
                clone.find("#numberOfOptions-" + entityId).html(result.result[i].numberOfOptions);
                clone.find("#description-" + entityId).html(result.result[i].description);
                if (result.result[i].fileDTO) {
                    clone.find("#file-" + entityId).html(result.result[i].fileDTO.title);
                    clone.find("#file-" + entityId).attr("entityId", result.result[i].fileDTO.id);
                }
                clone.find("#isActive-" + entityId).html(result.result[i].isActive ? "فعال" : "غیرفعال");

                clone.appendTo("#questionGrid");
            }

            $("#gridDiv").show('slow');

            $('tr[id^="row-"]').dblclick(function () {
                showRow(this.id.split('-')[1]);
            });
        } else {
            errorHandle(result);
        }
    }
    hSearch.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus + ' ' + jqXHR.status);
    }
    hSearch.complete = function complete() {
        unlockPage();
    }

    var fSearche = new Filter();
    fSearche.addParameter("questionTitle", '$("#questionTitle_Searcher").val()', Condition.EQUAL);

    function search() {
        ServiceInvoker.call(fSearche.getFilters(), hSearch, "/question/list");
        $("#gridDiv").show('slow');
    }

    /*----------------------------------------------------------------------------------- Show Row -------------------*/
    var hShowRow = new Handler();
    hShowRow.beforeSend = function beforeSend() {
        lockPage();
    }
    hShowRow.success = function success(result) {
        if (result.done) {
            $('#editDiv').show('slow');
            $('#editDiv').css({"height": "100%"});
            window.frames['editFrame'].fillEdit(result.result[0]);
        } else {
            errorHandle(result);
        }
    }
    hShowRow.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus + ' ' + jqXHR.status);
    }
    hShowRow.complete = function complete() {
        unlockPage();
    }

    var fShrSearche = new Filter();

    function showRow(id) {
        fShrSearche.clearParams();
        fShrSearche.addParameter("questionId", id, Condition.EQUAL)
        var oldPageNo = pageNo;
        pageNo = 1;
        ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/question/list");
        pageNo = oldPageNo;
    }

    /*----------------------------------------------------------------------------------- Add New  -------------------*/
    function addNew() {
        $('#editDiv').show('slow');
        $('#editDiv').css({"height": "100%"});
        window.frames['editFrame'].addNew();
    }

    /*----------------------------------------------------------------------------------- Listener -------------------*/
    $('#sendBTN').click(function () {
        pageNo = 1;
        $('#pageNo').val('1');
        search();
    });

    $('#sendNewBTN').click(function () {
        addNew();
    });

    $('#next').click(function () {
        if ($("#pageNo").length > 0) {
            pageNo = $("#pageNo").val();
            $("#pageNo").val(++pageNo)
        } else
            pageNo++;
        search();
    });

    $('#prev').click(function () {
        if ($("#pageNo").length > 0) {
            pageNo = $("#pageNo").val();
            if (pageNo == 1)
                return;
            $("#pageNo").val(--pageNo)
        } else {
            if (pageNo == 1)
                return;
            pageNo--;
        }
        search();
    });

    /*----------------------------------------------------------------------------------- Mask -----------------------*/
    $('.time').mask('00:00:00' ,{placeholder: "00:00:00"});
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});

});

/*--------------------------------------------------------------------------------------- Hide Edit ------------------*/
function hideEdit() {
    $('#editDiv').hide('slow');
}
/*--------------------------------------------------------------------------------------- End ------------------------*/