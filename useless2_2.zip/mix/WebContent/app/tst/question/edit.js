$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    var hSave = new Handler();
    hSave.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد ذخیره گردید');
            $("#durationId").val('entityid', result.result);
        } else {
            errorHandle(result)
        }

        ServiceInvoker.call(formData, hSave, "/question/save");
    }
    hSave.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus);
    }

    function saveRow() {
        var formData = '{"questionId": "' + $("#questionId").val() + '"' +
            ', "questionTitle" : "' + $("#questionTitle").val() + '"' +
            ', "questionText" : "' + $("#questionText").val() + '"' +
            ', "issueDate" : "' + $("#issueDate").val() + '"' +
            ', "requieredTimeMinute" : "' + $("#requieredTimeMinute").val() + '"' +
            ', "numberOfOptions" : "' + $("#numberOfOptions").val() + '"' +
            ', "description" : "' + $("#description").val() + '"' +

            ( $("#questionType").attr("entityId") != "" ?
            ', "questionType": { "comboValId" : ' + $("#questionType").attr("entityId") + ' }' : '') +

            ( $("#course").attr("entityId") != "" ?
            ', "course": { "courseId" : ' + $("#course").attr("entityId") + ' }' : '') +

            ( $("#courseHeadline").attr("entityId") != "" ?
            ', "courseHeadline": { "courseHeadlineId" : ' + $("#courseHeadline").attr("entityId") + ' }' : '') +

            ( $("#hardnessLevel").attr("entityId") != "" ?
            ', "hardnessLevel": { "comboValId" : ' + $("#hardnessLevel").attr("entityId") + ' }' : '') +

            ( $("#designerPerson").attr("entityId") != "" ?
            ', "designerPerson": { "personId" : ' + $("#designerPerson").attr("entityId") + ' }' : '') +

            ( $("#eduDuration").attr("entityId") != "" ?
            ', "eduDuration": { "eduDurationId" : ' + $("#eduDuration").attr("entityId") + ' }' : '') +

            ( $("#file").attr("entityId") != "" ?
            ', "fileDTO": { "id" : ' + $("#file").attr("entityId") + ' }' : '') +

            ', "isActive" : "' + $("#isActive").prop('checked') + '"' +
            ', "ticket" : "' + user.ticket + '"}';

        ServiceInvoker.call(formData, hSave, "/question/save");
    }

    /*----------------------------------------------------------------------------------- Delete ---------------------*/
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد حذف گردید');
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus);
    }

    var dFilter = new Filter();
    dFilter.addParameter("questionId", '$("#questionId").val()', Condition.EQUAL);

    function deleteRow() {
        ServiceInvoker.call(dFilter.getFilters(), hDelete, "/question/delete");
    }

    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var hIdQuestionType = function () {
        return [12, 100025, 42, 12];
    }
    var fQuestionType = new Filter();
    fQuestionType.addParameter("parent.name", "'نوع سوال'", Condition.EQUAL);
    AutocompleteStaticComboVal("questionType", fQuestionType, "Question-Type", hIdQuestionType);

    var fCourse = new Filter();
    fCourse.addParameter("courseTitle", '$("#course").val()', Condition.CONTAINS);
    AutocompleteDynamicCourse("course", fCourse);

    var fCourseHeadline = new Filter();
    fCourseHeadline.addParameter("headlineTitle", '$("#course").val()', Condition.CONTAINS);
    AutocompleteDynamicCourseHeadline("courseHeadline", fCourseHeadline);

    var hIdQuestionType = function () {
        return [100020, 100120];
    }
    var fHardnessLevel = new Filter();
    fHardnessLevel.addParameter("parent.name", "'سطح سوال'", Condition.EQUAL)
    AutocompleteStaticComboVal("hardnessLevel", fHardnessLevel, "Hardness-Level", hIdQuestionType);

    var fDesignerPerson = new Filter();
    fDesignerPerson.addParameter("nationalId", '$("#designerPerson").val()', Condition.CONTAINS);
    AutocompleteDynamicPerson("designerPerson", fDesignerPerson);

    var fDduDuration = new Filter();
    fDduDuration.addParameter("durationTitle", '$("#eduDuration").val()', Condition.CONTAINS);
    AutocompleteDynamicEduDuration("eduDuration", fDduDuration);

    var fFile = new Filter();
    fFile.addParameter("title", '$("#file").val()', Condition.CONTAINS);
    AutocompleteDynamicFile("file", fFile);

    /*----------------------------------------------------------------------------------- Listener -------------------*/
    $('#sendDeleteBTN').click(function () {
        deleteRow();
    });

    $('#sendSaveBTN').click(function () {
        saveRow();
    });

    $('#sendBackBTN').click(function () {
        parent.hideEdit();
    });

    /*----------------------------------------------------------------------------------- Mask -----------------------*/
    $('.time').mask('00:00:00', {placeholder: "00:00:00"});

    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    $(".date").persianDatepicker();
});

/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    addNew();
    $("#questionId").val(dto.questionId);
    $("#questionTitle").val(dto.questionTitle);
    $("#questionText").val(dto.questionText);
    $("#issueDate").val(dto.issueDate);
    if (dto.questionType != undefined) {
        $("#questionType").val(dto.questionType.name);
        $("#questionType").attr("entityId", dto.questionType.comboValId);
    }
    if (dto.course != undefined) {
        $("#course").val(dto.course.courseTitle);
        $("#course").attr("entityId", dto.course.courseId);
    }
    if (dto.courseHeadline != undefined) {
        $("#courseHeadline").val(dto.courseHeadline.headlineTitle);
        $("#courseHeadline").attr("entityId", dto.courseHeadline.courseHeadlineId);
    }
    if (dto.hardnessLevel != undefined) {
        $("#hardnessLevel").val(dto.hardnessLevel.name);
        $("#hardnessLevel").attr("entityId", dto.hardnessLevel.comboValId);
    }
    if (dto.designerPerson != undefined) {
        $("#designerPerson").val(dto.designerPerson.firstName + " " + dto.designerPerson.lastName);
        $("#designerPerson").attr("entityId", dto.designerPerson.personId);
    }
    if (dto.eduDuration != undefined) {
        $("#eduDuration").val(dto.eduDuration.durationTitle);
        $("#eduDuration").attr("entityId", dto.eduDuration.durationId);
    }
    $("#requieredTimeMinute").val(dto.requieredTimeMinute);
    $("#numberOfOptions").val(dto.numberOfOptions);
    $("#description").val(dto.description);
    if (dto.fileDTO != undefined) {
        $("#file").val(dto.fileDTO.title);
        $("#file").attr("entityId", dto.fileDTO.id);
    }
    $("#isActive").attr("checked", dto.isActive);
}

/*--------------------------------------------------------------------------------------- Add New --------------------*/
function addNew() {
    $("#questionId").val("");
    $("#questionTitle").val("");
    $("#questionText").val("");
    $("#issueDate").val("");
    $("#questionType").val("");
    $("#questionType").attr("entityId", "");
    $("#course").val("");
    $("#course").attr("entityId", "");
    $("#courseHeadline").val("");
    $("#courseHeadline").attr("entityId", "");
    $("#hardnessLevel").val("");
    $("#hardnessLevel").attr("entityId", "");
    $("#designerPerson").val("");
    $("#designerPerson").attr("entityId", "");
    $("#eduDuration").val("");
    $("#eduDuration").attr("entityId", "");
    $("#requieredTimeMinute").val("");
    $("#numberOfOptions").val("");
    $("#description").val("");
    $("#file").val("");
    $("#file").attr("entityId", "");
    $("#isActive").attr("checked", true);
}

/*--------------------------------------------------------------------------------------- End ------------------------*/