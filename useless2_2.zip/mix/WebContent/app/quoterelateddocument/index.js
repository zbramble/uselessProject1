/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var entityDetail=[];
var ret = parent.window.frames['quoteDoc'].location.toString();
var resultId = ret.split("?id=");
var searchFields = [

{
	propName : 'e.rowId',
	type : SearchPropertyType.NUMBER,
	title : 'ID',
	maxlength : 7
}, {
	propName : 'e.createdBy.rowId',
	autocompleteInstance : 'AutocompleteDynamicUser',
	type : SearchPropertyType.AUTOCOMPLETE,
	title : 'Created by',
	maxlength : 50,
	autocompleteProp : 'lastName',
	autocompleteCondition : Condition.CONTAINS
}, {
	propName : 'e.updatedBy.rowId',
	autocompleteInstance : 'AutocompleteDynamicUser',
	type : SearchPropertyType.AUTOCOMPLETE,
	title : 'Updated by',
	maxlength : 50,
	autocompleteProp : 'lastName',
	autocompleteCondition : Condition.CONTAINS
}, {
	propName : 'e.created',
	type : SearchPropertyType.DATE,
	title : 'Created',
	maxlength : 8
}, {
	propName : 'e.updated',
	type : SearchPropertyType.DATE,
	title : 'Updated',
	maxlength : 8
} ]

/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#documentName").attr("id", 'documentName-' + id).find('span').html(item.documentName);
        patternRow.find("#documnetTypeDTO").attr("id", 'total-' + id).find('span').html(item.documnetTypeDTO ? item.documnetTypeDTO.name : '');

        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/

function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
    	
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);

        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#documentName").attr("id", 'documentName-' + id).find('span').html(item.documentName);
        patternRow.find("#documnetTypeDTO").attr("id", 'documnetTypeDTO-' + id).find('span').html(item.documnetTypeDTO ? item.documnetTypeDTO.name : '');
        patternRow.find("#uploadedBy").attr("id", 'uploadedBy-' + id).find('span').html(item.updatedBy ? item.updatedBy.companyName : '');
        patternRow.find('#uploaded').attr("id", 'uploaded-' + id).find('span').html(item.updated);
 
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.find('#entityId2').attr("id", 'entityId2-' + id);
        patternRow.appendTo(tableBody);
        entityDetail[id]=item;
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
	showLoading();
}
hSearch.success = function success(result) {
	if (result.done) {
		searchResultEntities = result.result;
		if (result.result) {
			fillGrid(result.result);
		} else {
			hideLoading();
			setTimeout(function() {
				showError("No things to show");
			}, 300)
		}
	} else {
		hideLoading();
		setTimeout(function() {
			errorHandle(result);
		}, 300)
	}
}
hSearch.error = function error(jqXHR, textStatus) {
	hideLoading();
	setTimeout(function() {
		showError("Error: " + ResponseCode[jqXHR.status]);
	}, 300)
}
hSearch.complete = function complete() {
	unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("documentName", '$("#documentName_Searcher").val()', Condition.CONTAINS);


function search(){
	fSearch.addParameter("quote.rowId",resultId[1], Condition.EQUAL);
    ServiceInvoker.call(fSearch.getFilters(), hSearch, "/quoteDoc/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
	window.frames['editFrame'].showRow(id)
}

$(document).ready(function() {
/*----------------------------------------------------------------------------------- Set Mask -------------------*/
					$('#search')
							.on(
									'click',
									function() {
										if (AdvanceSearch.initializeFilter().length > 0) {
											fSearch.removeParameter(Condition.WHERE);
											fSearch
													.addParameter(
															Condition.WHERE,
															AdvanceSearch
																	.initializeFilter(),
															Condition.WHERE);
											$('.win-content-header')
													.removeClass(
															'full-search compact')
											$('#clear-filter').removeClass(
													'hide');
										} else if ($('.simple-search input')
												.val().trim().length > 0) {
											$('#clear-filter').removeClass(
													'hide');
										}
										search();
										$('.win-content-header').removeClass(
												'compact full-search')

									})

					$('#clear-filter').on('click', function() {
						// Remove Advance Filter Key From Filter Object & Clear
						// Advanced Form & Clear Simple Search From
						$('#filter-item-container').empty();
						$('.simple-search input').val('');
						fSearch.removeParameter(Condition.WHERE);
						this.classList.add('hide');
						search();
					})
					$('#uploadBtn').on('click',function(){
						var hSave = new Handler();
					    hSave.success = function success(result) {
					        if (result.done) {
					           // dialog('Save', result.resultCountAll + ' Item saved');
					           // $("#rowId").val(result.result);
					        	$('#myModal').modal('hide');
					            search();
					        }
					        else {
					            errorHandle(result);
					        }
					    }
					    hSave.error = function error(jqXHR, textStatus) {
					        dialog('Save', textStatus + 'Error: ')
					    }
					    /*----------------------------------------------------------------------- Start Save File -----------------------------------------------------------*/
				        var hImageSave = new Handler;
				        hImageSave.success = function (result) {
				            if (result.done) {
				            	
				                fileRowId = result.result[0];
				                $("#documentFileDTO").attr('entityId', result.result);
				                saveRow('edit-form', hSave, "/quoteDoc/save");
				            }
				            else {
				                errorHandle(result);
				            }
				        }
				        hImageSave.error = function (jqXHR, textStatus) {
				            dialog('Save', textStatus + 'Error: ');
				        }
				        var formData = new FormData;
				        formData.append('rowId', $("#documentFileDTO").attr("entityId"));
				        formData.append('title', $("#documentName").val());
				        formData.append('description', "Save File Quote Doc")
				        formData.append('useTitle', "Quote Related Document");
				        formData.append('useEntity', "QuoteRelatedDocument");
				        formData.append('path', $("#documentFileDTO").attr("path"));
				        formData.append('active', $("#active").prop("checked"));

				        var files = $('#documentFileDTO')[0].files;
				        if ($("#documentFileDTO")[0].files.length > 0) {
				            ServiceInvoker.upload(files, formData, hImageSave);
				        } else {
				        	saveRow('edit-form', hSave, "/quoteDoc/save");
				        }
					})
					$('#documnetTypeDTO').on('click',function(){
				    	var frelatedDocumentType = new Filter();
				    	frelatedDocumentType.addParameter("parent.name",'"Related Document Type"', Condition.EQUAL);
				    	AutocompleteDynamicComboVal("documnetTypeDTO", frelatedDocumentType);
				    	//fSearch.addParameter("documnetType", '$("#documnetTypeDTO").attr("entityId")', Condition.CONTAINS);
				    })
				    $('#btn-return').on('click',function(){
						if (parent.parent.location.toString().indexOf('masterdetail.html') > 0) {
					        parent.parent.document.getElementById('detail-frame').classList.remove('minimize')
					        parent.parent.document.getElementById('master-frame').classList.remove('maximize')
					    }
						parent.parent.hideEdit();
						parent.parent.search();
						parent.parent.$('#quote').css('display','none');
					})
					/*----------------------------------------------------------------------------------- Initialization -------------*/
					AdvanceSearch.init();
					setIndexListeners();
					search();

				});
function setData(){
	clearForm();
	$('#quoteDTO').attr('entityId',resultId[1]);
	$('#documentFileDTO').attr('entityId',"");
	$('#documentFileDTO').attr('path',"");
	$('#documentFileDTO').val('');
}
function deleteRow(id) {
	var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }
	var temp = '<br><br>';
        temp += (
        	'<span>Quote : </span><span style="color: darkgrey">' + entityDetail[id].quoteDTO.carrierName + '</span><br>'+
            '<span>File Type : </span><span style="color: darkgrey">' +entityDetail[id].documnetTypeDTO.name + '</span><br>'+
            '<span>File Name: </span><span style="color: darkgrey">' +entityDetail[id].documentName+ '</span><br>'
            
        );
    dialog('Confirm', 'Are you sure for delete ' + temp, function () {
    	var dFilter = new Filter();
        dFilter.addParameter("rowId", id, Condition.EQUAL);
        ServiceInvoker.call(dFilter.getFilters(), hDelete, "/quoteDoc/delete");
    }, function () {

    })   
}

/*--------------------------------------------------------------------------------------- End ------------------------*/