var entity;
var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
var ret = window.location.toString();
var resultId = ret.split("?id=");
pageSize = 1000;
$(document).ready(function () {
    setEditListeners();
    clearForm();
    if(resultId[1]){
    	showRow(resultId[1]);
   	 	window.frames['quoteItem'].location="../quoteitem/index.html?id="+resultId[1];
   	 	window.frames['quoteDetail'].location="../quote/tabdetail/detail.html?id="+resultId[1];
   	 	window.frames['quoteDoc'].location="../quoterelateddocument/index.html?id="+resultId[1];
   	 
    }else{
    	window.frames['quoteItem'].location="../quoteitem/index.html";
    	window.frames['quoteDetail'].location="../quote/tabdetail/detail.html";
    }
    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    $( function() {
        $( "#tabs" ).tabs();
        
      } );
    $('#tabs').click('tabsselect', function (event, ui) {
    	var $tabs = $("#tabs").tabs();
        var selected = $tabs.tabs("option", "active"); // => 0
        switch (selected) {
		case 0:
			//tab communicate
			//searchDetail(resultId[1]);
			break;
		case 1:
			
			break;
		case 2:
			
			
			break;
		case 3:
			//tab rate offer
			window.frames['quoteItem'].location="../quoteitem/index.html?id="+resultId[1];
			break;
		case 4:
			//tab detail
			window.frames['quoteDetail'].location="../quote/tabdetail/detail.html?id="+resultId[1];
			break;
		case 5:
			//tab document
			window.frames['quoteDoc'].location="../quoterelateddocument/index.html?id="+resultId[1];
			break;
		default:
			break;
		}
     });
    $('#return-btn').on('click',function(){
    	if (parent.parent.location.toString().indexOf('masterdetail.html') > 0) {
            parent.parent.document.getElementById('detail-frame').classList.remove('minimize')
            parent.parent.document.getElementById('master-frame').classList.remove('maximize')
        }
        backToGrid()
    	parent.$('#quote').css('display','none');
    })
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
    	//resultId[1] quote Id
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
            	//debugger;
            	if(!resultId[1])
            		dialog('Save', result.resultCountAll + ' Item saved');
            	else
            		searchDetail(resultId[1]);
               // $("#rowId").val(result.result);
                $("#logNotes").val('');
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
       saveRow('edit-form', hSave, "/quoteLog/save");
    });

});

/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/quoteLog/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    
    $("#logDate").val(dto.logDate);
    if(!resultId[1]){
    	$("#logNotes").val(dto.logNotes);
    	$("#rowId").val(dto.rowId);
    }else{
    	searchDetail(dto.quoteDTO.rowId);
    }
	if(dto.quoteDTO){
		$("#quoteDTO").val(dto.quoteDTO.carrierName);
        $("#quoteDTO").attr("entityId", dto.quoteDTO.rowId);
        
        $('#company').html(dto.quoteDTO.createdBy.companyName);
        $('#fullName').html(dto.quoteDTO.createdBy.fullName);
        $('#email').html(dto.quoteDTO.createdBy.email);
        if(dto.quoteDTO.createdBy.file)
        	$("#logo").attr("src", "data:image/png;base64," + dto.quoteDTO.createdBy.file.imageContent);
        else
        	$("#logo").attr("src", "../../core/img/image01.png");
        
        $("#qouteRequestDTO").html(dto.quoteDTO ? dto.quoteDTO.fullTitle :'');
    	//$("#freightMethodDTO").html(dto.quoteDTO.freightMethodDTO ? dto.quoteDTO.freightMethodDTO.name :'');
        if(dto.quoteDTO.freightMethodDTO){
        	if(dto.quoteDTO.freightMethodDTO.rowId == 10002)
        		$("#freightMethodDTO").html('<span class="ion-android-plane" style="font-size:20px;"></span>');
        	if(dto.quoteDTO.freightMethodDTO.rowId == 10003)
        		$("#freightMethodDTO").html('<span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(dto.quoteDTO.freightMefreightMethodDTO == 10004)
        		$("#freightMethodDTO").html('<span class="ion-android-plane" style="font-size:20px;"></span><span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(dto.quoteDTO.freightMethodDTO.rowId == 10005)
        		$("#freightMethodDTO").html('<span class="ion-android-bus" style="font-size:20px;"></span>');
        }
    	$("#freightTypeDTO").html(dto.quoteDTO.freightTypeDTO ? dto.quoteDTO.freightTypeDTO.name :'');
    	$("#departureLocationDTO").html(dto.quoteDTO.departureLocationDTO ? dto.quoteDTO.departureLocationDTO.name : '');
    	$("#arrivalLocationDTO").html(dto.quoteDTO.arrivalLocationDTO ? dto.quoteDTO.arrivalLocationDTO.name : '');
    	$("#quoteReference").html(dto.quoteDTO.quoteReference);
    	
	}
	
	if(dto.logUserDTO){
		$("#logUserDTO").val(dto.logUserDTO.username);
        $("#logUserDTO").attr("entityId", dto.logUserDTO.rowId);
	}
	//debugger;
	if(dto.createdBy){
    	$("#createdBy").val(dto.createdBy.fullTitle);
		$("#createdBy").attr("entityId", dto.createdBy.rowId);
	}
    if(dto.updatedBy){
    	$("#updatedBy").val(dto.updatedBy.fullTitle);
		$("#updatedBy").attr("entityId", dto.updatedBy.rowId);
	}
    $("#created").val(dto.created);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}
function fillEditQuote(dto){
	entity = dto;
    clearForm();
    $('#company').html(dto.createdBy.companyName);
    $('#fullName').html(dto.createdBy.fullName);
    $('#email').html(dto.createdBy.email);
    if(dto.createdBy.file)
    	$("#logo").attr("src", "data:image/png;base64," + dto.createdBy.file.imageContent);
    else
    	$("#logo").attr("src", "../../core/img/image01.png");

    $("#qouteRequestDTO").html(dto.qouteRequestDTO.shipmentName);
	$("#freightMethodDTO").html(dto.freightMethodDTO ? dto.freightMethodDTO.name :'');
	$("#freightTypeDTO").html(dto.freightTypeDTO ? dto.freightTypeDTO.name :'');
	$("#departureLocationDTO").html(dto.departureLocationDTO ? dto.departureLocationDTO.name : '');
	$("#arrivalLocationDTO").html(dto.arrivalLocationDTO ? dto.arrivalLocationDTO.name : '');
	$("#quoteReference").html(dto.quoteReference);
    Log(dto.active)
}
/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $('#logDate').val(today);
    $('#logUserDTO').val(user.fullName);
    $('#logUserDTO').attr("entityId",user.userId);
    var ret = window.location.toString();
    var result = ret.split("?id=");
    if(result[1])
    	$('#quoteDTO').attr('entityId',result[1]);

}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
        	if(!resultId[1])
        		parent.showEdit(result.result[0])
            else{
            if(result.result)
        		fillEdit(result.result[0])
        	else
        		showRowPageQuote(resultId[1])
            }
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}
/*-------------------------------------------------------------------------------------- Show Row Data RFQ -----------------------------------------------------*/
var hShowRowQuote = new Handler();
hShowRowQuote.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRowQuote.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
        	if(result.result)
        		fillEditQuote(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRowQuote.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRowQuote.complete = function complete() {
    unlockPage();
}
/*-------------------------------------------------------------------------- RFQ END --------------------------------------------------*/
var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    if(resultId[1])
    	fShrSearche.addParameter("quote.rowId", id, Condition.EQUAL);
    else
    	fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/quoteLog/list");
    pageNo = oldPageNo;
}
function showRowPageQuote(id){
	fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRowQuote, "/quote/list");
    pageNo = oldPageNo;
}
/*---------------------------------------------------------------------------- Start Fill Grid Message -------------------------------------------------------*/
function searchDetail(id){
	var hSearch = new Handler();
	hSearch.beforeSend = function beforeSend() {
	    parent.showLoading();
	}
	hSearch.success = function success(result) {
	    if (result.done) {
	        parent.hideLoading();
	        setTimeout(function () {
	           // parent.showEdit(result.result[0])
	        	//alert(result.result)
	        	fillTableDetail(result.result);
	        }, 300);
	    } else {
	        parent.hideLoading();
	        setTimeout(function () {
	            errorHandle(result);
	        }, 300)
	    }
	}
	hSearch.error = function error(jqXHR, textStatus) {
	    hideLoading();
	    setTimeout(function () {
	        showError("Error: " + textStatus + ' ' + jqXHR.status);
	    }, 300);
	}
	hSearch.complete = function complete() {
	    unlockPage();
	}
	fShrSearche.clearParams();
    fShrSearche.addParameter("quote.rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hSearch, "/quoteLog/list");
    pageNo = 20;
}

function fillTableDetail(entities){
	 $('.media > table').css({"display": "table"});
	    var tableBody = $('.media > table > tbody');
	    tableBody.find('tr').not('tr#row').remove();
	    tableBody.find('tr#row').removeAttr('style');

	entities.forEach(function (item, index) {

		 var patternRow = tableBody.find('#row').clone();
	     var id = item.rowId;
	     patternRow.attr('id', 'row-' + id);
	     //patternRow.find("#userPic").attr("id", 'userPic-' + id).html("<div class='media-left'><img src="+(user.imageContent ? 'data:image/png;base64,' + user.imageContent : '../../core/img/default-profile/user-male-icon.png')+" class='media-object' style='width:40px'></div><br>");
	     var reply="";
	     if(item.quoteLogReply){
	    	 for (var i = 0; i < item.quoteLogReply.length; i++) {
	    		 reply +="<div class='media'>"+
					"<div class='media-left'>"+
						"<a href=''>"+
							"<img class='media-object' src="+(item.quoteLogReply[i].createdBy.file ? 'data:image/png;base64,' + item.quoteLogReply[i].createdBy.file.imageContent : '../../core/img/default-profile/user-male-icon.png')+" style='width:40px'>"+
						"</a>"+
					"</div>"+
					"<div class='media-body' style='overflow-y: scroll;' id='divBody'>"+
						"<b class='media-heading'>"+item.quoteLogReply[i].createdBy.fullName+" , "+item.quoteLogReply[i].created.substring(0,10)+"</b>"+
						"<pre>"+item.quoteLogReply[i].replyNotes+"</pre>"+
					"</div>"+
				"</div>";
			}
	    	 
	     }
	     patternRow.find("#msg-body").attr("id", 'msg-body-' + id).html
	     (
	    		 "<div class='media-left'><img src="+(item.createdBy.file ? 'data:image/png;base64,' + item.createdBy.file.imageContent : '../../core/img/default-profile/user-male-icon.png')+" class='media-object' style='width:40px'></div>"+		 
	    		 "<div class='media-body'>"+
	    		 "<span id='userName'>"+(item.logUserDTO ? item.logUserDTO.fullName+" , "+item.logDate : '')+"</span>"+
    		 		"<pre>"+item.logNotes+"<br></pre>"+
    		 		reply+
    		 		"<a class='pull-left'  onclick=\"openReply("+id+")\"><span class='ion-reply text-primary' style='font-size: 16px;cursor:pointer'></span>"+
    		 		
						"<span class='text-primary' style='cursor:pointer'>Reply</span>"+
					"</a><br>"+
					"<div style='display:none' id='divReply-"+id+"'>"+
					"<div class='input-row'> "+
				     "<div class='test w1'>"+
				     	"<textarea autofocus class='mandatory' id='replyNotes-"+id+"' rows=4 cols=50  placeholder='Write Your Message ....' required></textarea>"+
				 	"</div>"+
				 "</div><div  style='padding: 8px;' align='left'>"+
				 "<button type='button' class='btn btn-default active' onclick=\"saveNoteReply("+id+")\" >Send Message</button>  "+
				 "  <button type='button' class='btn btn-primary' onclick=\"cancel("+id+")\">Cancel</button>"+
    		 	"</div></div><br>"
	     		);
	     patternRow.appendTo(tableBody);
	     $('#div-media-total').css("height",(document.getElementById('div-media-total').scrollHeight+120)+'px');
	    if(document.getElementById('divBody'))
	     $('.media-body').css("height",document.getElementById('divBody').scrollHeight+'px');
   });
	
}

function openReply(id){
	$('#divReply-'+id).show();	
}
function cancel(id){
	$('#replyNotes-'+id).val('');
	$('#divReply-'+id).hide();
}
function saveNoteReply(id){
	//quoteLog id
	var note = $('#replyNotes-'+id).val();
	//alert(note)
	//debugger;
	var hSave = new Handler();
     hSave.success = function success(result) {
         if (result.done) {
        	 $('#divReply-'+id).hide();
        	 searchDetail(resultId[1]);
         }
         else {
             errorHandle(result);
         }
     }
     hSave.error = function error(jqXHR, textStatus) {
         dialog('Save', textStatus + 'Error: ')
     }
     if(note != ''){
    	note = note.replace("\n", "\\n");
 		var temp = '{"replyNotes":"' + note+ '"' +
 			',"quoteLogDTO": {"rowId":' + id + '}'+
 			', "ticket":"' + user.ticket + '"},';
 		temp = temp.substr(0, temp.lastIndexOf(","));
 		ServiceInvoker.call(temp, hSave, "/quoteLogReply/save");
     }
}
/*--------------------------------------------------------------------------------------- End ------------------------*/

