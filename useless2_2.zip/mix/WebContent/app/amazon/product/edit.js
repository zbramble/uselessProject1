var entity;

$(document).ready(function () {
    setEditListeners();
    showRow();
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/product/save");
    });

	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
var fProduct = new Filter();
 /*   fProduct.addParameter("productTitle", '$("#relatedProductDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicProduct("relatedProductDTO", fProduct);

	var fcategory = new Filter();
    fcategory.addParameter("categoryDescription", '$("#categoryDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicCategory("categoryDTO", fcategory);
	
	var ftax = new Filter();
	ftax.addParameter("taxClassTitle", '$("#taxClassDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicTax("taxClassDTO", ftax);

	var fbrand = new Filter();
	fbrand.addParameter("brandTitle", '$("#brandDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicBrand("brandDTO", fbrand);

	var comboRelationShip = new Filter();
    comboRelationShip.addParameter("parent.name",'$("#relationShipTypeDTO").val()', Condition.CONTAINS);
    AutocompleteStaticComboVal("relationShipTypeDTO", comboRelationShip, "Relation-Ship-Type");
*/

});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/product/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    $("#sku").val(dto.sku);
    $("#manufactureSku").val(dto.manufactureSku);
    $("#barcode").val(dto.barcode);
	$("#productTitle").val(dto.productTitle);
	if(dto.relatedProductDTO){
		$("#relatedProductDTO").val(dto.relatedProductDTO.productTitle);
        $("#relatedProductDTO").attr("entityId", dto.relatedProductDTO.rowId);
	}
	$("#taxAmount").val(dto.taxAmount);
	if(dto.brandDTO){
		$("#brandDTO").val(dto.brandDTO.brandTitle);
        $("#brandDTO").attr("entityId", dto.brandDTO.rowId);
	}
	if(dto.categoryDTO){
		$("#categoryDTO").val(dto.categoryDTO.categoryDescription);
		$("#categoryDTO").attr("entityId", dto.categoryDTO.rowId);
	}
	$("#enable").prop("checked",dto.enable);
	$("#salePrice").val(dto.salePrice);
	$("#realPrice").val(dto.realPrice);
	if(dto.taxClassDTO){
		$("#taxClassDTO").val(dto.taxClassDTO.taxClassTitle);
        $("#taxClassDTO").attr("entityId", dto.taxClassDTO.rowId);
	}
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
	pageState = PageState.READY;
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            showEdit(result.result[0], result.result[1])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

function showRow(){
	// Is Opened as Tab
	var tabID = window.location.href.urlParameter('tabID');
	if(tabID != null && tabID != 0) { // is opened as tab
		var showFilter = new Filter();
	    //$('#tab-filter-title').css({'display' : 'block'});
		showFilter.addParams(top.tabFilter[tabID]);
	    ServiceInvoker.call(showFilter.getFilters(), hShowRow, "/AmazonProducts/load");
	}
}

function showEdit(header, row){
	var h = '';
	var r = '';
	for(i = 2; i < row.length; i++){
		if(i == 3){
			r += '<div class="input-row"><div style="min-width:170px;text-align:right;"><nobr>' + firstCapital(header[i]) + ':</nobr></div><br><div style="padding:4px;background-color:#f3f3f3;border-radius: 0.2rem;border: 1px solid #e4e4e4;margin-left:5px;"' +
				' id="' + header[i].replace(/ /g, '_') + '">'+( row[i] == null ? '' : row[i])+'"</div></div>';
		}else{
			if(i < 4 || i % 2 == 0)	r += '<div class="input-row">';
			r +='<div class="input-container w3 ignored " style="padding-right:0px">' +
				'<input id="' + header[i].replace(/ /g, '_') + '" value="'+( row[i] == null ? '' : row[i])+'" type="text" disabled><label style="min-width:170px">' + firstCapital(header[i]) + ':</label></div>';
			if(i < 4 || i % 2 == 1)	r +='</div>';
		}
	}
	$("#edit-form").html(r);
}
/*--------------------------------------------------------------------------------------- End ------------------------*/

