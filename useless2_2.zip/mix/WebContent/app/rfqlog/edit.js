var entity;
var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
var ret = window.location.toString();
var resultId = ret.split("?id=");
$(document).ready(function () {
    setEditListeners();
    clearForm();
    if(resultId[1]){
    	showRow(resultId[1]);
   	 	window.frames['rfqrelateddocumentFrame'].location="../rfqrelateddocument/index.html?id="+resultId[1];
    }else
    	window.frames['rfqrelateddocumentFrame'].location="../rfqrelateddocument/index.html";
    
    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    $( function() {
        $( "#tabs" ).tabs();
      } );
    $('#tabs').click('tabsselect', function (event, ui) {
    	var $tabs = $("#tabs").tabs();
        var selected = $tabs.tabs("option", "active"); // => 0
        switch (selected) {
		case 0:

			break;
		case 1:
			window.frames['rfqrelateddocumentFrame'].location="../rfqrelateddocument/index.html?id="+resultId[1];
			break;
		case 2:

			break;
		case 3:

			break;
		case 4:
	
			break;
		default:
			break;
		}
     });

    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
            	//debugger;
            	if(!resultId[1])
            		dialog('Save', result.resultCountAll + ' Item saved');
            	else
            		searchDetail(resultId[1]);
               // $("#rowId").val(result.result);
                $("#logNotes").val('');
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/rfqLog/save");
    });
    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var fQuote = new Filter();
    fQuote.addParameter("fullTitle", '$("#qouteRequestDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicQuoteRequest("qouteRequestDTO", fQuote);

    var fUser = new Filter();
    fUser.addParameter("fullTitle", '$("#logUserDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicUser("logUserDTO", fUser);
});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/rfqLog/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {//load for quote log
    entity = dto;
    clearForm();
    
    $("#logDate").val(dto.logDate);
    if(!resultId[1]){
    	$("#logNotes").val(dto.logNotes);
    	$("#rowId").val(dto.rowId);
    }else{
    	searchDetail(dto.qouteRequestDTO.rowId);
    }
	if(dto.qouteRequestDTO){
		$("#qouteRequestDTO").val(dto.qouteRequestDTO.shipmentName);
        $("#qouteRequestDTO").attr("entityId", dto.qouteRequestDTO.rowId);

        $("#shipmentName").html(dto.qouteRequestDTO ? dto.qouteRequestDTO.shipmentName :'');
        $("#incotermType").html(dto.qouteRequestDTO.incotermType ? dto.qouteRequestDTO.incotermType.name :'');

        $('#company').html(dto.qouteRequestDTO.createdBy.companyName);
        $('#fullName').html(dto.qouteRequestDTO.createdBy.fullName);
        $('#email').html(dto.qouteRequestDTO.createdBy.email);
        if(dto.qouteRequestDTO.createdBy.file)
        	$("#logo").attr("src", "data:image/png;base64," + dto.qouteRequestDTO.createdBy.file.imageContent);
        else
        	$("#logo").attr("src", "../../core/img/image01.png");
        if(dto.qouteRequestDTO.freightMethodTypeDTO){
        	if(dto.qouteRequestDTO.freightMethodTypeDTO.rowId == 10002)
        		$("#freightMethod").html('<span class="ion-android-plane" style="font-size:20px;"></span>');
        	if(dto.qouteRequestDTO.freightMethodTypeDTO.rowId == 10003)
        		$("#freightMethod").html('<span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(dto.qouteRequestDTO.freightMethodTypeDTO.rowId == 10004)
        		$("#freightMethod").html('<span class="ion-android-plane" style="font-size:20px;"></span><span class="ion-android-boat" style="font-size:20px;"></span>');
        	if(dto.qouteRequestDTO.freightMethodTypeDTO.rowId == 10005)
        		$("#freightMethod").html('<span class="ion-android-bus" style="font-size:20px;"></span>');

        }
    	$("#freightType").html(dto.qouteRequestDTO.freightTypeDTO ? dto.qouteRequestDTO.freightTypeDTO.name :'');
    	if(dto.qouteRequestDTO.origionLocationDTO && dto.qouteRequestDTO.pickupDate)
    		$("#origin").html( dto.qouteRequestDTO.origionLocationDTO.name + " , "+ dto.qouteRequestDTO.pickupDate);
    	else if(dto.qouteRequestDTO.origionLocationDTO)
    		$("#origin").html( dto.qouteRequestDTO.origionLocationDTO.name);
    	else
    		$("#origin").html(dto.qouteRequestDTO.pickupDate);
    	if(dto.qouteRequestDTO.destinationLocationDTO && dto.qouteRequestDTO.targetDeliveryDate)
    		$("#destination").html( dto.qouteRequestDTO.destinationLocationDTO.name + " , "+dto.qouteRequestDTO.targetDeliveryDate);
    	else if(dto.qouteRequestDTO.destinationLocationDTO)
    		$("#destination").html( dto.qouteRequestDTO.destinationLocationDTO.name );
    	else
    		$("#destination").html(dto.qouteRequestDTO.targetDeliveryDate);
    	
    	
	}

	if(dto.logUserDTO){
		$("#logUserDTO").val(dto.logUserDTO.username);
        $("#logUserDTO").attr("entityId", dto.logUserDTO.rowId);
	}
	//debugger;
	if(dto.createdBy){
    	$("#createdBy").val(dto.createdBy.fullTitle);
		$("#createdBy").attr("entityId", dto.createdBy.rowId);
	}
    if(dto.updatedBy){
    	$("#updatedBy").val(dto.updatedBy.fullTitle);
		$("#updatedBy").attr("entityId", dto.updatedBy.rowId);
	}
    $("#created").val(dto.created);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}
function fillEditRFQ(dto){//load for qouote reqouest
	entity = dto;
    clearForm();
    $('#company').html(dto.createdBy.companyName);
    $('#fullName').html(dto.createdBy.fullName);
    $('#email').html(dto.createdBy.email);
    if(dto.createdBy.file)
    	$("#logo").attr("src", "data:image/png;base64," +dto.createdBy.file.imageContent);
    else
    	$("#logo").attr("src", "../../core/img/image01.png");
    	
       $("#shipmentName").html(dto.shipmentName);
       if(dto.freightMethodTypeDTO){
	       if(dto.freightMethodTypeDTO.rowId == 10002)
				$("#freightMethod").html('<span class="ion-android-plane" style="font-size:20px;"></span>');
			if(dto.freightMethodTypeDTO.rowId == 10003)
				$("#freightMethod").html('<span class="ion-android-boat" style="font-size:20px;"></span>');
			if(dto.freightMethodTypeDTO.rowId == 10004)
				$("#freightMethod").html('<span class="ion-android-plane" style="font-size:20px;"></span><span class="ion-android-boat" style="font-size:20px;"></span>');
			if(dto.freightMethodTypeDTO.rowId == 10005)
				$("#freightMethod").html('<span class="ion-android-bus" style="font-size:20px;"></span>');
       }
    	//$("#freightMethod").find('span').html(dto.freightMethodTypeDTO ? dto.freightMethodTypeDTO.name :'');
    	$("#freightType").html(dto.freightTypeDTO ? dto.freightTypeDTO.name :'');
    	if(dto.origionLocationDTO && dto.pickupDate)
    		$("#origin").html( dto.origionLocationDTO.name + " , "+ dto.pickupDate);
    	else if(dto.origionLocationDTO)
    		$("#origin").html( dto.origionLocationDTO.name);
    	else
    		$("#origin").html(dto.pickupDate);
    	if(dto.destinationLocationDTO && dto.targetDeliveryDate)
    		$("#destination").html( dto.destinationLocationDTO.name + " , "+dto.targetDeliveryDate);
    	else if(dto.destinationLocationDTO)
    		$("#destination").html( dto.destinationLocationDTO.name );
    	else
    		$("#destination").html(dto.targetDeliveryDate);
    Log(dto.active)
}
/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $('#logDate').val(today);
    $('#logUserDTO').val(user.fullName);
    $('#logUserDTO').attr("entityId",user.userId);
    var ret = window.location.toString();
    var result = ret.split("?id=");
    if(result[1])
    	$('#qouteRequestDTO').attr('entityId',result[1]);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
        	if(!resultId[1])
        		parent.showEdit(result.result[0])
            else{
            if(result.result)
        		fillEdit(result.result[0])
        	else
        		showRowPageRFQ(resultId[1])
            }
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}
/*-------------------------------------------------------------------------------------- Show Row Data RFQ -----------------------------------------------------*/
var hShowRowRFQ = new Handler();
hShowRowRFQ.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRowRFQ.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
        	if(result.result)
        		fillEditRFQ(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRowRFQ.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRowRFQ.complete = function complete() {
    unlockPage();
}
/*-------------------------------------------------------------------------- RFQ END --------------------------------------------------*/
var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    if(resultId[1])
    	fShrSearche.addParameter("qouteRequest.rowId", id, Condition.EQUAL);
    else
    	fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/rfqLog/list");
    pageNo = oldPageNo;
}
function showRowPageRFQ(id){
	fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRowRFQ, "/qoutRequest/list");
    pageNo = oldPageNo;
}
/*---------------------------------------------------------------------------- Start Fill Grid Message -------------------------------------------------------*/
function searchDetail(id){
	var hSearch = new Handler();
	hSearch.beforeSend = function beforeSend() {
	    parent.showLoading();
	}
	hSearch.success = function success(result) {
	    if (result.done) {
	        parent.hideLoading();
	        setTimeout(function () {
	           // parent.showEdit(result.result[0])
	        	//alert(result.result)
	        	fillTableDetail(result.result);
	        }, 300);
	    } else {
	        parent.hideLoading();
	        setTimeout(function () {
	            errorHandle(result);
	        }, 300)
	    }
	}
	hSearch.error = function error(jqXHR, textStatus) {
	    hideLoading();
	    setTimeout(function () {
	        showError("Error: " + textStatus + ' ' + jqXHR.status);
	    }, 300);
	}
	hSearch.complete = function complete() {
	    unlockPage();
	}
	fShrSearche.clearParams();
    fShrSearche.addParameter("qouteRequest.rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hSearch, "/rfqLog/list");
    pageNo = 20;
}
function fillTableDetail(entities){
	 $('.media > table').css({"display": "table"});
	    var tableBody = $('.media > table > tbody');
	    tableBody.find('tr').not('tr#row').remove();
	    tableBody.find('tr#row').removeAttr('style');

	entities.forEach(function (item, index) {

		 var patternRow = tableBody.find('#row').clone();
	     var id = item.rowId;
	     patternRow.attr('id', 'row-' + id);
	     //patternRow.find("#userPic").attr("id", 'userPic-' + id).html("<div class='media-left'><img src="+(user.imageContent ? 'data:image/png;base64,' + user.imageContent : '../../core/img/default-profile/user-male-icon.png')+" class='media-object' style='width:40px'></div><br>");
	     var reply="";
	     if(item.rfqLogReply){
	    	
	    	 for (var i = 0; i < item.rfqLogReply.length; i++) {
	    		 reply +="<div class='media'>"+
					"<div class='media-left'>"+
						"<a href=''>"+
							"<img class='media-object' src="+(item.rfqLogReply[i].createdBy.file ? 'data:image/png;base64,' + item.rfqLogReply[i].createdBy.file.imageContent : '../../core/img/default-profile/user-male-icon.png')+" style='width:40px'>"+
						"</a>"+
					"</div>"+
					"<div class='media-body' style='overflow-y: scroll;' id='divBody'>"+
						"<b class='media-heading'>"+item.rfqLogReply[i].createdBy.fullName+" , "+item.rfqLogReply[i].created.substring(0,10)+"</b>"+
						"<pre>"+item.rfqLogReply[i].replyNotes+"</pre>"+
					"</div>"+
				"</div>";
			}
	    	 
	     }
	     patternRow.find("#msg-body").attr("id", 'msg-body-' + id).html
	     (
	    		 "<div class='media-left'><img src="+(item.createdBy.file ? 'data:image/png;base64,' + item.createdBy.file.imageContent : '../../core/img/default-profile/user-male-icon.png')+" class='media-object' style='width:40px'></div>"+		 
	    		 "<div class='media-body'>"+
	    		 "<span id='userName'>"+(item.logUserDTO ? item.logUserDTO.fullName+" , "+item.logDate : '')+"</span>"+
   		 		"<pre>"+item.logNotes+"<br></pre>"+
   		 		reply+
   		 		"<a class='pull-left'  onclick=\"openReply("+id+")\"><span class='ion-reply text-primary' style='font-size: 16px;cursor:pointer'></span>"+
   		 		
						"<span class='text-primary' style='cursor:pointer'>Reply</span>"+
					"</a><br>"+
					"<div style='display:none' id='divReply-"+id+"'>"+
					"<div class='input-row'> "+
				     "<div class='test w3'>"+
				     	"<textarea autofocus class='mandatory' id='replyNotes-"+id+"' rows=4 cols=50  placeholder='Write Your Message ....' required></textarea>"+
				 	"</div>"+
				 "</div><div  style='padding: 8px;' align='left'>"+
				 "<button type='button' class='btn btn-default active' onclick=\"saveNoteReply("+id+")\" >Send Message</button>  "+
				 "  <button type='button' class='btn btn-primary' onclick=\"cancel("+id+")\">Cancel</button>"+
   		 	"</div></div><br>"
	     		);
	     patternRow.appendTo(tableBody);
	     $('#div-media-total').css("height",(document.getElementById('div-media-total').scrollHeight+120)+'px');
	    if(document.getElementById('divBody'))
	     $('.media-body').css("height",document.getElementById('divBody').scrollHeight+'px');
  });
	
}

function openReply(id){
	$('#divReply-'+id).show();	
}
function cancel(id){
	$('#replyNotes-'+id).val('');
	$('#divReply-'+id).hide();
}
function saveNoteReply(id){
	//rfgLog id
	var note = $('#replyNotes-'+id).val();
	var hSave = new Handler();
    hSave.success = function success(result) {
        if (result.done) {
       	 $('#divReply-'+id).hide();
       	 searchDetail(resultId[1]);
        }
        else {
            errorHandle(result);
        }
    }
    hSave.error = function error(jqXHR, textStatus) {
        dialog('Save', textStatus + 'Error: ')
    }
    if(note != ''){
		note = note.replace("\n", "\\n");
		var temp = '{"replyNotes":"' + note+ '"' +
		 ',"rfqLogDTO": {"rowId":' + id + '}'+
		 ', "ticket":"' + user.ticket + '"},';
		temp = temp.substr(0, temp.lastIndexOf(","));
		ServiceInvoker.call(temp, hSave, "/rfqLogReply/save");
	}
    
}
/*--------------------------------------------------------------------------------------- End ------------------------*/

