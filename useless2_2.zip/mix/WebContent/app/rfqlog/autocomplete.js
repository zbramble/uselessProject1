/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicQuoteRequest(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/qoutRequest/list",
        mapPattern: {
            label: "fullTitle",
            value: "fullTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicUser(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/user/list",
        mapPattern: {
            label: "fullTitle",
            value: "fullTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};