package org.mega.bse.category;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class CategoryFacade extends BaseFacade {

	private static CategoryCopier copier = new CategoryCopier();
	private static CategoryFacade facade = new CategoryFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static CategoryFacade getInstance() {
		return facade;
	}
}
