package org.mega.bse.legmilestones;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;

public class LegMilestonesCopier extends BaseCopier<LegMilestones, LegMilestonesDTO>{

	@Override
	public LegMilestonesDTO copyFromEntity(LegMilestones legMilestones) {
		LegMilestonesDTO legMilestonesDTO = new LegMilestonesDTO();
		legMilestonesDTO.setRowId(legMilestones.getRowId());
		legMilestonesDTO.setMilestoneName(legMilestones.getMilestoneName());
		legMilestonesDTO.setTrackingInfo(legMilestones.isTrackingInfo());
		legMilestonesDTO.setDepartureDays(legMilestones.getDepartureDays());
		if(legMilestones.getLegType() != null){
			ComboValDTO c = new ComboValDTO();
			c.setRowId(legMilestones.getLegType().getRowId());
			c.setName(legMilestones.getLegType().getName());
			legMilestonesDTO.setLegTypeDTO(c);
		}
		if(legMilestones.getScopeType() != null){
			ComboValDTO c = new ComboValDTO();
			c.setRowId(legMilestones.getScopeType().getRowId());
			c.setName(legMilestones.getScopeType().getName());
			legMilestonesDTO.setScopeTypeDTO(c);
		}
		copyFromEntityBaseField(legMilestones, legMilestonesDTO);
		return legMilestonesDTO;
	}

	@Override
	public LegMilestones copyToEntity(LegMilestonesDTO legMilestonesDTO) throws Exception {
		LegMilestones legMilestones = new LegMilestones();
		legMilestones.setRowId(legMilestonesDTO.getRowId());
		legMilestones.setMilestoneName(legMilestonesDTO.getMilestoneName());
		legMilestones.setDepartureDays(legMilestonesDTO.getDepartureDays());
		legMilestones.setTrackingInfo(legMilestonesDTO.isTrackingInfo());
		if(legMilestonesDTO.getLegTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(legMilestonesDTO.getLegTypeDTO().getRowId());
			c.setName(legMilestonesDTO.getLegTypeDTO().getName());
			legMilestones.setLegType(c);
		}
		if(legMilestonesDTO.getScopeTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(legMilestonesDTO.getScopeTypeDTO().getRowId());
			c.setName(legMilestonesDTO.getScopeTypeDTO().getName());
			legMilestones.setScopeType(c);
		}
		copyToEntityBaseField(legMilestones, legMilestonesDTO);
		return legMilestones;
	}

}
