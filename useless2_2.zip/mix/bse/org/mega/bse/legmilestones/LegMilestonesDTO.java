package org.mega.bse.legmilestones;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;

public class LegMilestonesDTO extends BaseDTO {
	private long rowId;
	private String milestoneName;
	private int departureDays;
	private ComboValDTO legTypeDTO;
	private ComboValDTO scopeTypeDTO;
	private boolean trackingInfo;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getMilestoneName() {
		return milestoneName;
	}

	public void setMilestoneName(String milestoneName) {
		this.milestoneName = milestoneName;
	}

	public int getDepartureDays() {
		return departureDays;
	}

	public void setDepartureDays(int departureDays) {
		this.departureDays = departureDays;
	}

	public ComboValDTO getLegTypeDTO() {
		return legTypeDTO;
	}

	public void setLegTypeDTO(ComboValDTO legTypeDTO) {
		this.legTypeDTO = legTypeDTO;
	}

	public boolean isTrackingInfo() {
		return trackingInfo;
	}

	public void setTrackingInfo(boolean trackingInfo) {
		this.trackingInfo = trackingInfo;
	}

	public ComboValDTO getScopeTypeDTO() {
		return scopeTypeDTO;
	}

	public void setScopeTypeDTO(ComboValDTO scopeTypeDTO) {
		this.scopeTypeDTO = scopeTypeDTO;
	}

}
