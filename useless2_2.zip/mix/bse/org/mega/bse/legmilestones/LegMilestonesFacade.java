package org.mega.bse.legmilestones;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class LegMilestonesFacade extends BaseFacade{
	private static LegMilestonesCopier copier = new LegMilestonesCopier();
	private static LegMilestonesFacade facade = new LegMilestonesFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static LegMilestonesFacade getInstance() {
		return facade;
	}
}
