package org.mega.bse.company;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.location.Location;

@Entity
@Table(name = "BSE_COMPANY", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_COMPANY", columnNames = "BSE_COMPANY_ID") )
public class Company extends BaseEntity{
	@Id
	@Column(name = "BSE_COMPANY_ID")
	private long rowId;
	
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;

	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "COUNTRY_ID", foreignKey = @ForeignKey(name = "FK_BSE_COMP_REFERENCE_CO_LOCAT") , nullable = true)
	private Location country;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PROVINCE_ID", foreignKey = @ForeignKey(name = "FK_BSE_COMP_REFERENCE_CO_LOCA1") , nullable = true)
	private Location province;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CITY_ID", foreignKey = @ForeignKey(name = "FK_BSE_COMP_REFERENCE_CO_LOCA2") , nullable = true)
	private Location city;
	
	@Column(name = "COMPANY_NAME", length = 300,nullable = true)
	private String companyName;
	
	@Column(name = "CONTACT_PERSON_NAME", length = 300,nullable = true)
	private String companyPersonName;
	
	@Column(name = "COMPANY_WEBSITE", length = 2000,nullable = true)
	private String companyWebsite;
	
	@Column(name = "COMPANY_PHONE", length = 20,nullable = true)
	private String companyPhone;
	
	@Column(name = "COMPANY_EMAIL", length = 500,nullable = true)
	private String companyEmail;
	
	@Column(name = "CONTACT_PERSON_ROLE", length = 300,nullable = true)
	private String personRole;
	
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "COMPANY_LOGO", nullable = true)
	private byte[] companyLogo;
	
	@Column(name = "ADDRESS1", length = 1000,nullable = true)
	private String address1;
	
	@Column(name = "ADDRESS2", length = 100,nullable = true)
	private String address2;
	
	@Column(name = "ZIPCODE", length = 20,nullable = true)
	private String zipcode;

	
	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Location getCountry() {
		return country;
	}

	public void setCountry(Location country) {
		this.country = country;
	}

	public Location getProvince() {
		return province;
	}

	public void setProvince(Location province) {
		this.province = province;
	}

	public Location getCity() {
		return city;
	}

	public void setCity(Location city) {
		this.city = city;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyPersonName() {
		return companyPersonName;
	}

	public void setCompanyPersonName(String companyPersonName) {
		this.companyPersonName = companyPersonName;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getCompanyPhone() {
		return companyPhone;
	}

	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public String getPersonRole() {
		return personRole;
	}

	public void setPersonRole(String personRole) {
		this.personRole = personRole;
	}

	public byte[] getCompanyLogo() {
		return companyLogo;
	}

	public void setCompanyLogo(byte[] companyLogo) {
		this.companyLogo = companyLogo;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = "";
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = "";
    }
}
