package org.mega.bse.tax;

import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class TaxFacade extends BaseFacade {

	private static TaxCopier copier = new TaxCopier();
	private static TaxFacade facade = new TaxFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static TaxFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		TaxDTO taxDTO = (TaxDTO) baseDTO;
		try {
			if(taxDTO.isIsDefault()){
			BaseDB db = businessParam.getDB();
			 Query query = db.createNativeQuery("select e.tax_class_id,e.TAX_CLASS_TITLE from BSE_TAX_CLASS e where e.IS_DELETED = 0 and e.is_default = 1 and e.tax_class_id != "+taxDTO.getRowId());
			 if(query.getResultList().size() > 0){
				 List<Object[]> ret = (List<Object[]>) query.getResultList();
				 for (int i = 0; i < ret.size(); i++) {
					 TaxDTO tax = new TaxDTO();
					 tax.setRowId(Long.parseLong(ret.get(i)[0].toString()));
					 tax.setTaxClassTitle(ret.get(i)[1].toString());
					 tax.setIsDefault(false);
					 tax.setRate(1);
					 save(tax, businessParam);
				}
				 businessParam.releaseDB();
			 }
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.save(baseDTO, businessParam);
	}

}
