package org.mega.bse.freightchargeclassifi;

import org.mega.core.base.BaseCopier;

public class FreightChargeClassificatCopier extends BaseCopier<FreightChargeClassificat, FreightChargeClassificatDTO>{

	@Override
	public FreightChargeClassificatDTO copyFromEntity(FreightChargeClassificat classificat) {
		FreightChargeClassificatDTO classificatDTO = new FreightChargeClassificatDTO();
		classificatDTO.setRowId(classificat.getRowId());
		classificatDTO.setClassificationTitle(classificat.getClassificationTitle());
		copyFromEntityBaseField(classificat, classificatDTO);
		return classificatDTO;
	}

	@Override
	public FreightChargeClassificat copyToEntity(FreightChargeClassificatDTO classificatDTO) throws Exception {
		FreightChargeClassificat classificat = new FreightChargeClassificat();
		classificat.setRowId(classificatDTO.getRowId());
		classificat.setClassificationTitle(classificatDTO.getClassificationTitle());
		copyToEntityBaseField(classificat, classificatDTO);
		return classificat;
	}

}
