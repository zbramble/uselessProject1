package org.mega.bse.freightchargeclassifi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_FREIGHT_CHARGE_CLASSIFICAT", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_FREIGHT_CHARGE_CLASSIFI", columnNames = "CLASSIFICATION_ID"))
public class FreightChargeClassificat extends BaseEntity {

	@Id
	@Column(name = "CLASSIFICATION_ID")
	private long rowId;

	@Column(name = "CLASSIFICATION_TITLE", length = 500)
	private String classificationTitle;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getClassificationTitle() {
		return classificationTitle;
	}

	public void setClassificationTitle(String classificationTitle) {
		this.classificationTitle = classificationTitle;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = classificationTitle;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = classificationTitle;
	}

}
