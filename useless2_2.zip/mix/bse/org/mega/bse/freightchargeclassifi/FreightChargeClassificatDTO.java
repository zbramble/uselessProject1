package org.mega.bse.freightchargeclassifi;

import org.mega.core.base.BaseDTO;

public class FreightChargeClassificatDTO extends BaseDTO{
	
	private long rowId;
	private String classificationTitle;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getClassificationTitle() {
		return classificationTitle;
	}
	public void setClassificationTitle(String classificationTitle) {
		this.classificationTitle = classificationTitle;
	}
}
