package org.mega.bse.measurementunittype;

import javax.persistence.Column;

import org.mega.core.base.BaseDTO;

public class MeasurementUnitTypeDTO extends BaseDTO{

	private long rowId;
	
	private String measurementUnitName;
	
	private boolean unitDefault;
	
	private double conversionRate;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getMeasurementUnitName() {
		return measurementUnitName;
	}

	public void setMeasurementUnitName(String measurementUnitName) {
		this.measurementUnitName = measurementUnitName;
	}

	public boolean isUnitDefault() {
		return unitDefault;
	}

	public void setUnitDefault(boolean unitDefault) {
		this.unitDefault = unitDefault;
	}

	public double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(double conversionRate) {
		this.conversionRate = conversionRate;
	}
	
}
