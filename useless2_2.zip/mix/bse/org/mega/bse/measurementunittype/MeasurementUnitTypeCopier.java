package org.mega.bse.measurementunittype;

import org.mega.core.base.BaseCopier;

public class MeasurementUnitTypeCopier extends BaseCopier<MeasurementUnitType, MeasurementUnitTypeDTO>{

	@Override
	public MeasurementUnitTypeDTO copyFromEntity(MeasurementUnitType maMeasurementUnitType) {
		MeasurementUnitTypeDTO maMeasurementUnitTypeDTO = new MeasurementUnitTypeDTO();
		maMeasurementUnitTypeDTO.setRowId(maMeasurementUnitType.getRowId());
		maMeasurementUnitTypeDTO.setMeasurementUnitName(maMeasurementUnitType.getMeasurementUnitName());
		maMeasurementUnitTypeDTO.setUnitDefault(maMeasurementUnitType.isUnitDefault());
		maMeasurementUnitTypeDTO.setConversionRate(maMeasurementUnitType.getConversionRate());
		copyFromEntityBaseField(maMeasurementUnitType, maMeasurementUnitTypeDTO);
		return maMeasurementUnitTypeDTO;
	}

	@Override
	public MeasurementUnitType copyToEntity(MeasurementUnitTypeDTO maMeasurementUnitTypeDTO) throws Exception {
		MeasurementUnitType maMeasurementUnitType = new MeasurementUnitType();
		maMeasurementUnitType.setRowId(maMeasurementUnitTypeDTO.getRowId());
		maMeasurementUnitType.setMeasurementUnitName(maMeasurementUnitTypeDTO.getMeasurementUnitName());
		maMeasurementUnitType.setUnitDefault(maMeasurementUnitTypeDTO.isUnitDefault());
		maMeasurementUnitType.setConversionRate(maMeasurementUnitTypeDTO.getConversionRate());
		copyToEntityBaseField(maMeasurementUnitType, maMeasurementUnitTypeDTO);
		return maMeasurementUnitType;
	}

}
