package org.mega.bse.versselcodes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;

@Entity
@Table(name = "BSE_VESSEL_CODES", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_VERSSEL_CODES", columnNames = "VERSSEL_CODES_ID"))
public class VersselCodes extends BaseEntity {
	@Id
	@Column(name = "VERSSEL_CODES_ID")
	private long rowId;

	@Column(name = "NAME", length = 50)
	private String name;

	@Column(name = "VERSSEL_IMO")
	private int imo;

	@Column(name = "VERSSEL_MMSI")
	private int mmsi;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "VERSSEL_TYPE_ID", foreignKey = @ForeignKey(name = "FK_BSE_VERSSEL_TYPE_COMBO"), nullable = true)
	private ComboVal type;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "VERSSEL_FLAG_ID", foreignKey = @ForeignKey(name = "FK_BSE_VERSSEL_FLAG_COMBO"), nullable = true)
	private ComboVal flag;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getImo() {
		return imo;
	}

	public void setImo(int imo) {
		this.imo = imo;
	}

	public int getMmsi() {
		return mmsi;
	}

	public void setMmsi(int mmsi) {
		this.mmsi = mmsi;
	}

	public ComboVal getType() {
		return type;
	}

	public void setType(ComboVal type) {
		this.type = type;
	}

	public ComboVal getFlag() {
		return flag;
	}

	public void setFlag(ComboVal flag) {
		this.flag = flag;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = name;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = name;
	}

}
