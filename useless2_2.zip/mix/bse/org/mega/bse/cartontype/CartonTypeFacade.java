package org.mega.bse.cartontype;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class CartonTypeFacade extends BaseFacade{
	private static CartonTypeCopier copier = new CartonTypeCopier();
	private static CartonTypeFacade facade = new CartonTypeFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static CartonTypeFacade getInstance() {
		return facade;
	}
}
