package org.mega.bse.cartontype;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.measurementunittype.MeasurementUnitType;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_CARTON_TYPE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_CARTON_TYPE", columnNames = "BSE_CARTON_TYPE_ID"))
public class CartonType extends BaseEntity{

	@Id
	@Column(name = "BSE_CARTON_TYPE_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "MEASUREMENT_UNIT_TYPE_ID", foreignKey = @ForeignKey(name = "FK_BSE_CART_REFERENCE_MEASUREM"), nullable = true)
	private MeasurementUnitType measurementUnitType;
	
	@Column(name="CARTON_TYPE_TITLE",length=200)
	private String cartonTypeTitle;
	
	@Column(name="HEIGHT")
	private double height;
	
	@Column(name="WIDTH")
	private double width;
	
	@Column(name="LENGTH")
	private double length;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public MeasurementUnitType getMeasurementUnitType() {
		return measurementUnitType;
	}

	public void setMeasurementUnitType(MeasurementUnitType measurementUnitType) {
		this.measurementUnitType = measurementUnitType;
	}

	public String getCartonTypeTitle() {
		return cartonTypeTitle;
	}

	public void setCartonTypeTitle(String cartonTypeTitle) {
		this.cartonTypeTitle = cartonTypeTitle;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}
	
	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = cartonTypeTitle;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = cartonTypeTitle;
	}
		

}
