package org.ntnet.app.report;

import java.lang.reflect.Method;
import java.util.Iterator;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.mega.core.SystemConfig;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BaseService;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;
import org.mega.util.ExcelUtil;

@Path("/ReportService")
public class ReportService extends BaseService {
    private static ReportFacade reportFacade = ReportFacade.getInstance();
    Logger logger = BaseLogger.getLogger(ReportService.class);

    @POST
    @Path("/users")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult users(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
            return reportFacade.users(new BusinessParam(userSession, filter));
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
        }
    }

    @POST
    @Path("/downloadExcel")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces("application/vnd.ms-excel")
    public Response downloadExcel(Filter filter) {
        UserSession userSession;
        try {
            String facadeName;
            String methodName;
            Iterator<PairValue> params = filter.getParams().iterator();
            PairValue pairValue1 = params.next();
            PairValue pairValue2 = params.next();
            if (pairValue1.getKey().equals("facadeName"))
                facadeName = pairValue1.getValue();
            else
                return Response.noContent().build();

            filter.setPageNo(1);
            filter.setPageSize(SystemConfig.REPORT_EXCEL_MAX_SIZE);
            userSession = UserSessionManager.getUserSession(filter.getTicket());

            if (pairValue2.getKey().equals("methodName"))
                methodName = pairValue2.getValue();
            else
                return Response.noContent().build();

            Object facade = Class.forName(facadeName).getMethod("getInstance").invoke(null);
            Method method = facade.getClass().getMethod(methodName, BusinessParam.class);
            ServiceResult result = (ServiceResult) method.invoke(facade, new BusinessParam(userSession, filter));

            //ServiceResult result = reportFacade.vReward(new BusinessParam(userSession, filter));

            byte[] excel = ExcelUtil.toExcel(result, null, "Report");

            ResponseBuilder response = Response.ok((Object) excel);
            response.header("Content-Disposition", "attachment; filename=new-excel-file.xls");
            return response.build();
        } catch (Exception e) {
            logger.log(Level.ALL, "Error in downloadExcel", e);
            return Response.noContent().build();
        }
    }
}