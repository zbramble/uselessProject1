package org.mega.core.sec;

public class DataAccessCreator implements DataAccessCreatorI {
    public static String FILTER_NAME_MAIN_ORG = "mainOrg";

    @Override
    public DataAccess createDataAccess(UserInfo userInfo) {
        DataAccess dataAccess = new DataAccess();
        //TODO load accesses form database
//		dataAccess.addAccessKeyFilter(name, aksStr);
//		dataAccess.addSimpleFilter(name, filter);
//		dataAccess.

        dataAccess.addAccessKeyFilter(FILTER_NAME_MAIN_ORG, userInfo.getOrgId() + ":" + userInfo.getAccessKey());
        return null;
    }

}
