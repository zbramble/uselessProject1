

import java.io.File;
import java.util.ArrayList;

import javax.persistence.Entity;

public class ProjectTools {

	public static void main(String[] args) {
		ArrayList<Class> classes = new ArrayList<Class>();
		getAllClasses("org",classes);
		
		for(Class clazz : classes){
			if(clazz.getAnnotation(Entity.class) != null)
				System.out.println(clazz.getSimpleName());
		}
	}

	public static void getAllClasses(String pckgname, ArrayList classes) {
		try {
			// Get a File object for the package
			File directory = null;
			try {
				directory = new File(Thread.currentThread().getContextClassLoader().getResource(pckgname.replace('.', '/')).getFile());
			} catch (NullPointerException x) {
				System.out.println("Nullpointer");
				throw new ClassNotFoundException(pckgname + " does not appear to be a valid package");
			}
			if (directory.exists()) {
				// Get the list of the files contained in the package
				File[] files = directory.listFiles();
				for (int i = 0; i < files.length; i++) {
					// we are only interested in .class files
					if (files[i].getName().endsWith(".class")) {
						// removes the .class extension
						classes.add(Class.forName(pckgname + '.' + files[i].getName().substring(0, files[i].getName().length() - 6)));
					}else
					if(files[i].isDirectory()){
						getAllClasses(pckgname + "." + files[i].getName(),classes);
					}
				}
			} else {
				System.out.println("Directory does not exist");
				throw new ClassNotFoundException(pckgname + " does not appear to be a valid package");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
