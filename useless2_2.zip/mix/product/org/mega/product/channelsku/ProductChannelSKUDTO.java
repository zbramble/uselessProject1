package org.mega.product.channelsku;

import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseDTO;
import org.mega.product.ProductDTO;

public class ProductChannelSKUDTO extends BaseDTO {
private long rowId;
	private SiteDTO siteDTO;
	private ProductDTO productDTO;
	private String accessKey;
	private String description;
	private String notes;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public SiteDTO getSiteDTO() {
		return siteDTO;
	}
	public void setSiteDTO(SiteDTO siteDTO) {
		this.siteDTO = siteDTO;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	
}
