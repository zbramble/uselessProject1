package org.mega.product.extendedpropertie;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class ProductExtendedPropertieFacade extends BaseFacade{
	private static ProductExtendedPropertieCopier copier = new ProductExtendedPropertieCopier();
	private static ProductExtendedPropertieFacade facade = new ProductExtendedPropertieFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductExtendedPropertieFacade	 getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductExtendedPropertieDTO extendedDTO = (ProductExtendedPropertieDTO) baseDTO;
		if(extendedDTO.getRowId() == 0)
			extendedDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());

		return super.save(baseDTO, businessParam);
	}

}
