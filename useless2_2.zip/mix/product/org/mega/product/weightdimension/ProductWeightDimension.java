package org.mega.product.weightdimension;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.product.Product;

@Entity
@Table(name = "PRODUCT_WEIGHT_DIMENSION", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_WEIGHT_DIMENSION", columnNames = "PRODUCT_WEIGHT_DIMENSION_ID") )
public class ProductWeightDimension extends BaseEntity{
	
	@Id
	@Column(name = "PRODUCT_WEIGHT_DIMENSION_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODU_WEIGHT_REF_PRODCT") , nullable = true)
	private Product product;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "WEIGHT_UNIT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFEREN_CO_COMBO1") , nullable = true)
	private ComboVal weightUnit;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "DIMENSION_UINIT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFEREN_CO_COMBO2") , nullable = true)
	private ComboVal dimensionUnit;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "VOLUME_UNIT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFEREN_CO_COMBO3") , nullable = true)
	private ComboVal volumeUnit;
	
	@Column(name = "WEIGHT")
	private double weight;
	
	@Column(name = "WIDTH")
	private double width;
	
	@Column(name = "HEIGHT")
	private double height;
	
	@Column(name = "DEPTH")
	private double depth;
	
	@Column(name = "VOLUME")
	private double volume;
	
	@Column(name = "UNITS_IN_CARTON")
	private int unitsInCarton; 
	
	@Column(name = "CARTON_WIDTH", length = 10 ,nullable = true)
	private double cartonWidth;
	
	@Column(name = "CARTON_HEIGHT", length = 10,nullable = true)
	private double cartonheight;
	
	@Column(name = "CARTON_DEPTH", length = 10,nullable = true)
	private double cartonDepth;
	
	@Column(name = "CARTON_VOLUME", length = 10,nullable = true)
	private double cartonVolume;
	
	
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;
	
	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ComboVal getWeightUnit() {
		return weightUnit;
	}

	public void setWeightUnit(ComboVal weightUnit) {
		this.weightUnit = weightUnit;
	}

	public ComboVal getDimensionUnit() {
		return dimensionUnit;
	}

	public void setDimensionUnit(ComboVal dimensionUnit) {
		this.dimensionUnit = dimensionUnit;
	}

	public ComboVal getVolumeUnit() {
		return volumeUnit;
	}

	public void setVolumeUnit(ComboVal volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getDepth() {
		return depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public int getUnitsInCarton() {
		return unitsInCarton;
	}

	public void setUnitsInCarton(int unitsInCarton) {
		this.unitsInCarton = unitsInCarton;
	}

	public double getCartonWidth() {
		return cartonWidth;
	}

	public void setCartonWidth(double cartonWidth) {
		this.cartonWidth = cartonWidth;
	}

	public double getCartonheight() {
		return cartonheight;
	}

	public void setCartonheight(double cartonheight) {
		this.cartonheight = cartonheight;
	}

	public double getCartonDepth() {
		return cartonDepth;
	}

	public void setCartonDepth(double cartonDepth) {
		this.cartonDepth = cartonDepth;
	}

	public double getCartonVolume() {
		return cartonVolume;
	}

	public void setCartonVolume(double cartonVolume) {
		this.cartonVolume = cartonVolume;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = product.getFullTitle() + " props";
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
        fullTitle = product.getFullTitle() + " props";
    }

}
