﻿select * from co_combo_val c where c.parent_id = 10001;
select * from co_combo_val c where c.parent_id = 10007;
select * from co_combo_val c where c.parent_id = 100015;
select * from co_combo_val c where c.parent_id = 100018;
select * from co_combo_val c where c.parent_id = 100022;
select * from co_combo_val c where c.parent_id = 100025;
select * from co_combo_val c where c.parent_id = 100030;