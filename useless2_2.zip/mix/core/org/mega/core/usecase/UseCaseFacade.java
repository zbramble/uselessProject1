package org.mega.core.usecase;

import java.util.List;

import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.usecaseaction.UseCaseActionDTO;
import org.mega.core.usecaseaction.UseCaseActionFacade;
import org.mega.util.BeanUtil;

public class UseCaseFacade extends BaseFacade {
    private static UseCaseCopier copier = new UseCaseCopier();
    private static UseCaseFacade facade = new UseCaseFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static UseCaseFacade getInstance() {
        return facade;
    }

    public ServiceResult manyToManySave(UseCaseDTO useCaseDTO,
                                        List<UseCaseActionDTO> addItems,
                                        List<String> removeItems,
                                        BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);

        try {
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.insert);

            ServiceResult resultSave = save(useCaseDTO, businessParam);

            if (addItems != null && addItems.size() > 0) {
                for (int i = 0; i < addItems.size(); i++) {
                    UseCaseDTO useCaseSample = new UseCaseDTO();
                    useCaseSample.setRowId((Long) resultSave.getResult());
                    addItems.get(i).setUseCase(useCaseSample);
                    UseCaseActionFacade.getInstance().save(addItems.get(i), businessParam);
                }
            }
            if (removeItems.size() > 0) {
                String ids = removeItems.toString().replaceAll("\\[|\\]", "");
                BaseDB db = businessParam.getDB();
                db.runNativeQuery("delete from CO_USECASE_ACTION where USECASE_ID = " + useCaseDTO.getRowId() + " and ACTION_ID in (" + ids + ")");
                businessParam.releaseDB();
            }
            return resultSave;
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error saving " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }
}