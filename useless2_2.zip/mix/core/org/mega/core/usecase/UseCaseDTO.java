package org.mega.core.usecase;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.core.usecaseaction.UseCaseActionDTO;

public class UseCaseDTO extends BaseDTO {
    private long rowId;
    private String clazz;
    private String code;
    private String tableName;
    private String useCaseName;
    private UseCaseDTO parent;
    private boolean hasChild;
    private List<UseCaseDTO> children;
    private List<UseCaseActionDTO> useCaseActions;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getClazz() {
        return clazz;
    }

    public void setClazz(String clazz) {
        this.clazz = clazz;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getUseCaseName() {
        return useCaseName;
    }

    public void setUseCaseName(String useCaseName) {
        this.useCaseName = useCaseName;
    }

    public UseCaseDTO getParent() {
        return parent;
    }

    public void setParent(UseCaseDTO parent) {
        this.parent = parent;
    }

    public boolean isHasChild() {
        return hasChild;
    }

    public void setHasChild(boolean hasChild) {
        this.hasChild = hasChild;
    }

    public List<UseCaseDTO> getChildren() {
        return children;
    }

    public void setChildren(List<UseCaseDTO> children) {
        this.children = children;
    }

    public List<UseCaseActionDTO> getUseCaseActions() {
        return useCaseActions;
    }

    public void setUseCaseActions(List<UseCaseActionDTO> useCaseActions) {
        this.useCaseActions = useCaseActions;
    }
}
