package org.mega.core.comboval;

import org.mega.core.base.BaseCopier;

public class ComboValCopier extends BaseCopier<ComboVal, ComboValDTO> {

    @Override
    public ComboValDTO copyFromEntity(ComboVal comboVal) {
        ComboValDTO comboValDTO = new ComboValDTO();

        comboValDTO.setRowId(comboVal.getRowId());
        comboValDTO.setName(comboVal.getName());
        comboValDTO.setVal(comboVal.getVal());
        comboValDTO.setCode(comboVal.getCode());
        if (comboVal.getParent() != null) {
            ComboValDTO parenDTO = new ComboValDTO();
            parenDTO.setRowId(comboVal.getParent().getRowId());
            parenDTO.setName(comboVal.getParent().getName());
            comboValDTO.setParent(parenDTO);
        }
        copyFromEntityBaseField(comboVal, comboValDTO);

        return comboValDTO;
    }

    @Override
    public ComboVal copyToEntity(ComboValDTO comboValDTO) {
        ComboVal comboVal = new ComboVal();

        comboVal.setRowId(comboValDTO.getRowId() == 0 ? null : comboValDTO.getRowId());
        comboVal.setName(comboValDTO.getName());
        comboVal.setVal(comboValDTO.getVal());
        comboVal.setCode(comboValDTO.getCode());
        if (comboValDTO.getParent() != null) {
            ComboVal parent = new ComboVal();
            parent.setRowId(comboValDTO.getParent().getRowId());
            comboVal.setParent(parent);
        }
        copyToEntityBaseField(comboVal, comboValDTO);

        return comboVal;
    }
}