package org.mega.core.feedBack;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;


@Entity
@Table(name = "CO_FEEDBACK", uniqueConstraints = @UniqueConstraint(name = "PK_CO_FEEDBACK", columnNames = "FEEDBACK_ID"))
public class FeedBack extends BaseEntity {
    @Id
    @Column(name = "FEEDBACK_ID")
    private long rowId;

    @Column(name = "WINDOW_NAME", nullable = false, length = 50)
    private String windowName;

    @Column(name = "SATISFACTION")
    private boolean satisfaction;

    @Column(name = "OFFER", nullable = true, length = 500)
    private String offer;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "CONDITION_ID", nullable = true, foreignKey = @ForeignKey(name = "FK_CONDITIONID_REF_COMBO_VAL"))
    private ComboVal condition;

    @Column(name = "DESCRIPTION", nullable = true, length = 500)
    private String description;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getWindowName() {
        return windowName;
    }

    public void setWindowName(String windowName) {
        this.windowName = windowName;
    }

    public boolean isSatisfaction() {
        return satisfaction;
    }

    public void setSatisfaction(boolean satisfaction) {
        this.satisfaction = satisfaction;
    }

    public String getOffer() {
        return offer;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }

    public ComboVal getCondition() {
        return condition;
    }

    public void setCondition(ComboVal condition) {
        this.condition = condition;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
    }

	@Override
	public void preUpdate() throws Exception {
		// TODO Auto-generated method stub
		
	}
}