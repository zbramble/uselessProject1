package org.mega.core.feedBack;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class FeedBackFacade extends BaseFacade {
    private static FeedBackCopier copier = new FeedBackCopier();
    private static FeedBackFacade facade = new FeedBackFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static FeedBackFacade getInstance() {
        return facade;
    }
}