package org.mega.core.feedBack;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;

public class FeedBackDTO extends BaseDTO {
    private long rowId;
    private String windowName;
    private boolean satisfaction;
    private String offer;
    private ComboValDTO condition;
    private String description;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getWindowName() {
        return windowName;
    }

    public void setWindowName(String windowName) {
        this.windowName = windowName;
    }

    public boolean isSatisfaction() {
        return satisfaction;
    }

    public void setSatisfaction(boolean satisfaction) {
        this.satisfaction = satisfaction;
    }

    public String getOffer() {
        return offer;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }

    public ComboValDTO getCondition() {
        return condition;
    }

    public void setCondition(ComboValDTO condition) {
        this.condition = condition;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}