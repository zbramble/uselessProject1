package org.mega.core.organization;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;

public class OrganizationFacade extends BaseFacade {
    private static OrganizationCopier copier = new OrganizationCopier();
    private static OrganizationFacade facade = new OrganizationFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static OrganizationFacade getInstance() {
        return facade;
    }
    
    //TODO set user and organization accesskey
    @Override
    public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
    	// TODO Auto-generated method stub
    	return super.save(baseDTO, businessParam);
    }

    @Override
	public String getConstraint(BusinessParam businessParam) {
		UserSession userSession = businessParam.getUserSession();
		if(userSession.dontCheckAccess())
			return null;
		return "e.accessKey like '" + userSession.getUserInfo().getAccessKey() +"%' and e.rowId<>"+userSession.getUserInfo().getUserId();//User dont access to your data
	}
}