package org.mega.core.accessgrp;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/accessgrp")
public class AccessGrpService {
    @POST
    @Path("/save")
    public ServiceResult save(AccessGrpDTO accessGrpDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(accessGrpDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        return AccessGrpFacade.getInstance().save(accessGrpDTO, new BusinessParam(userSession));
    }

    @POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return AccessGrpFacade.getInstance().list(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return AccessGrpFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/load")
    public ServiceResult load(Filter filter) {
        return list(filter);
    }

    @POST
    @Path("/treeLoader")
    public ServiceResult treeLoader(Filter filter) throws Exception {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return AccessGrpFacade.getInstance().treeLoader(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/manyToManySave")
    public ServiceResult manyToManySave(MasterAccessGrpDTO masterAccessGrpDTO) {
        masterAccessGrpDTO.getListChild();
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(masterAccessGrpDTO.getAccessGrp().getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }

        return AccessGrpFacade.getInstance().manyToManySave(masterAccessGrpDTO.getAccessGrp(), masterAccessGrpDTO.getListChild(), masterAccessGrpDTO.getListId(), new BusinessParam(userSession));
    }

}
