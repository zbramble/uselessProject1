package org.mega.core.accessgrp;

import java.util.List;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BusinessParam;
import org.mega.core.usecaseaction.UseCaseActionFacade;

public class AccessGrpCopier extends BaseCopier<AccessGrp, AccessGrpDTO> {
    @Override
    public AccessGrpDTO copyFromEntity(AccessGrp accessGrp) {
        AccessGrpDTO accessGrpDTO = new AccessGrpDTO();

        accessGrpDTO.setRowId(accessGrp.getRowId());
        accessGrpDTO.setCode(accessGrp.getCode());
        accessGrpDTO.setName(accessGrp.getName());
        if (accessGrp.getUseCaseActions() != null) {
            accessGrpDTO.setUseCaseActions(
                UseCaseActionFacade.getInstance().getCopier().copyFromEntity(accessGrp.getUseCaseActions()));
        }
        /*if (accessGrp.getRoles() != null) {
            accessGrpDTO.setRoles(RoleFacade.getInstance().getCopier().copyFromEntity(accessGrp.getRoles()));
        }*/
        copyFromEntityBaseField(accessGrp, accessGrpDTO);

        return accessGrpDTO;
    }

    @Override
    public AccessGrp copyToEntity(AccessGrpDTO accessGrpDTO) throws Exception {
        AccessGrp accessGrp = new AccessGrp();
        if(accessGrpDTO.getRowId() != 0)
            accessGrp = AccessGrpFacade.getInstance().findEntityById(AccessGrp.class, accessGrpDTO.getRowId(), BusinessParam.getSystemBusinessParam());
        accessGrp.setRowId(accessGrpDTO.getRowId());
        accessGrp.setCode(accessGrpDTO.getCode());
        accessGrp.setName(accessGrpDTO.getName());
        if (accessGrpDTO.getUseCaseActions() != null) {
            List newUsecaseActions = UseCaseActionFacade.getInstance().getCopier().copyToEntity(accessGrpDTO.getUseCaseActions());
            accessGrp.getUseCaseActions().addAll(newUsecaseActions);
        }
        /*if (accessGrpDTO.getRoles() != null) {
            accessGrp.setRoles(RoleFacade.getInstance().getCopier().copyToEntity(accessGrpDTO.getRoles()));
        }*/
        copyToEntityBaseField(accessGrp, accessGrpDTO);

        return accessGrp;
    }
}