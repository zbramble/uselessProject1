package org.mega.core.base;

import java.util.concurrent.atomic.AtomicLong;

import org.mega.core.sec.UserSession;

public class BusinessParam {
    private BaseDB db;
    
    private AtomicLong stackCount = new AtomicLong(0L);//For transactional: for each getBaseDb plus 1(stackCount++) and for each release db stackCount--. When release and stackCount == 0 db must commint 

    private UserSession userSession;
    private Filter filter;

    public BusinessParam() {
    }

    public BusinessParam(UserSession userSession) {
        this.userSession = userSession;
    }

    public BusinessParam(UserSession userSession, Filter filter) {
        this.userSession = userSession;
        this.filter = filter;
    }

    public BusinessParam(BaseDB baseDB, UserSession userSession, Filter filter) {
        this.db = baseDB;
        this.userSession = userSession;
        this.filter = filter;
    }

    /**
     * Return an exist db or create one. When program get db and do some things then should releaseDB
     * @return
     * @throws Exception
     */
    public BaseDB getDB(long...expireSeconds) throws Exception{
    	if(db == null){
    		db = BaseDB.open("BusinessParam "+ getUserSession().getUserInfo().getUsername(),expireSeconds);
    		stackCount.set(0);
    	}
    	stackCount.incrementAndGet();
    	return db;
    }

    public void releaseDB() throws Exception{
    	if(stackCount.decrementAndGet() < 1){
    		Exception exception = null;
    		try {
				db.commitAndclose();
				db = null;
				return;
			} catch (Exception e) {
				exception = e;
				try{
					db.rollbackAndClose();
				}catch (Exception e2) {
					// TODO: handle exception
				}
			}    		
    		db = null;
    		throw exception;
    	}
    }

    public void rolback() {
		try{
			db.rollbackAndClose();
			db = null;
		}catch (Exception e2) {
		}
    }
    
    
    public UserSession getUserSession() {
        return userSession;
    }

    public void setUserSession(UserSession userSession) {
        this.userSession = userSession;
    }

    public Filter getFilter() {
        return filter;
    }

    public void setFilter(Filter filter) {
        this.filter = filter;
    }

	public static BusinessParam getSystemBusinessParam() {
		return new BusinessParam(UserSession.getSystemUserSession());
	}
	
	public static BusinessParam getSystemBusinessParam(BaseDB baseDB) {
		BusinessParam businessParam = new BusinessParam(baseDB, UserSession.getSystemUserSession(), null);
		businessParam.stackCount.addAndGet(1);//db used already once
		return businessParam;
	}
	
	public BusinessParam getUserSystemBusinessParam() {
		BusinessParam businessParam = new BusinessParam(db, UserSession.getSystemUserSession(), null);
		businessParam.stackCount = stackCount;
		return businessParam;
	}
	
	public static void main(String[] args) {
		AtomicLong i = new AtomicLong(3);
		System.out.println(i.getAndIncrement());
		System.out.println(i.longValue());
	}

}
