package org.mega.core.base;

import java.math.BigDecimal;

import javax.persistence.Query;
import javax.persistence.Table;

import org.apache.log4j.Logger;
import org.mega.core.SystemConfig;

/**
 * @author Golnari
 */
public class IDGenerator {
    static final String prefix = SystemConfig.ID_PREFIX;
    static Logger logger = BaseLogger.getLogger(IDGenerator.class);

    public static long genId(BaseEntity entity) throws Exception {
    	return genId(entity.getClass());
    }
    
    public static long genId(Class<?> entityClass) throws Exception {
    	return Long.parseLong(prefix + genIdWithoutPrifix(entityClass.getAnnotation(Table.class).name()));
    }

    public static long genIdWithoutPrifix(String tableName) throws Exception {
    	BaseDB db = null;
    	BigDecimal id;
    	try {
    		db = BaseDB.open("IDGenerator.genId");
    		
    		Query query = db.createNativeQuery("select id from core_seq where table_name='" + tableName + "' for update ");
    		try {
    			id = (BigDecimal) query.getSingleResult();
    			db.createNativeQuery("update core_seq set id = id + 1 where table_name='" + tableName + "'").executeUpdate();
    		} catch (Exception e) {
    			id = new BigDecimal(1);
    			db.createNativeQuery("insert into core_seq (id , table_name) values (1 , '" + tableName + "')").executeUpdate();
    		}
    		
    		db.commitAndclose();
    		return id.longValue();
    	} catch (Exception e) {
    		db.finalize();
    		throw new Exception("Error: ID generator for table " + tableName);
    	}
    }
    
    /**
     * Set id for class without prefix
     * @param clazz
     * @param newId
     * @return
     * @throws Exception
     */
    public static long setId(String tableName, long newId) throws Exception {
    	BaseDB db = null;
    	BigDecimal id;
    	try {
//    		String tableName = clazz.getAnnotation(Table.class).name();
    		db = BaseDB.open("IDGenerator.setId");
    		
    		Query query = db.createNativeQuery("select id from core_seq where table_name='" + tableName + "' for update ");
    		try {
    			id = (BigDecimal) query.getSingleResult();
    			db.createNativeQuery("update core_seq set id = " + newId + " where table_name='" + tableName + "'").executeUpdate();
    		} catch (Exception e) {
    			id = new BigDecimal(newId);
    			db.createNativeQuery("insert into core_seq (id , table_name) values (" + newId + " , '" + tableName + "')").executeUpdate();
    		}
    		
    		db.commitAndclose();
    		return newId;
    	} catch (Exception e) {
    		db.finalize();
    		throw new Exception("Error: ID generator for table " + tableName);
    	}
    }
}