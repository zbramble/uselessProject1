package org.mega.core.contact;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/contact")
public class ContactService {
    @POST
    @Path("/save")
    public ServiceResult save(ContactDTO contactDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(contactDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        return ContactFacade.getInstance().save(contactDTO, new BusinessParam(userSession));
    }

   

    @POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ContactFacade.getInstance().list(new BusinessParam(userSession, filter));
    }

    

    @POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ContactFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/userlist")
    public ServiceResult userList(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ContactFacade.getInstance().userList(new BusinessParam(userSession, filter));
    }
}