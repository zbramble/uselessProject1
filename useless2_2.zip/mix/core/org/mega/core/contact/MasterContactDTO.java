package org.mega.core.contact;

import java.util.List;

import org.mega.core.base.BaseDTO;

/**
 * Created by IT-13 on 4/30/2017.
 */
public class MasterContactDTO extends BaseDTO {
    List<ContactDTO> contact;
   

    public List<ContactDTO> getContact() {
        return contact;
    }

    public void setContact(List<ContactDTO> contact) {
        this.contact = contact;
    }

    @Override
    public Long getRowId() {
        return contact.get(0).getRowId();
    }
}
