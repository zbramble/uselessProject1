package org.mega.core.location;

import org.mega.bse.company.Company;
import org.mega.bse.company.CompanyDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class LocationDTO extends BaseDTO {
    private long rowId;
    private String name;
    private ComboValDTO type;
    private LocationDTO parent;
    //private List<LocationDTO> locations;
    private String accessKey;
	private CompanyDTO companyDTO;
	private String firstAddress;
	private String secondAddress;
   	private String country;
   	private String city;
   	private String postalCode;
	private ComboValDTO state;
    
    public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ComboValDTO getType() {
        return type;
    }

    public void setType(ComboValDTO type) {
        this.type = type;
    }

    public LocationDTO getParent() {
        return parent;
    }

    public void setParent(LocationDTO parent) {
        this.parent = parent;
    }

	public CompanyDTO getCompanyDTO() {
		return companyDTO;
	}

	public void setCompanyDTO(CompanyDTO companyDTO) {
		this.companyDTO = companyDTO;
	}

	public String getFirstAddress() {
		return firstAddress;
	}

	public void setFirstAddress(String firstAddress) {
		this.firstAddress = firstAddress;
	}

	public String getSecondAddress() {
		return secondAddress;
	}

	public void setSecondAddress(String secondAddress) {
		this.secondAddress = secondAddress;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public ComboValDTO getState() {
		return state;
	}

	public void setState(ComboValDTO state) {
		this.state = state;
	}

   /* public List<LocationDTO> getLocations() {
        return locations;
    }

    public void setLocations(List<LocationDTO> locations) {
        this.locations = locations;
    }*/
    
    
}
