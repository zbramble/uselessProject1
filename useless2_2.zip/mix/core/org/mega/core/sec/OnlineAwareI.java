package org.mega.core.sec;

public interface OnlineAwareI {
    void login(UserInfo userInfo);

    void logout(UserInfo userInfo);
}
