package org.mega.core.sec;

import java.util.Map;

import org.apache.log4j.Level;
import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseLogger;

public class UserSession {
	
	private UserInfo userInfo;
	private DataAccess dataAccess;//Access to data(not to action). Single access or hierarchical
	private static UserSession systemUserSession = null;

	public UserSession(UserInfo userInfo) {
		this.userInfo = userInfo;
		try {
			DataAccessCreatorI dataAccessCreator = (DataAccessCreatorI)Class.forName("org.mega.core.sec.DataAccessCreator").newInstance();
			this.dataAccess = dataAccessCreator.createDataAccess(userInfo);
		} catch (ClassNotFoundException e) {
			BaseLogger.getLogger(getClass()).log(Level.ALL,	"\r\n**********************************************\r\n Class org.mega.core.sec.DataAccessCreator didnt properly define in app project. This class must not define in core.\r\n**********************************************\r\n");
		} catch (Exception e) {
			BaseLogger.getLogger(getClass()).log(Level.ALL, "Error in create UserSession", e);			
			System.exit(1);
		}
	}
	
	/**
	 * Has user access to this action of usecase
	 * @param usercase
	 * @param actionId
	 * @return
	 */
	public boolean hasAccess(String usercase, int actionId) {
		if(dontCheckAccess())
			return true;
	  Integer act = userInfo.getAccess().get(usercase);
	  return act != null && (act | (int)Math.pow(2, actionId)) == act;
	}		  	

	public void checkAccess(String entityPoorName, ACTION action) throws Exception{
		if(!hasAccess(entityPoorName, action.ordinal()))
			throw new Exception("Access denied:" + entityPoorName + ':' + action);
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public Map<String, Integer> getPermision() {
		return userInfo.getAccess();
	}

	public static UserSession getSystemUserSession() {
		if(systemUserSession != null)
			return systemUserSession;
		UserInfo systemUser = new UserInfo();
		systemUser.setUserId(SystemConfig.SYSTEM_USER_ID);
		systemUser.setRoleId(SystemConfig.SYSTEM_ROLE_ID);
		systemUser.setAccessKey("");
		systemUser.setFullName("system");;
		systemUser.setCompanyName("system");
		systemUser.setActive(true);
		systemUser.setUsername("system");
		systemUser.setRoleName("system");
		systemUser.setOrgId(SystemConfig.ORGANOZATION_ROOT_ID);
		systemUserSession = new UserSession(systemUser);
		return systemUserSession;
	}
	public boolean dontCheckAccess() {
		return !SystemConfig.CHECK_ACCESSES || userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID || userInfo.getRoleId() == SystemConfig.SYSTEM_ROLE_ID;
	}
}
