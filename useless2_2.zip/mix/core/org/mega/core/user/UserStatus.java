package org.mega.core.user;

public enum UserStatus {
    ONLINE("Online"),
    OFFLINE("Offline"),
    BUSY("Busy");

    private String value;

    UserStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}