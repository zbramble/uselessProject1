package org.mega.core.usecaseaction;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class UseCaseActionFacade extends BaseFacade {
    private static UseCaseActionCopier copier = new UseCaseActionCopier();
    private static UseCaseActionFacade facade = new UseCaseActionFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static UseCaseActionFacade getInstance() {
        return facade;
    }
}