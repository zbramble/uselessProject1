package org.mega.core.usecaseaction;

import org.mega.core.accessgrp.AccessGrpFacade;
import org.mega.core.action.Action;
import org.mega.core.action.ActionDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.usecase.UseCase;
import org.mega.core.usecase.UseCaseDTO;

public class UseCaseActionCopier extends BaseCopier<UseCaseAction, UseCaseActionDTO> {

    @Override
    public UseCaseActionDTO copyFromEntity(UseCaseAction useCaseAction) {
        UseCaseActionDTO useCaseActionDTO = new UseCaseActionDTO();

        useCaseActionDTO.setRowId(useCaseAction.getRowId());
        useCaseActionDTO.setCode(useCaseAction.getCode());
        if (useCaseAction.getAction() != null) {
            ActionDTO actionDTO = new ActionDTO();
            actionDTO.setRowId(useCaseAction.getAction().getRowId());
            useCaseActionDTO.setAction(actionDTO);
        }
        if (useCaseAction.getUseCase() != null) {
            UseCaseDTO useCaseDTO = new UseCaseDTO();
            useCaseDTO.setRowId(useCaseAction.getUseCase().getRowId());
            useCaseActionDTO.setUseCase(useCaseDTO);
        }
        // in bakhsh ra niyaze nadarim
       /* if (UseCaseAction.getAccessGrps() != null) {
            UseCaseActionDTO.setAccessGrps(
                    AccessGrpFacade.getInstance().getCopier().copyFromEntity(UseCaseAction.getAccessGrps()));
        }*/
        copyFromEntityBaseField(useCaseAction, useCaseActionDTO);

        return useCaseActionDTO;
    }

    @Override
    public UseCaseAction copyToEntity(UseCaseActionDTO useCaseActionDTO) throws Exception {
        UseCaseAction useCaseAction = new UseCaseAction();

        useCaseAction.setRowId(useCaseActionDTO.getRowId());
        useCaseAction.setCode(useCaseActionDTO.getCode());
        if (useCaseActionDTO.getAction() != null) {
            Action action = new Action();
            action.setRowId(useCaseActionDTO.getAction().getRowId());
            useCaseAction.setAction(action);
        }
        if (useCaseActionDTO.getUseCase() != null) {
            UseCase useCase = new UseCase();
            useCase.setRowId(useCaseActionDTO.getUseCase().getRowId());
            useCaseAction.setUseCase(useCase);
        }
        if (useCaseActionDTO.getAccessGrps() != null) {
            useCaseAction.setAccessGrps(
                    AccessGrpFacade.getInstance().getCopier().copyToEntity(useCaseActionDTO.getAccessGrps()));
        }
        copyToEntityBaseField(useCaseAction, useCaseActionDTO);

        return useCaseAction;
    }
}