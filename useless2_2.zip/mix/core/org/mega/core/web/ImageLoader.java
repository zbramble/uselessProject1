package org.mega.core.web;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.file.File;
import org.mega.core.file.FileFacade;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;
import org.mega.util.IOUtil;
import org.mega.util.ImageUtil;

/**
 * Servlet implementation class ImageLoader
 */
public class ImageLoader extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ImageLoader() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("image/jpeg");
        OutputStream o = response.getOutputStream();
        o.write(IOUtil.readAndCloseStream(request.getSession().getServletContext().getResourceAsStream("/core/img/default-profile/profile-user.jpg")));
        o.flush();
        o.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        OutputStream o = response.getOutputStream();
        response.setContentType("image/jpeg");
        try {
            String fileId = request.getParameter("fileId");
            String ticket = request.getParameter("ticket");
            UserSession userSession = UserSessionManager.getUserSession(ticket);
            userSession.checkAccess("ImageLoader", ACTION.view);

            String boundWidth = request.getParameter("boundWidth");
            String boundHeight = request.getParameter("boundHeight");
            
            File fileEntity = FileFacade.getInstance().findEntityById(File.class, Long.parseLong(fileId), BusinessParam.getSystemBusinessParam());
            byte[] file = IOUtil.readFromFile(new java.io.File(SystemConfig.UPLAUD_FOLDER + java.io.File.separator + fileEntity.getPath()));

            if (boundWidth != null && boundHeight != null) {
                file = ImageUtil.resizeToBound(file, Integer.parseInt(boundWidth), Integer.parseInt(boundHeight));
            }

            o.write(file);
            o.flush();
            o.close();
        } catch (Exception e) {
            byte[] defaultImage = IOUtil.readAndCloseStream(request.getSession().getServletContext().getResourceAsStream("/core/img/default-profile/profile-user.jpg"));
            if (defaultImage != null)
                o.write(defaultImage);
            o.flush();
            o.close();
            BaseLogger.getLogger(this.getClass()).log(Level.INFO, "Error in loading image " + e.getLocalizedMessage());
        }
    }

}
