package org.mega.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Level;
import org.mega.core.base.BaseLogger;

public class IOUtil {
    public static final String ENCODING_UTF_8 = "utf-8";
    public static final String ENCODING_UTF_16 = "UTF-16";
    public static final String ENCODING_ISO = "ISO-8859-1";
    public static final String ENCODING_ANSII = "US-ASCII";
    public static final String ENCODING_NOTHINGS = "NOTHINGS";

    public static boolean writeToFile(String fileName, String content, String encode) {
        try {
            if (encode.toLowerCase().equals("utf-8"))
                content = "\uFEFF" + content.replaceAll("﻿", "").replaceAll("\uFEFF", "");
            File file = new File(fileName);
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter writer;
            if (encode.equals(ENCODING_NOTHINGS))
                writer = new OutputStreamWriter(fos);
            else {
                encode = encode == null ? ENCODING_UTF_8 : encode;
                writer = new OutputStreamWriter(fos, encode);
            }
            writer.write(content);
            writer.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static String readFromFile(String fileName, String encode) {
        StringBuffer ret = new StringBuffer();
        try {
            File file = new File(fileName);
            FileInputStream fii = new FileInputStream(file);
            encode = encode == null ? ENCODING_UTF_8 : encode;
            InputStreamReader r = new InputStreamReader(fii, encode);
            char buf[] = new char[1000];
            int len = r.read(buf);
            while (len > -1) {
                ret.append(new String(buf, 0, len));
                len = r.read(buf);
            }
            r.close();
            fii.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return ret.toString();
    }

    public static void writeToFile(File file, byte[] content) throws IOException {
        FileOutputStream out = new FileOutputStream(file);
        out.write(content);
        out.close();
    }

    public static byte[] readFromFile(File file) throws IOException {
        try {
            return readAndCloseStream(new FileInputStream(file));
        } catch (Exception e) {
            return null;
        }
    }

    public static byte[] readAndCloseStream(InputStream in) {
        try {
            byte[] buf = new byte[2048];
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            int numRead = 0;
            while ((numRead = in.read(buf)) > -1) {
                bytes.write(buf, 0, numRead);
            }
            in.close();
            bytes.flush();
            byte[] ret = bytes.toByteArray();
            bytes.close();
            return ret;
        } catch (Exception e) {
            BaseLogger.getLogger(IOUtil.class).log(Level.INFO, "Error in readAndCloseStream" + e.getLocalizedMessage());
            return null;
        }
    }

    public static String align(String num, int len, char filler) {
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < len - num.length(); i++) {
            buf.append(filler);
        }
        buf.append(num);
        return buf.toString();
    }

    public static String readAndCloseStream(InputStream in, String encoding) {
        String ret = null;
        try {
            ret = encoding == null ? new String(IOUtil.readAndCloseStream(in)) : new String(IOUtil.readAndCloseStream(in), encoding);
            in.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ret;
    }


    /**
     * Extract ZIP file into specified folder
     *
     * @param layoutTempZipFileName
     * @param targetFolder
     * @throws IOException
     */
    public static void extract(String layoutTempZipFileName, String targetFolder) throws IOException {
        ZipFile zip = new ZipFile(layoutTempZipFileName);
        Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            ZipEntry element = entries.nextElement();
            File f = new File(targetFolder + "/" + element.getName());
            if (element.isDirectory()) {
                f.mkdirs();
            } else {
                FileOutputStream outputStream = new FileOutputStream(f);
                IOUtils.copy(zip.getInputStream(element), outputStream);
                IOUtils.closeQuietly(outputStream);
            }
        }
    }

    public static void writeToFile(InputStream inputStream, String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.getParentFile().exists())
            file.getParentFile().mkdirs();
        writeToFile(file, readAndCloseStream(inputStream));
    }
}
