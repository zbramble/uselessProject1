package org.mega.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.mega.core.SystemConfig;

public class ExpireCache implements Runnable {
    private String cachName = "Expire Cache";
    private ConcurrentHashMap<String, TimedObject> cache = new ConcurrentHashMap<String, TimedObject>(50);
    private long defaultExpireTimeSecond = SystemConfig.EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS;// second
    private long maxSize = SystemConfig.EXPIRE_CACHE_MAX_SIZE;// Max number of cache elements. If be 0 dont check.
    private List<ExpireCacheRemoveAware> cacheRemoveAwares;

    /**
     * @param cacheName
     * @param defaultExpireTimeSecond 0 for unlimit
     * @param removeAwares
     */
    public static ExpireCache getInstance(String cacheName, long defaultExpireTimeSecond, ExpireCacheRemoveAware... removeAwares) {
        ExpireCache expireCache = new ExpireCache();
        expireCache.defaultExpireTimeSecond = defaultExpireTimeSecond;
        expireCache.cachName = "Expire Cache: " + cacheName;
        if (defaultExpireTimeSecond > 0) {
            new Thread(expireCache, expireCache.cachName).start();
            expireCache.cacheRemoveAwares = new ArrayList<>(Arrays.asList(removeAwares));
        }
        return expireCache;
    }

    public List<ExpireCacheRemoveAware> getCacheAwares() {
        return cacheRemoveAwares;
    }

    public void setCacheAware(List<ExpireCacheRemoveAware> cacheAutoRemoveAwares) {
        this.cacheRemoveAwares = cacheAutoRemoveAwares;
    }

    public void addCacheAware(ExpireCacheRemoveAware cacheAutoRemoveAwares) {
        this.cacheRemoveAwares.add(cacheAutoRemoveAwares);
    }

    public Object get(String name) {
        if (name == null) {
            return null;
        }

        TimedObject val = cache.get(name);
        if (val == null)
            return null;
        val.setTime(System.currentTimeMillis());
        return val.getObj();

    }

    public long getRefreshTime(String name) {
        if (name == null)
            return -1;

        TimedObject val = cache.get(name);
        return val.getTime();

    }

    /**
     * return 0 if val is null
     *
     * @param name
     * @return
     */
    public int getInt(String name) {
        Object val = get(name);
        return val == null ? 0 : (Integer) val;
    }

    public Object removeWithoutCallAwares(String name) {
        TimedObject removedTimedObj = cache.remove(name);
        Object removedObj = removedTimedObj == null ? null : removedTimedObj.getObj();
        return removedObj;
    }

    public Object removeAndCallAwares(String name) {
        TimedObject removedTimedObj = cache.remove(name);
        Object removedObj = removedTimedObj == null ? null : removedTimedObj.getObj();
        if (removedObj != null && cacheRemoveAwares != null) {
            for (ExpireCacheRemoveAware aware : cacheRemoveAwares) {
                aware.removed(name, removedObj);
            }
        }
        return removedObj;
    }

    /**
     * If cache is full remove first element and call remove aware
     *
     * @param name
     * @param value
     * @return old value if exists
     */
    public void put(String name, Object value, long... expireTimeSecond) {
        if (maxSize > 0 && cache.size() >= maxSize) {
            removeAndCallAwares(cache.keys().nextElement());
        }
        cache.put(name, new TimedObject(value, expireTimeSecond));
    }

    public int size() {
        return cache.size();
    }

    private class TimedObject {
        Object obj;
        long time;
        long expireTimeSecond;

        public TimedObject(Object obj, long... expireTimeSecond) {
            this.obj = obj;
            this.time = System.currentTimeMillis();
            this.expireTimeSecond = expireTimeSecond.length > 0 ? expireTimeSecond[0] : defaultExpireTimeSecond;
        }

        public Object getObj() {
            return obj;
        }

        public void setObj(Object obj) {
            this.obj = obj;
        }

        public long getTime() {
            return time;
        }

        public void setTime(long time) {
            this.time = time;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public void run() {
        while (true) {
            // 0.1 of expireTimeSecond system delay for check expires
            try {
                Thread.sleep(this.defaultExpireTimeSecond * 100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            long current = System.currentTimeMillis();
            for (Iterator iterator = cache.entrySet().iterator(); iterator.hasNext(); ) {
                Entry entry = (Entry) iterator.next();
                TimedObject to = (TimedObject) entry.getValue();
                if (to.getTime() + to.expireTimeSecond * 1000 < current) {
                    removeAndCallAwares((String) entry.getKey());
                }
            }
        }
    }

    public long getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(long maxSize) {
        this.maxSize = maxSize;
    }

    public String getCachName() {
        return cachName;
    }

    public void setCachName(String cachName) {
        this.cachName = cachName;
    }

    /**
     * Ø­Ø°Ù� ØªÙ…Ø§Ù… Ù…Ù‚Ø§Ø¯ÙŠØ± Ú©Ø´ Ø´Ø¯Ù‡
     */
    public void clear() {
        cache.clear();
    }
}
