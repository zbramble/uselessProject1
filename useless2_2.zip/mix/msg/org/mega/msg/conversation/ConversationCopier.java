package org.mega.msg.conversation;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.msg.conversationroom.ConversationRoom;
import org.mega.msg.conversationroom.ConversationRoomDTO;

public class ConversationCopier extends BaseCopier<Conversation, ConversationDTO> {
    @Override
    public ConversationDTO copyFromEntity(Conversation conversation) {
        ConversationDTO conversationDTO = new ConversationDTO();

        conversationDTO.setRowId(conversation.getRowId());
        if (conversation.getConversationRoom() != null) {
            ConversationRoomDTO conversationRoomDTO = new ConversationRoomDTO();
            conversationRoomDTO.setRowId(conversation.getConversationRoom().getRowId());
            conversationRoomDTO.setName(conversation.getConversationRoom().getName());
            conversationDTO.setConversationRoom(conversationRoomDTO);
        }
        conversationDTO.setText(conversation.getText());
        if (conversation.getAttache() != null) {
            FileDTO fileDTO = new FileDTO();
            fileDTO.setRowId(conversation.getAttache().getRowId());
            fileDTO.setFullTitle(conversation.getAttache().getFullTitle());
            conversationDTO.setAttache(fileDTO);
        }
        conversationDTO.setAmountLikes(conversation.getAmountLikes());
        conversationDTO.setOpinion(conversation.getOpinion());
        if (conversation.getStatus() != null) {
            ComboValDTO comboValDTO = new ComboValDTO();
            comboValDTO.setRowId(conversation.getStatus().getRowId());
            comboValDTO.setName(conversation.getStatus().getName());
            conversationDTO.setStatus(comboValDTO);
        }
        copyFromEntityBaseField(conversation, conversationDTO);
        if (conversation.getCreatedBy().getFile() != null) {
            FileDTO img = new FileDTO();
            img.setImageContent(conversation.getCreatedBy().getFile().getImageContent());
            conversationDTO.getCreatedBy().setFile(img);
        }

        return conversationDTO;
    }

    @Override
    public Conversation copyToEntity(ConversationDTO conversationDTO) throws Exception {
        Conversation conversation = new Conversation();

        conversation.setRowId(conversationDTO.getRowId());
        if (conversationDTO.getConversationRoom() != null) {
            ConversationRoom conversationRoom = new ConversationRoom();
            conversationRoom.setRowId(conversationDTO.getConversationRoom().getRowId());
            conversation.setConversationRoom(conversationRoom);
        }
        conversation.setText(conversationDTO.getText());
        if (conversationDTO.getAttache() != null) {
            File file = new File();
            file.setRowId(conversationDTO.getAttache().getRowId());
            conversation.setAttache(file);
        }
        conversation.setAmountLikes(conversationDTO.getAmountLikes());
        conversation.setOpinion(conversationDTO.getOpinion());
        if (conversationDTO.getStatus() != null) {
            ComboVal comboVal = new ComboVal();
            comboVal.setRowId(conversationDTO.getStatus().getRowId());
            conversation.setStatus(comboVal);
        }
        copyToEntityBaseField(conversation, conversationDTO);

        return conversation;
    }
}