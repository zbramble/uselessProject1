package org.mega.msg.supporter;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.user.User;

import javax.persistence.*;

@Entity
@Table(name = "MSG_SUPPORTER", uniqueConstraints = @UniqueConstraint(name = "PK_HLP_SUPPORTER", columnNames = "ID"))
public class Supporter extends BaseEntity {

    @Id
    @Column(name = "ID", nullable = false)
    private long rowId;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "USER_ID", foreignKey = @ForeignKey(name = "FK_SUPR_2_USER"))
    private User user;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "TYPE", foreignKey = @ForeignKey(name = "FK_SUPR_TYPE_2_CMVL"))
    private ComboVal type;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ComboVal getType() {
        return type;
    }

    public void setType(ComboVal type) {
        this.type = type;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
    }

	@Override
	public void preUpdate() throws Exception {
		// TODO Auto-generated method stub
		
	}
}