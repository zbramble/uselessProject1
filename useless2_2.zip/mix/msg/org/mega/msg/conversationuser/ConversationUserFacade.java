package org.mega.msg.conversationuser;

import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.user.UserStatus;
import org.mega.msg.conversation.Conversation;
import org.mega.msg.sse.Notification;
import org.mega.msg.sse.NotificationHandler;
import org.mega.msg.sse.NotificationType;

public class ConversationUserFacade extends BaseFacade {
    private static ConversationUserCopier copier = new ConversationUserCopier();
    private static ConversationUserFacade facade = new ConversationUserFacade();

    @Override
    public ConversationUserCopier getCopier() {
        return copier;
    }

    public static ConversationUserFacade getInstance() {
        return facade;
    }

    public List<ConversationUser> findByConversationRoomId(long conversationRoomId
            , BusinessParam businessParam) throws Exception {

        try {
            Query query = businessParam.getDB().createQuery("SELECT T FROM ConversationUser T " +
                    "WHERE T.conversationRoom.rowId =:conversationRoomId");
            query.setParameter("conversationRoomId", conversationRoomId);
            List<ConversationUser> conversationUsersList = query.getResultList();
            businessParam.releaseDB();
            return conversationUsersList;
        } catch (Exception e) {
            businessParam.rolback();
            throw new Exception("Error find entity " + ConversationUser.class.getName(), e);
        }
    }

    public ConversationUser findByConversationRoomIdAndUserId(
            long conversationRoomId, long userRowId, BusinessParam businessParam) throws Exception {

        try {
            Query query = businessParam.getDB().createQuery("SELECT T FROM ConversationUser T " +
                    "WHERE T.user.rowId =:userRowId " +
                    "AND T.conversationRoom.rowId = :conversationRoomId ");
            query.setParameter("userRowId", userRowId);
            query.setParameter("conversationRoomId", conversationRoomId);
            ConversationUser conversationUser = (ConversationUser) query.getSingleResult();
            businessParam.releaseDB();
            return conversationUser;
        } catch (Exception e) {
            businessParam.rolback();
            throw e;
        }
    }

    public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
        ServiceResult serviceResult = super.save(baseDTO, businessParam);

        if (serviceResult.isDone()) {
            long conversationRoomId = ((ConversationUserDTO) baseDTO).getConversationRoom().getRowId();

            try {
                List<ConversationUser> conversationUsers =
                        ConversationUserFacade.getInstance().findByConversationRoomId(conversationRoomId, businessParam);

                Notification notification = new Notification(conversationRoomId, 1
                        , NotificationType.ADD_USER_TO_CONVERSATION_ROOM
                        , serviceResult.getResult().toString());

                for (ConversationUser conversationUser : conversationUsers) {
                    // Send Notification for all user.
                    NotificationHandler.updateRoom("USER-" + conversationUser.getUser().getRowId(), notification);
                    NotificationHandler.updateRoom("APP-" + conversationUser.getUser().getRowId(), notification);
                }
            } catch (Exception e) {
                return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL
                        , "Error saving " + Conversation.class.getSimpleName(), e);
            }
        }
        return serviceResult;
    }

    public void update(BaseEntity baseEntity, BusinessParam businessParam) throws Exception {
        super.saveEntity(baseEntity, businessParam);
    }

    public void broadcastUserStatus(long userId, UserStatus status) {

        BusinessParam businessParam = BusinessParam.getSystemBusinessParam();
        Notification notification = new Notification(userId, 1, NotificationType.USER_STATUS, status);

        try {
            Query query = businessParam.getDB().createQuery(
                    "SELECT distinct e.user.rowId " +
                            "  FROM ConversationUser e " +
                            "  JOIN ConversationUser e1" +
                            "    on e.conversationRoom.rowId = e1.conversationRoom.rowId " +
                            " WHERE e1.user.rowId = :userId " +
                            " AND e.active = TRUE " +
                            " AND e.deleted = 0 " +
                            " AND e1.active = TRUE " +
                            " AND e1.deleted = 0 ");

            query.setParameter("userId", userId);
            List<Long> users = query.getResultList();
            businessParam.releaseDB();
            for (Long id : users) {
                NotificationHandler.updateRoom("USER-" + id, notification);
            }
        } catch (Exception e) {
            businessParam.rolback();
        }
    }
}