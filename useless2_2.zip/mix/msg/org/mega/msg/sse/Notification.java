package org.mega.msg.sse;

import java.util.List;

public class Notification {
    long id;
    int count;
    NotificationType type;
    String time;
    Object content;
    List<NotificationContent> contents;

    public Notification() {
    }

    public Notification(long id, int count, NotificationType type) {
        this.id = id;
        this.count = count;
        this.type = type;
    }

    public Notification(long id, int count, NotificationType type, Object content) {
        this.id = id;
        this.count = count;
        this.type = type;
        this.content = content;
    }

    public Notification(long id, int count, NotificationType type, Object content, List<NotificationContent> contents) {
        this.id = id;
        this.count = count;
        this.type = type;
        this.content = content;
        this.contents = contents;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public NotificationType getType() {
        return type;
    }

    public void setType(NotificationType type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public List<NotificationContent> getContents() {
        return contents;
    }

    public void setContents(List<NotificationContent> contents) {
        this.contents = contents;
    }
}