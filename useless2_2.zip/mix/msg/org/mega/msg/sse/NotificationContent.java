package org.mega.msg.sse;

public class NotificationContent {
    long conversationRoomId;
    private String text;
    private String link;

    public NotificationContent() {
    }

    public NotificationContent(long conversationRoomId, String text, String link) {
        this.conversationRoomId = conversationRoomId;
        this.text = text;
        this.link = link;
    }

    public long getConversationRoomId() {
        return conversationRoomId;
    }

    public void setConversationRoomId(long conversationRoomId) {
        this.conversationRoomId = conversationRoomId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}