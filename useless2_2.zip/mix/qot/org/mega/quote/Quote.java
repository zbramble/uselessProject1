package org.mega.quote;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.location.Location;
import org.mega.qot.quotrequest.QuotRequest;
import org.mega.quoteitem.QuoteItem;

@Entity
@Table(name = "QOT_QOUTE", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_QOUTE", columnNames = "QUOTE_ID"))
public class Quote extends BaseEntity{
	@Id
	@Column(name = "QUOTE_ID")
	private long rowId;
	
	@ManyToOne()
	@JoinColumn(name = "QOUTE_REQUEST_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_REFERENCE_QOT_QOUT"), nullable = true)
	private QuotRequest qouteRequest;
	
	@ManyToOne()
	@JoinColumn(name = "FREIGHT_METHOD_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_METHOD_TYPE_COMBO"), nullable = true)
	private ComboVal freightMethod;
	
	@ManyToOne()
	@JoinColumn(name = "FREIGHT_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_FREIGHT_TYPE"), nullable = true)
	private ComboVal freightType;
	
	@ManyToOne()
	@JoinColumn(name = "DEPARTURE_LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_LOCATION_CO_LOCAT"), nullable = true)
	private Location departureLocation;
	
	@ManyToOne()
	@JoinColumn(name = "ARRIVAL_LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_ARRIVAL_CO_LOCAT"), nullable = true)
	private Location arrivalLocation;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "QUOTE_STATUS_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QUOTE_STATUS_COMBO"), nullable = true)
	private ComboVal quoteStatusType;
	
	@Column(name="QUOTE_REFERENCE_ID",length=100)
	private String quoteReference;
	
	@Column(name="CARRIER_NAME",length=300)
	private String carrierName;
	
	@Column(name="TRANSIT_TIME_DAYS",length=100)
	private String transitTimeDays;
	
	@Column(name="CLOSING_DAYS",length=100)
	private String closingDays;
	
	@Column(name="DEPARTURE_DAYS",length=100)
	private String departureDays;
	
	@Column(name="ORIGION_ADDRESS",length=2000)
	private String origionAddress;
	
	@Column(name="DESTINATION_ADDRESS",length=2000)
	private String destinationAddress;
	
	@Column(name="ESTIMATED_CO2_EMISSSIONS",length=500)
	private String estimatedEmisssions;
	
	@Column(name="NOTE",length=500)
	private String note;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PAY_MENTS_ID", foreignKey = @ForeignKey(name = "FK_QUOTE_PAY_MENTS_COMBO"), nullable = true)
	private ComboVal payMents;
	
	@Column(name="TOTAL")
	private double total;
	
	@Column(name="DISCOUNT_AMOUNT")
	private double discountAmount;
	
	@Column(name="DISCOUNT_PERCENTAGE")
	private double discountPercentage;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "QUOTE_DATE")
	private Date quoteDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "EXPIRATION_DATE")
	private Date expirationDate;

	@OneToMany(mappedBy = "quote")
	private List<QuoteItem> quoteItems;
	
	public List<QuoteItem> getQuoteItems() {
		return quoteItems;
	}
	
	public void setQuoteItems(List<QuoteItem> quoteItems) {
		this.quoteItems = quoteItems;
	}
	
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public ComboVal getPayMents() {
		return payMents;
	}

	public void setPayMents(ComboVal payMents) {
		this.payMents = payMents;
	}

	public ComboVal getQuoteStatusType() {
		return quoteStatusType;
	}

	public void setQuoteStatusType(ComboVal quoteStatusType) {
		this.quoteStatusType = quoteStatusType;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public QuotRequest getQouteRequest() {
		return qouteRequest;
	}

	public void setQouteRequest(QuotRequest qouteRequest) {
		this.qouteRequest = qouteRequest;
	}

	public ComboVal getFreightMethod() {
		return freightMethod;
	}

	public void setFreightMethod(ComboVal freightMethod) {
		this.freightMethod = freightMethod;
	}

	public ComboVal getFreightType() {
		return freightType;
	}

	public void setFreightType(ComboVal freightType) {
		this.freightType = freightType;
	}

	public Location getDepartureLocation() {
		return departureLocation;
	}

	public void setDepartureLocation(Location departureLocation) {
		this.departureLocation = departureLocation;
	}

	public Location getArrivalLocation() {
		return arrivalLocation;
	}

	public void setArrivalLocation(Location arrivalLocation) {
		this.arrivalLocation = arrivalLocation;
	}

	public String getQuoteReference() {
		return quoteReference;
	}

	public void setQuoteReference(String quoteReference) {
		this.quoteReference = quoteReference;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getTransitTimeDays() {
		return transitTimeDays;
	}

	public void setTransitTimeDays(String transitTimeDays) {
		this.transitTimeDays = transitTimeDays;
	}

	public String getClosingDays() {
		return closingDays;
	}

	public void setClosingDays(String closingDays) {
		this.closingDays = closingDays;
	}

	public String getDepartureDays() {
		return departureDays;
	}

	public void setDepartureDays(String departureDays) {
		this.departureDays = departureDays;
	}

	public String getOrigionAddress() {
		return origionAddress;
	}

	public void setOrigionAddress(String origionAddress) {
		this.origionAddress = origionAddress;
	}

	public String getDestinationAddress() {
		return destinationAddress;
	}

	public void setDestinationAddress(String destinationAddress) {
		this.destinationAddress = destinationAddress;
	}

	public String getEstimatedEmisssions() {
		return estimatedEmisssions;
	}

	public void setEstimatedEmisssions(String estimatedEmisssions) {
		this.estimatedEmisssions = estimatedEmisssions;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	public Date getQuoteDate() {
		return quoteDate;
	}

	public void setQuoteDate(Date quoteDate) {
		this.quoteDate = quoteDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = qouteRequest.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = qouteRequest.getFullTitle();
	}


}
