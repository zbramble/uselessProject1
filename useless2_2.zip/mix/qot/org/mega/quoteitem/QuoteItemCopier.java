package org.mega.quoteitem;

import org.mega.bse.freightchargeclassifi.FreightChargeClassificatDTO;
import org.mega.bse.freightchargetype.FreightChargeType;
import org.mega.bse.freightchargetype.FreightChargeTypeDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotrequest.QuotRequestDTO;
import org.mega.quote.Quote;
import org.mega.quote.QuoteDTO;
import org.mega.util.DateUtil;

public class QuoteItemCopier extends BaseCopier<QuoteItem, QuoteItemDTO>{

	@Override
	public QuoteItemDTO copyFromEntity(QuoteItem quoteItem) {
		QuoteItemDTO quoteItemDTO = new QuoteItemDTO();
		quoteItemDTO.setRowId(quoteItem.getRowId());
		if(quoteItem.getFreightChargeType() != null){
			FreightChargeTypeDTO freightChargeTypeDTO = new FreightChargeTypeDTO();
			freightChargeTypeDTO.setRowId(quoteItem.getFreightChargeType().getRowId());
			if(quoteItem.getFreightChargeType().getClassificat() != null){
				FreightChargeClassificatDTO c = new FreightChargeClassificatDTO();
				c.setRowId(quoteItem.getFreightChargeType().getClassificat().getRowId());
				c.setClassificationTitle(quoteItem.getFreightChargeType().getClassificat().getClassificationTitle());
				freightChargeTypeDTO.setClassificatDTO(c);
			}
			freightChargeTypeDTO.setChargeTypeTitle(quoteItem.getFreightChargeType().getChargeTypeTitle());
			quoteItemDTO.setFreightChargeTypeDTO(freightChargeTypeDTO);
		}
		if(quoteItem.getQuote() != null){
			QuoteDTO quoteDTO = new QuoteDTO();
			quoteDTO.setRowId(quoteItem.getQuote().getRowId());
			//quoteDTO.setCarrierName(quoteItem.getQuote().getCarrierName());
			quoteDTO.setFullTitle(quoteItem.getQuote().getFullTitle());
			quoteDTO.setNote(quoteItem.getQuote().getNote());
			quoteDTO.setExpirationDate(DateUtil.getDateString(quoteItem.getQuote().getExpirationDate(),"en"));
			if(quoteItem.getQuote().getPayMents() != null){
				ComboValDTO c = new ComboValDTO();
				c.setRowId(quoteItem.getQuote().getPayMents().getRowId());
				c.setName(quoteItem.getQuote().getPayMents().getName());
				quoteDTO.setPayMents(c);
			}
			if(quoteItem.getQuote().getQouteRequest() != null){
				QuotRequestDTO q = new QuotRequestDTO();
				q.setRowId(quoteItem.getQuote().getQouteRequest().getRowId());
				q.setShipmentName(quoteItem.getQuote().getQouteRequest().getShipmentName());
				quoteDTO.setQouteRequestDTO(q);
			}
			if(quoteItem.getQuote().getCreatedBy() != null){
				UserDTO u = new UserDTO();
				u.setRowId(quoteItem.getQuote().getCreatedBy().getRowId());
				u.setCompanyName(quoteItem.getQuote().getCreatedBy().getCompanyName());
				u.setFullName(quoteItem.getQuote().getCreatedBy().getFullName());
				u.setEmail(quoteItem.getQuote().getCreatedBy().getEmail());
				if(quoteItem.getQuote().getCreatedBy().getFile() != null){
					FileDTO f = new FileDTO();
					f.setRowId(quoteItem.getQuote().getCreatedBy().getFile().getRowId());
					 f.setPath(quoteItem.getQuote().getCreatedBy().getFile().getPath());
					f.setImageContent(quoteItem.getQuote().getCreatedBy().getFile().getImageContent());
					u.setFile(f);
				}
				quoteDTO.setCreatedBy(u);
			}
			quoteItemDTO.setQuoteDTO(quoteDTO);
		}
		quoteItemDTO.setQuantity(quoteItem.getQuantity());
		quoteItemDTO.setSellPrice(quoteItem.getSellPrice());
		quoteItemDTO.setBuyPrice(quoteItem.getBuyPrice());
		quoteItemDTO.setLegFrom(quoteItem.getLegFrom());
		quoteItemDTO.setLegTo(quoteItem.getLegTo());
		quoteItemDTO.setFuel(quoteItem.getFuel());
		quoteItemDTO.setPeakSeason(quoteItem.getPeakSeason());
		quoteItemDTO.setTax1(quoteItem.getTax1());
		quoteItemDTO.setTax2(quoteItem.getTax2());
		copyFromEntityBaseField(quoteItem, quoteItemDTO);
		return quoteItemDTO;
	}

	@Override
	public QuoteItem copyToEntity(QuoteItemDTO quoteItemDTO) throws Exception {
		QuoteItem quoteItem = new QuoteItem();
		quoteItem.setRowId(quoteItemDTO.getRowId());
		if(quoteItemDTO.getFreightChargeTypeDTO() != null){
			FreightChargeType freightChargeType = new FreightChargeType();
			freightChargeType.setRowId(quoteItemDTO.getFreightChargeTypeDTO().getRowId());
			freightChargeType.setChargeTypeTitle(quoteItemDTO.getFreightChargeTypeDTO().getChargeTypeTitle());
			quoteItem.setFreightChargeType(freightChargeType);
		}
		if(quoteItemDTO.getQuoteDTO() != null){
			Quote quote = new Quote();
			quote.setRowId(quoteItemDTO.getQuoteDTO().getRowId());
			//quote.setCarrierName(quoteItemDTO.getQuoteDTO().getCarrierName());
			quote.setFullTitle(quoteItemDTO.getQuoteDTO().getFullTitle());
			quoteItem.setQuote(quote);
		}
		quoteItem.setQuantity(quoteItemDTO.getQuantity());
		quoteItem.setSellPrice(quoteItemDTO.getSellPrice());
		quoteItem.setBuyPrice(quoteItemDTO.getBuyPrice());
		quoteItem.setLegFrom(quoteItemDTO.getLegFrom());
		quoteItem.setLegTo(quoteItemDTO.getLegTo());
		quoteItem.setPeakSeason(quoteItemDTO.getPeakSeason());
		quoteItem.setFuel(quoteItemDTO.getFuel());
		quoteItem.setTax1(quoteItemDTO.getTax1());
		quoteItem.setTax2(quoteItemDTO.getTax2());
		copyToEntityBaseField(quoteItem, quoteItemDTO);
		return quoteItem;
	}

}
