package org.mega.quoteitem;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class QuoteItemFacade extends BaseFacade{
	private static QuoteItemCopier copier = new QuoteItemCopier();
	private static QuoteItemFacade facade = new QuoteItemFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static QuoteItemFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult list(BusinessParam businessParam) {
		ServiceResult result = null;
		try {
			BaseDB db = businessParam.getDB();
			//String select = "select e.BSE_FREIGHT_CHARGE_TYPE_ID , e.FREIGHT_CHARGE_TYPE_TITLE from BSE_FREIGHT_CHARGE_TYPE e";
			//Query query = db.createNativeQuery(select);
			Query query = db.createNativeQuery("select t.CLASSIFICATION_ID,t.CLASSIFICATION_TITLE from BSE_FREIGHT_CHARGE_CLASSIFICAT t");
			//System.out.println(query.getResultList().size());
			if(query.getResultList().size() > 0 ){
				List list =  query.getResultList();
				businessParam.releaseDB();
				List listItem = (List) super.list(businessParam).getResult();
				List l = new ArrayList();
				for (int i = 0; i < list.size(); i++) {
					List listResult = new ArrayList();
					Long idTtype = Long.parseLong(((Object[]) list.get(i))[0].toString());
					String title = ((Object[]) list.get(i))[1].toString();
					for (int j = 0; j < listItem.size(); j++) {
						QuoteItemDTO f = (QuoteItemDTO) listItem.get(j);
						Long quoteId = f.getFreightChargeTypeDTO().getClassificatDTO().getRowId();
						if(idTtype.equals(quoteId)){
							listResult.add(listItem.get(j));
						}
					}
					listResult.add(list.get(i));
					l.add(listResult);	
				}				
				result = new ServiceResult(l, l.size());
			}			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(result == null)
			return new ServiceResult();
		else 
			return result;
	}
}
