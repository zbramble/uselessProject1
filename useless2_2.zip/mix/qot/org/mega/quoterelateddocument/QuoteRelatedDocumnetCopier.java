package org.mega.quoterelateddocument;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.quote.Quote;
import org.mega.quote.QuoteDTO;

public class QuoteRelatedDocumnetCopier extends BaseCopier<QuoteRelatedDocumnet, QuoteRelatedDocumnetDTO>{

	@Override
	public QuoteRelatedDocumnetDTO copyFromEntity(QuoteRelatedDocumnet quoteRelatedDocumnet) {
		QuoteRelatedDocumnetDTO quoteRelatedDocumnetDTO = new QuoteRelatedDocumnetDTO();
		quoteRelatedDocumnetDTO.setRowId(quoteRelatedDocumnet.getRowId());
		quoteRelatedDocumnetDTO.setDocumentName(quoteRelatedDocumnet.getDocumentName());
		if(quoteRelatedDocumnet.getQuote() != null){
			QuoteDTO quoteDTO = new QuoteDTO();
			quoteDTO.setRowId(quoteRelatedDocumnet.getQuote().getRowId());
			quoteDTO.setCarrierName(quoteRelatedDocumnet.getQuote().getCarrierName());
			quoteRelatedDocumnetDTO.setQuoteDTO(quoteDTO);
		}
		if(quoteRelatedDocumnet.getDocumnetType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(quoteRelatedDocumnet.getDocumnetType().getRowId());
			comboValDTO.setName(quoteRelatedDocumnet.getDocumnetType().getName());
			quoteRelatedDocumnetDTO.setDocumnetTypeDTO(comboValDTO);
		}
		 if (quoteRelatedDocumnet.getDocumentFile() != null) {
	            FileDTO fDTO = new FileDTO();
	            fDTO.setRowId(quoteRelatedDocumnet.getDocumentFile().getRowId());
	            fDTO.setPath(quoteRelatedDocumnet.getDocumentFile().getPath());
	            fDTO.setImageContent(quoteRelatedDocumnet.getDocumentFile().getImageContent());
	            quoteRelatedDocumnetDTO.setDocumentFileDTO(fDTO);
	        }
		copyFromEntityBaseField(quoteRelatedDocumnet, quoteRelatedDocumnetDTO);
		return quoteRelatedDocumnetDTO;
	}

	@Override
	public QuoteRelatedDocumnet copyToEntity(QuoteRelatedDocumnetDTO quoteRelatedDocumnetDTO) throws Exception {
		QuoteRelatedDocumnet quoteRelatedDocumnet = new QuoteRelatedDocumnet();
		quoteRelatedDocumnet.setRowId(quoteRelatedDocumnetDTO.getRowId());
		quoteRelatedDocumnet.setDocumentName(quoteRelatedDocumnetDTO.getDocumentName());
		if(quoteRelatedDocumnetDTO.getQuoteDTO() != null){
			Quote quote = new Quote();
			quote.setRowId(quoteRelatedDocumnetDTO.getQuoteDTO().getRowId());
			quote.setCarrierName(quoteRelatedDocumnetDTO.getQuoteDTO().getCarrierName());
			quoteRelatedDocumnet.setQuote(quote);
		}
		if(quoteRelatedDocumnetDTO.getDocumnetTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(quoteRelatedDocumnetDTO.getDocumnetTypeDTO().getRowId());
			comboVal.setName(quoteRelatedDocumnetDTO.getDocumnetTypeDTO().getName());
			quoteRelatedDocumnet.setDocumnetType(comboVal);
		}
		 if (quoteRelatedDocumnetDTO.getDocumentFileDTO() != null) {
            File f = new File();
            f.setRowId(quoteRelatedDocumnetDTO.getDocumentFileDTO().getRowId());
            quoteRelatedDocumnet.setDocumentFile(f);
        }
		copyToEntityBaseField(quoteRelatedDocumnet, quoteRelatedDocumnetDTO);
		return quoteRelatedDocumnet;
	}

}
