package org.mega.qot.quotrequest;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.contact.Contact;
import org.mega.core.contact.ContactDTO;
import org.mega.core.file.FileDTO;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;
import org.mega.core.user.UserDTO;
import org.mega.qot.rfqpackage.RfqPackageFacade;
import org.mega.util.DateUtil;

public class QuotRequestCopier extends BaseCopier<QuotRequest, QuotRequestDTO>{

	@Override
	public QuotRequestDTO copyFromEntity(QuotRequest qoutRequest) {
		QuotRequestDTO qoutRequestDTO = new QuotRequestDTO();
		qoutRequestDTO.setRowId(qoutRequest.getRowId());
		qoutRequestDTO.setComanyAssistedProduct(qoutRequest.isComanyAssistedProduct());
		qoutRequestDTO.setCompanyFdaRegistered(qoutRequest.isCompanyFdaRegistered());
		qoutRequestDTO.setContainsEncryptionTechnologi(qoutRequest.isContainsEncryptionTechnologi());
		qoutRequestDTO.setContainsHazardousMaterial(qoutRequest.isContainsHazardousMaterial());
		qoutRequestDTO.setContainsMagneticProperties(qoutRequest.isContainsMagneticProperties());
		qoutRequestDTO.setContainsWood(qoutRequest.isContainsWood());
		qoutRequestDTO.setContaintsLithiumIonBatteries(qoutRequest.isContaintsLithiumIonBatteries());
		qoutRequestDTO.setCpscCertified(qoutRequest.isCpscCertified());
		qoutRequestDTO.setDescriptionOfProducts(qoutRequest.getDescriptionOfProducts());
		qoutRequestDTO.setShipmentName(qoutRequest.getShipmentName());
		qoutRequestDTO.setFccRegistered(qoutRequest.isFccRegistered());
		qoutRequestDTO.setMemo(qoutRequest.getMemo());
		qoutRequestDTO.setPackagingDetailsKnown(qoutRequest.isPackagingDetailsKnown());
		qoutRequestDTO.setPickupDate(DateUtil.getDateString(qoutRequest.getPickupDate(), "en"));
		qoutRequestDTO.setTargetDeliveryDate(DateUtil.getDateString(qoutRequest.getTargetDeliveryDate(), "en"));
		qoutRequestDTO.setTotalPieces(qoutRequest.getTotalPieces());
		qoutRequestDTO.setTotalVolume(qoutRequest.getTotalVolume());
		qoutRequestDTO.setTotalWeight(qoutRequest.getTotalWeight());
		qoutRequestDTO.setRefrigeration(qoutRequest.isRefrigeration());
		qoutRequestDTO.setFreezing(qoutRequest.isFreezing());
		if(qoutRequest.getCustomerName() != null){
			ContactDTO c = new ContactDTO();
			c.setRowId(qoutRequest.getCustomerName().getRowId());
			c.setNameFamily(qoutRequest.getCustomerName().getNameFamily());
			c.setEmail(qoutRequest.getCustomerName().getEmail());
			qoutRequestDTO.setCustomerName(c);
		}
		if(qoutRequest.getLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getLocation().getRowId());
			locationDTO.setName(qoutRequest.getLocation().getName());
			qoutRequestDTO.setLocationDTO(locationDTO);
		}
		if(qoutRequest.getDestinationLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getDestinationLocation().getRowId());
			locationDTO.setName(qoutRequest.getDestinationLocation().getName());
			qoutRequestDTO.setDestinationLocationDTO(locationDTO);
		}
		if(qoutRequest.getOrigionLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getOrigionLocation().getRowId());
			locationDTO.setName(qoutRequest.getOrigionLocation().getName());
			qoutRequestDTO.setOrigionLocationDTO(locationDTO);
		}
		if(qoutRequest.getOrigionPortLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getOrigionPortLocation().getRowId());
			locationDTO.setName(qoutRequest.getOrigionPortLocation().getName());
			qoutRequestDTO.setOrigionPortLocationDTO(locationDTO);
		}
		if(qoutRequest.getDestinationPortLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getDestinationPortLocation().getRowId());
			locationDTO.setName(qoutRequest.getDestinationPortLocation().getName());
			qoutRequestDTO.setDestinationPortLocationDTO(locationDTO);
		}
		if(qoutRequest.getLocation1() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getLocation1().getRowId());
			locationDTO.setName(qoutRequest.getLocation1().getName());
			qoutRequestDTO.setLocation1(locationDTO);
		}
		if(qoutRequest.getLocation2() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(qoutRequest.getLocation2().getRowId());
			locationDTO.setName(qoutRequest.getLocation2().getName());
			qoutRequestDTO.setLocation2(locationDTO);
		}
		if(qoutRequest.getQoutReqStatusType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getQoutReqStatusType().getRowId());
			comboValDTO.setName(qoutRequest.getQoutReqStatusType().getName());
			qoutRequestDTO.setQoutReqStatusTypeDTO(comboValDTO);
		}
		if(qoutRequest.getFreightMethodType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getFreightMethodType().getRowId());
			comboValDTO.setName(qoutRequest.getFreightMethodType().getName());
			qoutRequestDTO.setFreightMethodTypeDTO(comboValDTO);
		}
		if(qoutRequest.getIncotermType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getIncotermType().getRowId());
			comboValDTO.setName(qoutRequest.getIncotermType().getName());
			qoutRequestDTO.setIncotermTypeDTO(comboValDTO);
		}
		if(qoutRequest.getRfqMeasurementUnit() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getRfqMeasurementUnit().getRowId());
			comboValDTO.setName(qoutRequest.getRfqMeasurementUnit().getName());
			qoutRequestDTO.setRfqMeasurementUnitDTO(comboValDTO);
		}
		if(qoutRequest.getShipmentType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getShipmentType().getRowId());
			comboValDTO.setName(qoutRequest.getShipmentType().getName());
			qoutRequestDTO.setShipmentTypeDTO(comboValDTO);
		}
		if(qoutRequest.getFreightType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getFreightType().getRowId());
			comboValDTO.setName(qoutRequest.getFreightType().getName());
			qoutRequestDTO.setFreightTypeDTO(comboValDTO);
		}
		if(qoutRequest.getPaymentTerms() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(qoutRequest.getPaymentTerms().getRowId());
			comboValDTO.setName(qoutRequest.getPaymentTerms().getName());
			qoutRequestDTO.setPaymentTermsDTO(comboValDTO);
		}
		if(qoutRequest.isPackagingDetailsKnown()){
			if(qoutRequest.getQouteRequests() != null)
				qoutRequestDTO.setQouteRequests(RfqPackageFacade.getInstance().getCopier().copyFromEntity(qoutRequest.getQouteRequests()));
		}		
		copyFromEntityBaseField(qoutRequest, qoutRequestDTO);
		/*
		 * create by
		 */
		if(qoutRequest.getCreatedBy() != null){
			UserDTO u = new UserDTO();
			u.setRowId(qoutRequest.getCreatedBy().getRowId());
			u.setCompanyName(qoutRequest.getCreatedBy().getCompanyName());
			u.setFullName(qoutRequest.getCreatedBy().getFullName());
			u.setEmail(qoutRequest.getCreatedBy().getEmail());
			if(qoutRequest.getCreatedBy().getFile() != null){
				FileDTO f = new FileDTO();
				f.setRowId(qoutRequest.getCreatedBy().getFile().getRowId());
				 f.setPath(qoutRequest.getCreatedBy().getFile().getPath());
				f.setImageContent(qoutRequest.getCreatedBy().getFile().getImageContent());
				u.setFile(f);
			}
			qoutRequestDTO.setCreatedBy(u);
		}
		return qoutRequestDTO;
	}

	@Override
	public QuotRequest copyToEntity(QuotRequestDTO qoutRequestDTO) throws Exception {
		QuotRequest qoutRequest = new QuotRequest();
		qoutRequest.setRowId(qoutRequestDTO.getRowId());
		qoutRequest.setComanyAssistedProduct(qoutRequestDTO.isComanyAssistedProduct());
		qoutRequest.setCompanyFdaRegistered(qoutRequestDTO.isCompanyFdaRegistered());
		qoutRequest.setContainsEncryptionTechnologi(qoutRequestDTO.isContainsEncryptionTechnologi());
		qoutRequest.setContainsHazardousMaterial(qoutRequestDTO.isContainsHazardousMaterial());
		qoutRequest.setContainsMagneticProperties(qoutRequestDTO.isContainsMagneticProperties());
		qoutRequest.setContainsWood(qoutRequestDTO.isContainsWood());
		qoutRequest.setContaintsLithiumIonBatteries(qoutRequestDTO.isContaintsLithiumIonBatteries());
		qoutRequest.setCpscCertified(qoutRequestDTO.isCpscCertified());
		qoutRequest.setDescriptionOfProducts(qoutRequestDTO.getDescriptionOfProducts());
		qoutRequest.setShipmentName(qoutRequestDTO.getShipmentName());
		qoutRequest.setFccRegistered(qoutRequestDTO.isFccRegistered());
		qoutRequest.setMemo(qoutRequestDTO.getMemo());
		qoutRequest.setPackagingDetailsKnown(qoutRequestDTO.isPackagingDetailsKnown());
		//System.out.println(DateUtil.getDate(qoutRequestDTO.getPickupDate(), "en"));
		qoutRequest.setPickupDate(DateUtil.getDate(qoutRequestDTO.getPickupDate(), "en"));
		qoutRequest.setTargetDeliveryDate(DateUtil.getDate(qoutRequestDTO.getTargetDeliveryDate(), "en"));
		qoutRequest.setTotalPieces(qoutRequestDTO.getTotalPieces());
		qoutRequest.setTotalVolume(qoutRequestDTO.getTotalVolume());
		qoutRequest.setTotalWeight(qoutRequestDTO.getTotalWeight());
		qoutRequest.setRefrigeration(qoutRequestDTO.isRefrigeration());
		qoutRequest.setFreezing(qoutRequestDTO.isFreezing());
		if(qoutRequestDTO.getCustomerName() != null){
			Contact c = new Contact();
			c.setRowId(qoutRequestDTO.getCustomerName().getRowId());
			c.setNameFamily(qoutRequestDTO.getCustomerName().getNameFamily());
			c.setEmail(qoutRequestDTO.getCustomerName().getEmail());
			qoutRequest.setCustomerName(c);
		}
		if(qoutRequestDTO.getLocationDTO() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getLocationDTO().getRowId());
			location.setName(qoutRequestDTO.getLocationDTO().getName());
			qoutRequest.setLocation(location);
		}
		if(qoutRequestDTO.getDestinationLocationDTO() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getDestinationLocationDTO().getRowId());
			location.setName(qoutRequestDTO.getDestinationLocationDTO().getName());
			qoutRequest.setDestinationLocation(location);
		}
		if(qoutRequestDTO.getOrigionLocationDTO() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getOrigionLocationDTO().getRowId());
			location.setName(qoutRequestDTO.getOrigionLocationDTO().getName());
			qoutRequest.setOrigionLocation(location);
		}
		if(qoutRequestDTO.getOrigionPortLocationDTO() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getOrigionPortLocationDTO().getRowId());
			location.setName(qoutRequestDTO.getOrigionPortLocationDTO().getName());
			qoutRequest.setOrigionPortLocation(location);
		}
		if(qoutRequestDTO.getDestinationPortLocationDTO() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getDestinationPortLocationDTO().getRowId());
			location.setName(qoutRequestDTO.getDestinationPortLocationDTO().getName());
			qoutRequest.setDestinationPortLocation(location);
		}
		if(qoutRequestDTO.getLocation1() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getLocation1().getRowId());
			location.setName(qoutRequestDTO.getLocation1().getName());
			qoutRequest.setLocation1(location);
		}
		if(qoutRequestDTO.getLocation2() != null){
			Location location = new Location();
			location.setRowId(qoutRequestDTO.getLocation2().getRowId());
			location.setName(qoutRequestDTO.getLocation2().getName());
			qoutRequest.setLocation2(location);
		}
		if(qoutRequestDTO.getQoutReqStatusTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getQoutReqStatusTypeDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getQoutReqStatusTypeDTO().getName());
			qoutRequest.setQoutReqStatusType(comboVal);
		}
		if(qoutRequestDTO.getFreightMethodTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getFreightMethodTypeDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getFreightMethodTypeDTO().getName());
			qoutRequest.setFreightMethodType(comboVal);
		}
		if(qoutRequestDTO.getIncotermTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getIncotermTypeDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getIncotermTypeDTO().getName());
			qoutRequest.setIncotermType(comboVal);
		}
		if(qoutRequestDTO.getRfqMeasurementUnitDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getRfqMeasurementUnitDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getRfqMeasurementUnitDTO().getName());
			qoutRequest.setRfqMeasurementUnit(comboVal);
		}
		if(qoutRequestDTO.getShipmentTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getShipmentTypeDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getShipmentTypeDTO().getName());
			qoutRequest.setShipmentType(comboVal);
		}
		if(qoutRequestDTO.getFreightTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getFreightTypeDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getFreightTypeDTO().getName());
			qoutRequest.setFreightType(comboVal);
		}
		if(qoutRequestDTO.getPaymentTermsDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(qoutRequestDTO.getPaymentTermsDTO().getRowId());
			comboVal.setName(qoutRequestDTO.getPaymentTermsDTO().getName());
			qoutRequest.setPaymentTerms(comboVal);
		}
		copyToEntityBaseField(qoutRequest, qoutRequestDTO);
		return qoutRequest;
	}

}
