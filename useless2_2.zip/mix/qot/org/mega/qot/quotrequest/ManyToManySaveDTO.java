package org.mega.qot.quotrequest;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.qot.rfqpackage.RfqPackageDTO;

public class ManyToManySaveDTO extends BaseDTO{
	
	QuotRequestDTO qoutRequestDTO;
	List<RfqPackageDTO> rfqPackageDTOs ;
	public QuotRequestDTO getQoutRequestDTO() {
		return qoutRequestDTO;
	}
	public void setQoutRequestDTO(QuotRequestDTO qoutRequestDTO) {
		this.qoutRequestDTO = qoutRequestDTO;
	}
	public List<RfqPackageDTO> getRfqPackageDTOs() {
		return rfqPackageDTOs;
	}
	public void setRfqPackageDTOs(List<RfqPackageDTO> rfqPackageDTOs) {
		this.rfqPackageDTOs = rfqPackageDTOs;
	}
	@Override
	public Long getRowId() {
		// TODO Auto-generated method stub
		return qoutRequestDTO.getRowId();
	}
	

}
