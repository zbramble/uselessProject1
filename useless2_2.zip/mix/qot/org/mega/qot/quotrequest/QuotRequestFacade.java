package org.mega.qot.quotrequest;

import java.util.ArrayList;
import java.util.List;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.qot.rfqpackage.RfqPackageDTO;
import org.mega.qot.rfqpackage.RfqPackageFacade;

public class QuotRequestFacade extends BaseFacade{
	private static QuotRequestCopier copier = new QuotRequestCopier();
	private static QuotRequestFacade facade = new QuotRequestFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static QuotRequestFacade getInstance() {
		return facade;
	}
	
	public ServiceResult manyToMantSave(QuotRequestDTO dto,List<RfqPackageDTO> rfqPackageDTOs, BusinessParam businessParam) {
		if(businessParam.getUserSession().getUserInfo().getRoleId() != SystemConfig.SYS_ADMIN_ROLE_ID && (businessParam.getUserSession().getUserInfo().getRoleId() != 10004)){//Forwarder
			if(dto.getCustomerName().getRowId() != 0)
				new ServiceResult(ServiceResult.ERROR_CODE.ACCESS_DENIED, "Access Denied,Customer Name", "Access Denied,Customer Name");
		}
		ServiceResult id = super.save(dto, businessParam);
		dto.setRowId(Long.parseLong(id.getResult().toString()));
		ServiceResult packageId =null;
		List list = new ArrayList();
		list.add(id.getResult());
		for (int i = 0; i < rfqPackageDTOs.size(); i++) {
			RfqPackageDTO rfqPackageDTO   = new RfqPackageDTO();
			if(rfqPackageDTOs.get(i).getRowId() != 0)
				rfqPackageDTO.setRowId(rfqPackageDTOs.get(i).getRowId());
			rfqPackageDTO.setQouteRequestDTO(dto);
			rfqPackageDTO.setPackageName(rfqPackageDTOs.get(i).getPackageName());
			rfqPackageDTO.setCarrtonCount(rfqPackageDTOs.get(i).getCarrtonCount());
			rfqPackageDTO.setCartonHeight(rfqPackageDTOs.get(i).getCartonHeight());
			rfqPackageDTO.setCartonLength(rfqPackageDTOs.get(i).getCartonLength());
			rfqPackageDTO.setCartonWeight(rfqPackageDTOs.get(i).getCartonWeight());
			rfqPackageDTO.setCartonWidth(rfqPackageDTOs.get(i).getCartonWidth());
			packageId = RfqPackageFacade.getInstance().save(rfqPackageDTO, businessParam);
			list.add(packageId.getResult());
			
		}
		id.setResult(list);
		return id;
	}
	
	public ServiceResult updateStatus(QuotRequestDTO quotRequestDTO,BusinessParam businessParam){
		Long id = quotRequestDTO.getRowId();
		Long StatusId = quotRequestDTO.getQoutReqStatusTypeDTO().getRowId();
		try {
			BaseDB db = businessParam.getDB();
			db.runNativeQuery("update QOT_QOUT_REQUEST set QOUT_REQUEST_STATUS_TYPE_ID = "+StatusId+" where QOUTE_REQUEST_ID= " +  id);
			businessParam.releaseDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//ServiceResult result = QuotRequestFacade.getInstance().save(quotRequestDTO, businessParam);
		return new ServiceResult(id, 1);
		
	}
	
	@Override
	public String getConstraint(BusinessParam businessParam) {
		// TODO Auto-generated method stub
		UserSession userSession = businessParam.getUserSession();
		if(userSession.getUserInfo().getRoleId() == 10004){//forwarder
			
			return "(e.accessKey is null or e.qoutReqStatusType.rowId = 100027)";
		}else
			return super.getConstraint(businessParam);
	}
}
