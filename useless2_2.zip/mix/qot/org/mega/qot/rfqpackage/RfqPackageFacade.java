package org.mega.qot.rfqpackage;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class RfqPackageFacade extends BaseFacade{
	private static RfqPackageCopier copier = new RfqPackageCopier();
	private static RfqPackageFacade facade = new RfqPackageFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static RfqPackageFacade getInstance() {
		return facade;
	}
}
