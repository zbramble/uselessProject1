package org.mega.qot.rfqpackage;

import org.mega.bse.cartontype.CartonType;
import org.mega.bse.cartontype.CartonTypeDTO;
import org.mega.core.base.BaseDTO;
import org.mega.qot.quotrequest.QuotRequestDTO;

public class RfqPackageDTO extends BaseDTO{

	private long rowId;
	private QuotRequestDTO qouteRequestDTO;
	private CartonTypeDTO cartonTypeDTO;
	private String packageName;
	private boolean palletized;
	private int carrtonCount;		
	private double cartonLength;
	private double cartonWidth;
	private double cartonHeight;
	private double cartonWeight;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public QuotRequestDTO getQouteRequestDTO() {
		return qouteRequestDTO;
	}
	public void setQouteRequestDTO(QuotRequestDTO qouteRequestDTO) {
		this.qouteRequestDTO = qouteRequestDTO;
	}

	public CartonTypeDTO getCartonTypeDTO() {
		return cartonTypeDTO;
	}
	public void setCartonTypeDTO(CartonTypeDTO cartonTypeDTO) {
		this.cartonTypeDTO = cartonTypeDTO;
	}

	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public boolean isPalletized() {
		return palletized;
	}
	public void setPalletized(boolean palletized) {
		this.palletized = palletized;
	}
	public int getCarrtonCount() {
		return carrtonCount;
	}
	public void setCarrtonCount(int carrtonCount) {
		this.carrtonCount = carrtonCount;
	}
	public double getCartonLength() {
		return cartonLength;
	}
	public void setCartonLength(double cartonLength) {
		this.cartonLength = cartonLength;
	}
	public double getCartonWidth() {
		return cartonWidth;
	}
	public void setCartonWidth(double cartonWidth) {
		this.cartonWidth = cartonWidth;
	}
	public double getCartonHeight() {
		return cartonHeight;
	}
	public void setCartonHeight(double cartonHeight) {
		this.cartonHeight = cartonHeight;
	}
	public double getCartonWeight() {
		return cartonWeight;
	}
	public void setCartonWeight(double cartonWeight) {
		this.cartonWeight = cartonWeight;
	}
	
}
