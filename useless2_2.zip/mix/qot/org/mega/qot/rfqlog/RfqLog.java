package org.mega.qot.rfqlog;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.user.User;
import org.mega.qot.quotelogreply.QuoteLogReply;
import org.mega.qot.quotrequest.QuotRequest;
import org.mega.qot.rfqlogreply.RfqLogReply;

@Entity
@Table(name = "QOT_RFQ_LOG", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_RFQ_LOG", columnNames = "QOT_RFQ_LOG_ID"))
public class RfqLog extends BaseEntity{
	@Id
	@Column(name = "QOT_RFQ_LOG_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "QOUTE_REQUEST_ID", foreignKey = @ForeignKey(name = "FK_QOT_RFQ__QOUT_REQUEST"), nullable = true)
	private QuotRequest qouteRequest;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "LOG_USER_ID", foreignKey = @ForeignKey(name = "FK_QOT_RFQ_LOG_USER"), nullable = true)
	private User logUser;

	@Temporal(TemporalType.DATE)
	@Column(name = "LOG_DATE")
	private Date logDate;

	@Column(name="LOG_NOTES",length=2000)
	private String logNotes;

	@OneToMany(mappedBy = "rfqLog")
    private List<RfqLogReply> rfqLogReply;
	
	
	public List<RfqLogReply> getRfqLogReply() {
		return rfqLogReply;
	}

	public void setRfqLogReply(List<RfqLogReply> rfqLogReply) {
		this.rfqLogReply = rfqLogReply;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public QuotRequest getQouteRequest() {
		return qouteRequest;
	}

	public void setQouteRequest(QuotRequest qouteRequest) {
		this.qouteRequest = qouteRequest;
	}

	public User getLogUser() {
		return logUser;
	}

	public void setLogUser(User logUser) {
		this.logUser = logUser;
	}

	public Date getLogDate() {
		return logDate;
	}

	public void setLogDate(Date logDate) {
		this.logDate = logDate;
	}

	public String getLogNotes() {
		return logNotes;
	}

	public void setLogNotes(String logNotes) {
		this.logNotes = logNotes;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = qouteRequest.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = qouteRequest.getFullTitle();
	}


}
