package org.mega.qot.rfqlog;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.sec.UserSession;

public class RfqLogFacade extends BaseFacade{

	private static RfqLogCopier copier = new RfqLogCopier();
	private static RfqLogFacade facade = new RfqLogFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static RfqLogFacade getInstance() {
		return facade;
	}
	
	@Override
	public String getConstraint(BusinessParam businessParam) {
		// TODO Auto-generated method stub
		UserSession userSession = businessParam.getUserSession();
		if(userSession.getUserInfo().getRoleId() == 10004 ){//forwarder
			
			  return null;
		}else
			return super.getConstraint(businessParam);
	}

}
