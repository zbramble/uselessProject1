package org.mega.qot.rfqlogrelateddoc;

import org.mega.core.base.BaseDTO;
import org.mega.qot.rfqlog.RfqLogDTO;

public class RfqLogRelatedDocDTO extends BaseDTO{
	private long rowId;
	private RfqLogDTO rfqLogDTO;
	private int relatedDoc1;
	private int relatedDoc2;
	private int relatedDoc3;
	private int relatedDoc4;
	private int relatedDoc5;
	
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public RfqLogDTO getRfqLogDTO() {
		return rfqLogDTO;
	}
	public void setRfqLogDTO(RfqLogDTO rfqLogDTO) {
		this.rfqLogDTO = rfqLogDTO;
	}
	public int getRelatedDoc1() {
		return relatedDoc1;
	}
	public void setRelatedDoc1(int relatedDoc1) {
		this.relatedDoc1 = relatedDoc1;
	}
	public int getRelatedDoc2() {
		return relatedDoc2;
	}
	public void setRelatedDoc2(int relatedDoc2) {
		this.relatedDoc2 = relatedDoc2;
	}
	public int getRelatedDoc3() {
		return relatedDoc3;
	}
	public void setRelatedDoc3(int relatedDoc3) {
		this.relatedDoc3 = relatedDoc3;
	}
	public int getRelatedDoc4() {
		return relatedDoc4;
	}
	public void setRelatedDoc4(int relatedDoc4) {
		this.relatedDoc4 = relatedDoc4;
	}
	public int getRelatedDoc5() {
		return relatedDoc5;
	}
	public void setRelatedDoc5(int relatedDoc5) {
		this.relatedDoc5 = relatedDoc5;
	}
    
}
