package org.mega.qot.rfqlogrelateddoc;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class RfqLogRelatedDocFacade extends BaseFacade{

	private static RfqLogRelatedDocCopier copier = new RfqLogRelatedDocCopier();
	private static RfqLogRelatedDocFacade facade = new RfqLogRelatedDocFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static RfqLogRelatedDocFacade getInstance() {
		return facade;
	}

}
