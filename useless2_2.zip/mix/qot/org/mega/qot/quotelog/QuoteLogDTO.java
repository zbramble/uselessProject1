package org.mega.qot.quotelog;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotelogreply.QuoteLogReplyDTO;
import org.mega.quote.QuoteDTO;

public class QuoteLogDTO extends BaseDTO{
	private long rowId;
	private QuoteDTO quoteDTO;
	private UserDTO logUserDTO;
	private String logDate;
	private String logNotes;
	private List<QuoteLogReplyDTO> quoteLogReply;
	
	public List<QuoteLogReplyDTO> getQuoteLogReply() {
		return quoteLogReply;
	}
	public void setQuoteLogReply(List<QuoteLogReplyDTO> quoteLogReply) {
		this.quoteLogReply = quoteLogReply;
	}
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public QuoteDTO getQuoteDTO() {
		return quoteDTO;
	}
	public void setQuoteDTO(QuoteDTO quoteDTO) {
		this.quoteDTO = quoteDTO;
	}
	public UserDTO getLogUserDTO() {
		return logUserDTO;
	}
	public void setLogUserDTO(UserDTO logUserDTO) {
		this.logUserDTO = logUserDTO;
	}
	public String getLogDate() {
		return logDate;
	}
	public void setLogDate(String logDate) {
		this.logDate = logDate;
	}
	public String getLogNotes() {
		return logNotes;
	}
	public void setLogNotes(String logNotes) {
		this.logNotes = logNotes;
	}
}
