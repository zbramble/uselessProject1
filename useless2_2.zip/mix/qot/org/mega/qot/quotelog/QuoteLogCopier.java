package org.mega.qot.quotelog;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.core.location.LocationDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotelogreply.QuoteLogReplyFacade;
import org.mega.qot.quotrequest.QuotRequestDTO;
import org.mega.qot.rfqpackage.RfqPackageFacade;
import org.mega.quote.Quote;
import org.mega.quote.QuoteDTO;
import org.mega.util.DateUtil;

import jxl.write.biff.CopyAdditionalPropertySetsException;

public class QuoteLogCopier extends BaseCopier<QuoteLog, QuoteLogDTO>{

	@Override
	public QuoteLogDTO copyFromEntity(QuoteLog quoteLog) {
		QuoteLogDTO quoteLogDTO = new QuoteLogDTO();
		quoteLogDTO.setRowId(quoteLog.getRowId());
		quoteLogDTO.setLogDate(DateUtil.getDateString(quoteLog.getLogDate(),"en"));
		quoteLogDTO.setLogNotes(quoteLog.getLogNotes());
		if(quoteLog.getLogUser() != null){
			UserDTO logUserDTO = new UserDTO();
			logUserDTO.setRowId(quoteLog.getLogUser().getRowId());
			logUserDTO.setFullName(quoteLog.getLogUser().getFullName());
			quoteLogDTO.setLogUserDTO(logUserDTO);
		}
		if(quoteLog.getQuote() != null){
			QuoteDTO quoteDTO = new QuoteDTO();
			quoteDTO.setRowId(quoteLog.getQuote().getRowId());
			quoteDTO.setCarrierName(quoteLog.getQuote().getCarrierName());
			quoteDTO.setFullTitle(quoteLog.getQuote().getFullTitle());
			QuotRequestDTO reqouestDTO = new QuotRequestDTO();
			reqouestDTO.setRowId(quoteLog.getQuote().getQouteRequest().getRowId());
			reqouestDTO.setFullTitle(quoteLog.getQuote().getQouteRequest().getFullTitle());
			reqouestDTO.setShipmentName(quoteLog.getQuote().getQouteRequest().getShipmentName());
			quoteDTO.setQouteRequestDTO(reqouestDTO);
			
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(quoteLog.getQuote().getFreightMethod().getRowId());
			cDTO.setName(quoteLog.getQuote().getFreightMethod().getName());
			quoteDTO.setFreightMethodDTO(cDTO);
			if(quoteLog.getQuote().getFreightType() != null){
				ComboValDTO cTypeDTO = new ComboValDTO();
				cTypeDTO.setRowId(quoteLog.getQuote().getFreightType().getRowId());
				cTypeDTO.setName(quoteLog.getQuote().getFreightType().getName());
				quoteDTO.setFreightTypeDTO(cTypeDTO);
			}
			if(quoteLog.getQuote().getDepartureLocation() != null){
				LocationDTO lDTO = new LocationDTO();
				lDTO.setRowId(quoteLog.getQuote().getDepartureLocation().getRowId());
				lDTO.setName(quoteLog.getQuote().getDepartureLocation().getName());
				quoteDTO.setDepartureLocationDTO(lDTO);
			}
			if(quoteLog.getQuote().getArrivalLocation() != null){
				LocationDTO locationArrivalDTO = new LocationDTO();
				locationArrivalDTO.setRowId(quoteLog.getQuote().getArrivalLocation().getRowId());
				locationArrivalDTO.setName(quoteLog.getQuote().getArrivalLocation().getName());
				quoteDTO.setArrivalLocationDTO(locationArrivalDTO);
				quoteDTO.setQuoteReference(quoteLog.getQuote().getQuoteReference());
			}
			if(quoteLog.getQuote().getCreatedBy() != null){
				UserDTO u = new UserDTO();
				u.setRowId(quoteLog.getQuote().getCreatedBy().getRowId());
				u.setCompanyName(quoteLog.getQuote().getCreatedBy().getCompanyName());
				u.setFullName(quoteLog.getQuote().getCreatedBy().getFullName());
				u.setEmail(quoteLog.getQuote().getCreatedBy().getEmail());
				if(quoteLog.getQuote().getCreatedBy().getFile() != null){
					FileDTO f = new FileDTO();
					f.setRowId(quoteLog.getQuote().getCreatedBy().getFile().getRowId());
					 f.setPath(quoteLog.getQuote().getCreatedBy().getFile().getPath());
					f.setImageContent(quoteLog.getQuote().getCreatedBy().getFile().getImageContent());
					u.setFile(f);
				}
				quoteDTO.setCreatedBy(u);
			}
			quoteLogDTO.setQuoteDTO(quoteDTO);			
		}
		if(quoteLog.getQuoteLogReply() != null)
			quoteLogDTO.setQuoteLogReply(QuoteLogReplyFacade.getInstance().getCopier().copyFromEntity(quoteLog.getQuoteLogReply()));
		copyFromEntityBaseField(quoteLog, quoteLogDTO);
		/*
		 * create by log
		 */
		UserDTO u = new UserDTO();
		u.setRowId(quoteLog.getCreatedBy().getRowId());
		u.setCompanyName(quoteLog.getCreatedBy().getCompanyName());
		u.setFullName(quoteLog.getCreatedBy().getFullName());
		u.setEmail(quoteLog.getCreatedBy().getEmail());
		if(quoteLog.getCreatedBy().getFile() != null){
			FileDTO f = new FileDTO();
			f.setRowId(quoteLog.getCreatedBy().getFile().getRowId());
			f.setPath(quoteLog.getCreatedBy().getFile().getPath());
			f.setImageContent(quoteLog.getCreatedBy().getFile().getImageContent());
			u.setFile(f);
		}
		quoteLogDTO.setCreatedBy(u);
		return quoteLogDTO;
	}

	@Override
	public QuoteLog copyToEntity(QuoteLogDTO quoteLogDTO) throws Exception {
		QuoteLog quoteLog = new QuoteLog();
		quoteLog.setRowId(quoteLogDTO.getRowId());
		quoteLog.setLogDate(DateUtil.getDate(quoteLogDTO.getLogDate(),"en"));
		quoteLog.setLogNotes(quoteLogDTO.getLogNotes());
		if(quoteLogDTO.getLogUserDTO() != null){
			User logUser = new User();
			logUser.setRowId(quoteLogDTO.getLogUserDTO().getRowId());
			logUser.setFullName(quoteLogDTO.getLogUserDTO().getFullName());
			quoteLog.setLogUser(logUser);
		}
		if(quoteLogDTO.getQuoteDTO() != null){
			Quote quote = new Quote();
			quote.setRowId(quoteLogDTO.getQuoteDTO().getRowId());
			quote.setCarrierName(quoteLogDTO.getQuoteDTO().getCarrierName());
			quoteLog.setQuote(quote);
		}
		copyToEntityBaseField(quoteLog, quoteLogDTO);
		return quoteLog;
	}


}
