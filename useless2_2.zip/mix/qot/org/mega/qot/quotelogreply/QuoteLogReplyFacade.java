package org.mega.qot.quotelogreply;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class QuoteLogReplyFacade extends BaseFacade{
	private static QuoteLogReplyCopier copier = new QuoteLogReplyCopier();
	private static QuoteLogReplyFacade facade = new QuoteLogReplyFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static QuoteLogReplyFacade getInstance() {
		return facade;
	}
}
