package org.mega.qot.quotelogreply;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/quoteLogReply")
public class QuoteLogReplyService {
	@POST
    @Path("/save")
    public ServiceResult save(QuoteLogReplyDTO logReplyDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(logReplyDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try {
			return QuoteLogReplyFacade.getInstance().save(logReplyDTO, new BusinessParam(userSession));
		} catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
		}
    }
	@POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return QuoteLogReplyFacade.getInstance().list(new BusinessParam(userSession, filter));
    }
	@POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return QuoteLogReplyFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }
}
