package org.mega.qot.rfqlogreply;

import org.mega.core.base.BaseDTO;
import org.mega.qot.rfqlog.RfqLogDTO;

public class RfqLogReplyDTO extends BaseDTO{

	private long rowId;
	private String replyNotes;
	private RfqLogDTO rfqLogDTO;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getReplyNotes() {
		return replyNotes;
	}
	public void setReplyNotes(String replyNotes) {
		this.replyNotes = replyNotes;
	}
	public RfqLogDTO getRfqLogDTO() {
		return rfqLogDTO;
	}
	public void setRfqLogDTO(RfqLogDTO rfqLogDTO) {
		this.rfqLogDTO = rfqLogDTO;
	}
	
}
