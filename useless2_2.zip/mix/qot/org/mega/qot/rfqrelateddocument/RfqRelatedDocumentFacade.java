package org.mega.qot.rfqrelateddocument;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class RfqRelatedDocumentFacade extends BaseFacade{

	private static RfqRelatedDocumentCopier copier = new RfqRelatedDocumentCopier();
	private static RfqRelatedDocumentFacade facade = new RfqRelatedDocumentFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static RfqRelatedDocumentFacade getInstance() {
		return facade;
	}

}
