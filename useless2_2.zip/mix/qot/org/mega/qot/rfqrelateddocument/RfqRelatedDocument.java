package org.mega.qot.rfqrelateddocument;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.file.File;
import org.mega.qot.quotrequest.QuotRequest;


@Entity
@Table(name = "QOT_RFQ_RELATED_DOCUMENT", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_RFQ_RELATED_DOCUMENT", columnNames = "QOT_RFQ_RELATED_DOCUMENT_ID"))
public class RfqRelatedDocument extends BaseEntity{
	@Id
	@Column(name = "QOT_RFQ_RELATED_DOCUMENT_ID")
	private long rowId;
	
	@ManyToOne()
	@JoinColumn(name = "QOUTE_REQUEST_ID", foreignKey = @ForeignKey(name = "FK_RFQ_RELA_REFERENCE_QOT_QOUT"), nullable = true)
	private QuotRequest quotRequest;
	
	@ManyToOne()
	@JoinColumn(name = "RELATED_DOCUMENT_TYPE_ID", foreignKey = @ForeignKey(name = "FK_RFQ_RELA_REFERENCE_CO_COMBO"), nullable = true)
	private ComboVal relatedDocumentType;
	
	@Column(name = "RELATED_DOCUMENT_TITLE")
	private String relatedDocumentTitle;
	
	@ManyToOne
    @JoinColumn(name = "DOCUMENT_FILE", nullable = true)
    private File documentFile;
	
	
	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public QuotRequest getQuotRequest() {
		return quotRequest;
	}

	public void setQuotRequest(QuotRequest quotRequest) {
		this.quotRequest = quotRequest;
	}

	public ComboVal getRelatedDocumentType() {
		return relatedDocumentType;
	}

	public void setRelatedDocumentType(ComboVal relatedDocumentType) {
		this.relatedDocumentType = relatedDocumentType;
	}

	public String getRelatedDocumentTitle() {
		return relatedDocumentTitle;
	}

	public void setRelatedDocumentTitle(String relatedDocumentTitle) {
		this.relatedDocumentTitle = relatedDocumentTitle;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		if(quotRequest != null)
		    fullTitle = quotRequest.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		if(quotRequest != null)
		    fullTitle = quotRequest.getFullTitle();
	}

	public File getDocumentFile() {
		return documentFile;
	}

	public void setDocumentFile(File documentFile) {
		this.documentFile = documentFile;
	}

    
}
