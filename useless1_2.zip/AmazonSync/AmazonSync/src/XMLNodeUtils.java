/*  1:   */ 
/*  2:   */ 
/*  3:   */ import org.w3c.dom.NamedNodeMap;
/*  4:   */ import org.w3c.dom.Node;
/*  5:   */ import org.w3c.dom.NodeList;
/*  6:   */ 
/*  7:   */ public class XMLNodeUtils
/*  8:   */ {
/*  9:   */   public static Node getNode(String tagName, NodeList nodes)
/* 10:   */   {
/* 11: 9 */     for (int x = 0; x < nodes.getLength(); x++)
/* 12:   */     {
/* 13:10 */       Node node = nodes.item(x);
/* 14:11 */       if (node.getNodeName().equalsIgnoreCase(tagName)) {
/* 15:12 */         return node;
/* 16:   */       }
/* 17:   */     }
/* 18:16 */     return null;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static String getNodeValue(Node node)
/* 22:   */   {
/* 23:20 */     NodeList childNodes = node.getChildNodes();
/* 24:21 */     for (int x = 0; x < childNodes.getLength(); x++)
/* 25:   */     {
/* 26:22 */       Node data = childNodes.item(x);
/* 27:23 */       if (data.getNodeType() == 3) {
/* 28:24 */         return data.getNodeValue();
/* 29:   */       }
/* 30:   */     }
/* 31:26 */     return "";
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static String getNodeValue(String tagName, NodeList nodes)
/* 35:   */   {
/* 36:30 */     for (int x = 0; x < nodes.getLength(); x++)
/* 37:   */     {
/* 38:31 */       Node node = nodes.item(x);
/* 39:32 */       if (node.getNodeName().equalsIgnoreCase(tagName))
/* 40:   */       {
/* 41:33 */         NodeList childNodes = node.getChildNodes();
/* 42:34 */         for (int y = 0; y < childNodes.getLength(); y++)
/* 43:   */         {
/* 44:35 */           Node data = childNodes.item(y);
/* 45:36 */           if (data.getNodeType() == 3) {
/* 46:37 */             return data.getNodeValue();
/* 47:   */           }
/* 48:   */         }
/* 49:   */       }
/* 50:   */     }
/* 51:41 */     return "";
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static String getNodeAttr(String attrName, Node node)
/* 55:   */   {
/* 56:45 */     NamedNodeMap attrs = node.getAttributes();
/* 57:46 */     for (int y = 0; y < attrs.getLength(); y++)
/* 58:   */     {
/* 59:47 */       Node attr = attrs.item(y);
/* 60:48 */       if (attr.getNodeName().equalsIgnoreCase(attrName)) {
/* 61:49 */         return attr.getNodeValue();
/* 62:   */       }
/* 63:   */     }
/* 64:52 */     return "";
/* 65:   */   }
/* 66:   */   
/* 67:   */   public static String getNodeAttr(String tagName, String attrName, NodeList nodes)
/* 68:   */   {
/* 69:56 */     for (int x = 0; x < nodes.getLength(); x++)
/* 70:   */     {
/* 71:57 */       Node node = nodes.item(x);
/* 72:58 */       if (node.getNodeName().equalsIgnoreCase(tagName))
/* 73:   */       {
/* 74:59 */         NodeList childNodes = node.getChildNodes();
/* 75:60 */         for (int y = 0; y < childNodes.getLength(); y++)
/* 76:   */         {
/* 77:61 */           Node data = childNodes.item(y);
/* 78:62 */           if ((data.getNodeType() == 2) && 
/* 79:63 */             (data.getNodeName().equalsIgnoreCase(attrName))) {
/* 80:64 */             return data.getNodeValue();
/* 81:   */           }
/* 82:   */         }
/* 83:   */       }
/* 84:   */     }
/* 85:70 */     return "";
/* 86:   */   }
/* 87:   */ }


/* Location:           D:\apache-tomcat-9.0.0.M17\webapps\reviewtracker-0.0.1-SNAPSHOT\
 * Qualified Name:     com.milo.amz.webdriver.utils.XMLNodeUtils
 * JD-Core Version:    0.7.0.1
 */