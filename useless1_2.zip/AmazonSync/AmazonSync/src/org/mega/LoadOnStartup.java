package org.mega;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.mega.amazon.email.SendAmazonEmails;
import org.mega.amazon.order.FetchOrdersBuyerId;
import org.mega.amazon.order.ImportAmazonOrders;
import org.mega.amazon.review.ImportAmazonReviews;
import org.mega.amazon.review.UpdateReviewsOrderId;
import org.mega.app.job.TeamNegativeReviewsReportJob;
import org.mega.app.job.TeamReviewDropRiskReportJob;
import org.mega.core.SystemConfig;

public class LoadOnStartup extends HttpServlet {
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Amazon synchronization starting ...");
		SystemConfig.init();
		
		new Thread(new ImportAmazonReviews()).start();
		new Thread(new ImportAmazonOrders()).start();
		new Thread(new FetchOrdersBuyerId()).start();
		new Thread(new UpdateReviewsOrderId()).start();
		new Thread(new SendPublicEmails()).start();
		new Thread(new SendAmazonEmails()).start();
		
		TeamReviewDropRiskReportJob.scheduleATask(true);
		TeamNegativeReviewsReportJob.scheduleATask(true);
	}
}
