package org.mega.core;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

public class SystemConfig {
	
	public static int PER_REVIEW_PAGE_LOAD_DELAY_SECOND = 0;
	public static int LAST_DAYS_TO_IMPORT_REVIEW = 1;
	public static int LAST_DAYS_TO_IMPORT_ORDER = 1;
	public static String ID_PREFIX;
	public static long REVIEW_IMPORT_PERIOD_SECOND = 20;
	public static long EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS;//=60;
	public static long EXPIRE_CACHE_MAX_SIZE;// = 400;
	public static long	SYSTEM_USER_ID;// = 10000;	//System do some things with this user. No access checks for system or admin role 
	public static int NUMBER_OF_IMPORTED_FOR_COMMIT_DB;
	public static long ORGANOZATION_ROOT_ID;
	public static int IMPORT_A_PRODUCT_REVIEWS_TIMEOUT_SECOND;
	public static int FETCH_BUYERIDS_TIMEOUT_SECOND;
	public static boolean ENABLE_SYNC_REVIEW;
	public static boolean ENABLE_SYNC_ORDER;
	public static long ORDER_IMPORT_PERIOD_SECOND;
	
	public static long SYSTEM_ROLE_ID;
	public static long WEB_PAGE_LOAD_TIMOUT_SECOND;
	
	private static Properties properties = new Properties();
	public static String WEB_DRIVER_NAME;
	public static String PHANTOMJS_WEB_DRIVER_PATH;
	public static String CHROME_WEB_DRIVER_PATH;
	
	public static String SYSTEM_EMAIL_SERVER;
	public static String SYSTEM_EMAIL;
	public static String SYSTEM_EMAIL_USER;
	public static String SYSTEM_EMAIL_PASS;
	public static boolean SYSTEM_EMAIL_USE_SSL;
	public static String SYSTEM_EMAIL_SMTP_PORT;
	
	public static Date DATE_TO_SEND_NEGATIVE_REVIEW_EMAIL;
	public static boolean ENABLE_SEND_EMAILS;
	public static boolean ENABLE_FETCH_ORDER_BUYER_ID;
	public static boolean ENABLE_UPDATE_REVIEWS_ORDER_ID;
	public static boolean ENABLE_SEND_AMAZON_EMAIL;
	public static int FETCH_BUYERID_PERIOD_SECOND;
	public static int SEND_AMAZON_EMAIL_PERIOD_SECOND;
	public static int PER_ORDER_SERVICE_CALL_DELAY_SECONDS;
	public static int PER_BUYERID_PAGE_LOAD_SECONDS;
	public static int UPDATE_REVIEWS_ORDER_ID_PERIOD_SECOND;
	public static int SEND_AMAZON_EMAIL_TIMEOUT_SECOND;
	
	public static void init(){
		try {
			properties.load(SystemConfig.class.getClassLoader().getResourceAsStream("system.properties"));
			SYSTEM_ROLE_ID  						=	SystemConfig.getLongProp("SYSTEM_ROLE_ID");
			LAST_DAYS_TO_IMPORT_ORDER  				=	SystemConfig.getIntProp("LAST_DAYS_TO_IMPORT_ORDER");
			LAST_DAYS_TO_IMPORT_REVIEW  			=	SystemConfig.getIntProp("LAST_DAYS_TO_IMPORT_REVIEW");
			PER_REVIEW_PAGE_LOAD_DELAY_SECOND  		=	SystemConfig.getIntProp("PER_REVIEW_PAGE_LOAD_DELAY_SECOND");
			ID_PREFIX  								=	SystemConfig.getProp("ID_PREFIX");
			WEB_DRIVER_NAME  						=	SystemConfig.getProp("WEB_DRIVER_NAME");
			PHANTOMJS_WEB_DRIVER_PATH  				=	SystemConfig.getProp("PHANTOMJS_WEB_DRIVER_PATH");
			CHROME_WEB_DRIVER_PATH  				=	SystemConfig.getProp("CHROME_WEB_DRIVER_PATH");
			REVIEW_IMPORT_PERIOD_SECOND 			=	SystemConfig.getLongProp("REVIEW_IMPORT_PERIOD_SECOND");
			ORDER_IMPORT_PERIOD_SECOND 				=	SystemConfig.getLongProp("ORDER_IMPORT_PERIOD_SECOND");
			EXPIRE_CACHE_MAX_SIZE  					=	SystemConfig.getLongProp("EXPIRE_CACHE_MAX_SIZE");
			EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS  	=	SystemConfig.getLongProp("EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS");
			SYSTEM_USER_ID  						=	SystemConfig.getLongProp("SYSTEM_USER_ID");
			IMPORT_A_PRODUCT_REVIEWS_TIMEOUT_SECOND = 	SystemConfig.getIntProp("IMPORT_A_PRODUCT_REVIEWS_TIMEOUT_SECOND");
			FETCH_BUYERIDS_TIMEOUT_SECOND  			=	SystemConfig.getIntProp("FETCH_BUYERIDS_TIMEOUT_SECOND");
			NUMBER_OF_IMPORTED_FOR_COMMIT_DB  		=	SystemConfig.getIntProp("NUMBER_OF_IMPORTED_FOR_COMMIT_DB");
			WEB_PAGE_LOAD_TIMOUT_SECOND  			=	SystemConfig.getIntProp("WEB_PAGE_LOAD_TIMOUT_SECOND");
			FETCH_BUYERID_PERIOD_SECOND  			=	SystemConfig.getIntProp("FETCH_BUYERID_PERIOD_SECOND");
			UPDATE_REVIEWS_ORDER_ID_PERIOD_SECOND  	=	SystemConfig.getIntProp("UPDATE_REVIEWS_ORDER_ID_PERIOD_SECOND");
			ORGANOZATION_ROOT_ID  					=	SystemConfig.getLongProp("ORGANOZATION_ROOT_ID");
			SYSTEM_USER_ID  						=	SystemConfig.getLongProp("SYSTEM_USER_ID");
			ENABLE_SYNC_REVIEW  					=	SystemConfig.getBooleanProp("ENABLE_SYNC_REVIEW");
			ENABLE_SYNC_ORDER  						=	SystemConfig.getBooleanProp("ENABLE_SYNC_ORDER");
			ENABLE_FETCH_ORDER_BUYER_ID  			=	SystemConfig.getBooleanProp("ENABLE_FETCH_ORDER_BUYER_ID");
			ENABLE_SEND_EMAILS  					=	SystemConfig.getBooleanProp("ENABLE_SEND_EMAILS");
			ENABLE_UPDATE_REVIEWS_ORDER_ID  		=	SystemConfig.getBooleanProp("ENABLE_UPDATE_REVIEWS_ORDER_ID");
			ENABLE_SEND_AMAZON_EMAIL  				=	SystemConfig.getBooleanProp("ENABLE_SEND_AMAZON_EMAIL");
			DATE_TO_SEND_NEGATIVE_REVIEW_EMAIL  	=	SystemConfig.getDateProp("DATE_TO_SEND_NEGATIVE_REVIEW_EMAIL");
			LAST_DAYS_TO_IMPORT_ORDER  				=	SystemConfig.getIntProp("LAST_DAYS_TO_IMPORT_ORDER");
			PER_ORDER_SERVICE_CALL_DELAY_SECONDS  	=	SystemConfig.getIntProp("PER_ORDER_SERVICE_CALL_DELAY_SECONDS");
			PER_BUYERID_PAGE_LOAD_SECONDS  			=	SystemConfig.getIntProp("PER_BUYERID_PAGE_LOAD_SECONDS");
			SEND_AMAZON_EMAIL_PERIOD_SECOND  		=	SystemConfig.getIntProp("SEND_AMAZON_EMAIL_PERIOD_SECOND");
			SEND_AMAZON_EMAIL_TIMEOUT_SECOND  		=	SystemConfig.getIntProp("SEND_AMAZON_EMAIL_TIMEOUT_SECOND");

			SYSTEM_EMAIL_SERVER                     =   SystemConfig.getProp("SYSTEM_EMAIL_SERVER");
			SYSTEM_EMAIL                            =   SystemConfig.getProp("SYSTEM_EMAIL");
			SYSTEM_EMAIL_USER                       =   SystemConfig.getProp("SYSTEM_EMAIL_USER");
			SYSTEM_EMAIL_PASS                       =   SystemConfig.getProp("SYSTEM_EMAIL_PASS");
			SYSTEM_EMAIL_USE_SSL                    =   SystemConfig.getBooleanProp("SYSTEM_EMAIL_USE_SSL");
			SYSTEM_EMAIL_SMTP_PORT                  =   SystemConfig.getProp("SYSTEM_EMAIL_SMTP_PORT");
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static Date getDateProp(String propName) {
		String s[] = getProp(propName).split("/");
		Calendar cal = Calendar.getInstance();
		cal.set(Integer.parseInt(s[0]), Integer.parseInt(s[1]) -1, Integer.parseInt(s[2]),0,0,0);
		return cal.getTime();
	}

	public static boolean getBooleanProp(String propName) {
		return "true".equals(properties.getProperty(propName).trim());
	}

	public static String getProp(String propName){
		return properties.getProperty(propName).trim();
	}
	
	public static long getLongProp(String propName){
		return Long.parseLong(properties.getProperty(propName).trim());
	}
	
	public static double getDoubleProp(String propName){
		return Double.parseDouble(properties.getProperty(propName).trim());
	}
	
	public static int getIntProp(String propName) {
		return Integer.parseInt(properties.getProperty(propName).trim());
	}
	
	public static Properties getProperties(){
		return properties;
	}
}