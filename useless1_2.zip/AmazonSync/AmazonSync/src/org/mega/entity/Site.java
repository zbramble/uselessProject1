package org.mega.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_SITE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_SITE", columnNames = "BSE_SITE_ID") )
public class Site extends BaseEntity{

	@Id
	@Column(name = "BSE_SITE_ID")
	private long rowId;
	
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Column(name = "SITE_NAME", length = 500,nullable = true)
	private String siteName;
	
	@Column(name = "BSE_CHANNEL_ID")
	private String channelId;
	
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "order_last_update", nullable = false, updatable = false)
    private Date orderLastUpdate;

	public Date getOrderLastUpdate() {
		return orderLastUpdate;
	}

	public void setOrderLastUpdate(Date orderLastUpdate) {
		this.orderLastUpdate = orderLastUpdate;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSiteName() {
		return siteName;
	}
	
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	
	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = "";
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = "";
    }

}
