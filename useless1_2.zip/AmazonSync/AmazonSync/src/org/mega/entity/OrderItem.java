package org.mega.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name="ORDER_ORDER_ITEM", uniqueConstraints = @UniqueConstraint(name = "PK_ORDER_ORDER_ITEM", columnNames = "ROW_ID"))
public class OrderItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ROW_ID")
	private Long rowId;
	
	@Column(name = "ORDER_ID")
	private long orderId;

	@Column(name = "CHANNEL_SKU_ID")
	private long channelSkuId;

	@Column(name = "CHANNEL_SKU")
	private String channelSku;
	
	@Column(name = "CHANNEL_ORDER_ITEM_ID")
	private String channelOrderItemId;
	
	@Column(name = "QUANTITY_SHIPPED")
	private int quantityShipped;
	
	@Column(name = "CURRENCY_ID")
	private String currencyId;

	@Column(name = "QUANTITY")
	private int quantity;
	
	@Column(name = "TAX_CURRENCY_ID")
	private String taxCurrencyId;
	
	@Column(name = "TAXT_AMOUNT")
	private double taxtAmount;
	

	public long getChannelSkuId() {
		return channelSkuId;
	}

	public void setChannelSkuId(long channelSkuId) {
		this.channelSkuId = channelSkuId;
	}

	public String getChannelOrderItemId() {
		return channelOrderItemId;
	}

	public void setChannelOrderItemId(String channelOrderItemId) {
		this.channelOrderItemId = channelOrderItemId;
	}

	public int getQuantityShipped() {
		return quantityShipped;
	}

	public void setQuantityShipped(int quantityShipped) {
		this.quantityShipped = quantityShipped;
	}


	public void setRowId(Long rowId) {
		this.rowId = rowId;
	}



	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	public String getTaxCurrencyId() {
		return taxCurrencyId;
	}

	public void setTaxCurrencyId(String taxCurrencyId) {
		this.taxCurrencyId = taxCurrencyId;
	}

	public double getTaxtAmount() {
		return taxtAmount;
	}

	public void setTaxtAmount(double taxtAmount) {
		this.taxtAmount = taxtAmount;
	}

	public String getChannelSku() {
		return channelSku;
	}

	public void setChannelSku(String channelSku) {
		this.channelSku = channelSku;
	}

	@Override
	public Long getRowId() {
		return rowId;
	}
	
	@Override
	@PrePersist
	public void prePersist() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = "" + channelSkuId;		
	}
	
	@Override
	@PreUpdate
	public void preUpdate() throws Exception {
	      fullTitle = "" + channelSkuId;		
	}

}
