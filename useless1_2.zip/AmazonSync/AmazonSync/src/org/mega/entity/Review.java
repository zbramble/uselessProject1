package org.mega.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;


/**
 * The persistent class for the RV_REVIEW database table.
 * 
 */
@Entity
@Table(name="RV_REVIEW", uniqueConstraints = @UniqueConstraint(name = "PK_RV_REVIEW", columnNames = "ID"))
@NamedQuery(name="Review.findAll", query="SELECT r FROM Review r")
public class Review extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private Long rowId;

	@Column(name="BUYER_INFO_MATCHED")
	private long buyerInfoMatched;

	@Column(name="CHANNEL_SKU_ID")
	private long channelSkuId;

	@Column(name="ORDER_ID", updatable=false)
	private Long order_id = null;
	
	private String content;

	@Column(name="CUSTOMER_ID")
	private String customerId;

	@Column(name="CUSTOMER_NAME")
	private String customerName;

	@Column(name="FULL_RATING")
	private double fullRating;

	@Column(name="HELPFUL_VOTES")
	private double helpfulVotes;

	@Column(name="ITEM_ID")
	private String itemId;

	@Column(name="LINK_ON_SITE")
	private String linkOnSite;

	@Column(name="PRODUCT_ID")
	private byte[] productId;

	private double rating;

	@Column(name="REAL_NAME")
	private String realName;

	private double responded;

	@Temporal(TemporalType.DATE)
	@Column(name="REVIEW_DATE")
	private Date reviewDate;

	@Column(name="REVIEW_ID")
	private String reviewId;

	@Column(name="SPECIFIC_NOTE")
	private String specificNote;

	@Column(name="STATUS_ID")
	private Long statusId;

	private String title;

	@Column(name="TOTAL_VOTES")
	private double totalVotes;

	@Column(name="VERIFIED_PURCHASE")
	private boolean verifiedPurchase;

	public Review() {
		this.rowId= null;
	}

	public Long getRowId() {
		return this.rowId;
	}

	public void setRowId(long id) {
		this.rowId = id;
	}


	public long getBuyerInfoMatched() {
		return this.buyerInfoMatched;
	}

	public void setBuyerInfoMatched(long buyerInfoMatched) {
		this.buyerInfoMatched = buyerInfoMatched;
	}

	public long getChannelSkuId() {
		return this.channelSkuId;
	}

	public void setChannelSkuId(long channelSkuId) {
		this.channelSkuId = channelSkuId;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getFullRating() {
		return this.fullRating;
	}

	public void setFullRating(double fullRating) {
		this.fullRating = fullRating;
	}

	public String getFullTitle() {
		return this.fullTitle;
	}

	public void setFullTitle(String fullTitle) {
		this.fullTitle = fullTitle;
	}

	public double getHelpfulVotes() {
		return this.helpfulVotes;
	}

	public void setHelpfulVotes(double helpfulVotes) {
		this.helpfulVotes = helpfulVotes;
	}


	public String getItemId() {
		return this.itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getLinkOnSite() {
		return this.linkOnSite;
	}

	public void setLinkOnSite(String linkOnSite) {
		this.linkOnSite = linkOnSite;
	}

	public byte[] getProductId() {
		return this.productId;
	}

	public void setProductId(byte[] productId) {
		this.productId = productId;
	}

	public double getRating() {
		return this.rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getRealName() {
		return this.realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public double getResponded() {
		return this.responded;
	}

	public void setResponded(double responded) {
		this.responded = responded;
	}

	public Date getReviewDate() {
		return this.reviewDate;
	}

	public void setReviewDate(Date reviewDate) {
		this.reviewDate = reviewDate;
	}

	public String getReviewId() {
		return this.reviewId;
	}

	public void setReviewId(String reviewId) {
		this.reviewId = reviewId;
	}

	public String getSpecificNote() {
		return this.specificNote;
	}

	public void setSpecificNote(String specificNote) {
		this.specificNote = specificNote;
	}

	

	public Long getStatusId() {
		return statusId;
	}

	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getTotalVotes() {
		return this.totalVotes;
	}

	public void setTotalVotes(double totalVotes) {
		this.totalVotes = totalVotes;
	}

	public boolean getVerifiedPurchase() {
		return this.verifiedPurchase;
	}

	public void setVerifiedPurchase(boolean verifiedPurchase) {
		this.verifiedPurchase = verifiedPurchase;
	}

	public Long getOrder_id() {
		return order_id;
	}

	public void setOrder_id(Long order_id) {
		this.order_id = order_id;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = title;
	}
	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle	 = title;	
	}

}