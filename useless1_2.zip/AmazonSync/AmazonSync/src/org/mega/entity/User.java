package org.mega.entity;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_USER", uniqueConstraints = {@UniqueConstraint(name = "PK_CO_USER", columnNames = "USER_ID"),
        @UniqueConstraint(name = "UK_USER_USERNAME", columnNames = "USERNAME")})
public class User extends BaseEntity {
    @Id
    @Column(name = "USER_ID")
    private long rowId;

    @Column(name = "FULL_NAME", nullable = false, length = 50)
    private String fullName;

    @Column(name = "COMPANY_NAME", nullable = false, length = 50)
    private String companyName;

    @Column(name = "USERNAME", nullable = false, length = 30)
    private String username;
    
    @Column(name = "USER_PASSWORD", nullable = false, length = 100, updatable = false)
    private String userPassword;

    @Column(name = "EMAIL", length = 100)
    private String email;

    @Column(name = "email_is_confirmed")
    private boolean emailIsConfirmed;
    
    @Column(name="FAILED_LOGIN")
    Integer failedLogin = 0;
    
    
    public Integer getFailedLogin() {
		return failedLogin;
	}

	public void setFailedLogin(Integer failedLogin) {
		this.failedLogin = failedLogin;
	}

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEmailIsConfirmed() {
        return emailIsConfirmed;
    }

    public void setEmailIsConfirmed(boolean emailIsConfirmed) {
        this.emailIsConfirmed = emailIsConfirmed;
    }

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = fullName + "(" + username + "}";
    }
	
	@PreUpdate
    @Override
    public void preUpdate() throws Exception {
        fullTitle = fullName + "(" + username + "}";
	}

}