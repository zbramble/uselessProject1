package org.mega.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "PRODUCT_CHANNEL_SKU", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_CHANNEL_SKU", columnNames = "PRODUCT_CHANNEL_SKU_ID") )
public class ProductChannelSKU extends BaseEntity{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3233650248920219150L;

	@Id
	@Column(name = "PRODUCT_CHANNEL_SKU_ID")
	private long rowId;
	
	@Column(name = "BSE_SITE_ID")
	private String siteId;
	
	@Column(name = "PRODUCT_ID")
	private String productId;
		
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Column(name = "SKU")
	private String SKU;
	
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_REVIEWS_UPDATED", nullable = false, updatable = false)
    private Date lastReviewsUpdated;

	@Column(name = "REVIEW_INFO")
	private String reviewInfo;
	
	public Date getLastReviewsUpdated() {
		return lastReviewsUpdated;
	}

	public void setLastReviewsUpdated(Date lastReviewsUpdated) {
		this.lastReviewsUpdated = lastReviewsUpdated;
	}

	public String getReviewInfo() {
		return reviewInfo;
	}

	public void setReviewInfo(String reviewInfo) {
		this.reviewInfo = reviewInfo;
	}

	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	
	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSKU() {
		return SKU;
	}

	public void setSKU(String SKU) {
		this.SKU = SKU;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = SKU;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = SKU;
    }
}
