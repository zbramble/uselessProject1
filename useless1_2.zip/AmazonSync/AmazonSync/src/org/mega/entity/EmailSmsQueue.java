package org.mega.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
/**
 * @author Golnari
 *
 */
@Entity
@Table(name="CORE_EMAIL_SMS_QUEUE", uniqueConstraints = @UniqueConstraint(name = "PK_EMAIL_SMS_QUEUE", columnNames = "ROW_ID"))
public class EmailSmsQueue extends BaseEntity implements Serializable {
	public enum TYPE {AMAZON_EMAIL, PUBLIC_EMAIL, SMS};

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ROW_ID")
	private Long rowId;
	
	@Column(name = "TYPE_ID")
	private Long typeId;
    
	@Column(name = "TITLE")
	private String title;
	
	@Column(name = "CONTENT")
	private String content;
	
	@Column(name = "TO_ADRESS")
	private String toAdress;
	
	@Column(name = "ERROR")
	private String error;

	public Long getTypeId() {
		return typeId;
	}

	public void setTypeId(Long typeId) {
		this.typeId = typeId;
	}

	public String getToAdress() {
		return toAdress;
	}

	public void setToAdress(String toAdress) {
		this.toAdress = toAdress;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setRowId(Long rowId) {
		this.rowId = rowId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	@Override
	public Long getRowId() {
		return rowId;
	}
	@Override
	@PrePersist
	public void prePersist() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = "" + typeId;		
	}
	
	@Override
	@PreUpdate
	public void preUpdate() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = "" + typeId;		
	}

}
