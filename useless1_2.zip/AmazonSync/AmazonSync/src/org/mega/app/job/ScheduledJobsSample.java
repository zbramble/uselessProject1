package org.mega.app.job;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class ScheduledJobsSample extends TimerTask {
	boolean testMode = true;
	public static void main(String[] args) {
		scheduleATask(true);
	}

	private static void scheduleATask(boolean isFirst) {
		TimerTask tasknew = new ScheduledJobsSample();
		Timer timer = new Timer();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());

		if(!isFirst || calendar.get(Calendar.HOUR_OF_DAY) > 6)
			calendar.add(Calendar.DAY_OF_MONTH, 1);//فردا ساعت 6 اجرا شود
		
		calendar.set(Calendar.HOUR_OF_DAY, 6);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		
		
		calendar.add(Calendar.SECOND, 5);
		
		timer.schedule(tasknew, calendar.getTime());
	}

	@Override
	public void run() {
		System.out.println("working on " + new Date().toString());
		System.out.println(this.scheduledExecutionTime());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		scheduleATask(false);
	}

}


