select TEAM_TITLE,SITE_NAME,FULL_TITLE,SKU,TARGET,CURRENT_RATE,ALL_REVIEW_COUNT,RISK_1_STAR,NEED_5_STAR,team.email team_manager_email
 from
(select team.TEAM_TITLE,team_ch.PRODUCT_CHANNEL_SKU,usr.email from PMT_MARKETING_TEAM team ,PMT_TEAM_CHANNEL team_ch, co_user usr where team_ch.team_id = team.team_id and team.user_id=usr.user_id ) team,
	(
	select PRODUCT_CHANNEL_SKU_ID,FULL_TITLE,sku,site_name,t target,cr current_rate,ac all_review_count,risk_neg, case when risk_neg=0 then '1' when risk_neg < 0 then 'Droped' else '' || ceil(risk_neg) end risk_1_star  , case when risk_neg < 0 then '' || ceil(risk_pos) else ' At risk' end need_5_star  
	from (
		select PRODUCT_CHANNEL_SKU_ID,FULL_TITLE,sku,site_name,t,cr,ac , (t * ac - ac * cr) / (1 - t) risk_neg, (t * ac - ac * cr) / (5 - t) risk_pos from(
		select chann_sku.PRODUCT_CHANNEL_SKU_ID,chann_sku.FULL_TITLE,chann_sku.sku,site.site_name, chann_sku.REVIEW_RATE cr, chann_sku.ALL_REVIEW_COUNT ac, setting.REVIEW_TARGET t 
			from (select PRODUCT_CHANNEL_SKU_ID,FULL_TITLE,sku,BSE_SITE_ID,REVIEW_RATE,ALL_REVIEW_COUNT from Product_Channel_SKU where ACCESS_KEY like '%%%') chann_sku 
				left join PMT_REVIEW_TARGET_SETTING setting on setting.PRODUCT_CHANNEL_SKU_ID = chann_sku.PRODUCT_CHANNEL_SKU_ID
				join BSE_SITE site on site.BSE_SITE_ID = chann_sku.BSE_SITE_ID
		) 
	)
)performance
where team.PRODUCT_CHANNEL_SKU = performance.PRODUCT_CHANNEL_SKU_ID
order by TEAM_TITLE,risk_neg