package org.mega.app.job;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.persistence.Query;

import org.mega.core.base.BaseDB;
import org.mega.util.AttachFile;
import org.mega.util.DateUtil;
import org.mega.util.ExcelUtil;
import org.mega.util.IOUtil;
import org.mega.util.WebUtil;

import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class TeamReviewDropRiskReportJob extends TimerTask {
	static boolean testMode = false;
	public static void main(String[] args) {
		scheduleATask(true);
	}

	public static void scheduleATask(boolean isFirst) {
		TimerTask tasknew = new TeamReviewDropRiskReportJob();
		Timer timer = new Timer();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		if(!testMode || !isFirst){
			if(!isFirst || calendar.get(Calendar.HOUR_OF_DAY) > 6)
				calendar.add(Calendar.DAY_OF_MONTH, 1);//فردا ساعت 6 اجرا شود
			
			calendar.set(Calendar.HOUR_OF_DAY, 6);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
		}
		timer.schedule(tasknew, calendar.getTime());
	}

	@Override
	public void run() {
		System.out.println("Make and email team drop review risk " + new Date().toString());
		job();
		scheduleATask(false);
	}

	private void job() {
		BaseDB db = null;
		try{
			db = BaseDB.open("TeamReviewDropRiskReportJob", 3600);
			String sql = IOUtil.readAndCloseStream(this.getClass().getResourceAsStream("team_review_drop_risk.sql"), "utf-8");
			Query query = db.createNativeQuery(sql);
			List<Object[]> list = query.getResultList();
			
			String[] header = {"TEAM TITLE","SITE NAME", "FULL TITLE" , "SKU" , "TARGET", "CURRENT RATE", "ALL REVIEW COUNT"
					, "RISK 1 STAR"	, "NEED 5 STAR"	, "TEAM MANAGER EMAIL"};
		
			List<Object[]> teamList = new ArrayList<>();
			String teamName = null;
			for(Object[] row: list){
				if(((String) row[0]).equals(teamName) )
					teamList.add(row);
				else{
					if(teamName != null)
						sendTeamEmail(teamList);
					teamName = (String) row[0];
					teamList.clear();
					teamList.add(header);
					teamList.add(row);
				}
			}
			if(teamList.size() > 1)
				sendTeamEmail(teamList);
			db.commitAndclose();
		}catch (Exception e) {
			db.finalize();
			e.printStackTrace();
		}
	}

	private void sendTeamEmail(List<Object[]> teamList) throws RowsExceededException, WriteException, IOException {
		Date today = DateUtil.today(0, true);
		String day =(1900+ today.getYear()) + "-" + (today.getMonth()+1)+"-" + today.getDate();
		String fileName = "team_review_drop_risk_" + day ;

		byte[] attach = ExcelUtil.toExcel(teamList, fileName);
		AttachFile attachFile = new AttachFile(attach, fileName + ".xls", "application/vnd.ms-excel");
		List<AttachFile> attaches = new ArrayList<AttachFile>();
		attaches.add(attachFile);
		String emailText = "Dear team <b>" + (String)teamList.get(1)[0] + "</b>,<br>" +
							"Please find attached document containing products Rated under Target or at Risk of drop for  Date " + day +
							"<br>Best regards<br><b>MILO Marketing Suite</b>";
		 
		WebUtil.sendEmailByAttach((String)teamList.get(1)[9], "Team review drop risk " + day, emailText, attaches);
	}

}


