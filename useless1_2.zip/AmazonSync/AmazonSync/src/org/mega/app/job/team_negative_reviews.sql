  select 
   t.TEAM_TITLE,t.email,site.site_name,p.full_title product,r.rating,to_char(r.review_date,'YYYY/MM/DD') review_date,r.customer_name,r.LINK_ON_SITE
   from (select distinct team.team_id,team.TEAM_TITLE,team_ch.PRODUCT_CHANNEL_SKU,usr.email,nvl(team.last_negative_report_sent, sysdate - 1) last_negative_report_sent from PMT_MARKETING_TEAM team ,PMT_TEAM_CHANNEL team_ch,
   			co_user usr where team_ch.team_id = team.team_id and team.user_id=usr.user_id ) t
  JOIN RV_REVIEW r on (r.REVIEW_DATE > t.last_negative_report_sent and  r.channel_sku_id = t.PRODUCT_CHANNEL_SKU)
  JOIN PRODUCT_CHANNEL_SKU p on p.PRODUCT_CHANNEL_SKU_ID=t.PRODUCT_CHANNEL_SKU
  JOIN BSE_SITE site on p.BSE_SITE_ID=site.BSE_SITE_ID
  JOIN PMT_REVIEW_TARGET_SETTING s on
      (
         p.PRODUCT_CHANNEL_SKU_ID = s.PRODUCT_CHANNEL_SKU_ID
         and r.rating < s.REVIEW_TARGET
      )
ORDER BY team_title,site_name
