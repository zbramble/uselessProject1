package org.mega;

import java.util.Calendar;
import java.util.Iterator;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.entity.EmailSmsQueue;
import org.mega.util.WebUtil;

public class SendPublicEmails implements Runnable{

	@Override
	public void run() {
		while(true){
			if(!SystemConfig.ENABLE_SEND_EMAILS){
				try {Thread.sleep(60000);} catch (InterruptedException e) {	e.printStackTrace();}
				continue;
			}
			
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			try {
				System.out.println("----------------------------------------- Email sending ... " + cal.getTime().toLocaleString() + " ------------------------------------------------");
				sendEmails();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {Thread.sleep(SystemConfig.ORDER_IMPORT_PERIOD_SECOND * 1000);	} catch (InterruptedException e) {	e.printStackTrace();}
			cal.setTimeInMillis(System.currentTimeMillis());
			System.out.println("Review importing end: " + cal.getTime().toLocaleString());

		}
	}

	private void sendEmails() {
		BaseDB db = null;
		try {
			db = BaseDB.open("send email", 360);
			Iterator<EmailSmsQueue> iter =  db.createQuery("select e from EmailSmsQueue e where typeId= " + EmailSmsQueue.TYPE.PUBLIC_EMAIL.ordinal() +" and deleted = 0 ").getResultList().iterator();
			while(iter.hasNext()){
				EmailSmsQueue e = iter.next();
				try{
					WebUtil.sendEmail(e.getToAdress(), e.getTitle(), e.getContent());
				}catch (Exception ex) {
					String error = ex.getMessage() != null ? ex.getMessage().replaceAll("'","") : "";
					if(error != null && error.length() > 2000)
						error = error.substring(0,  2000);
					db.runQuery("update EmailSmsQueue e set e.deleted = e.rowId , e.updated = sysdate, e.error='Error:" + error + "' where e.rowId =" + e.getRowId());
					continue;
				}
				db.runQuery("update EmailSmsQueue e set e.deleted = e.rowId , e.updated = sysdate where e.rowId =" + e.getRowId());
			}
			db.commitAndclose();
		} catch (Exception e) {
			e.printStackTrace();
			try {db.rollbackAndClose();} catch (Exception e1) {
			}
		}
	}


}
