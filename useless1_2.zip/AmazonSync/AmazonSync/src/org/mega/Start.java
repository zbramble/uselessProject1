package org.mega;

import org.mega.amazon.order.ImportAmazonOrders;
import org.mega.amazon.review.ImportAmazonReviews;
import org.mega.core.SystemConfig;

public class Start {
	public static void main(String[] args) {
		System.out.println("Amazon synchronization starting ...");
		SystemConfig.init();
		
		new Thread(new ImportAmazonReviews()).start();
		new Thread(new ImportAmazonOrders()).start();
		new Thread(new SendPublicEmails()).start();

	}
}
