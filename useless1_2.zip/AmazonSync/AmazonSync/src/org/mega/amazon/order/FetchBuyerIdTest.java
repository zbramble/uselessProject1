package org.mega.amazon.order;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.print.DocFlavor.STRING;

import org.mega.core.SystemConfig;
import org.mega.util.WebUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FetchBuyerIdTest {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException {
		List<String> orders = new ArrayList<>();
		orders.add("114-5612044-7817866");
		orders.add("112-2432897-1839425");
		orders.add("114-3888110-2311400");
		orders.add("114-8491121-7560233");
		orders.add("114-0781445-2001855");
		orders.add("114-9603389-3185809");
		orders.add("111-1924101-6965848");
		orders.add("113-6541886-7055437");
		orders.add("112-4607650-1816223");
		orders.add("114-3117704-8616260");
		orders.add("114-6655619-9480267");
		orders.add("113-9085568-9777860");
		orders.add("113-1607578-0328247");
		orders.add("112-2827194-9107438");
		orders.add("113-7365185-7748238");
		orders.add("114-1674359-0864240");
		orders.add("111-5362119-9108254");
		orders.add("111-5362119-9108254");
		orders.add("112-5980274-2033821");
		orders.add("112-5980274-2033821");
		orders.add("113-7419819-8449840");

		SystemConfig.init();
		WebDriver driver = WebUtil.getWebDriver();

        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		while(orders.size() > 0){
	        String orderId = orders.get(0);
	        System.out.println(orders.size());
	        System.out.println("Fetch buyerId of " + orderId);
			driver.get("https://sellercentral.amazon.com/hz/orders/details?_encoding=UTF8&orderId="  + orderId );
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			List<WebElement> elements = driver.findElements(By.id("buyerId"));
			if(elements.size() == 0){//صفحه سفارش نیست
				//چک کند صفحه لاگین است
				elements = driver.findElements(By.xpath(".//*[@id='ap_email']"));
				if(elements.size() == 0){//صفحه لاگین نیست
					//چک کند صفحه فعال سازی لاگین دو مرحله ایست
					elements = driver.findElements(By.id("merchant-picker-btn-skip-for-now-announce"));
					if(elements.size() == 0){//لاگین دو مرحله ای نیست
					//دوباره از بالا بیاید
					}else{
						elements.get(0).click();
						wait.wait(10);
					}
				}else{//صفحه لاگین است 
					driver.findElement(By.xpath(".//*[@id='ap_email']")).sendKeys(new CharSequence[] {"anthony@pestnoproblem.com" });
					driver.findElement(By.xpath(".//*[@id='ap_password']")).sendKeys(new CharSequence[] { "Ajkml@5896" });
					driver.findElement(By.xpath(".//*[@id='signInSubmit']")).click();
				}
			}else{//صفحه سفارش است
				String byerId = elements.get(0).getAttribute("value");
				System.out.println(orderId + "\t" + byerId);
				orders.remove(0);
			}
		}
		
	}
}
