package org.mega.amazon.order;

public class Config {
    /** Developer AWS access key. */
    public static final String accessKey = "AKIAJMKWZYV5KHZW6O2A";

    /** Developer AWS secret key. */
    public static final String secretKey = "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";

    /** The client application name. */
    public static final String productAppName = "Products";
    public static final String reportAppName = "Reports";
    public static final String ordersAppName = "Orders";

    /** The client application version. */
    public static final String productAppVersion = "2011-10-01";
    public static final String reportAppVersion = "2009-01-01";
    public static final String orderAppVersion = "20213-09-01";

    /**
     * The endpoint for region service and version.
     * ex: serviceURL = MWSEndpoint.NA_PROD.toString();
     */
    public static final String productServiceURL = "https://mws.amazonservices.com/Products/2011-10-01";
    public static final String reportServiceURL = "https://mws.amazonservices.com/Reports/2009-01-01";
    public static final String orderServiceURL = "https://mws.amazonservices.com/Orders/2013-09-01";
    
    public static final String endPoint = "https://mws.amazonservices.com";

    
    public static final String sellerId = "A1JF0FEJIRJQ6I";

    public static final String marketplaceId = "ATVPDKIKX0DER";

}
