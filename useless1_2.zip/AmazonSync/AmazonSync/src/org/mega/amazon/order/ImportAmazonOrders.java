package org.mega.amazon.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.xml.datatype.XMLGregorianCalendar;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.entity.OrderItem;
import org.mega.entity.User;
import org.mega.util.DateUtil;

import com.amazonservices.mws.orders._2013_09_01.MarketplaceWebServiceOrdersAsyncClient;
import com.amazonservices.mws.orders._2013_09_01.MarketplaceWebServiceOrdersClient;
import com.amazonservices.mws.orders._2013_09_01.MarketplaceWebServiceOrdersConfig;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrderItemsRequest;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrderItemsResponse;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrdersByNextTokenRequest;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrdersByNextTokenResponse;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrdersByNextTokenResult;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrdersRequest;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrdersResponse;
import com.amazonservices.mws.orders._2013_09_01.model.ListOrdersResult;
import com.amazonservices.mws.orders._2013_09_01.model.Order;
import com.amazonservices.mws.orders._2013_09_01.model.ResponseHeaderMetadata;
/**
 * @author Golnari
 *
 */
public class ImportAmazonOrders implements Runnable{
	private static final long SITE_ID = 10001L;
	static boolean breakTag = false;
	private boolean testMode = false;
	
	@Override
	public void run() {
		while (true) {
			//Check to synchronize amazon orders
			if(!SystemConfig.ENABLE_SYNC_ORDER){
				try {Thread.sleep(60000);} catch (InterruptedException e) {	e.printStackTrace();}
				continue;
			}
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			try {
				System.out.println("----------------------------------------- Order importing ... " + cal.getTime().toLocaleString() + " ------------------------------------------------");
				importOrders();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {Thread.sleep(SystemConfig.ORDER_IMPORT_PERIOD_SECOND * 1000);	} catch (InterruptedException e) {	e.printStackTrace();}
			cal.setTimeInMillis(System.currentTimeMillis());
			System.out.println("Order importing end: " + cal.getTime().toLocaleString());

		}
	}

	private void importOrders() {
		BaseDB db = null;
		try {
			
            MarketplaceWebServiceOrdersConfig config = new MarketplaceWebServiceOrdersConfig();
            config.setServiceURL(Config.orderServiceURL);
            
			MarketplaceWebServiceOrdersClient client = new MarketplaceWebServiceOrdersAsyncClient(Config.accessKey, Config.secretKey, 
					Config.ordersAppName, Config.orderAppVersion, config, null);

	        // Create a request.
	        ListOrdersRequest request = new ListOrdersRequest();
	        
	        String sellerId = Config.sellerId;
	        request.setSellerId(sellerId);
	        
	        List<String> marketplaceIDs = new ArrayList<String>();
	        marketplaceIDs.add(Config.marketplaceId);
	        
	        request.setMarketplaceId(marketplaceIDs);
	        
	        db = BaseDB.open("Import orders", 60 * 60);// 1 hour
        	
	        //استخراج آخرین زمان به روز کردن سفارشات سایت - سفارشات روزانه دریافت و دربانک ذخیره می شود یعنی هر دفعه فقط سفارشات یک روز از آمازون دریافت می شود
	        Query query = db.createQuery("select e.orderLastUpdate from Site e where e.rowId=:siteId");
	        query.setParameter("siteId", SITE_ID);
	        Date lastUpdatedAfter = null;
	        
	        List list = query.getResultList();
        	if(list.get(0) != null){//دفعه اول نال است
        		lastUpdatedAfter = (Date)list.get(0);
        	}else{
        		//lastUpdatedAfter = DateUtil.today(-1 * SystemConfig.LAST_DAYS_TO_IMPORT_ORDER, true);
        		lastUpdatedAfter = DateUtil.today(-1 , true);
        	}
	       
	        Calendar calendar = Calendar.getInstance();
	        calendar.setTime(lastUpdatedAfter);
	        calendar.add(Calendar.HOUR_OF_DAY, 6);//سفارشات 6 ساعت را فقط
	        Date lastUpdatedBefore = calendar.getTime();
	
	        calendar.add(Calendar.HOUR_OF_DAY, -6);
	        calendar.add(Calendar.MINUTE, -1);//احتیاطا 1 دیقه قبلش را هم بیاورد
	        lastUpdatedAfter = calendar.getTime();
	        
	        // اگر به زمان الان رسیده باشد تا 1 دقیقه قبل را بیاورد
	        calendar.setTimeInMillis(System.currentTimeMillis());
	        calendar.add(Calendar.HOUR_OF_DAY, -6);//calendar.getTime()
	        if(calendar.getTime().after(lastUpdatedBefore))//اگر به روز جاری رسید دیگر آخر زمان بازه را نبندد بلکه از داده های آمده چک کند جدیدترینش را بردارد در خطوط بعدی آخرین به روز را برمیدارد
	        	request.setLastUpdatedBefore(DateUtil.getXMLGerCalendar(lastUpdatedBefore, 0));
	        else
	        	lastUpdatedBefore = lastUpdatedAfter;
	        request.setLastUpdatedAfter(DateUtil.getXMLGerCalendar(lastUpdatedAfter, 0));
	 
	        System.out.println("Order request last upcate after : " + lastUpdatedAfter);
	        System.out.println("Order request last upcate before: " + lastUpdatedBefore);
	        // Make the call.
           ListOrdersResponse response = client.listOrders(request);
            ResponseHeaderMetadata rhmd = response.getResponseHeaderMetadata();
            // We recommend logging every the request id and timestamp of every call.
            System.out.println("Response:");
            System.out.println("RequestId: "+rhmd.getRequestId());
            System.out.println("Request Time stamp: "+rhmd.getTimestamp());
            
            ListOrdersResult listOrdersResult = response.getListOrdersResult();
            String nextToken = listOrdersResult.getNextToken();
            
			List<Order> orders = listOrdersResult.getOrders();
			System.out.println("Orders:" + orders.size());
			int testCount =0;
			while(orders.size() > 0) {
				for(Order order:orders){
					Thread.sleep(SystemConfig.PER_ORDER_SERVICE_CALL_DELAY_SECONDS * 1000);
					testCount++;
					if(testMode  && testCount > 5)
						break;
	            	System.out.println(order.getBuyerEmail() + "\t\t" + order.getBuyerName());
	            	org.mega.entity.Order orderEntity = new org.mega.entity.Order(); 
	            	orderEntity.setSiteId(SITE_ID);
	            	orderEntity.setBuyerEmail(order.getBuyerEmail());
	            	orderEntity.setChannelOrderId(order.getAmazonOrderId());
	            	orderEntity.setBuyerName(order.getBuyerName());
	            	orderEntity.setOrderStatus(order.getOrderStatus());
	            	orderEntity.setOrderType(order.getOrderType());
	            	orderEntity.setSellerOrderId(order.getSellerOrderId());
	            	orderEntity.setPurchaseDate(DateUtil.xmlGeragurianToDate(order.getPurchaseDate()));
	            	orderEntity.setEarliestDeliveryDate(DateUtil.xmlGeragurianToDate(order.getEarliestDeliveryDate()));
	            	orderEntity.setLastUpdateDate(DateUtil.xmlGeragurianToDate(order.getLastUpdateDate()));
	            	if(orderEntity.getLastUpdateDate().after(lastUpdatedBefore))
	            		lastUpdatedBefore = orderEntity.getLastUpdateDate();
	            	orderEntity.setPurchaseDate(DateUtil.xmlGeragurianToDate(order.getPurchaseDate()));
	            	
	            	orderEntity.setActive(true);
	            	Date now = new Date(System.currentTimeMillis());
					
					User user = new User(); 
					user.setRowId(SystemConfig.SYSTEM_USER_ID);
					
					orderEntity.setCreatedBy(user);
					orderEntity.setUpdatedBy(user);
					
	            	query = db.createNativeQuery("select row_id from ORDER_ORDER where CHANNEL_ORDER_ID=:channelOrderId and SITE_ID=:siteId");
	            	query.setParameter("channelOrderId", orderEntity.getChannelOrderId());
	            	query.setParameter("siteId", SITE_ID);
	            	list = query.getResultList();
	            	if(list.size() != 0){
	            		long orderId = ((BigDecimal)list.get(0)).longValue();
	            		orderEntity.setRowId(orderId);
	            		//TODO بعد باید در کویری بالا تاریخ ایجاد فج شود و در موجودیت تنظیم شود
						orderEntity.setCreated(now);
						orderEntity.setUpdated(now);

	            		db.merge(orderEntity);
	            	}else{
						orderEntity.setCreated(now);
						orderEntity.setUpdated(now);
	            		db.persist(orderEntity);
	            	}
	            	//Get orders items
		            
	            	ListOrderItemsRequest orderItemRequest = new ListOrderItemsRequest();
	            	orderItemRequest.setAmazonOrderId(order.getAmazonOrderId());
	            	orderItemRequest.setSellerId(Config.sellerId);
	            	
	            	ListOrderItemsResponse itemsResponse = client.listOrderItems(orderItemRequest);
	            	
	            	for(com.amazonservices.mws.orders._2013_09_01.model.OrderItem item: itemsResponse.getListOrderItemsResult().getOrderItems()){
		            	OrderItem orderItem = new OrderItem();
		            	orderItem.setOrderId(orderEntity.getRowId());
		            	orderItem.setActive(true);
		            	orderItem.setQuantity(item.getQuantityOrdered());
		            	orderItem.setChannelOrderItemId(item.getOrderItemId());
		            	//orderItem.setCurrencyId(Integer.parseInt(item.getPromotionDiscount().getCurrencyCode());
		            	orderItem.setActive(true);
		            	orderItem.setCreated(now);
		            	orderItem.setUpdated(now);
		            	orderItem.setCreatedBy(user);
		            	orderItem.setUpdatedBy(user);
		            	
		            	query = db.createNativeQuery("select e.PRODUCT_CHANNEL_SKU_ID from PRODUCT_CHANNEL_SKU e where e.sku =:sku and BSE_SITE_ID= :siteId");
		            	query.setParameter("sku", item.getASIN());
		            	query.setParameter("siteId", SITE_ID);
		            	list = query.getResultList();
		            	if(list.size() == 0)
		            		continue;
		            	long channelSkuId = ((BigDecimal)list.get(0)).longValue();
		            	orderItem.setOrderId(orderEntity.getRowId());
		            	orderItem.setChannelSkuId(channelSkuId);
		            	
		            	query = db.createNativeQuery("select row_id from ORDER_ORDER_ITEM where CHANNEL_ORDER_ITEM_ID=:channelOrderItemId and CHANNEL_SKU_ID=:channelSkuId");
		            	query.setParameter("channelOrderItemId", orderItem.getChannelOrderItemId());
		            	query.setParameter("channelSkuId", channelSkuId);
		            	list = query.getResultList();
		            	if(list.size() != 0){
		            		long orderItemId = ((BigDecimal)list.get(0)).longValue();
		            		orderItem.setRowId(orderItemId);
		            		db.merge(orderItem);
		            	}else{
		            		db.persist(orderItem);
		            	}

	            	}
	            }
				if(testMode  && testCount > 3)
					break;
				if(nextToken != null){
					ListOrdersByNextTokenRequest byNextTokenRequest = new ListOrdersByNextTokenRequest();
					byNextTokenRequest.setNextToken(nextToken);
					byNextTokenRequest.setSellerId(sellerId);
					
					ListOrdersByNextTokenResult byNextTokenResult = client.listOrdersByNextToken(byNextTokenRequest).getListOrdersByNextTokenResult();
					orders = byNextTokenResult.getOrders();
					nextToken = byNextTokenResult.getNextToken();
				}else
					orders = new ArrayList<>();
				
			}
	        query = db.createQuery("update Site e set e.orderLastUpdate=:orderLastUpdate where e.rowId=:siteId");
	        query.setParameter("orderLastUpdate", lastUpdatedBefore);
	        query.setParameter("siteId", SITE_ID);
	        query.executeUpdate();
	        
			db.commitAndclose();
		} catch (Exception e) {
			e.printStackTrace();
			try {db.rollbackAndClose();} catch (Exception e1) {	}
		}
	}

}
