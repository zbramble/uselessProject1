package org.mega.amazon.order;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.util.WebUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FetchOrderBuyerIdJob implements Callable<Integer> {
	String accessKey;
	private Set<String> orders;
	private BaseDB db;
	private WebDriver driver;
	
	public FetchOrderBuyerIdJob(Iterator rows, String accessKey, BaseDB baseDB, WebDriver driver) {
		this.accessKey = accessKey;
		this.db = baseDB;
		this.orders = new HashSet<String>();
		
		while(rows.hasNext()){
			Object[] row = (Object[]) rows.next();
			orders.add( (String)row[2]);
		}
		this.driver = driver;
/*
		if(orders.size() > 0){
			driver = WebUtil.getWebDriver();
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			this.driver = driver;
		}else
			this.driver = null;*/
	}

	@Override
	public Integer call() throws Exception {
		return fetchBuyerId();
	}

	private Integer fetchBuyerId() throws Exception {
		while(orders.size() > 0){
	        String orderId = (String) orders.toArray()[0];
	        System.out.println("Fetch buyerId of " + orderId + "\t\t Queue size:" +orders.size());
			driver.get("https://sellercentral.amazon.com/hz/orders/details?_encoding=UTF8&orderId="  + orderId );
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			List<WebElement> elements = driver.findElements(By.id("buyerId"));
			if(elements.size() == 0){//صفحه سفارش نیست
				//چک کند صفحه لاگین است
				elements = driver.findElements(By.xpath(".//*[@id='ap_email']"));
				if(elements.size() == 0){//صفحه لاگین نیست
					//چک کند صفحه فعال سازی لاگین دو مرحله ایست
					elements = driver.findElements(By.id("merchant-picker-btn-skip-for-now-announce"));
					if(elements.size() == 0){//لاگین دو مرحله ای نیست
					//دوباره از بالا بیاید
					}else{
						elements.get(0).click();
						wait.wait(10);
					}
				}else{//صفحه لاگین است 
					driver.findElement(By.xpath(".//*[@id='ap_email']")).sendKeys(new CharSequence[] {"anthony@pestnoproblem.com" });
					driver.findElement(By.xpath(".//*[@id='ap_password']")).sendKeys(new CharSequence[] { "Ajkml@5896" });
					driver.findElement(By.xpath(".//*[@id='signInSubmit']")).click();
				}
			}else{//صفحه سفارش است
				String byerId = elements.get(0).getAttribute("value");
				System.out.println(orderId + "\t" + byerId);
				orders.remove(orderId);
				db.runNativeQuery("update order_order set buyer_id = '" + byerId + "' where channel_order_id = '" + orderId +"'");
			}
			Thread.sleep(SystemConfig.PER_BUYERID_PAGE_LOAD_SECONDS * 1000);
		}
		try{driver.quit();}catch (Exception e) {	}
		return 1;
	}

}
