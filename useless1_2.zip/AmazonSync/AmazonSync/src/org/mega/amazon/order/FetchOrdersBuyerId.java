package org.mega.amazon.order;

import java.util.Calendar;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.persistence.Query;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.util.WebUtil;
import org.openqa.selenium.WebDriver;
/**
 * Set  -Dphantomjs.binary.path=D:/workspace/seleniumProj/other/phantomjs.exe
 * @author Golnari
 *
 */
public class FetchOrdersBuyerId implements Runnable{
	static boolean breakTag = false;
	
	@Override
	public void run() {
		while (true) {
			//Check to synchronize amazon reviews
			if(!SystemConfig.ENABLE_FETCH_ORDER_BUYER_ID){
				try {Thread.sleep(60000);} catch (InterruptedException e) {	e.printStackTrace();}
				continue;
			}
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			try {
				System.out.println("----------------------------------------- Fetch BuyerId ... " + cal.getTime().toLocaleString() + " ------------------------------------------------");
				fetch();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {Thread.sleep(SystemConfig.FETCH_BUYERID_PERIOD_SECOND * 1000);	} catch (InterruptedException e) {	e.printStackTrace();}
			cal.setTimeInMillis(System.currentTimeMillis());
			System.out.println("Fetch BuyerId end: " + cal.getTime().toLocaleString());

		}
	}

	private void fetch() {
		BaseDB baseDB = null;
		WebDriver driver = null;

		try {
			baseDB = BaseDB.open("Fetch buyerId ", 60 * 60);// 1 hour
			Query query = baseDB.createNativeQuery("select DISTINCT o.ROW_ID,o.BUYER_EMAIL,o.CHANNEL_ORDER_ID,o.updated, i.CHANNEL_SKU_ID,site.site_name from(select ROW_ID,BUYER_EMAIL,CHANNEL_ORDER_ID,updated  from ORDER_ORDER where BUYER_EMAIL is not null and BUYER_ID is null" + 
						") o,	ORDER_ORDER_ITEM i, PRODUCT_CHANNEL_SKU s, BSE_SITE site " + 
						" where o.row_id=i.order_id and s.PRODUCT_CHANNEL_SKU_ID = i.CHANNEL_SKU_ID and s.IMPORT_SITE_ID = site.BSE_SITE_ID  and rownum <= 50 " + 
						" order by o.updated");

			System.out.println("***************************** Fetch BuyerId channel orders *************************");

			driver = WebUtil.getWebDriver();
			driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
			
			FetchOrderBuyerIdJob  fetchAnOrderBuyerId = new FetchOrderBuyerIdJob(query.getResultList().iterator(), "", baseDB, driver);
			
			ExecutorService executor = Executors.newFixedThreadPool(1);
			Future<Integer> future = executor.submit(fetchAnOrderBuyerId);
			executor.shutdown();
			try{
				future.get(SystemConfig.FETCH_BUYERIDS_TIMEOUT_SECOND, TimeUnit.SECONDS);
			}catch (Exception e) {
				executor.shutdownNow();
				throw e;
			}
			baseDB.commitAndclose();
			try {driver.quit();} catch (Exception e1) {	}
		} catch (Exception e) {
			e.printStackTrace();
			try {baseDB.commitAndclose();} catch (Exception e1) {baseDB.finalize();	}
			try {driver.quit();} catch (Exception e1) {	}
		}
	}

}
