package org.mega.amazon.order;

import org.mega.core.SystemConfig;
import org.mega.util.WebUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FindMatches {
	public static void main(String[] args) {
		SystemConfig.init();
		WebDriver driver = WebUtil.getWebDriver();
	    driver.get("https://sellercentral.amazon.com");
	    WebElement myDynamicElement = (WebElement)new WebDriverWait(driver, 20L).until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='ap_email']")));
	    
	    driver.findElement(By.xpath(".//*[@id='ap_email']")).sendKeys(new CharSequence[] {"michael.liu01@gmail.com" });
	    driver.findElement(By.xpath(".//*[@id='ap_password']")).sendKeys(new CharSequence[] { "Ajkml@5896" });
	    
	   driver.findElement(By.xpath(".//*[@id='signInSubmit']")).click();
	}
}
