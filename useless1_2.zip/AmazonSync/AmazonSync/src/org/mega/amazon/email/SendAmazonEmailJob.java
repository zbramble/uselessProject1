package org.mega.amazon.email;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.entity.EmailSmsQueue;
import org.mega.util.WebUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SendAmazonEmailJob implements Callable<Integer> {
	String accessKey;
	private List<EmailSmsQueue> emails;
	private BaseDB db;
	private WebDriver driver;
	
	public SendAmazonEmailJob(List<EmailSmsQueue> emails, String accessKey, BaseDB baseDB, WebDriver driver) {
		this.accessKey = accessKey;
		this.db = baseDB;
		this.emails = emails;
		this.driver = driver;
		
/*		if(emails.size() > 0){
			driver = WebUtil.getWebDriver();
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			this.driver = driver;
		}else
			this.driver = null;*/
	}

	@Override
	public Integer call() throws Exception {
		return sendEmails();
	}

	private Integer sendEmails() throws Exception {
		while(emails.size() > 0){
	        EmailSmsQueue email = emails.get(0);
	        System.out.println("Send email to " + email.getToAdress() + "\t\t Queue size:" + emails.size());
			driver.get("https://sellercentral.amazon.com/gp/help/contact/contact.html?orderID="  + email.getTitle() );//در ایمیل آمازون شناسه سفارش را در عنوان ایمیل گذاشتم
			WebDriverWait wait = new WebDriverWait(driver, 30);
			
			List<WebElement> elements = driver.findElements(By.id("commMgrCompositionSubject"));//موضوع ایمیل در صفحه ارسال ایمیل
			if(elements.size() == 0){//صفحه ارسال ایمیل  نیست
				//چک کند صفحه لاگین است
				elements = driver.findElements(By.xpath(".//*[@id='ap_email']"));
				if(elements.size() == 0){//صفحه لاگین نیست
					//چک کند صفحه فعال سازی لاگین دو مرحله ایست
					elements = driver.findElements(By.id("merchant-picker-btn-skip-for-now-announce"));
					if(elements.size() == 0){//لاگین دو مرحله ای نیست
					//دوباره از بالا بیاید
					}else{
						elements.get(0).click();
						wait.wait(10);
					}
				}else{//صفحه لاگین است
					driver.get("https://sellercentral.amazon.com");//اگر مستقیم وارد صفحه لاگین نشیم کپچا نشون میده
					wait = new WebDriverWait(driver, 30);
					driver.findElement(By.xpath(".//*[@id='ap_email']")).sendKeys(new CharSequence[] {"anthony@pestnoproblem.com" });
					driver.findElement(By.xpath(".//*[@id='ap_password']")).sendKeys(new CharSequence[] { "Ajkml@5896" });
					driver.findElement(By.xpath(".//*[@id='signInSubmit']")).click();
				}
			}else{//صفحه ارسال ایمیل است
				elements.get(0).sendKeys(new CharSequence[] { "Feedback Request" });
				driver.findElement(By.id("commMgrCompositionMessage")).sendKeys(new CharSequence[] {email.getContent()});
				new WebDriverWait(driver, 10);
				
				WebElement sendEmail = (WebElement)new WebDriverWait(this.driver, 60L).until(
						 ExpectedConditions.presenceOfElementLocated(By.xpath("(.//button[@id='sendemail' and @name='sendemail' and @class='awesomeButton buttonLarge primaryLargeButton'])[2]")));
				sendEmail.click();
				emails.remove(0);
				db.runQuery("update EmailSmsQueue e set e.deleted = '" + email.getRowId() + "' where e.rowId = '" + email.getRowId() + "'");
			}
			Thread.sleep(SystemConfig.PER_BUYERID_PAGE_LOAD_SECONDS * 1000);
		}
		try{driver.quit();}catch (Exception e) {	}
		return 1;
	}

}
