package org.mega.amazon.email;

import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.persistence.Query;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.entity.EmailSmsQueue;
import org.mega.util.WebUtil;
import org.openqa.selenium.WebDriver;
/**
 * Set  -Dphantomjs.binary.path=D:/workspace/seleniumProj/other/phantomjs.exe
 * @author Golnari
 *
 */
public class SendAmazonEmails implements Runnable{
	static boolean breakTag = false;
	
	@Override
	public void run() {
		while (true) {
			//Check to synchronize amazon reviews
			if(!SystemConfig.ENABLE_SEND_AMAZON_EMAIL){
				try {Thread.sleep(60000);} catch (InterruptedException e) {	e.printStackTrace();}
				continue;
			}
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			try {
				System.out.println("----------------------------------------- Send Amazon email ... " + cal.getTime().toLocaleString() + " ------------------------------------------------");
				sendEmails();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {Thread.sleep(SystemConfig.FETCH_BUYERID_PERIOD_SECOND * 1000);	} catch (InterruptedException e) {	e.printStackTrace();}
			cal.setTimeInMillis(System.currentTimeMillis());
			System.out.println("Send Amazon email: " + cal.getTime().toLocaleString());

		}
	}

	private void sendEmails() {
		BaseDB baseDB = null;
		WebDriver driver = null;

		try {
			baseDB = BaseDB.open("Send amazon email", 20 * 60);// 20 minutes
			Query query = baseDB.createQuery("select e from EmailSmsQueue e where e.deleted = 0 and e.typeId=:typeId order by e.created");
			query.setParameter("typeId", (long)EmailSmsQueue.TYPE.AMAZON_EMAIL.ordinal());
			query.setMaxResults(10);
			
			List<EmailSmsQueue> emails = query.getResultList();
			if(emails.size() == 0){
				baseDB.finalize();
				return;
			}
			driver = WebUtil.getWebDriver();
			driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);

			
			SendAmazonEmailJob  sendAmazonEmailJob = new SendAmazonEmailJob(emails, "", baseDB, driver);
			
			ExecutorService executor = Executors.newFixedThreadPool(1);
			Future<Integer> future = executor.submit(sendAmazonEmailJob);
			executor.shutdown();
			try{
				future.get(SystemConfig.FETCH_BUYERIDS_TIMEOUT_SECOND, TimeUnit.SECONDS);
			}catch (Exception e) {
				executor.shutdownNow();
				throw e;
			}
			baseDB.commitAndclose();
			try {driver.quit();} catch (Exception e1) {	}
		} catch (Exception e) {
			e.printStackTrace();
			try {baseDB.commitAndclose();} catch (Exception e1) {baseDB.finalize();	}
			try {driver.quit();} catch (Exception e1) {	}
		}
	}

}
