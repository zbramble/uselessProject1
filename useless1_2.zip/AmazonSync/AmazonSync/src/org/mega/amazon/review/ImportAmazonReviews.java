package org.mega.amazon.review;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.persistence.Query;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
/**
 * Set  -Dphantomjs.binary.path=D:/workspace/seleniumProj/other/phantomjs.exe
 * @author Golnari
 *
 */
public class ImportAmazonReviews implements Runnable{
	static boolean breakTag = false;
	
	@Override
	public void run() {
		while (true) {
			//Check to synchronize amazon reviews
			if(!SystemConfig.ENABLE_SYNC_REVIEW){
				try {Thread.sleep(60000);} catch (InterruptedException e) {	e.printStackTrace();}
				continue;
			}
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			try {
				System.out.println("----------------------------------------- Review importing ... " + cal.getTime().toLocaleString() + " ------------------------------------------------");
				importReviews();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {Thread.sleep(SystemConfig.REVIEW_IMPORT_PERIOD_SECOND * 1000);	} catch (InterruptedException e) {	e.printStackTrace();}
			cal.setTimeInMillis(System.currentTimeMillis());
			System.out.println("Review importing end: " + cal.getTime().toLocaleString());

		}
	}

	private void importReviews() {
		BaseDB baseDB = null;
		WebDriver driver = null;
		try {
			baseDB = BaseDB.open("Import reviews", 60 * 60);// 1 hour
			Query query = baseDB.createNativeQuery("select '' || c.PRODUCT_CHANNEL_SKU_ID, c.sku, c.BSE_SITE_ID,s.SITE_NAME,c.review_info,c.last_page,c.access_key from PRODUCT_CHANNEL_SKU c left join bse_site s on c.BSE_SITE_ID=s.BSE_SITE_ID where c.is_deleted=0 and c.is_active=1 and s.is_deleted=0 and s.is_active=1 order by nvl(last_reviews_updated, sysdate - 1000)");
			Iterator iter = query.getResultList().iterator();
			driver = getWebDriver();

			while (iter.hasNext() && !breakTag) {//breakTag in test mode for break while, run this breakTag=true
				Object[] sku = (Object[]) iter.next();
				try{
					System.out.println("***************************** import review of:" + sku[0] + "  sku:" + sku[1] + " *************************");
					int lastPage = ((BigDecimal) sku[5]).intValue();//اگر مشکلی در دریافتهای قبلی نباشد مقدارش صفر است وگر نه شماره صفحه ای که خطا دارد
					ImportAProductReview importAProductReview = new ImportAProductReview(Long.parseLong((String) sku[0]), (String) sku[1],(String) sku[3],(String) sku[4],lastPage,(String) sku[6], driver, baseDB);
					
					ExecutorService executor = Executors.newFixedThreadPool(1);
					Future<Integer> future = executor.submit(importAProductReview);
					executor.shutdown();
					try{
						future.get(SystemConfig.IMPORT_A_PRODUCT_REVIEWS_TIMEOUT_SECOND, TimeUnit.SECONDS);
					}catch (Exception e) {
						executor.shutdownNow();
						throw e;
					}
					//if(bulkCount > SystemConfig.NUMBER_OF_IMPORTED_FOR_COMMIT_DB){//renew connection
						//bulkCount = 0;
						baseDB.commitAndclose();
						baseDB = BaseDB.open("Import reviews", 60 * 60);// 1 hour
					//}
				}catch (Exception e) {
					//if(e.get)
							e.printStackTrace();
					if((e.getCause() != null && e.getCause() instanceof org.openqa.selenium.TimeoutException ) || e instanceof java.util.concurrent.TimeoutException){
						baseDB.runQuery("update ProductChannelSKU e set e.lastReviewsUpdated = sysdate, e.reviewInfo ='Error: timeout' where e.rowId=" + sku[0]);
						baseDB.commitAndclose();
						baseDB = BaseDB.open("Import reviews", 60 * 60);// 1 hour
						continue;
					}
					if(e instanceof org.openqa.selenium.NoSuchElementException){
						baseDB.runQuery("update ProductChannelSKU e set e.lastReviewsUpdated = sysdate, e.reviewInfo ='Error: not found' where e.rowId=" + sku[0]);
						baseDB.commitAndclose();
						baseDB = BaseDB.open("Import reviews", 60 * 60);// 1 hour
						continue;
					}
					
					String s = e.getMessage() == null ? "" : e.getMessage().replaceAll("'","''");
					if(s.length() > 1000)
						s = s.substring(0, 999);
					baseDB.runQuery("update ProductChannelSKU e set e.lastReviewsUpdated = sysdate, e.reviewInfo ='Error: "+s+"' where e.rowId=" + sku[0]);
					baseDB.commitAndclose();
					baseDB = BaseDB.open("Import reviews", 60 * 60);// 1 hour
					throw e;
				}
			}
			baseDB.commitAndclose();
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
			try {baseDB.rollbackAndClose();} catch (Exception e1) {	}
			try {driver.quit();} catch (Exception e1) {	}
		}
	}

	private WebDriver getWebDriver() {
		WebDriver driver;
		DesiredCapabilities capabilities;
		if(SystemConfig.WEB_DRIVER_NAME.equals("CHROME")){
			capabilities = DesiredCapabilities.chrome();
			//capabilities.setCapability(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY, new String[] {"--load-images=no", "--web-security=no", "--ignore-ssl-errors=yes"});
			System.setProperty("webdriver.chrome.driver", SystemConfig.CHROME_WEB_DRIVER_PATH);
			
			//Disable image load
			HashMap<String, Object> images = new HashMap<String, Object>(); 
	        images.put("images", 2); 

	        HashMap<String, Object> prefs = new HashMap<String, Object>(); 
	        prefs.put("profile.default_content_settings", images); 

	        ChromeOptions options =new ChromeOptions(); 
	        options.setExperimentalOption("prefs", prefs); 

	        capabilities.setCapability(ChromeOptions.CAPABILITY, options);

			driver = new ChromeDriver(capabilities);
		}
		else{
			capabilities = DesiredCapabilities.phantomjs();
			capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, new String[] {"--load-images=no", "--web-security=no", "--ignore-ssl-errors=yes"});
			System.setProperty("phantomjs.binary.path", SystemConfig.PHANTOMJS_WEB_DRIVER_PATH);
			driver = new PhantomJSDriver(capabilities);
			//-Dphantomjs.binary.path=D:/workspace/seleniumProj/other/phantomjs.exe
		}
		driver.manage().timeouts().pageLoadTimeout(SystemConfig.WEB_PAGE_LOAD_TIMOUT_SECOND, TimeUnit.SECONDS);

		return driver;
	}

}
