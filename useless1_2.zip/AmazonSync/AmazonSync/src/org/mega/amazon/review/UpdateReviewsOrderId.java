package org.mega.amazon.review;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Iterator;
import java.util.concurrent.Callable;

import javax.persistence.Query;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;

public class UpdateReviewsOrderId implements  Runnable{

	@Override
	public void run(){
		while (true) {
			if(!SystemConfig.ENABLE_UPDATE_REVIEWS_ORDER_ID){
				try {Thread.sleep(60000);} catch (InterruptedException e) {	e.printStackTrace();}
				continue;
			}
			
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			try {
				System.out.println("----------------------------------------- UpdateReviewsOrderId ... " + cal.getTime().toLocaleString() + " ------------------------------------------------");
				updateReviewsOrderId();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {Thread.sleep(SystemConfig.UPDATE_REVIEWS_ORDER_ID_PERIOD_SECOND * 1000);	} catch (InterruptedException e) {	e.printStackTrace();}
			cal.setTimeInMillis(System.currentTimeMillis());
			System.out.println("UpdateReviewsOrderId end: " + cal.getTime().toLocaleString());

		}

	}

	private void updateReviewsOrderId(){
		BaseDB db = null;
		try{
			db = BaseDB.open("UpdateReviewsOrderId", 120);
			String sql = "select distinct o.row_id order_id, r.id  "
					+ " from ORDER_ORDER o,ORDER_ORDER_ITEM i,(select * from RV_REVIEW where order_id is null ) r "
					+ " where r.CUSTOMER_ID = o.BUYER_ID and i.ORDER_ID = o.ROW_ID and r.CHANNEL_SKU_ID = i.CHANNEL_SKU_ID and rownum <=100";
			Query query = db.createNativeQuery(sql);
			Iterator<Object[]> iter = query.getResultList().iterator();
			while(iter.hasNext()){
				Object[] row = iter.next();
				long orderId = ((BigDecimal)row[0]).longValue();
				long reviewId = ((BigDecimal)row[1]).longValue();
				db.runNativeQuery("update rv_review set BUYER_INFO_MATCHED = 1 ,order_id=" + orderId + " where id=" + reviewId);
			}
			db.commitAndclose();
		}catch (Exception e) {
			try{db.finalize();}catch (Exception e2) {	};
			e.printStackTrace();
		}
	}

}
