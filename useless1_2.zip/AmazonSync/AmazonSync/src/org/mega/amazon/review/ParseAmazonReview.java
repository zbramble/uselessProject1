package org.mega.amazon.review;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ParseAmazonReview implements Callable<Integer> {
	private static final int LAST_DAYS_TO_IMPORT = 90;
	private boolean testMode = false;
	private String sku;//In amazon equals with asin
	private WebDriver webDriver;
	private String siteURL;
	
	private Date dateToImport ;
	
	public ParseAmazonReview(String sku,String siteURL, WebDriver webDriver) {
		this.sku = sku;
		this.siteURL = siteURL.indexOf("http") == -1 ? "https://" + siteURL : siteURL ;
		this.webDriver = webDriver;
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(System.currentTimeMillis());
		calendar.add(Calendar.DAY_OF_MONTH, - LAST_DAYS_TO_IMPORT);//Date to import reviews
		dateToImport = calendar.getTime();
	}
	
	@Override
	public Integer call() throws Exception {
		return importReviews();
	}

	private Integer importReviews() throws Exception {
		int pageNumber = 10;
		System.out.println("Start Import Amazon Reviews fro sku:"+sku+"/ " + new Date(System.currentTimeMillis()));
		// driver.get("https://www.amazon.com/dp/B01LZ6XKS6");
		getReviewPage(pageNumber);

		StringBuilder reviewInfo = new StringBuilder();
		int totalCount = 0;
		try{
			totalCount = Integer.parseInt(webDriver.findElement(By.className("totalReviewCount")).getText().replaceAll(",",""));
		}catch(Exception e){
			e.printStackTrace();
		}
		webDriver.findElement(By.className("product-by-line")).getText().equals("byAspectek");
		if(totalCount == 0){
			System.out.println(" Total count=0");
			return 0;
		}
		reviewInfo.append(totalCount);
		
		String rateAll = webDriver.findElement(By.className("arp-rating-out-of-text")).getText();
		reviewInfo.append(",").append(rateAll.split(" ")[0]);
	
		System.out.println("Total count: " + totalCount);
		int i = 0;
		while (i < totalCount) {
			List<WebElement> elements = webDriver.findElements(By.className("review"));
			System.out.println("page number = " + pageNumber);
			
			WebElement histogramTable = webDriver.findElement(By.id("histogramTable"));
			String[] starsPercentage = histogramTable.getText().replaceAll("%","").split("\n");
			double rate = (Integer.parseInt(starsPercentage[1]) * 5D * totalCount + Integer.parseInt(starsPercentage[3]) * 4D * totalCount 
					+ Integer.parseInt(starsPercentage[5]) * 3D * totalCount + Integer.parseInt(starsPercentage[7]) * 2D * totalCount
					+ Integer.parseInt(starsPercentage[9])* 1D * totalCount)/100 / totalCount;
			
			for (WebElement element : elements) {
				
				// System.out.println(element.getText());
				System.out.println(++i + " >\t " + element.getAttribute("ID"));
				
				WebElement markLink = element.findElement(By.className("a-link-normal"));
				String rating = markLink.getAttribute("title");
				
				System.out.println("Mark >\t" + rating);

				WebElement reviewTitle = element.findElement(By.className("review-title"));
				System.out.println("Title >\t" + reviewTitle.getText());

				WebElement author = element.findElement(By.className("author"));
				String authorHref = author.getAttribute("href");
				System.out.println("Author >\t" + author.getText() + " : \t" + authorHref);

				int indexOf = authorHref.indexOf("profile");
				int endOfCustomerId = authorHref.indexOf("/", indexOf + 10);
				String customerId = authorHref.substring(indexOf + 8, endOfCustomerId < 0 ? authorHref.length() : endOfCustomerId);
				System.out.println("CustomerId >\t" + customerId);

				WebElement dateElm = element.findElement(By.className("review-date"));
				System.out.println("Date >\t" + dateElm.getText());
				Date date = ReviewUtil.toDate(dateElm.getText());
				
				WebElement data = element.findElement(By.className("review-text"));
				System.out.println("Data >\t" + data.getText());
				
				System.out.println("filnish a page. sku:" + sku);
				System.out.println("-----------------------------------------------------------");
				if (testMode)
					break;
				if(date.before(dateToImport) ){//Seed to goal date
					System.out.println("sku " + sku + " seed to goal date");
					return i;
				}
			}
			pageNumber++;
			if (testMode && pageNumber > 3)
				break;
			getReviewPage(pageNumber);
		}
		System.out.println("sku " + sku + " INFO:" + reviewInfo.toString());
		return i;
	}
	
	public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException {
        System.setProperty("phantomjs.binary.path", "D:/workspace/seleniumProj/other/phantomjs.exe");
        DesiredCapabilities capabilities = DesiredCapabilities.phantomjs();
        capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, new String[] {"--load-images=no", "--web-security=no", "--ignore-ssl-errors=yes"});

        WebDriver driver = new PhantomJSDriver(capabilities);
       // driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

			String sku = "B009GBC2Y6";
				System.out.println("import review of:" + sku);
				ParseAmazonReview parseAmazonReview = new ParseAmazonReview(sku,"https://amazon.com", driver);
				
				ExecutorService executor = Executors.newFixedThreadPool(1);
				Future<Integer> future = executor.submit(parseAmazonReview);
				executor.shutdown();
				int ret = -1;
				try{
					ret = future.get(60, TimeUnit.SECONDS);
				}catch (Exception e) {
					executor.shutdownNow();
					throw e;
				}
				System.out.println("Ret = " + ret);
	}

	private void getReviewPage(int pageNumber) throws Exception{
		//https://www.amazon.com/product-reviews/B001J1QQMK/ref=cm_cr_arp_d_paging_btm_next_38?sortBy=recent&pageNumber=10&reviewerType=all_reviews
		String page = "https://www.amazon.com/product-reviews/" + sku + "/ref=cm_cr_getr_d_show_all?sortBy=recent&pageNumber="+ pageNumber + "&reviewerType=all_reviews";
		System.out.println(page);
		webDriver.get(page);
		WebDriverWait wait = new WebDriverWait(webDriver, 30);
		WebElement elm = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("nav_last")));
	}
}
