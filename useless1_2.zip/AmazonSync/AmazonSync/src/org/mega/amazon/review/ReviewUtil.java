package org.mega.amazon.review;

import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;

import org.mega.core.base.BaseDB;

public class ReviewUtil {
	static LinkedHashMap<String, Integer> monthes = new LinkedHashMap<String, Integer>();
	static{
		monthes.put("January", 0);
		monthes.put("February", 1);
		monthes.put("March", 2);
		monthes.put("April", 3);
		monthes.put("May", 4);
		monthes.put("June", 5);
		monthes.put("July", 6);
		monthes.put("August", 7);
		monthes.put("September", 8);
		monthes.put("October", 9);
		monthes.put("November", 10);
		monthes.put("December", 11);
	}
	
	public static void main(String[] args) {
	
		System.out.println(toDate("on May 22, 2017"));
	}

	/**
	 * 
	 * @param reviewDate such as "on May 22, 2017"
	 * @return Date object
	 */
	public static Date toDate(String reviewDate) {
		String[] s= reviewDate.split(" ");
		
		int m = monthes.get(s[1]);
		int d = Integer.parseInt(s[2].substring(0, s[2].length() -1));
		int y = Integer.parseInt(s[3]);
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(y, m, d, 0,0,0);
		return calendar.getTime();
	}

	//Run this method after all sku reviews imported
	public static void updateChannelSKUReviewInfo(String sku, String reviewInfo,int pageNumber, BaseDB db) throws Exception {
		db.runNativeQuery("update PRODUCT_CHANNEL_SKU e set e.last_Reviews_Updated = sysdate, e.review_Info = '"+ reviewInfo +"', e.last_Page='"+pageNumber+"' where e.SKU = '"+ sku +"'");
	}
}
