package org.mega.amazon.review;

import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.Callable;

import javax.persistence.Query;

import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.exception.ConstraintViolationException;
import org.mega.core.SystemConfig;
import org.mega.core.base.BaseDB;
import org.mega.entity.EmailSmsQueue;
import org.mega.entity.Review;
import org.mega.entity.ReviewTargetSetting;
import org.mega.entity.User;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import oracle.net.aso.l;

public class ImportAProductReview implements Callable<Integer> {
	private boolean testMode = false;
	private String sku;//In amazon equals with asin
	private WebDriver webDriver;
	private BaseDB db;
	private long channelSkuId;
	private String siteURL;
	
	private Date dateToImport ;
	private String accesssKey;
	private int lastPage;
	List<WebElement> reviewElements;
	int totalCount = 0;
	private String reviewInfo;
	
	private static LinkedHashMap<Long, String> lastReviewCache = new LinkedHashMap<Long, String>();//آخرین شناسه ریویوی یک چنل اسکو را  نگه می دارد
	
	public ImportAProductReview(long channelSkuId,String sku,String siteURL, String reviewInfo, int lastPage, String accesssKey, WebDriver webDriver, BaseDB db) {
		this.sku = sku;
		this.channelSkuId = channelSkuId;
		this.siteURL = siteURL.indexOf("http") == -1 ? "https://" + siteURL : siteURL ;
		this.webDriver = webDriver;
		this.db = db;
		this.accesssKey = accesssKey;
		this.lastPage = lastPage;
		this.reviewInfo = reviewInfo;
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(System.currentTimeMillis());
		calendar.add(Calendar.DAY_OF_MONTH, - SystemConfig.LAST_DAYS_TO_IMPORT_REVIEW);//Date to import reviews
		dateToImport = calendar.getTime();
	}
	
	@Override
	public Integer call() throws Exception {
		return importReviews();
	}

	private Integer importReviews() throws Exception {
		int pageNumber = 1;
		if(this.lastPage != 0)//در دور قبل خطا بوده است ابتدا از صفحه ای که خطا بوده ایمپورت کند
			pageNumber = this.lastPage;
		System.out.println("Start Import Amazon Reviews fro sku:"+sku+"/ " + new Date(System.currentTimeMillis()));
		
		int ret = getReviewPage(pageNumber);

		StringBuilder reviewInfo = new StringBuilder();
//		int totalCount = 0;
//		try{
//			totalCount = Integer.parseInt(webDriver.findElement(By.className("totalReviewCount")).getText().replaceAll(",",""));
//		}catch(Exception e){}
		
		if(totalCount == 0){
			db.runQuery("update ProductChannelSKU e set e.reviewInfo ='No review found', e.lastReviewsUpdated = sysdate where e.rowId=" + channelSkuId);
			System.out.println("No review recorded");
			return 0;
		}
		
		if(ret == -1){//هیچ ریویویی در صفحه نیست
			db.runNativeQuery("update Product_Channel_SKU e set e.review_Info ='No review found in page', e.last_Reviews_Updated = sysdate, e.last_Page=0 where e.PRODUCT_CHANNEL_SKU_ID=" + channelSkuId);
			System.out.println("No review id page");
			return 0;
			
		}

/*		if(!webDriver.findElement(By.className("product-by-line")).getText().equals("byAspectek")){
			db.runQuery("update ProductChannelSKU e set e.reviewInfo ='It is not for Aspectek', e.active=false where e.rowId=" + channelSkuId);
			System.out.println(">>> It is not for Aspectek");
			return 0;
		}*/
		reviewInfo.append(totalCount);
		
		String rateAll = webDriver.findElement(By.className("arp-rating-out-of-text")).getText();
		//نرخ کل برای آمازون دیقیق نیست از درصدها که محاسبه می شود دقیق تر است
		WebElement histogramTable = webDriver.findElement(By.id("histogramTable"));
		String[] starsPercentage = histogramTable.getText().replaceAll("%","").split("\n");
		double rateCalulated = (Integer.parseInt(starsPercentage[1]) * 5D * totalCount + Integer.parseInt(starsPercentage[3]) * 4D * totalCount 
				+ Integer.parseInt(starsPercentage[5]) * 3D * totalCount + Integer.parseInt(starsPercentage[7]) * 2D * totalCount
				+ Integer.parseInt(starsPercentage[9])* 1D * totalCount)/100 / totalCount;

		
		rateAll = rateAll.split(" ")[0];
		reviewInfo.append(",").append(rateAll);
		
		rateCalulated = ( rateCalulated + Double.parseDouble(rateAll) ) / 2d;//میانگین محاسباتی و اعلامی را منظور می کنیم
		
		db.runNativeQuery("update Product_Channel_SKU set all_review_Count ='" + totalCount + "',review_rate=round("+ rateCalulated +",4), updated = sysdate where PRODUCT_CHANNEL_SKU_ID=" + channelSkuId);

		System.out.println("Total count: " + totalCount);
		int i = (pageNumber - 1) * 10;
		while (i < totalCount) {
			//List<WebElement> reviewElements = webDriver.findElements(By.className("review"));
			System.out.println("page number = " + pageNumber);
			ReviewUtil.updateChannelSKUReviewInfo(this.sku, "Importing...",pageNumber, db);//در صورتی که شماره صفحه در بانک صفر بماند فرض می شود که خطایی ندارد ابتدا شماره صفحه تنظیم می شود سپس اگر مشکلی نبود آخر کار صفر می شود

			for (WebElement element : reviewElements) {
				Review review = new Review();
				review.setChannelSkuId(channelSkuId);
				review.setAccessKey(this.accesssKey);
				review.setBuyerInfoMatched(0);
				
				// System.out.println(element.getText());
				System.out.println(++i + " ReviewId>\t " + element.getAttribute("ID"));
				review.setReviewId(element.getAttribute("ID"));
				
				if(review.getReviewId().equals(lastReviewCache.get(channelSkuId))){//هیچ ریویوی جدیدی نیامده
					System.out.println(">>>> Already processed");
					ReviewUtil.updateChannelSKUReviewInfo(this.sku, this.reviewInfo,0, db);//در صورتی که شماره صفحه در بانک صفر بماند فرض می شود که خطایی ندارد ابتدا شماره صفحه تنظیم می شود سپس اگر مشکلی نبود آخر کار صفر می شود
					return 0;
				}
				else
					lastReviewCache.put(channelSkuId, review.getReviewId());
				
				WebElement markLink = element.findElement(By.className("a-link-normal"));
				String rating = markLink.getAttribute("title");
				
				review.setRating(Double.parseDouble(rating.substring(0, rating.indexOf(" "))));
				
				System.out.println("Mark >\t" + rating);

				WebElement reviewTitle = element.findElement(By.className("review-title"));
				System.out.println("Title >\t" + reviewTitle.getText());
				review.setTitle(reviewTitle.getText());
				review.setLinkOnSite(reviewTitle.getAttribute("href"));

				WebElement author = element.findElement(By.className("author"));
				String authorHref = author.getAttribute("href");
				System.out.println("Author >\t" + author.getText() + " : \t" + authorHref);
				review.setCustomerName(author.getText());

				int indexOf = authorHref.indexOf("profile");
				int endOfCustomerId = authorHref.indexOf("/", indexOf + 10);
				String customerId = authorHref.substring(indexOf + 8, endOfCustomerId < 0 ? authorHref.length() : endOfCustomerId);
				review.setCustomerId(customerId);
				System.out.println("CustomerId >\t" + customerId);

				WebElement dateElm = element.findElement(By.className("review-date"));
				System.out.println("Date >\t" + dateElm.getText());
				Date date = ReviewUtil.toDate(dateElm.getText());
				review.setReviewDate(date);
				
				review.setVerifiedPurchase(element.getText().indexOf("Verified Purchase") > -1);
				
				WebElement data = element.findElement(By.className("review-text"));
				//System.out.println("Data >\t" + data.getText());
				review.setContent(data.getText());
				
				review.setCreated(new Date(System.currentTimeMillis()));
				review.setUpdated(new Date(System.currentTimeMillis()));
				review.setActive(true);
				
				review.setStatusId(100063L);
								
				User user = new User();
				user.setRowId(SystemConfig.SYSTEM_USER_ID);
				review.setCreatedBy(user);
				review.setUpdatedBy(user);
				try{
					BaseDB insertDB = BaseDB.open("insert review", 10);
					insertDB.persist(review);
					notify(review,insertDB, user);
					insertDB.commitAndclose();
					System.out.println("A revoew inserted: sku:" +sku + ", ReviewId:" + review.getRowId());
				}catch (Exception e) {
					//آیا به  آخرین ریویو رسیده است
					if(e.getCause() != null && e.getCause().getCause() instanceof ConstraintViolationException &&
						((ConstraintViolationException)e.getCause().getCause()).getConstraintName().indexOf("UN_REVIEW_CHANL_REVWID") > -1){
						
						if(this.lastPage > 1){//قبلا خطا داشته تکراری ها را رد کند تا سر تاریخ وارد کند
							continue;
						}else{
							ReviewUtil.updateChannelSKUReviewInfo(this.sku, reviewInfo.toString(),0, db);
							return i;//Seed to last imported already
						}
					}
					throw e;
				}
				System.out.println("-----------------------------------------------------------");
				if (testMode)
					break;
				if(date.before(dateToImport) ){//Seed to goal date
					ReviewUtil.updateChannelSKUReviewInfo(this.sku, reviewInfo.toString(),0, db);
					return i;
				}
			}//for

			pageNumber++;
			if (testMode && pageNumber > 3)
				break;
			getReviewPage(pageNumber);
		}//while
		ReviewUtil.updateChannelSKUReviewInfo(this.sku, reviewInfo.toString(),0, db);
		return i;
	}

	//بر اساس تنظیمات نمره های منفی روزانه هفتگی ماهانه و در زمان را می شمرد و در صورت گذشتن از تعداد تنظیم شده ایمیل می زند
	private void notify(Review review,BaseDB db, User user) throws Exception {
		if(review.getReviewDate().before(SystemConfig.DATE_TO_SEND_NEGATIVE_REVIEW_EMAIL))
			return;
		Query q = db.createQuery("select e from ReviewTargetSetting e where e.channelSKUId=:csID");
		q.setParameter("csID", "" + review.getChannelSkuId());
		ReviewTargetSetting setting = (ReviewTargetSetting) q.getSingleResult();
		//چک realtime
		if(review.getRating() < setting.getReviewTarget()){
			//WebUtil.sendEmail(setting.getRealTimeNotification(), "test", "content");
			EmailSmsQueue esq = new EmailSmsQueue();
			esq.setActive(true);
			esq.setTypeId(1L);//email
			String reviewDate = (1900+review.getReviewDate().getYear())+"/"+ (review.getReviewDate().getMonth()+1)+"/"+review.getReviewDate().getDate();
			esq.setTitle("MILO Marketing Suite: Negative reviews real time alert for " + reviewDate);
			esq.setContent(makeEmailContent(review, setting));
			esq.setToAdress(setting.getRealTimeNotification());
			esq.setCreatedBy(user);
			esq.setUpdatedBy(user);
			esq.setCreated(new Date(System.currentTimeMillis()));
			esq.setUpdated(new Date(System.currentTimeMillis()));
			db.persist(esq);
		}
	}

	private String makeEmailContent(Review review, ReviewTargetSetting setting) {
		StringBuilder s = new StringBuilder();
		s.append("Hi,<br>A negative review recorded for \"").append(setting.getFullTitle()).append("\"<br>")
			.append("Date:").append((1900+review.getReviewDate().getYear())+"/"+ (review.getReviewDate().getMonth()+1)+"/"+review.getReviewDate().getDate()).append("<br>")
			.append("Rate:<b>").append(review.getRating()).append("</b><br><br>").append("Review:").append(review.getTitle()).append("<br>")
			.append("").append(review.getContent()).append("<br><br>")
			.append(review.getLinkOnSite()).append("<br><br>")
			.append("<b><font color=\"red\"> MILO Marketing Suite</font> </b>");
		
		return s.toString();
	}

	private int getReviewPage(int pageNumber) throws Exception{
		//String url = "https://www.amazon.com/product-reviews/" + sku + "/ref=cm_cr_getr_d_show_all?sortBy=recent&pageNumber="+ pageNumber + "&reviewerType=all_reviews";
		String url = siteURL + "/product-reviews/" + sku + "/ref=cm_cr_getr_d_show_all?sortBy=recent&pageNumber="+ pageNumber + "&reviewerType=all_reviews";
		System.out.println(url);
		webDriver.get(url);
	
		Thread.sleep(SystemConfig.PER_REVIEW_PAGE_LOAD_DELAY_SECOND * 1000);//آمازون اگر سریع صفحه درخواست کنی کپچا نشان می دهد

		WebDriverWait wait = new WebDriverWait(webDriver, SystemConfig.WEB_PAGE_LOAD_TIMOUT_SECOND);
		WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("totalReviewCount")));
		totalCount = Integer.parseInt(el.getText().replaceAll(",",""));
		if(totalCount == 0)
			return 0;
		
		if(webDriver.findElements(By.className("no-reviews-section")).size()> 0)
			return -1;
//		if(lastPage > 1 && reviewInfo.equals("Error: timeout") && Math.random() > 0.5){//رندم چک شود آیا تایم اوت بخاطر این است که در صفحه  ریویو نیست البته برای صفحاتی که تایم اوت دارند
//			reviewElements = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("no-reviews-section")));
//			reviewElements = null;
//		}
//		else
			reviewElements = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("review")));
			return reviewElements.size();
	}

}
