package org.mega.util;

import java.util.Calendar;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.mega.core.SystemConfig;

import com.amazonservices.mws.client.MwsUtl;

public class DateUtil {

	public static Date xmlGeragurianToDate(XMLGregorianCalendar xmlDate) {
		if(xmlDate == null)
			return null;
		Calendar calendar = Calendar.getInstance();
		calendar.set(xmlDate.getYear(), xmlDate.getMonth() -1, xmlDate.getDay(), xmlDate.getHour(), xmlDate.getMinute(), xmlDate.getSecond());
		return calendar.getTime();
	}
	
	/**
	 * با فاصله زمانی گفته شده زمان را باز می گرداند
	 * @param dayDiff فاصله مثبت یا منفی بر حسب روز
	 * @param hourDiff
	 * @param minuteDiff
	 * @return
	 */
	public static XMLGregorianCalendar getXMLGerCalendar(int dayDiff, int hourDiff, int minuteDiff){
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(System.currentTimeMillis());
        cal.add(Calendar.DAY_OF_MONTH, dayDiff);
        cal.add(Calendar.HOUR_OF_DAY, hourDiff);
        cal.add(Calendar.MINUTE, minuteDiff);

        XMLGregorianCalendar c= MwsUtl.getDTF().newXMLGregorianCalendar();
        c.setYear(cal.get(Calendar.YEAR));
        c.setMonth(cal.get(Calendar.MONTH) + 1);
        c.setDay(cal.get(Calendar.DAY_OF_MONTH));
        c.setHour(cal.get(Calendar.HOUR_OF_DAY));
        c.setMinute(cal.get(Calendar.MINUTE)); 
        c.setSecond(cal.get(Calendar.SEPTEMBER)); 
		
        return c;
	}
	
	public static XMLGregorianCalendar getXMLGerCalendar(Date date, double dayDiff){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        
        int days = (int)Math.abs(dayDiff);
        int hours = (int)((Math.abs(dayDiff) - days) * 24);
        if(dayDiff  < 0){
        	days= days * -1;
        	hours = hours * -1;
        }
        
        cal.add(Calendar.DAY_OF_MONTH, days);
        cal.add(Calendar.HOUR_OF_DAY, hours);
        
        XMLGregorianCalendar c= MwsUtl.getDTF().newXMLGregorianCalendar();
        c.setYear(cal.get(Calendar.YEAR));
        c.setMonth(cal.get(Calendar.MONTH) + 1);
        c.setDay(cal.get(Calendar.DAY_OF_MONTH));
        c.setHour(cal.get(Calendar.HOUR_OF_DAY));
        c.setMinute(cal.get(Calendar.MINUTE)); 
        c.setSecond(cal.get(Calendar.SEPTEMBER)); 
		
        return c;
	}
	
	/**
	 * 
	 * @param dayDiff such as 0.4 
	 * @return
	 */
	public static Date today(double dayDiff, boolean onlyDate){
		int days = (int) Math.abs(dayDiff);
		int hours = (int) ((Math.abs(dayDiff) - days) * 24);
		if (dayDiff < 0) {
			days = days * -1;
			hours = hours * -1;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(System.currentTimeMillis());
		calendar.add(Calendar.DAY_OF_MONTH, days);
		calendar.add(Calendar.HOUR_OF_DAY, hours);
		
		if(onlyDate){
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			
		}
		return calendar.getTime();
	}
}
