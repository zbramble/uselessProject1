package org.mega.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.mega.core.SystemConfig;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

//import com.fasterxml.jackson.databind.ObjectMapper;

public class WebUtil {
	public static enum CONTENT_TYPE {JSON, TEXT};
	public static WebDriver getWebDriver() {
		WebDriver driver;
		DesiredCapabilities capabilities;
		if(SystemConfig.WEB_DRIVER_NAME.equals("CHROME")){
			capabilities = DesiredCapabilities.chrome();
			//capabilities.setCapability(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY, new String[] {"--load-images=no", "--web-security=no", "--ignore-ssl-errors=yes"});
			System.setProperty("webdriver.chrome.driver", SystemConfig.CHROME_WEB_DRIVER_PATH);
			
			//Disable image load
			HashMap<String, Object> images = new HashMap<String, Object>(); 
	        images.put("images", 2); 

	        HashMap<String, Object> prefs = new HashMap<String, Object>(); 
	        prefs.put("profile.default_content_settings", images); 

	        ChromeOptions options =new ChromeOptions(); 
	        options.setExperimentalOption("prefs", prefs); 
	        options.addArguments("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36");
	        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	        
	        capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, org.openqa.selenium.UnexpectedAlertBehaviour.ACCEPT);
			capabilities.setBrowserName("chrome");
		    capabilities.setPlatform(Platform.WINDOWS);

			driver = new ChromeDriver(capabilities);
		}
		else{
			capabilities = DesiredCapabilities.phantomjs();
			capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, new String[] {"--load-images=no", "--web-security=no", "--ignore-ssl-errors=yes"});
			System.setProperty("phantomjs.binary.path", SystemConfig.PHANTOMJS_WEB_DRIVER_PATH);
			capabilities.setBrowserName("chrome");
		    capabilities.setPlatform(Platform.WINDOWS);
		    capabilities.setCapability("phantomjs.page.settings.userAgent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36");
		   
			driver = new PhantomJSDriver(capabilities);
			//-Dphantomjs.binary.path=D:/workspace/seleniumProj/other/phantomjs.exe
		}
		driver.manage().timeouts().pageLoadTimeout(SystemConfig.WEB_PAGE_LOAD_TIMOUT_SECOND, TimeUnit.SECONDS);
		
		return driver;
	}


	public static void sendEmail(String recieverEmail,String subbject, String content, String...attachFiles) {
		String username = SystemConfig.SYSTEM_EMAIL_USER;
		String password = SystemConfig.SYSTEM_EMAIL_PASS;
		String sender 	= SystemConfig.SYSTEM_EMAIL;
		
		Properties props = new Properties();
		props.put("mail.smtp.host", SystemConfig.SYSTEM_EMAIL_SERVER);
		//props.put("mail.smtp.host", "smtp.gmail.com");
		
		props.put("mail.smtp.auth", "true"); 
		props.put("mail.smtp.starttls.enable","true");
		if(SystemConfig.SYSTEM_EMAIL_USE_SSL){
			props.put("mail.smtp.EnableSSL.enable","true");
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");   
		}
		props.put("mail.smtp.socketFactory.fallback", "false");   
		props.put("mail.smtp.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT); 
		props.put("mail.smtp.socketFactory.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT);
		props.put("mail.debug", "false");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {
			Message message = new MimeMessage(session);
			message.setRecipients(Message.RecipientType.TO,	InternetAddress.parse(recieverEmail));
			message.setFrom(InternetAddress.parse(sender)[0]);
			message.setSubject(subbject);

			// creates message part
	        MimeBodyPart messageBodyPart = new MimeBodyPart();
	        messageBodyPart.setContent(content, "text/html");
	 
	        // creates multi-part
	        Multipart multipart = new MimeMultipart();
	        multipart.addBodyPart(messageBodyPart);
	 
	        // adds attachments
	        if (attachFiles != null && attachFiles.length > 0) {
	            for (String filePath : attachFiles) {
	                MimeBodyPart attachPart = new MimeBodyPart();
	 
                	DataSource source = new FileDataSource(filePath);
                	attachPart.setDataHandler(new DataHandler(source));
                	attachPart.setFileName(new File(filePath).getName());
	                multipart.addBodyPart(attachPart);
	            }
	        }
	 
	        // sets the multi-part as e-mail's content
	        message.setContent(multipart);
			
			Transport.send(message);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}	
	
	public static void sendEmailByAttach(String recieverEmail,String subbject, String content, List<AttachFile> attaches) {
		String username = SystemConfig.SYSTEM_EMAIL_USER;
		String password = SystemConfig.SYSTEM_EMAIL_PASS;
		String sender 	= SystemConfig.SYSTEM_EMAIL;
		
		Properties props = new Properties();
		props.put("mail.smtp.host", SystemConfig.SYSTEM_EMAIL_SERVER);
		//props.put("mail.smtp.host", "smtp.gmail.com");
		
		props.put("mail.smtp.auth", "true"); 
		props.put("mail.smtp.starttls.enable","true");
		if(SystemConfig.SYSTEM_EMAIL_USE_SSL){
			props.put("mail.smtp.EnableSSL.enable","true");
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");   
		}
		props.put("mail.smtp.socketFactory.fallback", "false");   
		props.put("mail.smtp.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT); 
		props.put("mail.smtp.socketFactory.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT);
		props.put("mail.debug", "false");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {
			Message message = new MimeMessage(session);
			message.setRecipients(Message.RecipientType.TO,	InternetAddress.parse(recieverEmail));
			message.setFrom(InternetAddress.parse(sender)[0]);
			message.setSubject(subbject);

			// creates message part
	        MimeBodyPart messageBodyPart = new MimeBodyPart();
	        messageBodyPart.setContent(content, "text/html");
	 
	        // creates multi-part
	        Multipart multipart = new MimeMultipart();
	        multipart.addBodyPart(messageBodyPart);
	 
	        // adds attachments
            for (AttachFile attach: attaches) {
                MimeBodyPart attachPart = new MimeBodyPart();
 
            	DataSource source = new ByteArrayDataSource(attach.content,attach.mime);
            	attachPart.setDataHandler(new DataHandler(source));
            	attachPart.setFileName(attach.name);
                multipart.addBodyPart(attachPart);
            }
	 
	        // sets the multi-part as e-mail's content
	        message.setContent(multipart);
			
			Transport.send(message);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	public static void main(String[] args) throws IOException {
		SystemConfig.init();
		byte[] file1Bytes = IOUtil.readFromFile(new File("C:/Users/LENOVO/Downloads/REVIEW_DROP_RISK_20170712.xls"));
		List<AttachFile> attaches = new ArrayList<AttachFile>();
		AttachFile attachFile = new AttachFile(file1Bytes, "report2.xls", "application/vnd.ms-excel");
//		attaches.add(attachFile);
		
		WebUtil.sendEmailByAttach("golnari@gmail.com,mehdi_00000@yahoo.com", "test 1", "test 1", attaches);
		
	}
	

}
