/*  1:   */ 
/*  2:   */ 
/*  3:   */ import org.openqa.selenium.Platform;
/*  4:   */ import org.openqa.selenium.WebDriver;
/*  5:   */ import org.openqa.selenium.chrome.ChromeDriver;
/*  6:   */ import org.openqa.selenium.phantomjs.PhantomJSDriver;
/*  7:   */ import org.openqa.selenium.remote.DesiredCapabilities;
/*  8:   */ 
/*  9:   */ public class WebDriverFactory
/* 10:   */ {
/* 11:   */   public static WebDriver getPhantomeJSDriver()
/* 12:   */   {
/* 13:11 */     WebDriver driver = null;
/* 14:12 */     System.setProperty("phantomjs.binary.path", "D:\\WebDriver\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe");
/* 15:   */     
/* 16:14 */     DesiredCapabilities capability = null;
/* 17:15 */     capability = DesiredCapabilities.chrome();
/* 18:16 */     capability.setBrowserName("chrome");
/* 19:17 */     capability.setPlatform(Platform.WINDOWS);
/* 20:18 */     capability.setCapability("phantomjs.page.settings.userAgent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0");
/* 21:   */     try
/* 22:   */     {
/* 23:21 */       driver = new PhantomJSDriver(capability);
/* 24:   */     }
/* 25:   */     catch (Throwable e)
/* 26:   */     {
/* 27:24 */       e.printStackTrace();
/* 28:   */     }
/* 29:26 */     return driver;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static WebDriver getChromDriver()
/* 33:   */   {
/* 34:29 */     WebDriver driver = null;
/* 35:30 */     System.setProperty("webdriver.chrome.driver", "D:\\WebDriver\\chromedriver_win32\\chromedriver.exe");
/* 36:   */     
/* 37:32 */     DesiredCapabilities capability = null;
/* 38:33 */     capability = DesiredCapabilities.chrome();
/* 39:34 */     capability.setBrowserName("chrome");
/* 40:35 */     capability.setPlatform(Platform.WINDOWS);
/* 41:   */     try
/* 42:   */     {
/* 43:39 */       driver = new ChromeDriver(capability);
/* 44:   */     }
/* 45:   */     catch (Throwable e)
/* 46:   */     {
/* 47:42 */       e.printStackTrace();
/* 48:   */     }
/* 49:44 */     return driver;
/* 50:   */   }
/* 51:   */ }


/* Location:           D:\apache-tomcat-9.0.0.M17\webapps\reviewtracker-0.0.1-SNAPSHOT\
 * Qualified Name:     com.milo.amz.webdriver.utils.WebDriverFactory
 * JD-Core Version:    0.7.0.1
 */