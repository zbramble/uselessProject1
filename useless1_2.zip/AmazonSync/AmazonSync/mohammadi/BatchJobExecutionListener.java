package com.milo.amz.review.batch.listener;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class BatchJobExecutionListener
  implements JobExecutionListener
{
  public void beforeJob(JobExecution jobExecution) {}
  
  public void afterJob(JobExecution jobExecution) {}
}


/* Location:           D:\apache-tomcat-9.0.0.M17\webapps\reviewtracker-0.0.1-SNAPSHOT\
 * Qualified Name:     com.milo.amz.review.batch.listener.BatchJobExecutionListener
 * JD-Core Version:    0.7.0.1
 */