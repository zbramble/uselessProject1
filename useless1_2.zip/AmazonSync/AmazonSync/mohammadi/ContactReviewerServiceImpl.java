/*  1:   */ package com.milo.amz.review.service.impl;
/*  2:   */ 
/*  3:   */ import com.milo.amz.review.service.ContactReviewerService;
/*  4:   */ import com.milo.amz.review.service.PurchaseOrderService;
/*  5:   */ import com.milo.amz.review.service.ReviewService;
/*  6:   */ import com.milo.amz.review.service.dto.PurchaseOrderDTO;
/*  7:   */ import com.milo.amz.review.service.dto.ReviewDTO;
/*  8:   */ import com.milo.amz.webdriver.utils.WebDriverFactory;
/*  9:   */ import java.util.List;
/* 10:   */ import javax.inject.Inject;
/* 11:   */ import org.openqa.selenium.By;
/* 12:   */ import org.openqa.selenium.WebDriver;
/* 13:   */ import org.openqa.selenium.WebDriver.Options;
/* 14:   */ import org.openqa.selenium.WebDriver.Window;
/* 15:   */ import org.openqa.selenium.WebElement;
/* 16:   */ import org.openqa.selenium.support.ui.ExpectedConditions;
/* 17:   */ import org.openqa.selenium.support.ui.WebDriverWait;
/* 18:   */ import org.springframework.beans.factory.annotation.Autowired;
/* 19:   */ import org.springframework.data.domain.Page;
/* 20:   */ import org.springframework.stereotype.Service;
/* 21:   */ 
/* 22:   */ @Service
/* 23:   */ public class ContactReviewerServiceImpl
/* 24:   */   implements ContactReviewerService
/* 25:   */ {
/* 26:   */   private WebDriver driver;
/* 27:   */   @Autowired
/* 28:   */   private PurchaseOrderService purchaseOrderService;
/* 29:   */   @Inject
/* 30:   */   private ReviewService reviewService;
/* 31:   */   
/* 32:   */   private void loginInSellerCentral()
/* 33:   */   {
/* 34:30 */     this.driver = WebDriverFactory.getChromDriver();
/* 35:31 */     this.driver.manage().window().maximize();
/* 36:32 */     this.driver.get("https://sellercentral.amazon.com");
/* 37:   */     
/* 38:34 */     WebElement myDynamicElement = (WebElement)new WebDriverWait(this.driver, 20L).until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='ap_email']")));
/* 39:   */     
/* 40:36 */     this.driver.findElement(By.xpath(".//*[@id='ap_email']")).sendKeys(new CharSequence[] {"michael.liu01@gmail.com" });
/* 41:37 */     this.driver.findElement(By.xpath(".//*[@id='ap_password']")).sendKeys(new CharSequence[] { "Ajkml@5896" });
/* 42:   */     
/* 43:39 */     this.driver.findElement(By.xpath(".//*[@id='signInSubmit']")).click();
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void sendEmail(String reviewId, String buyerId, String message)
/* 47:   */   {
/* 48:45 */     loginInSellerCentral();
/* 49:46 */     Page<PurchaseOrderDTO> purchaseOrderList = this.purchaseOrderService.findByBuyerId(buyerId, null);
/* 50:47 */     PurchaseOrderDTO purchaseOrderDTO = (PurchaseOrderDTO)purchaseOrderList.getContent().get(0);
/* 51:48 */     this.driver.get("https://sellercentral.amazon.com/gp/help/contact/contact.html?orderID=" + purchaseOrderDTO.getSellerOrderId() + "&marketplaceID=" + purchaseOrderDTO.getMarketplaceId() + "&buyerID=" + purchaseOrderDTO.getBuyerId());
/* 52:49 */     WebElement sendEmail = (WebElement)new WebDriverWait(this.driver, 60L).until(
/* 53:50 */       ExpectedConditions.presenceOfElementLocated(By.xpath("(.//button[@id='sendemail' and @name='sendemail' and @class='awesomeButton buttonLarge primaryLargeButton'])[2]")));
/* 54:51 */     WebElement compositionSubjectElement = (WebElement)new WebDriverWait(this.driver, 20L).until(
/* 55:52 */       ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='commMgrCompositionSubject']")));
/* 56:53 */     compositionSubjectElement.sendKeys(new CharSequence[] { "Feedback Request" });
/* 57:54 */     new WebDriverWait(this.driver, 20L);
/* 58:55 */     this.driver.findElement(By.xpath(".//*[@id='commMgrCompositionMessage']")).sendKeys(new CharSequence[] { message });
/* 59:56 */     new WebDriverWait(this.driver, 20L);
/* 60:   */     try
/* 61:   */     {
/* 62:59 */       sendEmail.click();
/* 63:60 */       ReviewDTO reviewDTO = this.reviewService.findByReviewID(reviewId);
/* 64:61 */       reviewDTO.setResponded(true);
/* 65:   */     }
/* 66:   */     catch (Exception e)
/* 67:   */     {
/* 68:66 */       e.printStackTrace();
/* 69:   */     }
/* 70:   */   }
/* 71:   */ }


/* Location:           D:\apache-tomcat-9.0.0.M17\webapps\reviewtracker-0.0.1-SNAPSHOT\
 * Qualified Name:     com.milo.amz.review.service.impl.ContactReviewerServiceImpl
 * JD-Core Version:    0.7.0.1
 */