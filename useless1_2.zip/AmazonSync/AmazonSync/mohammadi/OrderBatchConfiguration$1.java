/*   1:    */ package com.milo.amz.review.batch;
/*   2:    */ 
/*   3:    */ import com.amazonservices.mws.orders._2013_09_01.model.Order;
/*   4:    */ import com.milo.amz.review.GeneralUtils;
/*   5:    */ import com.milo.amz.review.service.PurchaseOrderService;
/*   6:    */ import com.milo.amz.review.service.dto.PurchaseOrderDTO;
/*   7:    */ import com.milo.amz.review.service.mapper.OrderMapper;
/*   8:    */ import java.time.LocalDate;
/*   9:    */ import java.time.Month;
/*  10:    */ import org.openqa.selenium.By;
/*  11:    */ import org.openqa.selenium.WebDriver;
/*  12:    */ import org.openqa.selenium.WebDriver.Navigation;
/*  13:    */ import org.openqa.selenium.WebElement;
/*  14:    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*  15:    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*  16:    */ import org.springframework.batch.item.ItemProcessor;
/*  17:    */ 
/*  18:    */ class OrderBatchConfiguration$1
/*  19:    */   implements ItemProcessor<Order, PurchaseOrderDTO>
/*  20:    */ {
/*  21:    */   OrderBatchConfiguration$1(OrderBatchConfiguration paramOrderBatchConfiguration, WebDriver paramWebDriver) {}
/*  22:    */   
/*  23:    */   public PurchaseOrderDTO process(Order item)
/*  24:    */     throws Exception
/*  25:    */   {
/*  26:318 */     long id = -1L;
/*  27:319 */     WebElement myDynamicElement = null;
/*  28:    */     
/*  29:321 */     PurchaseOrderDTO purchaseOrderDTO = OrderBatchConfiguration.access$0(this.this$0).findBySellerOrderId(item.getAmazonOrderId());
/*  30:322 */     if (((purchaseOrderDTO != null) && (purchaseOrderDTO.getBuyerId() == null)) || ((purchaseOrderDTO == null) && 
/*  31:323 */       (!"Canceled".equals(item.getOrderStatus())) && (item.getBuyerEmail() != null)))
/*  32:    */     {
/*  33:324 */       this.this$0.orderBatchReport.setStep("Checking With sellerCentral");
/*  34:325 */       this.this$0.orderBatchReport.setCurrentItem(this.this$0.orderBatchReport.getCurrentItem() + 1);
/*  35:326 */       if (purchaseOrderDTO != null) {
/*  36:327 */         id = purchaseOrderDTO.getId().longValue();
/*  37:    */       }
/*  38:328 */       purchaseOrderDTO = OrderBatchConfiguration.access$1(this.this$0).orderDTOTOPurchaseOrder(item);
/*  39:329 */       if (id != -1L) {
/*  40:330 */         purchaseOrderDTO.setId(Long.valueOf(id));
/*  41:    */       }
/*  42:331 */       if (purchaseOrderDTO.getSellerOrderId() == null) {
/*  43:332 */         purchaseOrderDTO.setSellerOrderId(item.getAmazonOrderId());
/*  44:    */       }
/*  45:333 */       String contactBuyer = "";
/*  46:334 */       this.val$driver.get("https://sellercentral.amazon.com/gp/orders-v2/list/ref=ag_myo_dnav_xx_");
/*  47:    */       try
/*  48:    */       {
/*  49:336 */         myDynamicElement = (WebElement)new WebDriverWait(this.val$driver, 20L).until(
/*  50:337 */           ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@name='searchType']")));
/*  51:    */         
/*  52:339 */         myDynamicElement.sendKeys(new CharSequence[] { "Buyer Email" });
/*  53:340 */         myDynamicElement = 
/*  54:341 */           (WebElement)new WebDriverWait(this.val$driver, 20L).until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='searchKeyword']")));
/*  55:342 */         myDynamicElement.sendKeys(new CharSequence[] { item.getBuyerEmail() });
/*  56:    */         
/*  57:344 */         myDynamicElement = this.val$driver.findElement(By.xpath(".//*[@id='_myoLO_preSelectedRangeSelect']"));
/*  58:    */         
/*  59:346 */         myDynamicElement.sendKeys(new CharSequence[] { "Exact dates" });
/*  60:    */         
/*  61:348 */         myDynamicElement = 
/*  62:349 */           (WebElement)new WebDriverWait(this.val$driver, 20L).until(ExpectedConditions.presenceOfElementLocated(By.id("exactDateBegin")));
/*  63:350 */         String rangeDate = purchaseOrderDTO.getLastUpdateDate().getMonth().getValue() + "/" + 
/*  64:351 */           purchaseOrderDTO.getLastUpdateDate().getDayOfMonth() + "/" + 
/*  65:352 */           purchaseOrderDTO.getLastUpdateDate().getYear();
/*  66:353 */         myDynamicElement.clear();
/*  67:354 */         myDynamicElement.sendKeys(new CharSequence[] { "1/1/08" });
/*  68:    */         
/*  69:356 */         myDynamicElement = this.val$driver.findElement(By.id("exactDateEnd"));
/*  70:357 */         myDynamicElement.clear();
/*  71:358 */         myDynamicElement.sendKeys(new CharSequence[] { "12/28/17" });
/*  72:    */         
/*  73:360 */         new WebDriverWait(this.val$driver, 20L);
/*  74:    */         
/*  75:    */ 
/*  76:363 */         new WebDriverWait(this.val$driver, 20L);
/*  77:    */         
/*  78:365 */         this.val$driver.findElement(By.xpath(".//*[@id='SearchID']")).click();
/*  79:    */       }
/*  80:    */       catch (Exception e)
/*  81:    */       {
/*  82:368 */         OrderBatchConfiguration.access$2(this.this$0, this.val$driver);
/*  83:369 */         return purchaseOrderDTO;
/*  84:    */       }
/*  85:    */       try
/*  86:    */       {
/*  87:374 */         WebElement notFoundElement = 
/*  88:375 */           (WebElement)new WebDriverWait(this.val$driver, 7L).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
/*  89:376 */           "(.//*[contains(@href,'" + purchaseOrderDTO.getSellerOrderId() + "')])[1]")));
/*  90:    */         
/*  91:378 */         WebElement buyerElement = this.val$driver.findElement(By.xpath("(.//*[contains(@id,'buyerName')])[1]"));
/*  92:    */         
/*  93:380 */         buyerElement.click();
/*  94:    */         
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:389 */         buyerElement = (WebElement)new WebDriverWait(this.val$driver, 20L).until(
/* 103:390 */           ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='commMgrCompositionSubject']")));
/* 104:    */         
/* 105:392 */         purchaseOrderDTO.setBuyerId(GeneralUtils.getParameterByName("buyerID", this.val$driver.getCurrentUrl()));
/* 106:393 */         this.val$driver.navigate().back();
/* 107:394 */         new WebDriverWait(this.val$driver, 20L);
/* 108:    */       }
/* 109:    */       catch (Exception e)
/* 110:    */       {
/* 111:404 */         this.val$driver.navigate().back();
/* 112:    */       }
/* 113:    */     }
/* 114:408 */     return purchaseOrderDTO;
/* 115:    */   }
/* 116:    */ }


/* Location:           D:\apache-tomcat-9.0.0.M17\webapps\reviewtracker-0.0.1-SNAPSHOT\
 * Qualified Name:     com.milo.amz.review.batch.OrderBatchConfiguration.1
 * JD-Core Version:    0.7.0.1
 */