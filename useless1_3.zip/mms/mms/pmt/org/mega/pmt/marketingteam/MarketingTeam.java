package org.mega.pmt.marketingteam;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.user.User;

@Entity
@Table(name = "PMT_MARKETING_TEAM ", uniqueConstraints = @UniqueConstraint(name = "PK_PMT_MARKETING_TEAM", columnNames = "TEAM_ID"))
public class MarketingTeam extends BaseEntity{
	
	@Id
    @Column(name = "TEAM_ID")
    private long rowId;
	
	@Column(name = "TEAM_TITLE", length = 300)
	private String teamTitle;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "USER_ID", foreignKey = @ForeignKey(name = "FK_PMT_MARK_REFERENCE_CO_USER") , nullable = false)
	private User user;
	
	@Column(name = "DESCRIPTION", length = 500)
	private String description;
	
	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

    
    public String getTeamTitle() {
		return teamTitle;
	}

	public void setTeamTitle(String teamTitle) {
		this.teamTitle = teamTitle;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = teamTitle;
    }
	
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = teamTitle;
    }
}
