package org.mega.pmt.marketingteam;

import org.mega.core.base.BaseCopier;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;

public class MarketingTeamCopier extends BaseCopier<MarketingTeam, MarketingTeamDTO>{

	@Override
	public MarketingTeamDTO copyFromEntity(MarketingTeam marketingTeam) {
		MarketingTeamDTO marketingTeamDTO = new MarketingTeamDTO();
		marketingTeamDTO.setRowId(marketingTeam.getRowId());
		marketingTeamDTO.setTeamTitle(marketingTeam.getTeamTitle());
		marketingTeamDTO.setDescription(marketingTeam.getDescription());
		if(marketingTeam.getUser() != null){
			UserDTO userDTO = new UserDTO();
			userDTO.setRowId(marketingTeam.getUser().getRowId());
			userDTO.setFullName(marketingTeam.getUser().getFullName());
			userDTO.setAccessKey(marketingTeam.getAccessKey());
			marketingTeamDTO.setUserDTO(userDTO);
		}
		copyFromEntityBaseField(marketingTeam, marketingTeamDTO);
		return marketingTeamDTO;
	}

	@Override
	public MarketingTeam copyToEntity(MarketingTeamDTO marketingTeamDTO) throws Exception {
		MarketingTeam marketingTeam = new MarketingTeam();
		marketingTeam.setRowId(marketingTeamDTO.getRowId());
		if(marketingTeamDTO.getUserDTO() != null){
			User user = new User();
			user.setRowId(marketingTeamDTO.getUserDTO().getRowId());
			marketingTeam.setUser(user);
			user.setAccessKey(marketingTeamDTO.getAccessKey());
		}
		marketingTeam.setTeamTitle(marketingTeamDTO.getTeamTitle());
		marketingTeam.setDescription(marketingTeamDTO.getDescription());
		copyToEntityBaseField(marketingTeam, marketingTeamDTO);
		return marketingTeam;
	}

}
