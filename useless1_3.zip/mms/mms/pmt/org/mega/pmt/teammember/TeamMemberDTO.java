package org.mega.pmt.teammember;

import org.mega.core.base.BaseDTO;
import org.mega.core.user.UserDTO;
import org.mega.pmt.marketingteam.MarketingTeamDTO;

public class TeamMemberDTO extends BaseDTO{

	private long rowId;
	private UserDTO userDTO;
	private MarketingTeamDTO teamDTO;
	private String description;
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public UserDTO getUserDTO() {
		return userDTO;
	}

	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}

	public MarketingTeamDTO getTeamDTO() {
		return teamDTO;
	}

	public void setTeamDTO(MarketingTeamDTO teamDTO) {
		this.teamDTO = teamDTO;
	}

	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

}
