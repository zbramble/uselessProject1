package org.mega.pmt.teammember;

import org.mega.core.base.BaseCopier;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.pmt.marketingteam.MarketingTeam;
import org.mega.pmt.marketingteam.MarketingTeamDTO;

public class TeamMemberCopier extends BaseCopier<TeamMember, TeamMemberDTO>{

	@Override
	public TeamMemberDTO copyFromEntity(TeamMember teamMember) {
		TeamMemberDTO teamMemberDTO = new TeamMemberDTO();
		teamMemberDTO.setRowId(teamMember.getRowId());
		teamMemberDTO.setDescription(teamMember.getDescription());
		if(teamMember.getUser() != null){
			UserDTO userDTO = new UserDTO();
			userDTO.setRowId(teamMember.getUser().getRowId());
			userDTO.setFullName(teamMember.getUser().getFullName());
			teamMemberDTO.setUserDTO(userDTO);
		}
		if(teamMember.getTeam() != null){
			MarketingTeamDTO marketingTeamDTO = new MarketingTeamDTO();
			marketingTeamDTO.setRowId(teamMember.getTeam().getRowId());
			marketingTeamDTO.setTeamTitle(teamMember.getTeam().getTeamTitle());
			teamMemberDTO.setTeamDTO(marketingTeamDTO);
		}
		copyFromEntityBaseField(teamMember, teamMemberDTO);
		return teamMemberDTO;
	}

	@Override
	public TeamMember copyToEntity(TeamMemberDTO teamMemberDTO) throws Exception {
		TeamMember teamMember = new TeamMember();
		teamMember.setRowId(teamMemberDTO.getRowId());
		teamMember.setDescription(teamMemberDTO.getDescription());
		if(teamMemberDTO.getUserDTO() != null){
			User user = new User();
			user.setRowId(teamMemberDTO.getUserDTO().getRowId());
			user.setFullName(teamMemberDTO.getUserDTO().getFullName());
			teamMember.setUser(user);
		}
		if(teamMemberDTO.getTeamDTO() != null){
			MarketingTeam marketingTeam = new MarketingTeam();
			marketingTeam.setRowId(teamMemberDTO.getTeamDTO().getRowId());
			marketingTeam.setTeamTitle(teamMemberDTO.getTeamDTO().getTeamTitle());
			teamMember.setTeam(marketingTeam);
		}
		copyToEntityBaseField(teamMember, teamMemberDTO);
		return teamMember;
	}

}
