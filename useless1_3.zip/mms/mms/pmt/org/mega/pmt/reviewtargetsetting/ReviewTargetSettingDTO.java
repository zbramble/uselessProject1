package org.mega.pmt.reviewtargetsetting;

import org.mega.core.base.BaseDTO;
import org.mega.product.channelsku.ProductChannelSKUDTO;

public class ReviewTargetSettingDTO extends BaseDTO{
	
	private long rowId;
	private ProductChannelSKUDTO channelSKU;
	//private String description;
	private double reviewTarget;
	private int dailyThreshould;
	private int weeklyThreshould;
	private int monthlyThreshould;
	private int dailyCount;
	private int weeklyCount;
	private int monthlyCount;
	private String negativeCollectStart;
	private String realTimeNotification;
	private String dailyNotification;
	private String weeklyNotification;
	private String monthlyNotification;
	private int negativeRiskCount;
	/*private int dailyReviewCount;
	private int weeklyReviewCount;
	private int monthlyReviewCount;*/
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ProductChannelSKUDTO getChannelSKU() {
		return channelSKU;
	}
	public void setChannelSKU(ProductChannelSKUDTO channelSKU) {
		this.channelSKU = channelSKU;
	}
	/*public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}*/
	public double getReviewTarget() {
		return reviewTarget;
	}
	public void setReviewTarget(double reviewTarget) {
		this.reviewTarget = reviewTarget;
	}
	public int getDailyThreshould() {
		return dailyThreshould;
	}
	public void setDailyThreshould(int dailyThreshould) {
		this.dailyThreshould = dailyThreshould;
	}
	public int getWeeklyThreshould() {
		return weeklyThreshould;
	}
	public void setWeeklyThreshould(int weeklyThreshould) {
		this.weeklyThreshould = weeklyThreshould;
	}
	public int getMonthlyThreshould() {
		return monthlyThreshould;
	}
	public void setMonthlyThreshould(int monthlyThreshould) {
		this.monthlyThreshould = monthlyThreshould;
	}
	public int getDailyCount() {
		return dailyCount;
	}
	public void setDailyCount(int dailyCount) {
		this.dailyCount = dailyCount;
	}
	public int getWeeklyCount() {
		return weeklyCount;
	}
	public void setWeeklyCount(int weeklyCount) {
		this.weeklyCount = weeklyCount;
	}
	public int getMonthlyCount() {
		return monthlyCount;
	}
	public void setMonthlyCount(int monthlyCount) {
		this.monthlyCount = monthlyCount;
	}
	public String getNegativeCollectStart() {
		return negativeCollectStart;
	}
	public void setNegativeCollectStart(String negativeCollectStart) {
		this.negativeCollectStart = negativeCollectStart;
	}
	public String getRealTimeNotification() {
		return realTimeNotification;
	}
	public void setRealTimeNotification(String realTimeNotification) {
		this.realTimeNotification = realTimeNotification;
	}
	
	public String getDailyNotification() {
		return dailyNotification;
	}
	public void setDailyNotification(String dailyNotification) {
		this.dailyNotification = dailyNotification;
	}
	public String getWeeklyNotification() {
		return weeklyNotification;
	}
	public void setWeeklyNotification(String weeklyNotification) {
		this.weeklyNotification = weeklyNotification;
	}
	public String getMonthlyNotification() {
		return monthlyNotification;
	}
	public void setMonthlyNotification(String monthlyNotification) {
		this.monthlyNotification = monthlyNotification;
	}
	public int getNegativeRiskCount() {
		return negativeRiskCount;
	}
	public void setNegativeRiskCount(int negativeRiskCount) {
		this.negativeRiskCount = negativeRiskCount;
	}
	
	/*public int getDailyReviewCount() {
		return dailyReviewCount;
	}
	public void setDailyReviewCount(int dailyReviewCount) {
		this.dailyReviewCount = dailyReviewCount;
	}
	public int getWeeklyReviewCount() {
		return weeklyReviewCount;
	}
	public void setWeeklyReviewCount(int weeklyReviewCount) {
		this.weeklyReviewCount = weeklyReviewCount;
	}
	public int getMonthlyReviewCount() {
		return monthlyReviewCount;
	}
	public void setMonthlyReviewCount(int monthlyReviewCount) {
		this.monthlyReviewCount = monthlyReviewCount;
	}*/

}
