package org.mega.pmt.reviewtargetsetting;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/reviewSetting")
public class ReviewTargetSettingService {

	@POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ReviewTargetSettingFacade.getInstance().list(new BusinessParam(userSession, filter));
    }
	
	@POST
    @Path("/save")
    public ServiceResult save(ReviewTargetSettingDTO reviewTargetRuleSettingDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(reviewTargetRuleSettingDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try {
			return ReviewTargetSettingFacade.getInstance().save(reviewTargetRuleSettingDTO, new BusinessParam(userSession));
		} catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
		}
    }
	
	@POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ReviewTargetSettingFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }
	
	@POST
	@Path("/saveSelected")
	public ServiceResult saveSelected(List<ReviewTargetSettingDTO> listReview){
		 UserSession userSession;
	        try {
	            userSession = UserSessionManager.getUserSession(listReview.get(0).getTicket());
	        } catch (Exception e) {
	            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
	        }
	        try {
				return ReviewTargetSettingFacade.getInstance().saveSelected(listReview, new BusinessParam(userSession));
			} catch (Exception e) {
	            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
			}
	}
}
