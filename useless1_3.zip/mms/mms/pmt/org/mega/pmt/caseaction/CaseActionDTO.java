package org.mega.pmt.caseaction;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.user.UserDTO;
import org.mega.product.customerservicecase.CustomerServiceCaseDTO;

public class CaseActionDTO extends BaseDTO{

    private long rowId;
	private CustomerServiceCaseDTO customerServiceCaseDTO;
	private ComboValDTO actionTypeDTO;
	private UserDTO actionUserDTO;
	private String actionEmail;
	private String actionDate;
	private String actionDesc;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public CustomerServiceCaseDTO getCustomerServiceCaseDTO() {
		return customerServiceCaseDTO;
	}
	public void setCustomerServiceCaseDTO(CustomerServiceCaseDTO customerServiceCaseDTO) {
		this.customerServiceCaseDTO = customerServiceCaseDTO;
	}
	public ComboValDTO getActionTypeDTO() {
		return actionTypeDTO;
	}
	public void setActionTypeDTO(ComboValDTO actionTypeDTO) {
		this.actionTypeDTO = actionTypeDTO;
	}
	public UserDTO getActionUserDTO() {
		return actionUserDTO;
	}
	public void setActionUserDTO(UserDTO actionUserDTO) {
		this.actionUserDTO = actionUserDTO;
	}
	public String getActionEmail() {
		return actionEmail;
	}
	public void setActionEmail(String actionEmail) {
		this.actionEmail = actionEmail;
	}
	public String getActionDate() {
		return actionDate;
	}
	public void setActionDate(String actionDate) {
		this.actionDate = actionDate;
	}
	public String getActionDesc() {
		return actionDesc;
	}
	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}
	
}
