package org.mega.pmt.caseaction;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.user.User;
import org.mega.product.customerservicecase.CustomerServiceCase;

@Entity
@Table(name = "PMT_CS_CASE_ACTION ", uniqueConstraints = @UniqueConstraint(name = "PK_PMT_CS_CASE_ACTION", columnNames = "PMT_CS_CASE_ACTION_ID"))
public class CaseAction extends BaseEntity{

	@Id
    @Column(name = "PMT_CS_CASE_ACTION_ID")
    private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PMT_CUSTOMER_SERVICE_CASE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CS_C_CUSTOMER_SERVICE") , nullable = false)
	private CustomerServiceCase customerServiceCase;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ACTION_TYPE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CS_C_REFERENCE_CO_COMBO") , nullable = false)
	private ComboVal actionType;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ACTION_USER_ID", foreignKey = @ForeignKey(name = "FK_PMT_CS_C_REFERENCE_CO_COMBO") , nullable = false)
	private User actionUser;
	
	@Column(name="ACTION_EMAIL")
	private String actionEmail;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "ACTION_DATE")
	private Date actionDate;
	
	@Column(name="ACTION_DESC")
	private String actionDesc;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public CustomerServiceCase getCustomerServiceCase() {
		return customerServiceCase;
	}
	
	public void setCustomerServiceCase(CustomerServiceCase customerServiceCase) {
		this.customerServiceCase = customerServiceCase;
	}
	public ComboVal getActionType() {
		return actionType;
	}

	public void setActionType(ComboVal actionType) {
		this.actionType = actionType;
	}

	public User getActionUser() {
		return actionUser;
	}

	public void setActionUser(User actionUser) {
		this.actionUser = actionUser;
	}

	public String getActionEmail() {
		return actionEmail;
	}

	public void setActionEmail(String actionEmail) {
		this.actionEmail = actionEmail;
	}

	public Date getActionDate() {
		return actionDate;
	}

	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	public String getActionDesc() {
		return actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = customerServiceCase.getCustomerName();
    }
	
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = customerServiceCase.getCustomerName();
    }

}
