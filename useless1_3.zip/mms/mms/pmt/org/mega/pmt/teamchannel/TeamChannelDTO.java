package org.mega.pmt.teamchannel;

import org.mega.core.base.BaseDTO;
import org.mega.pmt.marketingteam.MarketingTeamDTO;
import org.mega.product.channelsku.ProductChannelSKUDTO;

public class TeamChannelDTO extends BaseDTO{

	private long rowId;
	private MarketingTeamDTO teamDTO;
	private ProductChannelSKUDTO channelSKU;
	private String description;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public MarketingTeamDTO getTeamDTO() {
		return teamDTO;
	}
	public void setTeamDTO(MarketingTeamDTO teamDTO) {
		this.teamDTO = teamDTO;
	}
	public ProductChannelSKUDTO getChannelSKU() {
		return channelSKU;
	}
	public void setChannelSKU(ProductChannelSKUDTO channelSKU) {
		this.channelSKU = channelSKU;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
