package org.mega.pmt.teamchannel;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.pmt.marketingteam.MarketingTeamDTO;

public class MasterTeamChannelDTO extends BaseDTO{
	
	private MarketingTeamDTO marketingTeamDTO;
	private List<String> channelSKUDTO;
	public MarketingTeamDTO getMarketingTeamDTO() {
		return marketingTeamDTO;
	}
	public void setMarketingTeamDTO(MarketingTeamDTO marketingTeamDTO) {
		this.marketingTeamDTO = marketingTeamDTO;
	}
	
	public List<String> getChannelSKUDTO() {
		return channelSKUDTO;
	}
	public void setChannelSKUDTO(List<String> channelSKUDTO) {
		this.channelSKUDTO = channelSKUDTO;
	}
	@Override
	public Long getRowId() {
		// TODO Auto-generated method stub
		return marketingTeamDTO.getRowId();
	}
	
	

}
