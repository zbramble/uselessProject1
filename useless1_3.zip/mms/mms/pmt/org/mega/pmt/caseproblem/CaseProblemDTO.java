package org.mega.pmt.caseproblem;

import org.mega.core.base.BaseDTO;
import org.mega.core.file.FileDTO;
import org.mega.product.customerservicecase.CustomerServiceCaseDTO;
import org.mega.product.problem.ProductProblemDTO;

public class CaseProblemDTO extends BaseDTO{

    private long rowId;
	private CustomerServiceCaseDTO customerServiceCaseDTO;
	private ProductProblemDTO productProblemDTO;
	private String problemDescription;
	private FileDTO relatedDocDTO;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public CustomerServiceCaseDTO getCustomerServiceCaseDTO() {
		return customerServiceCaseDTO;
	}
	public void setCustomerServiceCaseDTO(CustomerServiceCaseDTO customerServiceCaseDTO) {
		this.customerServiceCaseDTO = customerServiceCaseDTO;
	}
	public ProductProblemDTO getProductProblemDTO() {
		return productProblemDTO;
	}
	public void setProductProblemDTO(ProductProblemDTO productProblemDTO) {
		this.productProblemDTO = productProblemDTO;
	}
	public String getProblemDescription() {
		return problemDescription;
	}
	public void setProblemDescription(String problemDescription) {
		this.problemDescription = problemDescription;
	}
	public FileDTO getRelatedDocDTO() {
		return relatedDocDTO;
	}
	public void setRelatedDocDTO(FileDTO relatedDocDTO) {
		this.relatedDocDTO = relatedDocDTO;
	}

}
