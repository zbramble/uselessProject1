package org.mega.pmt.caseproblem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.file.File;
import org.mega.product.customerservicecase.CustomerServiceCase;
import org.mega.product.problem.ProductProblem;

@Entity
@Table(name = "PMT_CS_CASE_PROBLEM ", uniqueConstraints = @UniqueConstraint(name = "PK_PMT_CS_CASE_PROBLEM", columnNames = "PMT_CS_CASE_PROBLEM"))
public class CaseProblem extends BaseEntity{

	@Id
    @Column(name = "PMT_CS_CASE_PROBLEM")
    private long rowId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PMT_CUSTOMER_SERVICE_CASE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUSTOMER_SERVICE_PROB") , nullable = false)
	private CustomerServiceCase customerServiceCase;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_PROBLEM_ID", foreignKey = @ForeignKey(name = "FK_PMT_PRODUCT_PROBLEM") , nullable = false)
	private ProductProblem productProblem;
	
	@Column(name = "PROBLEM_DESCRIPTION", length = 2000)
	private String problemDescription;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "RELATED_DOC", foreignKey = @ForeignKey(name = "FK_FILE_PRODUCT") , nullable = true)
	private File relatedDoc;
	
	public CustomerServiceCase getCustomerServiceCase() {
		return customerServiceCase;
	}

	public void setCustomerServiceCase(CustomerServiceCase customerServiceCase) {
		this.customerServiceCase = customerServiceCase;
	}

	public ProductProblem getProductProblem() {
		return productProblem;
	}

	public void setProductProblem(ProductProblem productProblem) {
		this.productProblem = productProblem;
	}

	public String getProblemDescription() {
		return problemDescription;
	}

	public void setProblemDescription(String problemDescription) {
		this.problemDescription = problemDescription;
	}

	public File getRelatedDoc() {
		return relatedDoc;
	}

	public void setRelatedDoc(File relatedDoc) {
		this.relatedDoc = relatedDoc;
	}

	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = customerServiceCase.getProduct().getProductTitle();
    }
	
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = customerServiceCase.getProduct().getProductTitle();
    }
}
