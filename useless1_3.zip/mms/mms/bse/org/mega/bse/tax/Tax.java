package org.mega.bse.tax;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_TAX_CLASS", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_TAX_CLASS", columnNames = "TAX_CLASS_ID") )
public class Tax extends BaseEntity {

	@Id
	@Column(name = "TAX_CLASS_ID")
	private long rowId;

	@Column(name = "TAX_CLASS_TITLE", length = 300)
	private String taxClassTitle;

	@Column(name = "RATE")
	private long rate;

	@Column(name = "DESCRIPTION", length = 500)
	private String description;
	
	@Column(name = "IS_DEFAULT", length = 1)
	private boolean isDefault;

	public boolean isIsDefault() {
		return isDefault;
	}

	public void setIsDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}
	
	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getTaxClassTitle() {
		return taxClassTitle;
	}

	public void setTaxClassTitle(String taxClassTitle) {
		this.taxClassTitle = taxClassTitle;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = taxClassTitle;
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = taxClassTitle;
    }

}
