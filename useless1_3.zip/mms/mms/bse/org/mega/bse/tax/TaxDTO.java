package org.mega.bse.tax;

import org.mega.core.base.BaseDTO;

public class TaxDTO extends BaseDTO {

	private long rowId;
	private String taxClassTitle;
	private long rate;
	private String description;
	private boolean isDefault;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getTaxClassTitle() {
		return taxClassTitle;
	}

	public void setTaxClassTitle(String taxClassTitle) {
		this.taxClassTitle = taxClassTitle;
	}

	public long getRate() {
		return rate;
	}

	public void setRate(long rate) {
		this.rate = rate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isIsDefault() {
		return isDefault;
	}

	public void setIsDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}

}
