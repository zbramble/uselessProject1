package org.mega.bse.channel;

import org.mega.core.base.BaseDTO;

public class ChannelDTO extends BaseDTO{
	private long rowId;
	private String description;
	private String channelName;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
}
