package org.mega.bse.channelintegration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.site.Site;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.organization.Organization;

@Entity
@Table(name = "BSE_CHANNEL_INTEGRATION", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_CHANNEL_INTEGRATION", columnNames = "CHANNEL_INTEGRATION_ID"))
public class ChannelIntegration extends BaseEntity{
	
	@Id
    @Column(name = "CHANNEL_INTEGRATION_ID")
    private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SITE_ID", foreignKey = @ForeignKey(name = "FK_BSE_CHANL_INTEG_SITE") , nullable = true)
	private Site site;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ORG_ID", foreignKey = @ForeignKey(name = "FK_BSE_CHANL_INTEG_ORG") , nullable = true)
	private Organization org;

	@Column(name = "AMAZON_ACCESS_KEY", length = 500,nullable = true)
	private String amazonAccessKey;
	
	@Column(name = "SECRET_KEY", length = 500,nullable = true)
	private String secretKey;
	
	@Column(name = "SELLER_ID", length = 500,nullable = true)
	private String sellerId;
	
	@Column(name = "MARKETPLACE_ID", length = 500,nullable = true)
	private String marketplaceId;
	
	@Column(name = "SELLER_USER_NAME", length = 500,nullable = true)
	private String sellerUserName;
	
	@Column(name = "SELLER_USER_PASS", length = 500,nullable = true)
	private String sellerUserPass;

	
	public String getAmazonAccessKey() {
		return amazonAccessKey;
	}

	public void setAmazonAccessKey(String amazonAccessKey) {
		this.amazonAccessKey = amazonAccessKey;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getMarketplaceId() {
		return marketplaceId;
	}

	public void setMarketplaceId(String marketplaceId) {
		this.marketplaceId = marketplaceId;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getSellerUserName() {
		return sellerUserName;
	}

	public void setSellerUserName(String sellerUserName) {
		this.sellerUserName = sellerUserName;
	}

	public String getSellerUserPass() {
		return sellerUserPass;
	}

	public void setSellerUserPass(String sellerUserPass) {
		this.sellerUserPass = sellerUserPass;
	}

	public Organization getOrg() {
		return org;
	}

	public void setOrg(Organization org) {
		this.org = org;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = amazonAccessKey + "/"+sellerUserName;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = amazonAccessKey + "/"+sellerUserName;
    }
}
