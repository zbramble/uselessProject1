package org.mega.bse.channelintegration;


import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.organization.OrganizationDTO;


public class ChannelIntegrationDTO extends BaseDTO{

    private long rowId;
    private SiteDTO siteDTO;
    private OrganizationDTO orgDTO;
    private String amazonAccessKeyDTO;
    private String secretKeyDTO;
    private String sellerIdDTO;
    private String marketplaceIdDTO;
    private String sellerUserNameDTO;
    private String sellerUserPassDTO;
    
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public SiteDTO getSiteDTO() {
		return siteDTO;
	}
	public void setSiteDTO(SiteDTO siteDTO) {
		this.siteDTO = siteDTO;
	}
	public OrganizationDTO getOrgDTO() {
		return orgDTO;
	}
	public void setOrgDTO(OrganizationDTO orgDTO) {
		this.orgDTO = orgDTO;
	}
	public String getAmazonAccessKeyDTO() {
		return amazonAccessKeyDTO;
	}
	public void setAmazonAccessKeyDTO(String amazonAccessKeyDTO) {
		this.amazonAccessKeyDTO = amazonAccessKeyDTO;
	}
	public String getSecretKeyDTO() {
		return secretKeyDTO;
	}
	public void setSecretKeyDTO(String secretKeyDTO) {
		this.secretKeyDTO = secretKeyDTO;
	}
	public String getSellerIdDTO() {
		return sellerIdDTO;
	}
	public void setSellerIdDTO(String sellerIdDTO) {
		this.sellerIdDTO = sellerIdDTO;
	}
	public String getMarketplaceIdDTO() {
		return marketplaceIdDTO;
	}
	public void setMarketplaceIdDTO(String marketplaceIdDTO) {
		this.marketplaceIdDTO = marketplaceIdDTO;
	}
	public String getSellerUserNameDTO() {
		return sellerUserNameDTO;
	}
	public void setSellerUserNameDTO(String sellerUserNameDTO) {
		this.sellerUserNameDTO = sellerUserNameDTO;
	}
	public String getSellerUserPassDTO() {
		return sellerUserPassDTO;
	}
	public void setSellerUserPassDTO(String sellerUserPassDTO) {
		this.sellerUserPassDTO = sellerUserPassDTO;
	}
    
}
