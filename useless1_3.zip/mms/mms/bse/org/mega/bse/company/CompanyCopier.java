package org.mega.bse.company;

import org.mega.core.base.BaseCopier;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;

public class CompanyCopier extends BaseCopier<Company, CompanyDTO>{

	@Override
	public CompanyDTO copyFromEntity(Company company) {
		CompanyDTO companyDTO = new CompanyDTO();
		companyDTO.setRowId(company.getRowId());
		companyDTO.setAddress1(company.getAddress1());
		companyDTO.setAddress2(company.getAddress2());
		if(company.getCity() != null){
			LocationDTO lDTO = new LocationDTO();
			lDTO.setRowId(company.getCity().getRowId());
			lDTO.setName(company.getCity().getName());
			companyDTO.setCityDTO(lDTO);
		}
		if(company.getProvince() != null){
			LocationDTO lDTO = new LocationDTO();
			lDTO.setRowId(company.getProvince().getRowId());
			lDTO.setName(company.getProvince().getName());
			companyDTO.setProvinceDTO(lDTO);
		}
		if(company.getCountry() != null){
			LocationDTO lDTO = new LocationDTO();
			lDTO.setRowId(company.getCountry().getRowId());
			lDTO.setName(company.getCountry().getName());
			companyDTO.setCountryDTO(lDTO);
		}
		companyDTO.setCompanyEmail(company.getCompanyEmail());
		if(company.getCompanyLogo() != null){
			FileDTO fDTO = new FileDTO();
			fDTO.setRowId(company.getCompanyLogo().getRowId());
			fDTO.setName(company.getCompanyLogo().getName());
			companyDTO.setCompanyLogo(fDTO);
		}
		companyDTO.setCompanyName(company.getCompanyName());
		companyDTO.setCompanyPersonName(company.getCompanyPersonName());
		companyDTO.setCompanyPhone(company.getCompanyPhone());
		companyDTO.setCompanyWebsite(company.getCompanyWebsite());
		companyDTO.setDescription(company.getDescription());
		companyDTO.setPersonRole(company.getPersonRole());
		companyDTO.setZipcode(company.getZipcode());
		copyFromEntityBaseField(company, companyDTO);
		return companyDTO;
	}

	@Override
	public Company copyToEntity(CompanyDTO companyDTO) throws Exception {
		Company company = new Company();
		company.setRowId(companyDTO.getRowId());
		company.setAddress1(companyDTO.getAddress1());
		company.setAddress2(companyDTO.getAddress2());
		if(companyDTO.getCityDTO() != null){
			Location l = new Location();
			l.setRowId(companyDTO.getCityDTO().getRowId());
			l.setName(companyDTO.getCityDTO().getName());
			company.setCity(l);
		}
		if(companyDTO.getProvinceDTO() != null){
			Location l = new Location();
			l.setRowId(companyDTO.getProvinceDTO().getRowId());
			l.setName(companyDTO.getProvinceDTO().getName());
			company.setProvince(l);
		}
		if(companyDTO.getCountryDTO() != null){
			Location l = new Location();
			l.setRowId(companyDTO.getCountryDTO().getRowId());
			l.setName(companyDTO.getCountryDTO().getName());
			company.setCountry(l);
		}
		if(companyDTO.getCompanyLogo() != null){
			File f = new File();
			f.setRowId(companyDTO.getCompanyLogo().getRowId());
			f.setName(companyDTO.getCompanyLogo().getName());
			company.setCompanyLogo(f);
		}
		company.setCompanyEmail(companyDTO.getCompanyEmail());
		company.setCompanyName(companyDTO.getCompanyName());
		company.setCompanyPersonName(companyDTO.getCompanyPersonName());
		company.setCompanyPhone(companyDTO.getCompanyPhone());
		company.setCompanyWebsite(companyDTO.getCompanyWebsite());
		company.setDescription(companyDTO.getDescription());
		company.setPersonRole(companyDTO.getPersonRole());
		company.setZipcode(companyDTO.getZipcode());
		copyToEntityBaseField(company, companyDTO);
		return company;
	}

}
