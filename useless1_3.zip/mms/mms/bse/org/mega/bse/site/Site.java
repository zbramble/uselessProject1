package org.mega.bse.site;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.channel.Channel;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_SITE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_SITE", columnNames = "BSE_SITE_ID") )
public class Site extends BaseEntity{

	@Id
	@Column(name = "BSE_SITE_ID")
	private long rowId;
	
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Column(name = "SITE_NAME", length = 500,nullable = true)
	private String siteName;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BSE_CHANNEL_ID", foreignKey = @ForeignKey(name = "FK_BSE_SITE_REFERENCE_BSE_CHAN") , nullable = true)
	private Channel channel;
	
	public Channel getChannel() {
		return channel;
	}
	
	public void setChannel(Channel channel) {
		this.channel = channel;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSiteName() {
		return siteName;
	}
	
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	
	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = "";
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = "";
    }

}
