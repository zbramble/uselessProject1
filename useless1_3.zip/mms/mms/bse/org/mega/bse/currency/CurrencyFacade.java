package org.mega.bse.currency;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class CurrencyFacade extends BaseFacade {

	private static CurrencyCopier copier = new CurrencyCopier();
	private static CurrencyFacade facade = new CurrencyFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static CurrencyFacade getInstace() {
		return facade;
	}

}
