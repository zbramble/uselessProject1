package org.mega.bse.category;

import org.mega.core.base.BaseCopier;

public class CategoryCopier extends BaseCopier<Category, CategoryDTO>{

	@Override
	public CategoryDTO copyFromEntity(Category category) {
		CategoryDTO categoryDTO = new CategoryDTO();
		categoryDTO.setRowId(category.getRowId());
		if(category.getTopCategory() != null){
			CategoryDTO c = new CategoryDTO();
			c.setRowId(category.getTopCategory().getRowId());
			c.setCategoryDescription(category.getTopCategory().getCategoryDescription());
			categoryDTO.setTopCategoryDTO(c);
		}
		categoryDTO.setCategoryDescription(category.getCategoryDescription());
		categoryDTO.setDescription(category.getDescription());
		categoryDTO.setEnable(category.isEnable());
		copyFromEntityBaseField(category, categoryDTO);
		return categoryDTO;
	}

	@Override
	public Category copyToEntity(CategoryDTO categoryDTO) throws Exception {
		Category category = new Category();
		category.setRowId(categoryDTO.getRowId());
		if(categoryDTO.getTopCategoryDTO() != null){
			Category c = new Category();
			c.setRowId(categoryDTO.getTopCategoryDTO().getRowId());
			c.setCategoryDescription(categoryDTO.getCategoryDescription());
			category.setTopCategory(c);
		}
		category.setCategoryDescription(categoryDTO.getCategoryDescription());
		category.setDescription(categoryDTO.getDescription());
		category.setEnable(categoryDTO.isEnable());
		copyToEntityBaseField(category, categoryDTO);
		return category;
	}

}
