select team.TEAM_TITLE,co_user.FULL_NAME as manager, team_problems.problems, team_review.all_rev_count, team_review.neg_rev_count, order_items.order_item_count
	from (select * from PMT_MARKETING_TEAM  where ACCESS_KEY like '%%%' ) team
	left join
	(select team,team_id, sum(problems) problems from( --جمع مشکلات
		-- تعداد مشکلات اعلام شده برای هر تیم در هر سایت
		select tc.full_title team, tc.team_id, problems, site.SITE_NAME from (
			select PRODUCT_ID, BSE_SITE_ID , sum(c) problems from(--مشکلات اصلی و فرعی
				--مشکلات اصلی
				select sc.PRODUCT_ID, sc.BSE_SITE_ID, count(sc.PMT_CUSTOMER_SERVICE_CASE_ID) c from PMT_CUSTOMER_SERVICE_CASE sc where ACCESS_KEY like '%%%' and CREATED BETWEEN TO_Date('@FROM_DATE@','YYYY/MM/DD') and TO_Date('2017/07/10','YYYY/MM/DD') and sc.CASE_TYPE_ID=100014 GROUP by sc.PRODUCT_ID,sc.BSE_SITE_ID
				union
				--مشکلات فرعی
				select sc.PRODUCT_ID, sc.BSE_SITE_ID, count(cp.PMT_CS_CASE_PROBLEM) c from (select * from PMT_CS_CASE_PROBLEM where ACCESS_KEY like '%%%'  and CREATED BETWEEN TO_Date('@FROM_DATE@','YYYY/MM/DD') and TO_Date('2017/07/10','YYYY/MM/DD'))cp join PMT_CUSTOMER_SERVICE_CASE sc on (sc.PMT_CUSTOMER_SERVICE_CASE_ID = cp.PMT_CUSTOMER_SERVICE_CASE_ID) GROUP by sc.PRODUCT_ID,sc.BSE_SITE_ID
			)
			GROUP by PRODUCT_ID, BSE_SITE_ID
		) problems
	join	(select PRODUCT_CHANNEL_SKU_id,PRODUCT_ID, BSE_SITE_ID from PRODUCT_CHANNEL_SKU) pcs on (problems.PRODUCT_ID = pcs.PRODUCT_ID and pcs.BSE_SITE_ID = problems.BSE_SITE_ID)
	join PMT_TEAM_CHANNEL tc on tc.PRODUCT_CHANNEL_SKU = pcs.PRODUCT_CHANNEL_SKU_id join BSE_SITE site on site.BSE_SITE_ID = pcs.BSE_SITE_ID
	) GROUP by team,team_id
)team_problems on team_problems.team_id = team.TEAM_ID
left join(
	select team_ch.TEAM_ID, count(team_ch.PRODUCT_CHANNEL_SKU)as all_rev_count,count(setting.PRODUCT_CHANNEL_SKU_ID) neg_rev_count  from 
		(select TEAM_ID, PRODUCT_CHANNEL_SKU from PMT_TEAM_CHANNEL team_ch where ACCESS_KEY like '%%%') team_ch
		JOIN ( select * from RV_REVIEW  where REVIEW_DATE BETWEEN TO_Date('@FROM_DATE@','YYYY/MM/DD') and TO_Date('2017/07/10','YYYY/MM/DD') ) review on review.channel_sku_id = team_ch.PRODUCT_CHANNEL_SKU
	   	left JOIN PMT_REVIEW_TARGET_SETTING setting on (setting.PRODUCT_CHANNEL_SKU_ID = review.CHANNEL_SKU_ID and review.rating < setting.REVIEW_TARGET )
	GROUP by  team_ch.TEAM_ID
)team_review on (team_review.team_id = team.TEAM_ID )
left join
(
	select team_channl.TEAM_ID, count(item.row_id) order_item_count from PMT_TEAM_CHANNEL team_channl join
	(select item.ROW_ID, item.CHANNEL_SKU_ID from ORDER_ORDER_ITEM item  where ACCESS_KEY like '%%%' or ACCESS_KEY is null) item
	on item.CHANNEL_SKU_ID = team_channl.PRODUCT_CHANNEL_SKU
	group by  team_channl.TEAM_ID
) order_items on order_items.team_id = team.team_id
join co_user on co_user.USER_ID = team.user_id





