select FULL_TITLE,sku,site_name,REVIEW_TARGET target,cr current_rate,ac all_review_count,risk_neg, case when risk_neg=0 then '1' when risk_neg < 0 then 'Droped' else '' || ceil(risk_neg) end risk_1_star  , case when risk_neg < 0 then '' || ceil(risk_pos) else ' At risk' end need_5_star   from (
	select FULL_TITLE,sku,site_name,REVIEW_TARGET,t,cr,ac , (t * ac - ac * cr) / (1 - t) risk_neg, (t * ac - ac * cr) / (5 - t) risk_pos from(
	select chann_sku.FULL_TITLE,chann_sku.sku,site.site_name, chann_sku.REVIEW_RATE cr, chann_sku.ALL_REVIEW_COUNT ac,REVIEW_TARGET, case when setting.target_detail=0.5 then floor(REVIEW_TARGET) + 0.25 else (floor(REVIEW_TARGET) - 0.25) end t
		from (select PRODUCT_CHANNEL_SKU_ID,FULL_TITLE,sku,BSE_SITE_ID,REVIEW_RATE,ALL_REVIEW_COUNT from Product_Channel_SKU where ACCESS_KEY like '%%%') chann_sku 
			left join(select PRODUCT_CHANNEL_SKU_ID,REVIEW_TARGET, REVIEW_TARGET - floor(REVIEW_TARGET) target_detail from PMT_REVIEW_TARGET_SETTING) setting on setting.PRODUCT_CHANNEL_SKU_ID = chann_sku.PRODUCT_CHANNEL_SKU_ID
			join BSE_SITE site on site.BSE_SITE_ID = chann_sku.BSE_SITE_ID
	) 
) order by risk_neg

