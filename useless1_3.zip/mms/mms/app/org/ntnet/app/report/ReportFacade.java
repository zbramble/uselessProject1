package org.ntnet.app.report ;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.util.DateUtil;
import org.mega.util.IOUtil;
import org.mega.util.QueryUtil;

public class ReportFacade extends BaseFacade {
	
	private static ReportFacade reportdFacade = new ReportFacade();


	public static ReportFacade getInstance() {
		return reportdFacade;
	}


	/**
	 * @param filter پارامتر اول فیلتر مشخص کنند گزارش است
	 * @return	ردیف اول پاسخ نام فیلدهاست
	 */
	public ServiceResult users(BusinessParam businessParam) throws Exception {
		businessParam.getFilter().getParams().iterator();
		businessParam.getUserSession().checkAccess("VRewardListAction", ACTION.view);
        
        BaseDB db = null;
        try {
            db = BaseDB.open("BaseService.saveEntity");
            
            String where = QueryUtil.genQuery(null, businessParam.getFilter(), QueryUtil.QUERY_TYPE.WHERE_ONLY);
            final String queryString = "select ROW_NUMBER() OVER (ORDER BY  UPDATED desc) rm,e.* from (select USERNAME, FIRST_NAME || ' '  || LAST_NAME as name, IS_ACTIVE, TO_CHAR(updated,'yyyy/mm/dd','NLS_CALENDAR=''PERSIAN''')updated from co_user) e " + 
            		(where.length() > 0 ? where: "")  + " order by UPDATED desc";
            Query query = db.createNativeQuery(queryString);
            query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
            query.setMaxResults(businessParam.getFilter().getPageSize());
	        
            List<Object[]> ret = (List<Object[]>) query.getResultList();
	        int countAll = ret.size();
            db.commitAndclose();
            if(ret.size() == 0)
            	return new ServiceResult(null, countAll);
            String[] header = {"ردیف", "نام کاربری", "نام","فعال", "زمان به روزرسانی"};
            ret.add(0, header);            
            return new ServiceResult(ret, countAll);
        } catch (Exception e) {
            e.printStackTrace();
            db.rollbackAndClose();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
        }
	}

	public ServiceResult reviewAndOrders(BusinessParam businessParam) throws Exception {
        BaseDB db = null;
        try {
            db = businessParam.getDB(60);
	
			businessParam.getUserSession().checkAccess("ReviewAndOrderReport", ACTION.view);
			List<PairValue> params = businessParam.getFilter().getParams();
			
			String fromDate = ((PairValue) params.get(0)).getValue();
			String toDate = ((PairValue) params.get(1)).getValue();
			
			if("".equals(fromDate)){
				fromDate = DateUtil.today("en", -1).substring(0,10);
				toDate = DateUtil.today("en", 0).substring(0,10);
			}
			
			String sql = "select ( " 
							+ " select count(*) as c from RV_REVIEW where REVIEW_DATE BETWEEN TO_Date('" + fromDate +"','YYYY/MM/DD') and  TO_Date('" + toDate+"','YYYY/MM/DD')  "
							+ " )as all_reviews, ( "
							+ " select count(*) as c from RV_REVIEW where REVIEW_DATE BETWEEN TO_Date('" + fromDate +"','YYYY/MM/DD') and  TO_Date('" + toDate+"','YYYY/MM/DD') and BUYER_INFO_MATCHED=1"
							+ " )as matched_reviews ,( "
							+ " select count(*) as c from order_order where PURCHASE_DATE BETWEEN TO_Date('" + fromDate +"','YYYY/MM/DD') and  TO_Date('" + toDate+"','YYYY/MM/DD') and BUYER_EMAIL is not null"
							+ " ) as all_purchased_orders,( "
							+ " select count(*) as c from order_order where PURCHASE_DATE BETWEEN TO_Date('" + fromDate +"','YYYY/MM/DD') and  TO_Date('" + toDate+"','YYYY/MM/DD') and BUYER_ID is not null"
							+ " ) as buyers_found_orders from dual ";
			
            Query query = db.createNativeQuery(sql);
            Object[] ret = (Object[]) query.getResultList().get(0);
            businessParam.releaseDB();
            List r = new ArrayList<>();
            for(Object o: ret)
            	r.add(o);
            r.add(fromDate);
            r.add(toDate);
	        return new ServiceResult(r, 1);
        } catch (Exception e) {
        	businessParam.releaseDB();
            e.printStackTrace();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
        }	
		
	}
	
	public ServiceResult teamNegativeReviews(BusinessParam businessParam) throws Exception {
		BaseDB db = null;
		try {
			db = businessParam.getDB(60);
			
			businessParam.getUserSession().checkAccess("ReviewAndOrderReport", ACTION.view);
			List<PairValue> params = businessParam.getFilter().getParams();
			
			String fromDate = ((PairValue) params.get(0)).getValue();
			String toDate = ((PairValue) params.get(1)).getValue();
			
			if("".equals(fromDate)){
				fromDate = DateUtil.today("en", -1).substring(0,10);
				toDate = DateUtil.today("en", 0).substring(0,10);
			}
			
			String sql = "select t.TEAM_TITLE,cr.site_name,cr.full_title,count(cr.id)as c from PMT_MARKETING_TEAM t join ( "
					+ " select r.id, r.channel_sku_id,tc.TEAM_ID,site.site_name,p.full_title from PMT_TEAM_CHANNEL tc JOIN ("
				 	+ " 	select * from RV_REVIEW  where REVIEW_DATE BETWEEN TO_Date('"+fromDate+"','YYYY/MM/DD') and  TO_Date('"+toDate  +"','YYYY/MM/DD') "
					+ " ) r on r.channel_sku_id = tc.PRODUCT_CHANNEL_SKU "
				 	+ " JOIN PMT_REVIEW_TARGET_SETTING s on (s.PRODUCT_CHANNEL_SKU_ID = tc.PRODUCT_CHANNEL_SKU and r.rating < s.REVIEW_TARGET) "
				 	+ " JOIN PRODUCT_CHANNEL_SKU p on p.PRODUCT_CHANNEL_SKU_ID=tc.PRODUCT_CHANNEL_SKU "
				 	+ " JOIN BSE_SITE site on p.BSE_SITE_ID=site.BSE_SITE_ID "
					+ " ) cr  on cr.TEAM_ID = t.TEAM_ID GROUP by t.TEAM_TITLE , cr.site_name,cr.full_title";
			
			sql = "select ROW_NUMBER() OVER (ORDER BY  team_title,site_name) rm,e.* from (" + sql + ") e";
			
			Query query = db.createNativeQuery(sql);
			query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
			query.setMaxResults(businessParam.getFilter().getPageSize());
			
			List ret = new ArrayList<>();
			String[] header = {"#", "Team", "Channel", "Product","Negative reviews"};
			ret.add(header);
			ret.addAll(query.getResultList());
			
			businessParam.releaseDB();
			ret.add(fromDate);
			ret.add(toDate);
			return new ServiceResult(ret, 1);
		} catch (Exception e) {
			businessParam.releaseDB();
			e.printStackTrace();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
		}	
	}
	
	public ServiceResult teamPerformace(BusinessParam businessParam) throws Exception {
		BaseDB db = null;
		try {
			db = businessParam.getDB(60);
			
			businessParam.getUserSession().checkAccess("TeamPerformaceReport", ACTION.view);
			List<PairValue> params = businessParam.getFilter().getParams();
			
			String fromDate = ((PairValue) params.get(0)).getValue();
			String toDate = ((PairValue) params.get(1)).getValue();
			
			if("".equals(fromDate)){
				fromDate = DateUtil.today("en", -1).substring(0,10);
				toDate = DateUtil.today("en", 0).substring(0,10);
			}
			
			String sql = IOUtil.readAndCloseStream(this.getClass().getResourceAsStream("team_performace.sql"), "utf-8");
			sql = sql.replaceAll("@FROM_DATE@", fromDate).replaceAll("@TO_DATE@", toDate);
			sql = "select ROW_NUMBER() OVER (ORDER BY  team_title) rm,e.TEAM_TITLE, e.manager,nvl(e.problems,0) problems, nvl(e.all_rev_count,0) all_rev_count, nvl(e.neg_rev_count, 0) neg_rev_count, nvl(e.order_item_count,0) order_item_count, nvl(round(e.neg_rev_count *100/e.all_rev_count,2),0) as Negative_Reviews_Rate ,nvl(round(e.problems * 100 /  e.order_item_count,2),0) as Customer_Complain_Rate from (" + sql + ") e";
			
			Query query = db.createNativeQuery(sql);
			query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
			query.setMaxResults(businessParam.getFilter().getPageSize());

			List ret = new ArrayList<>();
			String[] header = {"#", "team", "Manager", "Complains", "All reviews", "Negative reviews", "Orders" ,"Negative reviews rate","Complains rate"};
			
			ret.add(header);
			ret.addAll(query.getResultList());
			
			businessParam.releaseDB();
			ret.add(fromDate);
			ret.add(toDate);
			return new ServiceResult(ret, 1);
		} catch (Exception e) {
			businessParam.releaseDB();
			e.printStackTrace();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
		}	
	}
	
	
	public ServiceResult reviewDropRisk(BusinessParam businessParam) throws Exception {
		BaseDB db = null;
		try {
			db = businessParam.getDB(60);
			
			List<PairValue> params = businessParam.getFilter().getParams();
			String sku = ((PairValue) params.get(0)).getValue();

			businessParam.getUserSession().checkAccess("ReviewDropRiskReport", ACTION.view);
			
			String sql = IOUtil.readAndCloseStream(this.getClass().getResourceAsStream("review_drop_risk.sql"), "utf-8");
			sql = "select ROW_NUMBER() OVER (ORDER BY  risk_neg) rm,e.FULL_TITLE, e.SKU, e.SITE_NAME, e.TARGET, e.CURRENT_RATE, e.ALL_REVIEW_COUNT " +
					",e.RISK_1_STAR, e.NEED_5_STAR from (" + sql + ") e";
			if(sku.length() > 3)
				sql += " where e.sku = '" + sku + "'";
			Query query = db.createNativeQuery(sql);
			query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
			query.setMaxResults(businessParam.getFilter().getPageSize());
			
			List ret = new ArrayList<>();
			String[] header = {"#", "Product", "SKU", "Site", "Target", "Current rate", "All review count","Risk of 1 star","Need for 5 star"};
			
			ret.add(header);
			ret.addAll(query.getResultList());
			
			businessParam.releaseDB();
			return new ServiceResult(ret, 1);
		} catch (Exception e) {
			businessParam.releaseDB();
			e.printStackTrace();
			return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
		}	
	}
	
	@Override
	public BaseCopier getCopier() {//Didn't use
		return null;
	}

}