package org.mega.amazon.MerchantPlace;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.site.Site;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.organization.Organization;

@Entity
@Table(name = "AMAZON_MARKET_PLACE", uniqueConstraints = @UniqueConstraint(name = "PK_AMAZON_MARKET_PLACE", columnNames = "ID"))
public class AmazonMarketPlace extends BaseEntity {

	@Id
	@Column(name = "ID")
	private long rowId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "site_id", nullable = false)
	Site site;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "org_id", nullable = false)
	Organization org;
	
	@Column(name = "AMAZON_ACCESS_KEY", length = 300)
	private String amazonAccessKey;

	@Column(name = "SECRECT_KEY", length = 1000)
	private String secrectKey;

	@Column(name = "SELLER_ID", length = 500)
	private String sellerId;

	@Column(name = "MARKET_PLACE_ID", length = 110, updatable = false)
	private String amazonMarketPlaceId;

	@Column(name = "SERVICE_URL", length = 110, updatable = false)
	private String serviceUrl;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public Organization getOrg() {
		return org;
	}

	public void setOrg(Organization org) {
		this.org = org;
	}

	public String getSecrectKey() {
		return secrectKey;
	}

	public void setSecrectKey(String secrectKey) {
		this.secrectKey = secrectKey;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getAmazonMarketPlaceId() {
		return amazonMarketPlaceId;
	}

	public void setAmazonMarketPlaceId(String amazonMarketPlaceId) {
		this.amazonMarketPlaceId = amazonMarketPlaceId;
	}

	public String getServiceUrl() {
		return serviceUrl;
	}

	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = site.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = site.getFullTitle();
	}
}
