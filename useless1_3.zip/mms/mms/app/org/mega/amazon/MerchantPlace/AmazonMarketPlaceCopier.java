package org.mega.amazon.MerchantPlace;

import org.mega.bse.site.Site;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.organization.Organization;
import org.mega.core.organization.OrganizationDTO;

public class AmazonMarketPlaceCopier extends BaseCopier<AmazonMarketPlace, AmazonMarketPlaceDTO>{

	@Override
	public AmazonMarketPlaceDTO copyFromEntity(AmazonMarketPlace amazonMarketPlace) {
		AmazonMarketPlaceDTO amazonMarketPlaceDTO = new AmazonMarketPlaceDTO();
		amazonMarketPlaceDTO.setRowId(amazonMarketPlace.getRowId());
		amazonMarketPlaceDTO.setAccessKey(amazonMarketPlace.getAccessKey());
		
		if(amazonMarketPlace.getSite() != null){
			SiteDTO s = new SiteDTO();
			s.setRowId(amazonMarketPlace.getSite().getRowId());
			s.setSiteName(amazonMarketPlace.getSite().getSiteName());
			amazonMarketPlaceDTO.setSite(s);
		}
		if(amazonMarketPlace.getOrg() != null){
			OrganizationDTO o = new OrganizationDTO();
			o.setRowId(amazonMarketPlace.getOrg().getRowId());
			o.setName(amazonMarketPlace.getOrg().getName());
			amazonMarketPlaceDTO.setOrg(o);
		}
		amazonMarketPlaceDTO.setSecrectKey(amazonMarketPlace.getSecrectKey());
		amazonMarketPlaceDTO.setSellerId(amazonMarketPlace.getSellerId());
		amazonMarketPlaceDTO.setAmazonMarketPlaceId(amazonMarketPlace.getAmazonMarketPlaceId());
		amazonMarketPlaceDTO.setServiceUrl(amazonMarketPlace.getServiceUrl());
		
		copyFromEntityBaseField(amazonMarketPlace, amazonMarketPlaceDTO);
		return amazonMarketPlaceDTO;
	}

	@Override
	public AmazonMarketPlace copyToEntity(AmazonMarketPlaceDTO amazonMarketPlaceDTO) throws Exception {
		AmazonMarketPlace amazonMarketPlace = new AmazonMarketPlace();
		amazonMarketPlace.setRowId(amazonMarketPlaceDTO.getRowId());
		amazonMarketPlace.setAccessKey(amazonMarketPlaceDTO.getAccessKey());
		
		if(amazonMarketPlaceDTO.getSite() != null){
			Site site = new Site();
			site.setRowId(amazonMarketPlaceDTO.getSite().getRowId());
			site.setSiteName(amazonMarketPlaceDTO.getSite().getSiteName());
			amazonMarketPlace.setSite(site);
		}
		if(amazonMarketPlaceDTO.getOrg() != null){
			Organization o = new Organization();
			o.setRowId(amazonMarketPlaceDTO.getOrg().getRowId());
			o.setName(amazonMarketPlaceDTO.getOrg().getName());
			amazonMarketPlace.setOrg(o);
		}
		amazonMarketPlace.setSecrectKey(amazonMarketPlaceDTO.getSecrectKey());
		amazonMarketPlace.setSellerId(amazonMarketPlaceDTO.getSellerId());
		amazonMarketPlace.setAmazonMarketPlaceId(amazonMarketPlaceDTO.getAmazonMarketPlaceId());
		amazonMarketPlace.setServiceUrl(amazonMarketPlaceDTO.getServiceUrl());
		
		copyToEntityBaseField(amazonMarketPlace, amazonMarketPlaceDTO);
		return amazonMarketPlace;
	}

}
