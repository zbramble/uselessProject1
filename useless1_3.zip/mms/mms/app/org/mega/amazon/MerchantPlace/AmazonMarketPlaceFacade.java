package org.mega.amazon.MerchantPlace;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class AmazonMarketPlaceFacade extends BaseFacade {

	private static AmazonMarketPlaceCopier copier = new AmazonMarketPlaceCopier();
	private static AmazonMarketPlaceFacade facade = new AmazonMarketPlaceFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static AmazonMarketPlaceFacade getInstace() {
		return facade;
	}

}
