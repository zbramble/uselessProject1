package org.mega.order.order;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.bse.site.Site;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
/**
 * amazon order fields:
 *       <Order>
        <LatestShipDate>2017-04-02T19:18:42Z</LatestShipDate>
        <OrderType>StandardOrder</OrderType>
        <PurchaseDate>2017-03-31T19:33:41Z</PurchaseDate>
        <BuyerEmail>rmd1pbpkrg6rfv7@marketplace.amazon.com</BuyerEmail>
        <AmazonOrderId>114-4402852-6264258</AmazonOrderId>
        <LastUpdateDate>2017-04-02T19:30:51Z</LastUpdateDate>
        <IsReplacementOrder>false</IsReplacementOrder>
        <ShipServiceLevel>SecondDay</ShipServiceLevel>
        <NumberOfItemsShipped>1</NumberOfItemsShipped>
        <OrderStatus>Shipped</OrderStatus>
        <SalesChannel>Amazon.com</SalesChannel>
        <IsBusinessOrder>false</IsBusinessOrder>
        <NumberOfItemsUnshipped>0</NumberOfItemsUnshipped>
        <PaymentMethodDetails>
          <PaymentMethodDetail>CreditCard</PaymentMethodDetail>
        </PaymentMethodDetails>
        <BuyerName>Brian Rakestraw</BuyerName>
        <OrderTotal>
          <CurrencyCode>USD</CurrencyCode>
          <Amount>15.34</Amount>
        </OrderTotal>
        <IsPremiumOrder>false</IsPremiumOrder>
        <EarliestShipDate>2017-04-02T19:18:42Z</EarliestShipDate>
        <MarketplaceId>ATVPDKIKX0DER</MarketplaceId>
        <FulfillmentChannel>AFN</FulfillmentChannel>
        <PaymentMethod>Other</PaymentMethod>
        <ShippingAddress>
          <StateOrRegion>FL</StateOrRegion>
          <City>Clearwater</City>
          <CountryCode>US</CountryCode>
          <PostalCode>33759-1405</PostalCode>
          <Name>Brian Rakestraw</Name>
          <AddressLine1>2856 Chelsea Pl N</AddressLine1>
        </ShippingAddress>
        <IsPrime>false</IsPrime>
        <ShipmentServiceLevelCategory>SecondDay</ShipmentServiceLevelCategory>
        <SellerOrderId>114-4402852-6264258</SellerOrderId>
      </Order>
 * @author LENOVO
 *
 */
@Entity
@Table(name="ORDER_ORDER", uniqueConstraints = @UniqueConstraint(name = "PK_ORDER_ORDER", columnNames = "ROW_ID"))
public class Order extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ROW_ID")
	private long rowId;
	
	//amazonOrderId
	@Column(name = "CHANNEL_ORDER_ID")
	private String channelOrderId;
	
	@Column(name = "SELLER_ORDER_ID")
	private String sellerOrderId;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "PURCHASE_DATE", nullable = false)
    private Date purchaseDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_UPDATE_DATE", nullable = false)
    private Date lastUpdateDate;

	@Column(name = "ORDER_STATUS")
    private String orderStatus;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SITE_ID", foreignKey = @ForeignKey(name = "FK_ORDER_SITE") , nullable = true)
    private Site site;

	@Column(name = "BUYER_EMAIL")
    private String buyerEmail;

	@Column(name = "BUYER_NAME")
    private String buyerName;

	@Column(name = "BUYER_ID")
	private String buyerId;

	@Column(name = "ORDER_TYPE")
    private String orderType;

	@Column(name = "EARLIEST_DELIVERY_DATE")
    private Date earliestDeliveryDate;

	@Column(name = "LATEST_DELIVERY_DATE")
    private Date latestDeliveryDate;

	
	public String getChannelOrderId() {
		return channelOrderId;
	}

	public void setChannelOrderId(String channelOrderId) {
		this.channelOrderId = channelOrderId;
	}

	public String getSellerOrderId() {
		return sellerOrderId;
	}

	public void setSellerOrderId(String sellerOrderId) {
		this.sellerOrderId = sellerOrderId;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Date getEarliestDeliveryDate() {
		return earliestDeliveryDate;
	}

	public void setEarliestDeliveryDate(Date earliestDeliveryDate) {
		this.earliestDeliveryDate = earliestDeliveryDate;
	}

	public Date getLatestDeliveryDate() {
		return latestDeliveryDate;
	}

	public void setLatestDeliveryDate(Date latestDeliveryDate) {
		this.latestDeliveryDate = latestDeliveryDate;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	@Override
	public Long getRowId() {
		return rowId;
	}
	
	@Override
	public void prePersist() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = channelOrderId;		
	}
	
	@Override
	public void preUpdate() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = channelOrderId;		
	}

}
