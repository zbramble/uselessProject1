package org.mega.order.orderitem;


import org.mega.bse.currency.CurrencyDTO;
import org.mega.core.base.BaseDTO;
import org.mega.order.order.OrderDTO;
import org.mega.product.channelsku.ProductChannelSKUDTO;


public class OrderItemDTO extends BaseDTO{

	private long rowId;
	private OrderDTO orderDTO;
	private ProductChannelSKUDTO productChannelSKUDTO;
	private String channelOrderItemIdDTO;
	private int quantityShippedDTO;
	private CurrencyDTO currencyDTO;
	private double quantityDTO;
	private CurrencyDTO taxCurrencyDTO;
	private double taxtAmountDTO;
	private String channelSKUDTO;
	
	
	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public ProductChannelSKUDTO getProductChannelSKUDTO() {
		return productChannelSKUDTO;
	}

	public void setProductChannelSKUDTO(ProductChannelSKUDTO productChannelSKUDTO) {
		this.productChannelSKUDTO = productChannelSKUDTO;
	}

	public OrderDTO getOrderDTO() {
		return orderDTO;
	}
	
	public void setOrderDTO(OrderDTO orderDTO) {
		this.orderDTO = orderDTO;
	}
	
	public String getChannelOrderItemIdDTO() {
		return channelOrderItemIdDTO;
	}
	public void setChannelOrderItemIdDTO(String channelOrderItemIdDTO) {
		this.channelOrderItemIdDTO = channelOrderItemIdDTO;
	}
	public int getQuantityShippedDTO() {
		return quantityShippedDTO;
	}
	public void setQuantityShippedDTO(int quantityShippedDTO) {
		this.quantityShippedDTO = quantityShippedDTO;
	}
	public CurrencyDTO getCurrencyDTO() {
		return currencyDTO;
	}
	public void setCurrencyDTO(CurrencyDTO currencyDTO) {
		this.currencyDTO = currencyDTO;
	}
	
	public double getQuantityDTO() {
		return quantityDTO;
	}

	public void setQuantityDTO(double quantityDTO) {
		this.quantityDTO = quantityDTO;
	}

	public CurrencyDTO getTaxCurrencyDTO() {
		return taxCurrencyDTO;
	}
	public void setTaxCurrencyDTO(CurrencyDTO taxCurrencyDTO) {
		this.taxCurrencyDTO = taxCurrencyDTO;
	}
	public double getTaxtAmountDTO() {
		return taxtAmountDTO;
	}
	public void setTaxtAmountDTO(double taxtAmountDTO) {
		this.taxtAmountDTO = taxtAmountDTO;
	}

	public String getChannelSKUDTO() {
		return channelSKUDTO;
	}

	public void setChannelSKUDTO(String channelSKUDTO) {
		this.channelSKUDTO = channelSKUDTO;
	}

	
}
