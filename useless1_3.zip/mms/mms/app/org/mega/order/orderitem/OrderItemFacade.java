package org.mega.order.orderitem;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class OrderItemFacade extends BaseFacade {

	private static OrderItemCopier copier = new OrderItemCopier();
	private static OrderItemFacade facade = new OrderItemFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static OrderItemFacade getInstace() {
		return facade;
	}

}
