package org.mega.product.multimedia;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class ProductMultimediaFacade extends BaseFacade{
	private static ProductMultimediaCopier copier = new ProductMultimediaCopier();
	private static ProductMultimediaFacade facade = new ProductMultimediaFacade();

	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductMultimediaDTO multimediaDTO = (ProductMultimediaDTO) baseDTO;
		if(multimediaDTO.getRowId() == 0)
			multimediaDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductMultimediaFacade getInstace() {
		return facade;
	}
	
}
