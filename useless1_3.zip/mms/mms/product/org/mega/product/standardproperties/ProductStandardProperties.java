package org.mega.product.standardproperties;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.location.Location;
import org.mega.product.Product;

@Entity
@Table(name = "PRODUCT_STANDARD_PROPERTIES", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_STANDARD_PROPERTIES", columnNames = "PRODUCT_STANDARD_PROPERTIES_ID") )
public class ProductStandardProperties extends BaseEntity{
	
	@Id
	@Column(name = "PRODUCT_STANDARD_PROPERTIES_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODU__REFERENCE_PRODUCT") , nullable = true)
	private Product product;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "LOCATION_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_CO_LOCAT") )
	private Location location;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "COLOR_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_CO_COMBO"))
	private ComboVal color;
	
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "FIRDT_AVAILABLE_DATE")
	private Date firdAvailableDate;
	
	@Column(name = "PRODUCT_CETIFICATIONS", length = 2000,nullable = true)
	private String productCetifications;
	
	@Column(name = "IS_DANGEROUS")
	private boolean dangerous;
	
	@Column(name = "IS_FDA_REGULATED")
	private boolean fdaRegulated;
	
	@Column(name = "IS_USDA_LACEY_ACT")
	private boolean usdaLaceyAct;
	
	@Column(name = "HS_CODE", length = 20,nullable = true)
	private String hsCode;
	
	@Column(name = "HTS_CODE", length = 20,nullable = true)
	private String htsCode;
	
	@Column(name = "MANUFACTURER", length = 500,nullable = true)
	private String manufacturer;
	
	@Column(name = "MODEL", length = 500,nullable = true)
	private String model;
	
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;
	
	
	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public ComboVal getColor() {
		return color;
	}

	public void setColor(ComboVal color) {
		this.color = color;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getFirdAvailableDate() {
		return firdAvailableDate;
	}

	public void setFirdAvailableDate(Date firdAvailableDate) {
		this.firdAvailableDate = firdAvailableDate;
	}

	public String getProductCetifications() {
		return productCetifications;
	}

	public void setProductCetifications(String productCetifications) {
		this.productCetifications = productCetifications;
	}

	public boolean isDangerous() {
		return dangerous;
	}

	public void setDangerous(boolean dangerous) {
		this.dangerous = dangerous;
	}

	public boolean isFdaRegulated() {
		return fdaRegulated;
	}

	public void setFdaRegulated(boolean fdaRegulated) {
		this.fdaRegulated = fdaRegulated;
	}

	public boolean isUsdaLaceyAct() {
		return usdaLaceyAct;
	}

	public void setUsdaLaceyAct(boolean usdaLaceyAct) {
		this.usdaLaceyAct = usdaLaceyAct;
	}

	public String getHsCode() {
		return hsCode;
	}

	public void setHsCode(String hsCode) {
		this.hsCode = hsCode;
	}

	public String getHtsCode() {
		return htsCode;
	}

	public void setHtsCode(String htsCode) {
		this.htsCode = htsCode;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = getProduct().getProductTitle();
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = getProductCetifications();
    }
}
