package org.mega.product.standardproperties;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/productStandard")
public class ProductStandardPropertiesService {
	@POST
    @Path("/save")
    public ServiceResult save(ProductStandardPropertiesDTO productStandardDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(productStandardDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try {
			return ProductStandardPropertiesFacade.getInstace().save(productStandardDTO, new BusinessParam(userSession));
		} catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
		}
    }
	@POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ProductStandardPropertiesFacade.getInstace().list(new BusinessParam(userSession, filter));
    }
	@POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ProductStandardPropertiesFacade.getInstace().delete(new BusinessParam(userSession, filter));
    }
	
	@POST
	@Path("/loadDataExist")
	@Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public ServiceResult loadDataExist(Filter filter){
		UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        List<PairValue> list = filter.getParams();
        long id = 0;
        for (int i = 0; i < list.size(); i++) {
			id = Long.parseLong(list.get(i).getValue());
		}
        return ProductStandardPropertiesFacade.getInstace().loadDataExist(id, new BusinessParam(userSession, filter));
	}
	
}
