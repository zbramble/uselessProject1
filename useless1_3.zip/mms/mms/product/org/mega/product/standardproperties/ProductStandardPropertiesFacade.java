package org.mega.product.standardproperties;

import java.util.List;

import org.hibernate.query.Query;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class ProductStandardPropertiesFacade extends BaseFacade{
	private static ProductStandardPropertiesCopier copier = new ProductStandardPropertiesCopier();
	private static ProductStandardPropertiesFacade facade = new ProductStandardPropertiesFacade();

	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductStandardPropertiesDTO productStandard = (ProductStandardPropertiesDTO) baseDTO;
		if(productStandard.getRowId() == 0)
			productStandard.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductStandardPropertiesFacade getInstace() {
		return facade;
	}
	
	public ServiceResult loadDataExist(long id,BusinessParam businessParam){
		 try {
			 BaseDB db = businessParam.getDB();
			 String querySelect = "select e.* FROM PRODUCT_STANDARD_PROPERTIES e " +
                     "WHERE e.PRODUCT_ID= "+id;
             Query query = (Query) db.createNativeQuery(querySelect);
         	if(!query.getResultList().isEmpty()){
         		List<ProductStandardPropertiesDTO> result = query.getResultList();
         		db.commitAndclose();
         		return new ServiceResult(result, 1);
         	}
         	db.commitAndclose();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return new ServiceResult(0, 0);

	}

}
