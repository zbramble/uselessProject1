package org.mega.product.channelsku;

import org.mega.bse.site.Site;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductChannelSKUCopier extends BaseCopier<ProductChannelSKU, ProductChannelSKUDTO>{

	@Override
	public ProductChannelSKUDTO copyFromEntity(ProductChannelSKU channelSKU) {
		ProductChannelSKUDTO channelSKUDTO = new ProductChannelSKUDTO();
		channelSKUDTO.setRowId(channelSKU.getRowId());
		channelSKUDTO.setDescription(channelSKU.getDescription());
		channelSKUDTO.setSKU(channelSKU.getSKU());
		if(channelSKU.getProduct() != null){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(channelSKU.getProduct().getRowId());
			pDTO.setProductTitle(channelSKU.getProduct().getProductTitle());
			channelSKUDTO.setProductDTO(pDTO);
		}
		if(channelSKU.getSite() != null){
			SiteDTO sDTO = new SiteDTO();
			sDTO.setRowId(channelSKU.getSite().getRowId());
			sDTO.setSiteName(channelSKU.getSite().getSiteName());
			channelSKUDTO.setSiteDTO(sDTO);
		}
		channelSKUDTO.setAllReviewCount(channelSKU.getAllReviewCount());
		channelSKUDTO.setReviewRate(channelSKU.getReviewRate());
		copyFromEntityBaseField(channelSKU,channelSKUDTO);
		return channelSKUDTO;
	}

	@Override
	public ProductChannelSKU copyToEntity(ProductChannelSKUDTO channelSKUDTO) throws Exception {
		ProductChannelSKU channelSKU = new ProductChannelSKU();
		channelSKU.setRowId(channelSKUDTO.getRowId());
		channelSKU.setDescription(channelSKUDTO.getDescription());
		channelSKU.setSKU(channelSKUDTO.getSKU());
		if(channelSKUDTO.getProductDTO() != null){
			Product p = new Product();
			p.setRowId(channelSKUDTO.getProductDTO().getRowId());
			p.setProductTitle(channelSKUDTO.getProductDTO().getProductTitle());
			channelSKU.setProduct(p);
		}
		if(channelSKUDTO.getSiteDTO() != null){
			Site s = new Site();
			s.setRowId(channelSKUDTO.getSiteDTO().getRowId());
			s.setSiteName(channelSKUDTO.getSiteDTO().getSiteName());
			channelSKU.setSite(s);
		}
		channelSKU.setAllReviewCount(channelSKUDTO.getAllReviewCount());
		channelSKU.setReviewRate(channelSKUDTO.getReviewRate());
		copyToEntityBaseField(channelSKU, channelSKUDTO);
		return channelSKU;
	}
	
	
}
