package org.mega.product.channelsku;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.PairValue.CONDITION;
import org.mega.core.base.PairValue.TYPE;
import org.mega.core.base.ServiceResult;
import org.mega.pmt.reviewtargetsetting.ReviewTargetSettingDTO;
import org.mega.pmt.reviewtargetsetting.ReviewTargetSettingFacade;

public class ProductChannelSKUFacade extends BaseFacade {

	private static ProductChannelSKUCopier copier = new ProductChannelSKUCopier();
	private static ProductChannelSKUFacade facade = new ProductChannelSKUFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductChannelSKUFacade getInstace() {
		return facade;
	}

	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductChannelSKUDTO channelDTO = (ProductChannelSKUDTO) baseDTO;
		if (channelDTO.getRowId() == 0) {
			channelDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
			ServiceResult id = super.save(baseDTO, businessParam);
			channelDTO.setRowId(Long.parseLong(id.getResult().toString()));
			// insert to review rule target
			ReviewTargetSettingDTO reviewTargetSettingDTO = new ReviewTargetSettingDTO();
			reviewTargetSettingDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
			reviewTargetSettingDTO.setChannelSKU(channelDTO);
			reviewTargetSettingDTO.setReviewTarget(4.00);
			reviewTargetSettingDTO.setNegativeCollectStart("");
			ReviewTargetSettingFacade.getInstance().save(reviewTargetSettingDTO, businessParam);
		}
		return super.save(baseDTO, businessParam);
	}

	public ServiceResult listChannel(BusinessParam businessParam) {
		String marketingId = businessParam.getFilter().getParams().get(0).getValue().toString();
		try {
			BaseDB db = businessParam.getDB();
			String select = "select pc.PRODUCT_CHANNEL_SKU_ID from  product_channel_sku pc" +
					" where pc.product_channel_sku_id   not in" + "("
					+ "  select tc.product_channel_sku from pmt_team_channel tc where tc.team_id = "+marketingId+")";
			Query query = db.createNativeQuery(select);
			List<PairValue> l = new ArrayList<PairValue>();
			Filter f = new Filter();
			f.setTicket(businessParam.getUserSession().getUserInfo().getTicket());
			f.setPageNo(businessParam.getFilter().getPageNo());
			f.setPageSize(businessParam.getFilter().getPageSize());
			PairValue p = new PairValue("rowId", query.getResultList().toString().replace("[", "").replace("]", ""), CONDITION.IN);
			l.add(p);
			if(!businessParam.getFilter().getParams().get(1).getValue().equals("")){
				p = new PairValue(businessParam.getFilter().getParams().get(1).getKey(), businessParam.getFilter().getParams().get(1).getValue(), businessParam.getFilter().getParams().get(1).getCondition());
				l.add(p);
			}
			if(businessParam.getFilter().getParams().size() > 3){
				for (int i = 2; i <= (businessParam.getFilter().getParams().size()-2); i++) {
					p = new PairValue(businessParam.getFilter().getParams().get(i).getKey(), businessParam.getFilter().getParams().get(i).getValue(), businessParam.getFilter().getParams().get(i).getCondition());
					l.add(p);
				}
			}
			f.setParams(l);
			businessParam.setFilter(f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return super.list(businessParam);
	}

}
