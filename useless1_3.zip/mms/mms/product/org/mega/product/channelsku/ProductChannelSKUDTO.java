package org.mega.product.channelsku;

import javax.persistence.Column;

import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseDTO;
import org.mega.product.ProductDTO;

public class ProductChannelSKUDTO extends BaseDTO {
private long rowId;
	private SiteDTO siteDTO;
	private ProductDTO productDTO;
	private String description;
	private String SKU;
	private long allReviewCount;
	private double reviewRate;
	
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public SiteDTO getSiteDTO() {
		return siteDTO;
	}
	public void setSiteDTO(SiteDTO siteDTO) {
		this.siteDTO = siteDTO;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSKU() {
		return SKU;
	}
	public void setSKU(String SKU) {
		this.SKU = SKU;
	}
	public long getAllReviewCount() {
		return allReviewCount;
	}
	public void setAllReviewCount(long allReviewCount) {
		this.allReviewCount = allReviewCount;
	}
	public double getReviewRate() {
		return reviewRate;
	}
	public void setReviewRate(double reviewRate) {
		this.reviewRate = reviewRate;
	}
	
	
}
