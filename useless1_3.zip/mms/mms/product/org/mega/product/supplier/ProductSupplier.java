package org.mega.product.supplier;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.company.Company;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.product.Product;
@Entity
@Table(name = "PRODUCT_SUPPLIER", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT_SUPPLIER", columnNames = "PRODUCT_SUPPLIER_ID") )
public class ProductSupplier extends BaseEntity{
	
	
	@Id
	@Column(name = "PRODUCT_SUPPLIER_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_PRODU22") , nullable = true)
	private Product product;
	
	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BSE_COMPANY_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT__REFERENCE_BSE_COMP") , nullable = true)
	private Company company;
	
	@Column(name = "LEAD_TIME_DAYS")
	private int leadTimeDays;	
	
	@Column(name = "MIN_ORDER_QTY")
	private int minOrderQty;
		
	@Column(name = "PRICE")
	private double price;
		
	@Column(name = "NOTE", length = 1000,nullable = true)
	private String note;
			
	@Column(name = "IS_DEFAULT_SUPPLIER")
	private boolean defaultSupplier;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public int getLeadTimeDays() {
		return leadTimeDays;
	}

	public void setLeadTimeDays(int leadTimeDays) {
		this.leadTimeDays = leadTimeDays;
	}

	public int getMinOrderQty() {
		return minOrderQty;
	}

	public void setMinOrderQty(int minOrderQty) {
		this.minOrderQty = minOrderQty;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public boolean isDefaultSupplier() {
		return defaultSupplier;
	}

	public void setDefaultSupplier(boolean defaultSupplier) {
		this.defaultSupplier = defaultSupplier;
	} 

	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        System.out.println(rowId);
        fullTitle = note;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = "";
    }

}
