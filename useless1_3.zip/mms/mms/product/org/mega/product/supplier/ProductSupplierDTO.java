package org.mega.product.supplier;

import org.mega.bse.company.CompanyDTO;
import org.mega.core.base.BaseDTO;
import org.mega.product.ProductDTO;

public class ProductSupplierDTO extends BaseDTO{
	
	private long rowId;
	private ProductDTO productDTO;
	private String description;
	private CompanyDTO companyDTO;
	private int leadTimeDays;	
	private int minOrderQty;
	private double price;
	private String note;
	private boolean defaultSupplier;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public CompanyDTO getCompanyDTO() {
		return companyDTO;
	}
	public void setCompanyDTO(CompanyDTO companyDTO) {
		this.companyDTO = companyDTO;
	}
	public int getLeadTimeDays() {
		return leadTimeDays;
	}
	public void setLeadTimeDays(int leadTimeDays) {
		this.leadTimeDays = leadTimeDays;
	}
	public int getMinOrderQty() {
		return minOrderQty;
	}
	public void setMinOrderQty(int minOrderQty) {
		this.minOrderQty = minOrderQty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public boolean isDefaultSupplier() {
		return defaultSupplier;
	}
	public void setDefaultSupplier(boolean defaultSupplier) {
		this.defaultSupplier = defaultSupplier;
	}
	
}
