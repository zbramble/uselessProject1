package org.mega.product.supplier;

import org.mega.bse.company.Company;
import org.mega.bse.company.CompanyDTO;
import org.mega.core.base.BaseCopier;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductSupplierCopier extends BaseCopier<ProductSupplier, ProductSupplierDTO>{

	@Override
	public ProductSupplierDTO copyFromEntity(ProductSupplier supplier) {
		ProductSupplierDTO supplierDTO = new ProductSupplierDTO();
		supplierDTO.setRowId(supplier.getRowId());
		if(supplier.getCompany() != null){
			CompanyDTO cDTO = new CompanyDTO();
			cDTO.setRowId(supplier.getCompany().getRowId());
			cDTO.setCompanyName(supplier.getCompany().getCompanyName());
			supplierDTO.setCompanyDTO(cDTO);
		}
		if(supplier.getProduct() != null){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(supplier.getProduct().getRowId());
			pDTO.setProductTitle(supplier.getProduct().getProductTitle());
			supplierDTO.setProductDTO(pDTO);
		}
		supplierDTO.setDefaultSupplier(supplier.isDefaultSupplier());
		supplierDTO.setDescription(supplier.getDescription());
		supplierDTO.setLeadTimeDays(supplier.getLeadTimeDays());
		supplierDTO.setMinOrderQty(supplier.getMinOrderQty());
		supplierDTO.setNote(supplier.getNote());
		supplierDTO.setPrice(supplier.getPrice());
		copyFromEntityBaseField(supplier, supplierDTO);
		return supplierDTO;
	}

	@Override
	public ProductSupplier copyToEntity(ProductSupplierDTO supplierDTO) throws Exception {
		ProductSupplier supplier = new ProductSupplier();
		supplier.setRowId(supplierDTO.getRowId());
		if(supplierDTO.getCompanyDTO() != null){
			Company c = new Company();
			c.setRowId(supplierDTO.getCompanyDTO().getRowId());
			c.setCompanyName(supplierDTO.getCompanyDTO().getCompanyName());
			supplier.setCompany(c);
		}
		if(supplierDTO.getProductDTO() != null){
			Product p = new Product();
			p.setRowId(supplierDTO.getProductDTO().getRowId());
			p.setProductTitle(supplierDTO.getProductDTO().getProductTitle());
			supplier.setProduct(p);
		}
		supplier.setDefaultSupplier(supplierDTO.isDefaultSupplier());
		supplier.setDescription(supplierDTO.getDescription());
		supplier.setLeadTimeDays(supplierDTO.getLeadTimeDays());
		supplier.setMinOrderQty(supplierDTO.getMinOrderQty());
		supplier.setNote(supplierDTO.getNote());
		supplier.setPrice(supplierDTO.getPrice());
		copyToEntityBaseField(supplier, supplierDTO);
		return supplier;
	}

}
