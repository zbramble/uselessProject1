----------------------------------------------------
-- Export file for user MMSUITE                   --
-- Created by Default on 24/05/2017, 04:09:10 �.� --
----------------------------------------------------

spool 2.log

prompt
prompt Creating table PMT_TEAM_CHANNEL
prompt ===============================
prompt
create table MMSUITE.PMT_TEAM_CHANNEL
(
  pmt_team_channel_id NUMBER(38) not null,
  team_id             NUMBER(38),
  is_active           NUMBER(1),
  created             TIMESTAMP(6),
  is_deleted          NUMBER(19),
  full_title          VARCHAR2(200),
  updated             TIMESTAMP(6),
  access_key          VARCHAR2(110),
  description         VARCHAR2(500),
  created_by          NUMBER(19),
  updated_by          NUMBER(19),
  product_channel_sku NUMBER(38)
)
tablespace MMSUITE_TBLS
  pctfree 10
  initrans 1
  maxtrans 255;
alter table MMSUITE.PMT_TEAM_CHANNEL
  add constraint PK_PMT_TEAM_CHANNEL primary key (PMT_TEAM_CHANNEL_ID)
  using index 
  tablespace MMSUITE_TBLS
  pctfree 10
  initrans 2
  maxtrans 255;
alter table MMSUITE.PMT_TEAM_CHANNEL
  add constraint FK_PMT_TEAM_CH_REFERENCE_MARK foreign key (TEAM_ID)
  references MMSUITE.PMT_MARKETING_TEAM (TEAM_ID);
alter table MMSUITE.PMT_TEAM_CHANNEL
  add constraint FK_PRODUCT_CHANNEL_SKU foreign key (PRODUCT_CHANNEL_SKU)
  references MMSUITE.PRODUCT_CHANNEL_SKU (PRODUCT_CHANNEL_SKU_ID);


spool off
