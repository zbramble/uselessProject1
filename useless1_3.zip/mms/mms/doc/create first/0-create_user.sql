CREATE TABLESPACE mms_TBLS DATAFILE
'D:\MILO\ORACLE\ARIANA_DATA\mms01.DBF' SIZE 150M
AUTOEXTEND ON
BLOCKSIZE 8192
FORCE LOGGING
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 256K
FLASHBACK ON;

--oracle 12c
alter session set "_oracle_script"=true;
drop user mms cascade;


--oracle 12c
alter session set "_ORACLE_SCRIPT"=true;

create user mms
  identified by "mms"
  default tablespace mms_TBLS
  temporary tablespace TEMP
  profile DEFAULT;
--  password expire;
-- Grant/Revoke role privileges 

--revoke dba from nes;
grant connect to mms;
--grant dba to ntnet;
grant create table to mms;
grant create synonym to mms;
grant unlimited tablespace to mms;
--alter user <user_name> quota unlimited on <tablespace_name>
