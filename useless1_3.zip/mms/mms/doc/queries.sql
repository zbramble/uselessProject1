exp mbi/mbi##321
--create table space and datafile together
CREATE TABLESPACE mmsuite_TBLS DATAFILE
'G:\ora_data\ntnet01.dbf' SIZE 150M
AUTOEXTEND ON
BLOCKSIZE 8192
FORCE LOGGING
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 256K
FLASHBACK ON;


drop user mmsuite cascade;


--oracle 12c
alter session set "_ORACLE_SCRIPT"=true;

create user mmsuite
  identified by "mmsuite"
  default tablespace mmsuite_TBLS
  temporary tablespace TEMP
  profile DEFAULT;
--  password expire;
-- Grant/Revoke role privileges 

--revoke dba from nes;
grant connect to mmsuite;
--grant dba to ntnet;
grant create table to mmsuite;
grant create synonym to mmsuite;
grant unlimited tablespace to mmsuite;
--alter user <user_name> quota unlimited on <tablespace_name>
