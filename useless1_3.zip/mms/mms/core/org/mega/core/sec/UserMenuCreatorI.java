package org.mega.core.sec;

public interface UserMenuCreatorI {
	public UserMenuCreatorI init(UserInfo userInfo);
	public String getMenuTree();
	public String getMenuData();
}
