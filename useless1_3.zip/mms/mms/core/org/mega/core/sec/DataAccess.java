package org.mega.core.sec;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
/**
 * به ازای هر دسترسی که باید در پروژه چک شود یک مورد در این کلاس باید اضافه شود.
 * از این رو هر پروژه باید کلاسی که اینترفیس ِ
 *	DataAccessCreatorI
 *	را پیاده کرده باشد داشته باشد
 * @author golnari@gmail.com
 *
 */
public class DataAccess {
	
	//Key: filter name and value(Access keys or simple) :[key=orgs, value=10002:AA,10034:ACAA]
	private Map<String,  String> allFiltersStr = new LinkedHashMap<String,  String>();

	//SQL filter for hierarchical accesses, for use in query replace [field_exp] by own expression such as e.org.accessKey or ACCESS_KEY
	private Map<String,  String> accessKeysSQLFilter = new LinkedHashMap<String,  String>();
	
	//Access keys of checked nodes in access tree. In tree used for tick a node or not
	//تمام نودهایی قابل دسترسي که به بچه هایش نیز دسترسی هست
	private LinkedHashMap<String,  HashSet<String>> topNodesAK = new LinkedHashMap<String, HashSet<String>>();
	
	//Access keys of partial checked nodes in access tree. In tree used for partial tick a node or not
	//نود هاي بالايي که قابل دسترسي نيست ولي براي نمايش درخت لازم است. یکی یا جند بچه از آن قابل دسترسی است
	private LinkedHashMap<String,  HashSet<String>> upperNodesAK = new LinkedHashMap<String, HashSet<String>>();
	
	/**
	 * Add a simple filter with simple type, Sample: mainOrg, 10002
	 * @param name
	 * @param filter
	 */
	public void addSimpleFilter(String name, String filter) {
		allFiltersStr.put(name,  filter);
	}	

	/**
	 * Add a filter with access key type, Sample: name=orgs, akStr=10002:AAA,10034:AAAAAB
	 * @param name
	 * @param aksStr
	 */
	public void addAccessKeyFilter(String name, String aksStr) {
		allFiltersStr.put(name,  aksStr);

//		String[] organStr = ((aksStr.indexOf(",") >= 0) ? aksStr : ",").split(",");
		String[] akStr = aksStr.split(",");
		//تمام نودهایی قابل دسترسي که به بچه هایش نیز دسترسی هست
		HashSet<String> topNodesSet = new HashSet<String>();
		//نود هاي بالايي که قابل دسترسي نيست ولي براي نمايش درخت لازم است. یکی یا جند بچه از آن قابل دسترسی است
		HashSet<String> upperNodesSet = new HashSet<String>();
		
		StringBuilder filter = new StringBuilder("(");

		for (int i = 0; i < akStr.length; i++) {
			if(akStr[i].length() == 0)
				continue;
			String[] organ = akStr[i].split(":");
			if(organ.length == 1)
				topNodesSet.add("");
			else
				topNodesSet.add(organ[1]);
		}
		
		for (String ac : topNodesSet) {
			if(filter.length() > 2)
				filter.append(" or ");
			filter.append(" [field_exp] like '").append(ac).append("%'");
			for(int j = 2; j < ac.length(); j+=2){//نمايش نودهاي نمايشي که خودشان در دسترس نيستند ولي بچه هايي دارند که قابل دسترسي هستند
				String upperAC  = ac.substring(0,j);
				if(!topNodesSet.contains(upperAC))
					upperNodesSet.add(upperAC);
			}
		}
		filter.append(")");
			
		accessKeysSQLFilter.put(name, filter.toString());
		topNodesAK.put(name, topNodesSet);
		upperNodesAK.put(name, upperNodesSet);
	}	

	public String getSimpleFilter(String name){
		return allFiltersStr.get(name);
	}

	/**
	 * Filters adds by addAccessKeyFilter. This method return a where clause for a filter.
	 * @param filterName A filter name that added with addAccessKeyFilter method, such as mainOrg
	 * @param fieldExp A string that certain database element to filter such as e.person.user.accessKey 
	 * @return SQL where clause
	 */
	public String getHierarchicalSQLFilter(String filterName, String fieldExp) {
		return accessKeysSQLFilter.get(filterName).replaceAll("\\[field_exp\\]", fieldExp);
	}
	
	/**
	 * فيلتر سلسله مراتبي را بنا به دسترسي مي سازد. براي يک عبارت داده شده
	 * @param akFilterStr	 10001:AA,1023:ABAA, 
	 * @param fieldExp عبارتي که بايد در فيلتر جايگزين شود:  e.org.accessKey یا ACCESS_KEY
	 * @return
	 */
	public static String genHierarchicalSQLFilter(String akFilterStr, String fieldExp) {
		if(akFilterStr == null || akFilterStr.indexOf(":") == -1)
			return "";
		String[] akAndId = akFilterStr.split(",");
		StringBuilder filter = new StringBuilder("(");
		for (int i = 0; i < akAndId.length; i++) {
			if(akAndId[i].length() == 0)
				continue;
			String[] organ = akAndId[i].split(":");
			if(organ.length <2)
				continue;
			if(filter.length() > 2)
				filter.append(" or ");
			filter.append(" " + fieldExp + " like '").append(organ[1]).append("%'");
		}
		filter.append(")");
		return filter.toString();
	}
}
