package org.mega.core.exception;

public class UserExpiredException extends RuntimeException {
    public UserExpiredException() {
        super();
    }

    public UserExpiredException(String message) {
        super(message);
    }
}