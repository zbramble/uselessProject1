package org.mega.core.exception;

public class DeleteParamsException extends RuntimeException {
}
