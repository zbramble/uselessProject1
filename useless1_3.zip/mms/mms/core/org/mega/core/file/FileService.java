package org.mega.core.file;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.BodyPartEntity;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.hibernate.annotations.Loader;
import org.mega.core.SystemConfig;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.exception.DataNotFoundException;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;
import org.mega.util.IOUtil;
import org.mega.util.ImageUtil;

@Path("/file")
public class FileService {
    @POST
    @Path("/save")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @Loader
    public ServiceResult save(final FormDataMultiPart multiPart) {
        List<Object> ids = new ArrayList<>();

        UserSession userSession;
        try {
            String ticket = multiPart.getField("ticket").getValue();
            userSession = UserSessionManager.getUserSession(ticket);
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }

        long rowId = 0;
        String title = null;
        String description = null;
        String useTitle = null;
        String useEntity = null;
        String path = null;
        boolean active = true;

        try {
            String rowIdStr = multiPart.getField("rowId").getValue();
            rowId = Long.parseLong(rowIdStr.equals("") ? "0" : rowIdStr);
            title = multiPart.getField("title").getValue();
            description = multiPart.getField("description").getValue();
            useTitle = multiPart.getField("useTitle").getValue();
            useEntity = multiPart.getField("useEntity").getValue();
            path = multiPart.getField("path").getValue();
            active = multiPart.getField("active").getValue().equals("true") ? true : false;
        } catch (Exception e) {
            //System.out.println("مقادیر فیلد مشخص نشده است");
        }


        List<FormDataBodyPart> bodyParts = null;
        try {
            bodyParts = multiPart.getFields("file");
        } catch (Exception e) {
            //System.out.println("فایلی ارسال نشده است");
        }

        if (bodyParts != null) {
            for (int i = 0; i < bodyParts.size(); i++) {

                FileDTO fileDTO = new FileDTO();
                fileDTO.setRowId(rowId);
                fileDTO.setTitle(title);
                fileDTO.setDescription(description);
                fileDTO.setUseTitle(useTitle);
                fileDTO.setUseEntity(useEntity);
                fileDTO.setActive(active);

                String sourceName = bodyParts.get(i).getContentDisposition().getFileName();

                fileDTO.setName(sourceName);
                fileDTO.setDataType(bodyParts.get(i).getMediaType().toString());
                fileDTO.setDataSize(multiPart.getField("file-" + sourceName + "-size").getValue());

                try {

                    if (rowId == 0 || path.equals("")) {
                        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
                        Calendar calendar = Calendar.getInstance();
                        String currentFolder = dateFormat.format(calendar.getTime());

                        String fileName = System.nanoTime() + sourceName.substring(sourceName.indexOf(".")).toLowerCase();
                        fileDTO.setPath(java.io.File.separator + currentFolder + java.io.File.separator + fileName);
                        path = SystemConfig.UPLAUD_FOLDER + java.io.File.separator + currentFolder
                                + java.io.File.separator + fileName;
                    } else {
                        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
                        Calendar calendar = Calendar.getInstance();
                        String backupSuffixName = dateFormat.format(calendar.getTime());

                        String[] oldPath = path.split(Pattern.quote(java.io.File.separator));

                        String newPath = SystemConfig.UPLAUD_FOLDER + java.io.File.separator + oldPath[1]
                                + java.io.File.separator + "backup"
                                + java.io.File.separator;

                        path = SystemConfig.UPLAUD_FOLDER + path;
                        if (!Files.isDirectory(Paths.get(newPath))) {
                            Files.createDirectory(Paths.get(newPath));
                        }
                        String[] fileName = oldPath[2].split(Pattern.quote("."));
                        Files.move(Paths.get(path), Paths.get(newPath + fileName[0] + "-" + backupSuffixName + "." + fileName[1]));
                    }

                    BodyPartEntity bodyPartEntity = (BodyPartEntity) bodyParts.get(i).getEntity();
                    IOUtil.writeToFile(bodyPartEntity.getInputStream(), path);

                    if (fileDTO.getDataType().toUpperCase().equals("IMAGE/JPEG")) {
                        BufferedImage originalImage = ImageIO.read(bodyPartEntity.getInputStream());
                        BufferedImage resizeImageJpg = ImageUtil.resizeImage(originalImage, 75);
                        byte[] imageContent = ImageUtil.getImageContent(resizeImageJpg, ImageUtil.Format.JPG);
                        fileDTO.setImageContent(imageContent);
                    }

                } catch (Exception e) {
                    return new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, e.getMessage(), e.getLocalizedMessage());
                }

                try {
                    ServiceResult serviceResult = FileFacade.getInstance().save(fileDTO, new BusinessParam(userSession));
                    ids.add(serviceResult.getResult());
                } catch (Exception e) {
                    try {
                        Files.delete(Paths.get(path));
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
                }
            }
        } else {
            try {
                FileDTO fileDTO = new FileDTO();
                fileDTO.setRowId(rowId);
                fileDTO.setTitle(title);
                fileDTO.setDescription(description);
                fileDTO.setUseTitle(useTitle);
                fileDTO.setUseEntity(useEntity);
                fileDTO.setActive(active);

                ServiceResult serviceResult = FileFacade.getInstance().save(fileDTO, new BusinessParam(userSession));
                ids.add(serviceResult.getResult());
            } catch (Exception e) {
                return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
            }
        }

        return new ServiceResult(ids, ids.size());
    }

    @POST
    @Path("/list")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return FileFacade.getInstance().list(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/delete")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return FileFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/download")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response download(Filter filter) {
        UserSession userSession;
        ServiceResult serviceResult;

        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
            ResponseFile responseFile = FileFacade.getInstance().download(new BusinessParam(userSession, filter));
            return Response.ok(responseFile.getFileStream(), responseFile.getType())//MediaType.APPLICATION_OCTET_STREAM)
                    .header("content-disposition", "attachment")
                    .build();
        } catch (DataNotFoundException e) {
            serviceResult = new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, e.getMessage(), e.getLocalizedMessage());
        } catch (Exception e) {
            serviceResult = new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }

        return Response.ok(serviceResult, MediaType.APPLICATION_JSON).entity(serviceResult).build();
    }
}