package org.mega.core.file;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

import javax.ws.rs.core.StreamingOutput;

import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.exception.DataNotFoundException;
import org.mega.core.user.User;

public class FileFacade extends BaseFacade {
    private static FileFacade facade = new FileFacade();
    private static FileCopier copier = new FileCopier();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static FileFacade getInstance() {
        return facade;
    }

    @Override
    public ServiceResult save(BaseDTO dto, BusinessParam businessParam) {
        FileDTO fileDTO = (FileDTO) dto;
        Class<?> entityClass = FileDTO.class;
        try {
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.insert);

            File entity;

            if (fileDTO.getRowId() == 0) {
                entity = copier.copyToEntity(fileDTO);
                entity.setCreated(new Date(System.currentTimeMillis()));
                entity.setCreatedBy(findEntityById(User.class, businessParam.getUserSession().getUserInfo().getUserId(), businessParam));
            } else {
                entity = findEntityById(File.class, fileDTO.getRowId(), businessParam);

                if (fileDTO.getName() != null) {
                    entity.setName(fileDTO.getName());
                }
                if (fileDTO.getPath() != null) {
                    entity.setPath(fileDTO.getPath());
                }
                if (fileDTO.getTitle() != null) {
                    entity.setTitle(fileDTO.getTitle());
                }
                if (fileDTO.getUseTitle() != null) {
                    entity.setUseTitle(fileDTO.getUseTitle());
                }
                if (fileDTO.getUseEntity() != null) {
                    entity.setUseEntity(fileDTO.getUseEntity());
                }
                if (fileDTO.getDataSize() != null) {
                    entity.setDataSize(fileDTO.getDataSize());
                }
                if (fileDTO.getDataType() != null) {
                    entity.setDataType(fileDTO.getDataType());
                }
                if (fileDTO.getDescription() != null) {
                    entity.setDescription(fileDTO.getDescription());
                }
                if (fileDTO.getImageContent() != null) {
                    entity.setImageContent(fileDTO.getImageContent());
                }
            }

            entity.setUpdated(new Date(System.currentTimeMillis()));
            entity.setUpdatedBy(findEntityById(User.class, businessParam.getUserSession().getUserInfo().getUserId(), businessParam));

            long id = saveEntity(entity, businessParam);
            BaseLogger.getLogger(this.getClass()).info("saved id=" + entity.getRowId());
            return new ServiceResult(id, 1);
        } catch (
                Exception e
                )

        {
            BaseLogger.getLogger().info("Error saving " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }

    public ResponseFile download(BusinessParam businessParam) {
        ResponseFile responseFile = new ResponseFile();

        try {
            PairValue pairValue = businessParam.getFilter().getParams().get(0);
            File file = findEntityById(File.class, Long.parseLong(pairValue.getValue()), businessParam);
            responseFile.setType(file.getDataType());
            Path path = Paths.get(SystemConfig.UPLAUD_FOLDER + file.getPath());

            StreamingOutput fileStream = output -> {
                byte[] data = Files.readAllBytes(path);
                output.write(data);
                output.flush();
            };
            responseFile.setFileStream(fileStream);

        } catch (Exception e) {
            throw new DataNotFoundException(e.getMessage());
        }

        return responseFile;
    }
}