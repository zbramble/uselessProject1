package org.mega.core.accessgrp;

import java.util.List;

import org.mega.core.base.BaseDTO;

public class MasterAccessGrpDTO extends BaseDTO {
    private AccessGrpDTO accessGrp;
    private List<String> listChild;//added items
    private List<String> listId;//removed items

    public AccessGrpDTO getAccessGrp() {
        return accessGrp;
    }

    public void setAccessGrp(AccessGrpDTO accessGrp) {
        this.accessGrp = accessGrp;
    }

    public List<String> getListChild() {
        return listChild;
    }

    public void setListChild(List<String> listChild) {
        this.listChild = listChild;
    }

    public List<String> getListId() {
        return listId;
    }

    public void setListId(List<String> listId) {
        this.listId = listId;
    }

    @Override
    public Long getRowId() {
        return 0L;
    }
}
