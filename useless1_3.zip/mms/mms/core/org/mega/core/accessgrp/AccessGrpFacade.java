package org.mega.core.accessgrp;

import java.util.List;

import org.hibernate.query.Query;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.util.BeanUtil;

public class AccessGrpFacade extends BaseFacade {

    static AccessGrpCopier copier = new AccessGrpCopier();
    private static AccessGrpFacade facade = new AccessGrpFacade();


    public ServiceResult treeLoader(BusinessParam businessParam) throws Exception {
        Class<?> entityClass = BeanUtil.getEntityClass(this);

        BaseDB db = null;

        try {
            db = BaseDB.open(entityClass.getSimpleName() + "Facade.list");

            String queryString = "select u.USECASE_ID,u.USECASE_NAME,u.PARENT_ID,u.HAS_CHILD, ua.USECASE_ACTION_ID, a.ACTION_ID, a.ACTION_NAME from CO_USECASE u join CO_USECASE_ACTION ua on (ua.USECASE_ID = u.USECASE_ID ) left join CO_ACTION a on (ua.ACTION_ID = a.ACTION_ID)  where u.is_active=1 and a.is_active = 1 and ua.is_active = 1 ORDER BY  u.USECASE_ID ASC";
            Query query = (Query) db.createNativeQuery(queryString);


            List<Object[]> ret = (List<Object[]>) query.getResultList();
            int countAll = ret.size();
            db.commitAndclose();
            return new ServiceResult(ret, countAll);
        } catch (Exception e) {
            e.printStackTrace();
            db.rollbackAndClose();
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, e.getMessage(), e.getLocalizedMessage());
        }

    }

    public ServiceResult manyToManySave(AccessGrpDTO accessGrpDTO,
                                        List<String> addItems,
                                        List<String> removeItems,
                                        BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);

        try {
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.insert);

            ServiceResult resultSave = save(accessGrpDTO, businessParam);
            BaseDB db = BaseDB.open(entityClass.getSimpleName() + "Facade.list");
            if (addItems != null && addItems.size() > 0) {
                for (int i = 0; i < addItems.size(); i++) {
                    String queryAddString = "INSERT INTO CO_ACCESS_GRP_USECASE_ACT T " +
                            "(T.ACCESS_GRP_ID,T.USECASE_ACTION_ID) " +
                            "VALUES ( :accessGrpId, :usecaseActionId )";
                    Query queryAdd = (Query) db.createNativeQuery(queryAddString);
                    queryAdd.setParameter("accessGrpId", resultSave.getResult());
                    queryAdd.setParameter("usecaseActionId", addItems.get(i));
                    queryAdd.executeUpdate();
                }
            }
            if (removeItems != null && removeItems.size() > 0) {
                for (int i = 0; i < removeItems.size(); i++) {
                    String queryDeleteString = "DELETE FROM CO_ACCESS_GRP_USECASE_ACT t " +
                            "WHERE t.access_grp_id= :accessGrpId" +
                            " and t.usecase_action_id= :usecaseActionId";
                    Query queryDelete = (Query) db.createNativeQuery(queryDeleteString);
                    queryDelete.setParameter("accessGrpId", resultSave.getResult());
                    queryDelete.setParameter("usecaseActionId", removeItems.get(i));
                    queryDelete.executeUpdate();
                }
            }
            db.commitAndclose();
            return resultSave;
        } catch (Exception e) {
            BaseLogger.getLogger().info("Error saving " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }

    @Override
    public ServiceResult delete(BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);
        try {
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.insert);
            BaseDB db = BaseDB.open(entityClass.getSimpleName() + "Facade.list");
            if (businessParam.getFilter().getParams() != null && businessParam.getFilter().getParams().size() > 0) {
                String queryDeleteString = "DELETE FROM CO_ACCESS_GRP_USECASE_ACT t " +
                        "WHERE t.access_grp_id= :accessGrpId";
                Query queryDelete = (Query) db.createNativeQuery(queryDeleteString);
                queryDelete.setParameter("accessGrpId", businessParam.getFilter().getParams().get(0).getValue());
                queryDelete.executeUpdate();
            }
            ServiceResult result = super.delete(businessParam);
            db.commitAndclose();
            return result;
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error " + entityClass.getSimpleName() + " delete", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, "Error delete " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static AccessGrpFacade getInstance() {
        return facade;
    }
}