package org.mega.core.location;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/location")
public class LocationService {
    @POST
    @Path("/save")
    public ServiceResult save(LocationDTO locationDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(locationDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        return LocationFacade.getInstance().save(locationDTO, new BusinessParam(userSession));
    }

    @POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return LocationFacade.getInstance().list(new BusinessParam(userSession, filter));
    }

    @POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return LocationFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }
}