package org.mega.core.base;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.mega.util.ExpireCache;
import org.mega.util.ExpireCacheRemoveAware;

public class BaseDB {
    private static EntityManagerFactory ENTITY_MANAGER_FACTORY;
    private static ExpireCache cache = ExpireCache.getInstance("DB", 60, new BaseDB.DBExpired());
    private static long count = 1;//generate id for cache

    protected static class DBExpired implements ExpireCacheRemoveAware {

        @Override
        public void removed(String key, Object val) {
            try {
                BaseDB baseDB = (BaseDB) val;
                baseDB.finalize();
                baseDB = null;
            } catch (Exception e) {

            }
        }
    }

    EntityManager entityManager;
    EntityTransaction transaction;
    String name;
    String key;

    private BaseDB() {
    }

    private BaseDB(EntityManager entityManager, EntityTransaction transaction, String name) {
        this.entityManager = entityManager;
        this.transaction = transaction;
        this.name = name;
    }

    /**
     * Open a db, After use call close() method
     *
     * @param name         A name for log
     * @param expireSecond Seconds for expire db,0 for unlimited
     * @return
     */
    public static BaseDB open(String name, long... expireSecond) throws Exception {
    	if(ENTITY_MANAGER_FACTORY == null)
    		ENTITY_MANAGER_FACTORY = Persistence.createEntityManagerFactory("Mega");
        EntityManager entityManager = ENTITY_MANAGER_FACTORY.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();
        BaseDB baseDB = new BaseDB(entityManager, transaction, name);
        baseDB.key = new StringBuilder("DB ").append(name).append(" ").append(count++).toString();

        cache.put(baseDB.key, baseDB, expireSecond);
        return baseDB;
    }

    public void persist(BaseEntity entity) throws Exception {
        entityManager.persist(entity);
    }

    public void flush() throws Exception {
    	entityManager.flush();
    }

    public BaseEntity merge(BaseEntity entity) throws Exception {
    	entity = entityManager.merge(entity);
    	return entity;
    }

    public <E> E findById(Class<E> entityClass, Long id) throws Exception {
        return entityManager.find(entityClass, id);
    }

    /**
     * Commit transaction and close entity manager
     */
    public void commitAndclose() throws Exception {
        cache.removeWithoutCallAwares(key);
        transaction.commit();
        entityManager.close();
    }

    public String getName() {
        return name;
    }

    /**
     * rollback transaction and close entity manager
     */
    public void rollbackAndClose() throws Exception {
        try {
            cache.removeWithoutCallAwares(key);
            transaction.rollback();
        } catch (Exception e) {
            throw e;
        } finally {
            entityManager.close();
        }
    }

    public Query createNativeQuery(String sql) throws Exception {
        return entityManager.createNativeQuery(sql);
    }

    public int runNativeQuery(String sql) throws Exception {
    	return entityManager.createNativeQuery(sql).executeUpdate();
    }
    

    public Query createQuery(String ejbql) throws Exception {
        return entityManager.createQuery(ejbql);
    }

    public String getKey() {
        return key;
    }

    /**
     * Commit iff Exception rollback then close;
     * No Exception raised
     */
    public void finalize() {
        cache.removeWithoutCallAwares(key);
//      try {
//          this.commitAndclose();
//      } catch (Exception e) {
          try {
              this.rollbackAndClose();
          } catch (Exception ex) {
//          }
       }
    }
}
