package org.mega.core.contact;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.location.Location;
import org.mega.core.organization.Organization;
import org.mega.core.person.Person;
import org.mega.core.user.User;

@Entity
@Table(name = "CO_CONTACT", uniqueConstraints = @UniqueConstraint(name = "PK_CO_CONTACT", columnNames = "CONTACT_ID"))
public class Contact extends BaseEntity {
    @Id
    @Column(name = "CONTACT_ID")
    private long rowId;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "TYPE", nullable = true, foreignKey = @ForeignKey(name = "FK_PER_TYPE_REF_CORE_COM"))
    private ComboVal type;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "PERSON_ID", nullable = true, foreignKey = @ForeignKey(name = "FK_CONTACT_REF_CO_PERSON"))
    private Person person;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "ORGANIZATION_ID", nullable = true, foreignKey = @ForeignKey(name = "FK_CONTACT_REF_CO_ORG"))
    private Organization organization;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "USER_ID", nullable = true, foreignKey = @ForeignKey(name = "FK_CONTACT_REF_CO_USER"))
    private User user;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "GENDER", nullable = true, foreignKey = @ForeignKey(name = "FK_PER_GENDER_REF_CORE_COM"))
    private ComboVal gender;

    @Column(name = "NAME_FAMILY", length = 50)
    private String nameFamily;

    @Column(name = "PHONE", length = 11)
    private String phone;

    @Column(name = "MOBILE", length = 11)
    private String mobile;

    @Column(name = "PHONE_SOCIAL_NETWORK", length = 11)
    private String phoneSocialNetwork;

    @Column(name = "SOCIAL_NETWORK", length = 50)
    private String socialNetwork;

    @Column(name = "ADDRESS_SOCIAL_NETWORK", length = 50)
    private String addressSocialNetwork;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "STATE", nullable = true, foreignKey = @ForeignKey(name = "FK_STATE_REF_Location"))
    private Location state;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "CITY", nullable = true, foreignKey = @ForeignKey(name = "FK_PER_CITY_REF_Location"))
    private Location city;

    @Column(name = "ADDRESS", length = 500)
    private String address;

    @Column(name = "POSTAL_CODE", length = 10)
    private String postalCode;

    @Column(name = "EMAIL", length = 50)
    private String email;

    @Column(name = "NOTE", length = 50)
    private String note;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public ComboVal getType() {
        return type;
    }

    public void setType(ComboVal type) {
        this.type = type;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ComboVal getGender() {
        return gender;
    }

    public void setGender(ComboVal gender) {
        this.gender = gender;
    }

    public String getNameFamily() {
        return nameFamily;
    }

    public void setNameFamily(String nameFamily) {
        this.nameFamily = nameFamily;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhoneSocialNetwork() {
        return phoneSocialNetwork;
    }

    public void setPhoneSocialNetwork(String phoneSocialNetwork) {
        this.phoneSocialNetwork = phoneSocialNetwork;
    }

    public String getSocialNetwork() {
        return socialNetwork;
    }

    public void setSocialNetwork(String socialNetwork) {
        this.socialNetwork = socialNetwork;
    }

    public String getAddressSocialNetwork() {
        return addressSocialNetwork;
    }

    public void setAddressSocialNetwork(String addressSocialNetwork) {
        this.addressSocialNetwork = addressSocialNetwork;
    }

    public Location getState() {
        return state;
    }

    public void setState(Location state) {
        this.state = state;
    }

    public Location getCity() {
        return city;
    }

    public void setCity(Location city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = "";
        if(user != null){
            fullTitle += user.getUsername() + " ";
        }
        if(organization != null){
            fullTitle += organization.getName() + " ";
        }
        if(person != null){
            fullTitle += person.getFullTitle() + " ";
        }
        if(nameFamily != null){
            fullTitle += nameFamily + " ";
        }

        fullTitle += mobile;
    }

    @PreUpdate
    public void preUpdate() {
        fullTitle = "";
        if(user != null){
            fullTitle += user.getUsername() + " ";
        }
        if(organization != null){
            fullTitle += organization.getName() + " ";
        }
        if(person != null){
            fullTitle += person.getFullTitle() + " ";
        }
        if(nameFamily != null){
            fullTitle += nameFamily + " ";
        }

        fullTitle += mobile;
    }
}
