package org.mega.core.contact;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.LocationDTO;
import org.mega.core.organization.OrganizationDTO;
import org.mega.core.person.PersonDTO;
import org.mega.core.user.UserDTO;


public class ContactDTO extends BaseDTO {
    private long rowId;
    private ComboValDTO type;
    private PersonDTO person;
    private OrganizationDTO organization;
    private UserDTO user;
    private ComboValDTO gender;
    private String nameFamily;
    private String phone;
    private String mobile;
    private String postalCode;
    private String email;
    private String phoneSocialNetwork;
    private String socialNetwork;
    private String addressSocialNetwork;
    private LocationDTO state;
    private LocationDTO city;
    private String address;
    private String note;
    private String accessKey;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public ComboValDTO getType() {
        return type;
    }

    public void setType(ComboValDTO type) {
        this.type = type;
    }

    public PersonDTO getPerson() {
        return person;
    }

    public void setPerson(PersonDTO person) {
        this.person = person;
    }

    public OrganizationDTO getOrganization() {
        return organization;
    }

    public void setOrganization(OrganizationDTO organization) {
        this.organization = organization;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public ComboValDTO getGender() {
        return gender;
    }

    public void setGender(ComboValDTO gender) {
        this.gender = gender;
    }

    public String getNameFamily() {
        return nameFamily;
    }

    public void setNameFamily(String nameFamily) {
        this.nameFamily = nameFamily;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhoneSocialNetwork() {
        return phoneSocialNetwork;
    }

    public void setPhoneSocialNetwork(String phoneSocialNetwork) {
        this.phoneSocialNetwork = phoneSocialNetwork;
    }

    public String getSocialNetwork() {
        return socialNetwork;
    }

    public void setSocialNetwork(String socialNetwork) {
        this.socialNetwork = socialNetwork;
    }

    public String getAddressSocialNetwork() {
        return addressSocialNetwork;
    }

    public void setAddressSocialNetwork(String addressSocialNetwork) {
        this.addressSocialNetwork = addressSocialNetwork;
    }

    public LocationDTO getState() {
        return state;
    }

    public void setState(LocationDTO state) {
        this.state = state;
    }

    public LocationDTO getCity() {
        return city;
    }

    public void setCity(LocationDTO city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }
}
