package org.mega.core.organization;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;

public class OrganizationDTO extends BaseDTO {
    private long rowId;
    private String name;
    private long establishingYear;
    private OrganizationDTO parentOrg;
    private ComboValDTO orgStatus;
    private ComboValDTO type;
    private ComboValDTO orgGrade;
    private long orderr;
    private long longitude;
    private long latitude;
    private String imageName;
    private String tel;
    private String fax;
    private String address;
    private String description;
    private String accessKey;
    private String code;
    private ComboValDTO ownershipType;
    private ComboValDTO roadType;
    private String fullName;
    private byte[] logoImage;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getEstablishingYear() {
        return establishingYear;
    }

    public void setEstablishingYear(long establishingYear) {
        this.establishingYear = establishingYear;
    }

    public OrganizationDTO getParentOrg() {
        return parentOrg;
    }

    public void setParentOrg(OrganizationDTO parentOrg) {
        this.parentOrg = parentOrg;
    }

    public ComboValDTO getOrgStatus() {
        return orgStatus;
    }

    public void setOrgStatus(ComboValDTO orgStatus) {
        this.orgStatus = orgStatus;
    }

    public ComboValDTO getType() {
        return type;
    }

    public void setType(ComboValDTO type) {
        this.type = type;
    }

    public ComboValDTO getOrgGrade() {
        return orgGrade;
    }

    public void setOrgGrade(ComboValDTO orgGrade) {
        this.orgGrade = orgGrade;
    }

    public long getOrderr() {
        return orderr;
    }

    public void setOrderr(long orderr) {
        this.orderr = orderr;
    }

    public long getLongitude() {
        return longitude;
    }

    public void setLongitude(long longitude) {
        this.longitude = longitude;
    }

    public long getLatitude() {
        return latitude;
    }

    public void setLatitude(long latitude) {
        this.latitude = latitude;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ComboValDTO getOwnershipType() {
        return ownershipType;
    }

    public void setOwnershipType(ComboValDTO ownershipType) {
        this.ownershipType = ownershipType;
    }

    public ComboValDTO getRoadType() {
        return roadType;
    }

    public void setRoadType(ComboValDTO roadType) {
        this.roadType = roadType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public byte[] getLogoImage() {
        return logoImage;
    }

    public void setLogoImage(byte[] logoImage) {
        this.logoImage = logoImage;
    }
}