package org.mega.core.user;

import org.mega.core.base.BaseCopier;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.core.sec.OnlineUserManager;

public class UserCopier extends BaseCopier<User, UserDTO> {
    @Override
    public UserDTO copyFromEntity(User user) {
        UserDTO userDTO = new UserDTO();

        userDTO.setRowId(user.getRowId());
        userDTO.setFullName(user.getFullName());
        userDTO.setCompanyName(user.getCompanyName());
        userDTO.setUsername(user.getUsername());
        userDTO.setActive(user.isActive());
        userDTO.setAccessKey(user.getAccessKey());
        userDTO.setEmail(user.getEmail());
        userDTO.setEmailIsConfirmed(user.isEmailIsConfirmed());
        if (user.getFile() != null) {
            FileDTO fDTO = new FileDTO();
            fDTO.setRowId(user.getFile().getRowId());
            fDTO.setPath(user.getFile().getPath());
            fDTO.setImageContent(user.getFile().getImageContent());
            userDTO.setFile(fDTO);
        }
        if (OnlineUserManager.getInstance().isOnline(user.getRowId())) {
            userDTO.setStatus(UserStatus.ONLINE);
        } else {
            userDTO.setStatus(UserStatus.OFFLINE);
        }
        copyFromEntityBaseField(user, userDTO);

        return userDTO;
    }

    @Override
    public User copyToEntity(UserDTO userDTO) {
        User user = new User();

        user.setRowId(userDTO.getRowId());
        user.setAccessKey(userDTO.getAccessKey());
        user.setFullName(userDTO.getFullName());
        user.setCompanyName(userDTO.getCompanyName());
        user.setUsername(userDTO.getUsername());
        if (userDTO.getUserPassword() != "") {
            user.setUserPassword(userDTO.getUserPassword());
        }
        user.setEmail(userDTO.getEmail());
        user.setEmailIsConfirmed(userDTO.isEmailIsConfirmed());
        if (userDTO.getFile() != null) {
            File f = new File();
            f.setRowId(userDTO.getFile().getRowId());
            user.setFile(f);
        }
        copyToEntityBaseField(user, userDTO);

        return user;
    }
}