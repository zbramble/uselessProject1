package org.mega.core.user;

import org.mega.core.base.BaseDTO;
import org.mega.core.file.FileDTO;
import org.mega.core.person.PersonDTO;
import org.mega.core.userrole.UserRoleDTO;

import java.util.List;

public class UserDTO extends BaseDTO {
    private long rowId;
    private String fullName;
    private String companyName;
    private List<UserRoleDTO> userRoles;
    private String username;
    private String accessKey;
    private String userPassword;
    private String email;
    private boolean emailIsConfirmed;
    private FileDTO file;
    private UserStatus status;

    public UserDTO() {
        // TODO Auto-generated constructor stub
    }

    public UserDTO(long rowId) {
        this.rowId = rowId;
    }

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }


    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public List<UserRoleDTO> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRoleDTO> userRoles) {
        this.userRoles = userRoles;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEmailIsConfirmed() {
        return emailIsConfirmed;
    }

    public void setEmailIsConfirmed(boolean emailIsConfirmed) {
        this.emailIsConfirmed = emailIsConfirmed;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public FileDTO getFile() {
        return file;
    }

    public void setFile(FileDTO file) {
        this.file = file;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }
}