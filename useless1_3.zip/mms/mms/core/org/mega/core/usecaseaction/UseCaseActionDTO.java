package org.mega.core.usecaseaction;

import java.util.List;

import org.mega.core.accessgrp.AccessGrpDTO;
import org.mega.core.action.ActionDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.usecase.UseCaseDTO;

public class UseCaseActionDTO extends BaseDTO {
    private long rowId;
    private String code;
    private ActionDTO action;
    private UseCaseDTO useCase;
    private List<AccessGrpDTO> accessGrps;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ActionDTO getAction() {
        return action;
    }

    public void setAction(ActionDTO action) {
        this.action = action;
    }

    public UseCaseDTO getUseCase() {
        return useCase;
    }

    public void setUseCase(UseCaseDTO useCase) {
        this.useCase = useCase;
    }

    public List<AccessGrpDTO> getAccessGrps() {
        return accessGrps;
    }

    public void setAccessGrps(List<AccessGrpDTO> accessGrps) {
        this.accessGrps = accessGrps;
    }
}