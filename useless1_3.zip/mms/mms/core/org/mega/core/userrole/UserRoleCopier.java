package org.mega.core.userrole;

import org.mega.core.base.BaseCopier;
import org.mega.core.organization.Organization;
import org.mega.core.organization.OrganizationDTO;
import org.mega.core.role.Role;
import org.mega.core.role.RoleDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;

public class UserRoleCopier extends BaseCopier<UserRole, UserRoleDTO> {
    @Override
    public UserRoleDTO copyFromEntity(UserRole userRole) {
        UserRoleDTO userRoleDTO = new UserRoleDTO();

        userRoleDTO.setRowId(userRole.getRowId());
        userRoleDTO.setCode(userRole.getCode());
        if (userRole.getOrganization() != null) {
            OrganizationDTO organizationDTO = new OrganizationDTO();
            organizationDTO.setRowId(userRole.getOrganization().getRowId());
            organizationDTO.setName(userRole.getOrganization().getName());
            userRoleDTO.setOrganization(organizationDTO);
        }
        if (userRole.getRole() != null) {
            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setRowId(userRole.getRole().getRowId());
            roleDTO.setRoleName(userRole.getRole().getRoleName());
            userRoleDTO.setRole(roleDTO);
        }
        if (userRole.getUser() != null) {
            UserDTO userDTO = new UserDTO();
            userDTO.setRowId(userRole.getUser().getRowId());
            userDTO.setUsername(userRole.getUser().getUsername());
            userRoleDTO.setUser(userDTO);
        }
        copyFromEntityBaseField(userRole, userRoleDTO);

        return userRoleDTO;
    }

    @Override
    public UserRole copyToEntity(UserRoleDTO userRoleDTO) {
        UserRole userRole = new UserRole();

        userRole.setRowId(userRoleDTO.getRowId());
        userRole.setCode(userRoleDTO.getCode());
        if (userRoleDTO.getOrganization() != null) {
            Organization organization = new Organization();
            organization.setRowId(userRoleDTO.getOrganization().getRowId());
            userRole.setOrganization(organization);
        }
        if (userRoleDTO.getRole() != null) {
            Role role = new Role();
            role.setRowId(userRoleDTO.getRole().getRowId());
            userRole.setRole(role);
        }
        if (userRoleDTO.getUser() != null) {
            User user = new User();
            user.setRowId(userRoleDTO.getUser().getRowId());
            userRole.setUser(user);
        }
        copyToEntityBaseField(userRole, userRoleDTO);

        return userRole;
    }
}