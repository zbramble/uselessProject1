package org.mega.util;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.mega.core.SystemConfig;

import com.fasterxml.jackson.databind.ObjectMapper;

public class WebUtil {
    public static enum CONTENT_TYPE {JSON, TEXT}

    public static void sendEmail(String recieverEmail, String subbject, String content, String... attachFiles) {
        String username = SystemConfig.SYSTEM_EMAIL_USER;
        String password = SystemConfig.SYSTEM_EMAIL_PASS;
        String sender = SystemConfig.SYSTEM_EMAIL;

        Properties props = new Properties();
        props.put("mail.smtp.host", SystemConfig.SYSTEM_EMAIL_SERVER);
        //props.put("mail.smtp.host", "smtp.gmail.com");

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        if (SystemConfig.SYSTEM_EMAIL_USE_SSL) {
            props.put("mail.smtp.EnableSSL.enable", "true");
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        }
        props.put("mail.smtp.socketFactory.fallback", "false");
        props.put("mail.smtp.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT);
        props.put("mail.smtp.socketFactory.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT);
        props.put("mail.debug", "false");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recieverEmail));
            message.setFrom(InternetAddress.parse(sender)[0]);
            message.setSubject(subbject);

            // creates message part
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(content, "text/html");

            // creates multi-part
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            // adds attachments
            if (attachFiles != null && attachFiles.length > 0) {
                for (String filePath : attachFiles) {
                    MimeBodyPart attachPart = new MimeBodyPart();

                    DataSource source = new FileDataSource(filePath);
                    attachPart.setDataHandler(new DataHandler(source));
                    attachPart.setFileName(new File(filePath).getName());
                    multipart.addBodyPart(attachPart);
                }
            }

            // sets the multi-part as e-mail's content
            message.setContent(multipart);

            Transport.send(message);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static void sendEmailByAttach(String recieverEmail, String subbject, String content, List<AttachFile> attaches) {
        String username = SystemConfig.SYSTEM_EMAIL_USER;
        String password = SystemConfig.SYSTEM_EMAIL_PASS;
        String sender = SystemConfig.SYSTEM_EMAIL;

        Properties props = new Properties();
        props.put("mail.smtp.host", SystemConfig.SYSTEM_EMAIL_SERVER);
        //props.put("mail.smtp.host", "smtp.gmail.com");

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        if (SystemConfig.SYSTEM_EMAIL_USE_SSL) {
            props.put("mail.smtp.EnableSSL.enable", "true");
            props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        }
        props.put("mail.smtp.socketFactory.fallback", "false");
        props.put("mail.smtp.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT);
        props.put("mail.smtp.socketFactory.port", SystemConfig.SYSTEM_EMAIL_SMTP_PORT);
        props.put("mail.debug", "false");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recieverEmail));
            message.setFrom(InternetAddress.parse(sender)[0]);
            message.setSubject(subbject);

            // creates message part
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(content, "text/html");

            // creates multi-part
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);

            // adds attachments
            for (AttachFile attach : attaches) {
                MimeBodyPart attachPart = new MimeBodyPart();

                DataSource source = new ByteArrayDataSource(attach.content, attach.mime);
                attachPart.setDataHandler(new DataHandler(source));
                attachPart.setFileName(attach.name);
                multipart.addBodyPart(attachPart);
            }

            // sets the multi-part as e-mail's content
            message.setContent(multipart);

            Transport.send(message);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) throws IOException {
        SystemConfig.init();
        byte[] file1Bytes = IOUtil.readFromFile(new File("C:/Users/LENOVO/Downloads/REVIEW_DROP_RISK_20170712.xls"));
        List<AttachFile> attaches = new ArrayList<AttachFile>();
        AttachFile attachFile = new AttachFile(file1Bytes, "report2.xls", "application/vnd.ms-excel");
        //attaches.add(attachFile);

        WebUtil.sendEmailByAttach("golnari@gmail.com", "Milo email test1", "Hi, Dear <b>Mr Anthony</b></br>This email is sent to test MILO email server that used in MMS project<br>Best regards.", attaches);

    }

    /**
     * Call a service and return wished object
     *
     * @param urlPath   service url
     * @param jsonToReq json to send as service input
     * @param retClazz  return object class type
     * @return
     * @throws MalformedURLException
     * @throws IOException
     */
    public static Object restServiceCall(String urlPath, String jsonToReq, Class<?> retClazz) throws IOException {
        //Send request
        URL url = new URL(urlPath);
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        connection.setRequestProperty("Content-Type", "application/json");

        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
        if (jsonToReq != null)
            out.write(jsonToReq);
        out.close();
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(connection.getInputStream(), retClazz);
    }

    /**
     * Returns page content as text
     *
     * @param urlPath Page url
     * @return Page content as text
     * @throws IOException
     */
    public static String readPage(String urlPath) throws IOException {
        URL url = new URL(urlPath);
        return IOUtil.readAndCloseStream(url.openStream(), "utf-8");
    }
}