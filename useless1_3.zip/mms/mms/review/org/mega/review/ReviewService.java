package org.mega.review;

import java.awt.Desktop.Action;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.base.ServiceResult.ERROR_CODE;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;
import org.mega.util.ExcelUtil;
import org.mega.util.WebUtil;
import org.ntnet.app.report.ReportService;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/review")
public class ReviewService {
    Logger logger = BaseLogger.getLogger(ReportService.class);

	@POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return ReviewFacade.getInstace().list(new BusinessParam(userSession, filter));
    }
	
    @POST
    @Path("/mailToAmazonCustomer")
    public ServiceResult mailToAmazonCustomer(MailDTO mailDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(mailDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try{
        	userSession.checkAccess("mailToCustomer", ACTION.insert);
        	ReviewFacade.getInstace().sendEmailToAmazonCustomer(mailDTO, new BusinessParam(userSession));
        	return new ServiceResult(1,1);
        }catch (Exception e) {
        	return new ServiceResult(ERROR_CODE.UNKNOWN, "Send email failed" , e);
		}
    }
    
    @POST
    @Path("/downloadExcel")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces("application/vnd.ms-excel")
    public Response downloadExcel(Filter filter) {
        UserSession userSession;
        try {
            filter.setPageSize(100);
            userSession = UserSessionManager.getUserSession(filter.getTicket());
            userSession.checkAccess(Review.class.getName(), ACTION.exportExcel);
            
            ServiceResult result = (ServiceResult) ReviewFacade.getInstace().list(new BusinessParam(userSession, filter));
            List ret = new ArrayList<>(((List)result.getResult()).size());
            String[] h =  {"Review Date", "Rating", "Site","Product","Customer name","Review  title", "Review text","Verified Purchase", "Matched buyer","Review link", "Order link"};
            ret.add(h);
            for(Object dto: (List)result.getResult()){
            	ReviewDTO d= (ReviewDTO)dto;
            	Object[] row = new Object[11];
            	row[0] = d.getReviewDate().toString();
            	row[1] = Double.toString(d.getRating());
            	row[2] = d.getChannelSkuId().getSiteDTO().getSiteName();
            	row[3] = d.getChannelSkuId().getFullTitle();
            	row[4] = d.getCustomerName();
            	row[5] = d.getTitle();
            	row[6] = d.getContent();
            	row[7] = "" + d.getVerifiedPurchase();
            	row[8] = "" + d.isBuyerInfoMatched();
            	row[9] = d.getLinkOnSite();
            	if(d.getOrderDto() != null)
            		row[10] = "https://sellercentral.amazon.com/hz/orders/details?_encoding=UTF8&orderId=" + d.getOrderDto().getChannelOrderIdDTO();
            	
            	ret.add(row);
            }

            byte[] excel = ExcelUtil.toExcel(ret, null, "Report");

            ResponseBuilder response = Response.ok((Object) excel);
            response.header("Content-Disposition", "attachment; filename=new-excel-file.xls");
            return response.build();
        } catch (Exception e) {
            logger.log(Level.ALL, "Error in downloadExcel", e);
            return Response.noContent().build();
        }
    }
    
}
