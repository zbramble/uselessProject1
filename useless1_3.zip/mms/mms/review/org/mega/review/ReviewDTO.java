package org.mega.review;

import java.util.Date;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.order.order.OrderDTO;
import org.mega.product.ProductDTO;
import org.mega.product.channelsku.ProductChannelSKUDTO;

public class ReviewDTO extends BaseDTO {
	
	private long rowId;
	private boolean buyerInfoMatched;
	private ProductChannelSKUDTO channelSkuId;
	private String content;
	private String customerId;
	private String customerName;
	private double fullRating;
	private double helpfulVotes;
	private String itemId;
	private ProductDTO productId;
	private double rating;
	private String realName;
	private double responded;
	private Date reviewDate;
	private String reviewId;
	private String specificNote;
	private ComboValDTO statusDTO;
	private String title;
	private double totalVotes;
	private boolean verifiedPurchase;
	private OrderDTO orderDto;
	private String linkOnSite;
	
	public boolean isBuyerInfoMatched() {
		return buyerInfoMatched;
	}
	public void setBuyerInfoMatched(boolean buyerInfoMatched) {
		this.buyerInfoMatched = buyerInfoMatched;
	}
	public ProductChannelSKUDTO getChannelSkuId() {
		return channelSkuId;
	}
	public void setChannelSkuId(ProductChannelSKUDTO channelSkuId) {
		this.channelSkuId = channelSkuId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getFullRating() {
		return fullRating;
	}
	public void setFullRating(double fullRating) {
		this.fullRating = fullRating;
	}
	public double getHelpfulVotes() {
		return helpfulVotes;
	}
	public void setHelpfulVotes(double helpfulVotes) {
		this.helpfulVotes = helpfulVotes;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public ProductDTO getProductId() {
		return productId;
	}
	public void setProductId(ProductDTO productId) {
		this.productId = productId;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public double getResponded() {
		return responded;
	}
	public void setResponded(double responded) {
		this.responded = responded;
	}
	public Date getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(Date reviewDate) {
		this.reviewDate = reviewDate;
	}
	public String getReviewId() {
		return reviewId;
	}
	public void setReviewId(String reviewId) {
		this.reviewId = reviewId;
	}
	public String getSpecificNote() {
		return specificNote;
	}
	public void setSpecificNote(String specificNote) {
		this.specificNote = specificNote;
	}
	public ComboValDTO getStatusDTO() {
		return statusDTO;
	}
	public void setStatusDTO(ComboValDTO statusDTO) {
		this.statusDTO = statusDTO;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getTotalVotes() {
		return totalVotes;
	}
	public void setTotalVotes(double totalVotes) {
		this.totalVotes = totalVotes;
	}
	public boolean getVerifiedPurchase() {
		return verifiedPurchase;
	}
	public void setVerifiedPurchase(boolean verifiedPurchase) {
		this.verifiedPurchase = verifiedPurchase;
	}
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public void setOrder(OrderDTO oDTO) {
		this.orderDto = oDTO;
	}
	public OrderDTO getOrderDto() {
		return orderDto;
	}
	public void setOrderDto(OrderDTO orderDto) {
		this.orderDto = orderDto;
	}
	public void setLinkOnSite(String linkOnSite) {
		this.linkOnSite = linkOnSite;
	}
	public String getLinkOnSite() {
		return linkOnSite;
	}
	
}
