package org.mega.review;

import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.order.order.OrderDTO;
import org.mega.product.ProductDTO;
import org.mega.product.channelsku.ProductChannelSKUDTO;



public class ReviewCopier extends BaseCopier<Review, ReviewDTO>{

	@Override
	public ReviewDTO copyFromEntity(Review rvReview) {
		StackTraceElement traceElement = Thread.currentThread().getStackTrace()[4];
		boolean isInDownloadExcel = traceElement.getMethodName().equals("downloadExcel");
		
		ReviewDTO rvReviewDTO = new ReviewDTO();
		rvReviewDTO.setRowId(rvReview.getRowId());
		rvReviewDTO.setBuyerInfoMatched(rvReview.getBuyerInfoMatched());
		rvReviewDTO.setAccessKey(rvReview.getAccessKey());
		if(rvReview.getChannelSkuId() != null){
			ProductChannelSKUDTO pDTO = new ProductChannelSKUDTO();
			pDTO.setRowId(rvReview.getChannelSkuId().getRowId());
			pDTO.setFullTitle(rvReview.getChannelSkuId().getFullTitle());
			SiteDTO siteDTO = new SiteDTO();
			siteDTO.setSiteName(rvReview.getChannelSkuId().getSite().getSiteName());
			pDTO.setSiteDTO(siteDTO );;
			rvReviewDTO.setChannelSkuId(pDTO);
		}
		if(rvReview.getProductId() != null && !isInDownloadExcel){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(rvReview.getProductId().getRowId());
			pDTO.setProductTitle(rvReview.getProductId().getProductTitle());
			rvReviewDTO.setProductId(pDTO);
		}
		
		if(rvReview.getOrder() != null){
			OrderDTO oDTO = new OrderDTO();
			oDTO.setRowId(rvReview.getOrder().getRowId());
			oDTO.setChannelOrderIdDTO(rvReview.getOrder().getChannelOrderId());
			oDTO.setBuyerEmailDTO(rvReview.getOrder().getBuyerEmail());
			rvReviewDTO.setOrder(oDTO);
		}
		if(rvReview.getStatus() != null){
			ComboValDTO statusDTO = new ComboValDTO();
			statusDTO.setRowId(rvReview.getStatus().getRowId());
			statusDTO.setName(rvReview.getStatus().getName());
			rvReviewDTO.setStatusDTO(statusDTO);
		}

		rvReviewDTO.setContent(rvReview.getContent());
		rvReviewDTO.setCustomerId(rvReview.getCustomerId());
		rvReviewDTO.setCustomerName(rvReview.getCustomerName());
		rvReviewDTO.setFullRating(rvReview.getFullRating());
		rvReviewDTO.setHelpfulVotes(rvReview.getHelpfulVotes());
		rvReviewDTO.setItemId(rvReview.getItemId());
		rvReviewDTO.setRating(rvReview.getRating());
		rvReviewDTO.setRealName(rvReview.getRealName());
		rvReviewDTO.setResponded(rvReview.getResponded());
		rvReviewDTO.setReviewDate(rvReview.getReviewDate());
		rvReviewDTO.setReviewId(rvReview.getReviewId());
		rvReviewDTO.setSpecificNote(rvReview.getSpecificNote());
		rvReviewDTO.setTitle(rvReview.getTitle());
		rvReviewDTO.setLinkOnSite(rvReview.getLinkOnSite());
		rvReviewDTO.setTotalVotes(rvReview.getTotalVotes());
		rvReviewDTO.setVerifiedPurchase(rvReview.getVerifiedPurchase());
		return rvReviewDTO;
	}

	@Override
	public Review copyToEntity(ReviewDTO rvReviewDTO) throws Exception {
		Review rvReview = new Review();
		rvReview.setRowId(rvReviewDTO.getRowId());
		/*channelSKU.setAccessKey(channelSKUDTO.getAccessKey());
		channelSKU.setDescription(channelSKUDTO.getDescription());
		channelSKU.setSKU(channelSKUDTO.getSKU());
		if(channelSKUDTO.getProductDTO() != null){
			Product p = new Product();
			p.setRowId(channelSKUDTO.getProductDTO().getRowId());
			channelSKU.setProduct(p);
		}
		if(channelSKUDTO.getSiteDTO() != null){
			Site s = new Site();
			s.setRowId(channelSKUDTO.getSiteDTO().getRowId());
			channelSKU.setSite(s);
		}*/
		return rvReview;
	}
	
	
}
