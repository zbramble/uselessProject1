package org.mega.msg.conversationroom;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.msg.conversationuser.ConversationUserDTO;

import java.util.List;

public class MasterConversationRoomDTO extends BaseDTO {
    private ConversationRoomDTO conversationRoom;
    private List<ConversationUserDTO> conversationUsers;

    public ConversationRoomDTO getConversationRoom() {
        return conversationRoom;
    }

    public void setConversationRoom(ConversationRoomDTO conversationRoom) {
        this.conversationRoom = conversationRoom;
    }

    public List<ConversationUserDTO> getConversationUsers() {
        return conversationUsers;
    }

    public void setConversationUsers(List<ConversationUserDTO> conversationUsers) {
        this.conversationUsers = conversationUsers;
    }

    @Override
    public Long getRowId() {
        return conversationRoom.getRowId();
    }
}
