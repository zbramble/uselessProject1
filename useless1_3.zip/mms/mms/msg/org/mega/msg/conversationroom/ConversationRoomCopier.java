package org.mega.msg.conversationroom;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.msg.conversationuser.ConversationUserFacade;

public class ConversationRoomCopier extends BaseCopier<ConversationRoom, ConversationRoomDTO> {
    @Override
    public ConversationRoomDTO copyFromEntity(ConversationRoom conversationRoom) {
        ConversationRoomDTO conversationRoomDTO = new ConversationRoomDTO();

        conversationRoomDTO.setRowId(conversationRoom.getRowId() == 0 ? null : conversationRoom.getRowId());
        conversationRoomDTO.setName(conversationRoom.getName());
        if (conversationRoom.getCategory() != null) {
            ComboValDTO category = new ComboValDTO();
            category.setRowId(conversationRoom.getCategory().getRowId());
            category.setName(conversationRoom.getCategory().getName());
            category.setVal(conversationRoom.getCategory().getVal());
            conversationRoomDTO.setCategory(category);
        }
        if (conversationRoom.getType() != null) {
            ComboValDTO type = new ComboValDTO();
            type.setRowId(conversationRoom.getType().getRowId());
            type.setName(conversationRoom.getType().getName());
            conversationRoomDTO.setType(type);
        }
        if (conversationRoom.getPriority() != null) {
            ComboValDTO priority = new ComboValDTO();
            priority.setRowId(conversationRoom.getPriority().getRowId());
            priority.setName(conversationRoom.getPriority().getName());
            conversationRoomDTO.setPriority(priority);
        }

        conversationRoomDTO.setConversationUsersLists(
                ConversationUserFacade.getInstance().getCopier()
                        .copyFromEntity(conversationRoom.getConversationUsersLists()));

        conversationRoomDTO.setLastConversation(conversationRoom.getLastConversation());
        conversationRoomDTO.setLastStatus(conversationRoom.getLastStatus());
        copyFromEntityBaseField(conversationRoom, conversationRoomDTO);
        return conversationRoomDTO;
    }

    @Override
    public ConversationRoom copyToEntity(ConversationRoomDTO conversationRoomDTO) throws Exception {
        ConversationRoom conversationRoom = new ConversationRoom();

        conversationRoom.setRowId(conversationRoomDTO.getRowId());
        conversationRoom.setName(conversationRoomDTO.getName());
        if (conversationRoomDTO.getCategory() != null) {
            ComboVal category = new ComboVal();
            category.setRowId(conversationRoomDTO.getCategory().getRowId());
            category.setName(conversationRoomDTO.getCategory().getName());
            conversationRoom.setCategory(category);
        }
        if (conversationRoomDTO.getType() != null) {
            ComboVal type = new ComboVal();
            type.setRowId(conversationRoomDTO.getType().getRowId());
            type.setName(conversationRoomDTO.getType().getName());
            conversationRoom.setType(type);
        }
        if (conversationRoomDTO.getPriority() != null) {
            ComboVal priority = new ComboVal();
            priority.setRowId(conversationRoomDTO.getPriority().getRowId());
            priority.setName(conversationRoomDTO.getPriority().getName());
            conversationRoom.setPriority(priority);
        }
        copyToEntityBaseField(conversationRoom, conversationRoomDTO);
        return conversationRoom;
    }
}