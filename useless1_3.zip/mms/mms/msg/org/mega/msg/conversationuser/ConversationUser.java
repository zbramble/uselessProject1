package org.mega.msg.conversationuser;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.user.User;
import org.mega.msg.conversationroom.ConversationRoom;

import javax.persistence.*;

@Entity
@Table(name = "MSG_CONVERSATION_USER",
        uniqueConstraints = @UniqueConstraint(name = "PK_MSG_CONVERSATION_USER", columnNames = "ID"))
public class ConversationUser extends BaseEntity {

    @Id
    @Column(name = "ID", nullable = false)
    private long rowId;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "CONVERSATION_ROOM_ID", foreignKey = @ForeignKey(name = "FK_CNUL_2_CNRM"))
    private ConversationRoom conversationRoom;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "USER_ID", foreignKey = @ForeignKey(name = "FK_CNUL_2_USER"))
    private User user;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "USER_TYPE", foreignKey = @ForeignKey(name = "FK_CNUL_USER_TYPE_2_CMVL"))
    private ComboVal userType;

    @Column(name = "UNSEEN")
    private int unseen;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public ConversationRoom getConversationRoom() {
        return conversationRoom;
    }

    public void setConversationRoom(ConversationRoom conversationRoom) {
        this.conversationRoom = conversationRoom;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ComboVal getUserType() {
        return userType;
    }

    public void setUserType(ComboVal userType) {
        this.userType = userType;
    }

    public int getUnseen() {
        return unseen;
    }

    public void setUnseen(int unseen) {
        this.unseen = unseen;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ConversationUser that = (ConversationUser) o;

        if (rowId != that.rowId) return false;
        if (unseen != that.unseen) return false;
        if (conversationRoom != null ? !conversationRoom.equals(that.conversationRoom) : that.conversationRoom != null)
            return false;
        if (user != null ? !user.equals(that.user) : that.user != null) return false;
        return !(userType != null ? !userType.equals(that.userType) : that.userType != null);

    }

    @Override
    public int hashCode() {
        int result = (int) (rowId ^ (rowId >>> 32));
        result = 31 * result + (conversationRoom != null ? conversationRoom.hashCode() : 0);
        result = 31 * result + (user != null ? user.hashCode() : 0);
        result = 31 * result + (userType != null ? userType.hashCode() : 0);
        result = 31 * result + unseen;
        return result;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
    }

	@Override
	public void preUpdate() throws Exception {
		// TODO Auto-generated method stub
		
	}
}