package org.mega.msg.conversationuser;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.exception.CopierException;
import org.mega.core.file.FileDTO;
import org.mega.core.sec.OnlineUserManager;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.core.user.UserStatus;
import org.mega.msg.conversationroom.ConversationRoom;
import org.mega.msg.conversationroom.ConversationRoomDTO;

public class ConversationUserCopier extends BaseCopier<ConversationUser, ConversationUserDTO> {
    @Override
    public ConversationUserDTO copyFromEntity(ConversationUser conversationUser) {
        ConversationUserDTO helpDeskGroupUserDTO = new ConversationUserDTO();

        helpDeskGroupUserDTO.setRowId(conversationUser.getRowId());
        if (conversationUser.getConversationRoom() != null) {
            ConversationRoomDTO conversationRoomDTO = new ConversationRoomDTO();
            conversationRoomDTO.setRowId(conversationUser.getConversationRoom().getRowId());
            conversationRoomDTO.setName(conversationUser.getConversationRoom().getName());
            helpDeskGroupUserDTO.setConversationRoom(conversationRoomDTO);
        }
        if (conversationUser.getUser() != null) {
            UserDTO user = new UserDTO();
            user.setRowId(conversationUser.getUser().getRowId());
            user.setFullTitle(conversationUser.getUser().getFullTitle());
            user.setFullName(conversationUser.getUser().getFullName());
            if (conversationUser.getUser().getFile() != null) {
                FileDTO img = new FileDTO();
                img.setImageContent(conversationUser.getUser().getFile().getImageContent());
                user.setFile(img);
            }
            if (OnlineUserManager.getInstance().isOnline(conversationUser.getUser().getRowId())) {
                user.setStatus(UserStatus.ONLINE);
            } else {
                user.setStatus(UserStatus.OFFLINE);
            }
            helpDeskGroupUserDTO.setUser(user);
        }
        if (conversationUser.getUserType() != null) {
            ComboValDTO userType = new ComboValDTO();
            userType.setRowId(conversationUser.getUserType().getRowId());
            userType.setName(conversationUser.getUserType().getName());
            helpDeskGroupUserDTO.setUserType(userType);
        }
        helpDeskGroupUserDTO.setUnseen(conversationUser.getUnseen());
        copyFromEntityBaseField(conversationUser, helpDeskGroupUserDTO);

        return helpDeskGroupUserDTO;
    }

    @Override
    public ConversationUser copyToEntity(ConversationUserDTO conversationUserDTO) throws CopierException {
        ConversationUser conversationUser = new ConversationUser();

        conversationUser.setRowId(conversationUserDTO.getRowId());
        if (conversationUserDTO.getConversationRoom() != null) {
            ConversationRoom conversationRoom = new ConversationRoom();
            conversationRoom.setRowId(conversationUserDTO.getConversationRoom().getRowId());
            conversationUser.setConversationRoom(conversationRoom);
        }
        if (conversationUserDTO.getUser() != null) {
            User user = new User();
            user.setRowId(conversationUserDTO.getUser().getRowId());
            conversationUser.setUser(user);
        }
        if (conversationUserDTO.getUserType() != null) {
            ComboVal userType = new ComboVal();
            userType.setRowId(conversationUserDTO.getUserType().getRowId());
            conversationUser.setUserType(userType);
        }
        copyToEntityBaseField(conversationUser, conversationUserDTO);
        return conversationUser;
    }
}