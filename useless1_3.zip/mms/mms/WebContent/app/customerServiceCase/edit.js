var entity;
var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
var selecetdObj={};
$(document).ready(function () {
	
    setEditListeners();
    $('#other-problem-btn').hide();
	showGrid();
    clearForm();
    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    $("#siteDTO").attr("entityId",10001);
    $("#siteDTO").val('Amazon.com');
    $("#channelDTO").attr("entityId",10001);
    $("#channelDTO").val('Amazon');
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
                parent.search();
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/customerServiceCase/save");
    });
    
    /*----------------------------------------------------------------------- problem --------------------------------*/
    $('#other-problem-btn').on('click',function(){
    	var id = $('#rowId').val();
  		addTab({
              window: window,
              src: '/pmt/caseproblem',
  			title: 'Case Problem',
              filter: [
                  {
                      filterTitle: 'Customer Case Service',
                      key: 'customerServiceCase.rowId',
                      value: id,
                      condition: Condition.EQUAL,
                      customerTitle:parent.getSearchResultValue(id, 'customerName')
                  }
              ]
          })
    })
    /*----------------------------------------------------------------- channel ---------------------------------------*/
    $('#channelDTO').on('change',function(){
    	$('#siteDTO').val('');
    	$('#siteDTO').attr('entityId',0);
    })
   
	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
var fProduct = new Filter();
fProduct.addParameter("productTitle", '$("#productDTO").val()', Condition.CONTAINS);
AutocompleteDynamicProduct("productDTO", fProduct);
    
var fProblem = new Filter();
fProblem.addParameter("product.productTitle", '$("#productDTO").val()', Condition.CONTAINS);
fProblem.addParameter("description",'$("#productProblemDTO").val()', Condition.CONTAINS);
AutocompleteDynamicProductProblem("productProblemDTO",fProblem);

var comboCaseType = new Filter();
comboCaseType.addParameter("parent.name",'"Case Type"', Condition.EQUAL);
AutocompleteDynamicComboVal("caseTypeDTO", comboCaseType);
	
var comboCaseSatusType = new Filter();
comboCaseSatusType.addParameter("parent.name",'"Case Status Type"', Condition.EQUAL);
AutocompleteDynamicComboVal("caseSatusTypeDTO", comboCaseSatusType);

var comboCaseReasonType = new Filter();
comboCaseReasonType.addParameter("parent.name",'"Case Reason Type"', Condition.EQUAL);
AutocompleteDynamicComboVal("caseReasonTypeDTO", comboCaseReasonType);

var comboReqActionType = new Filter();
comboReqActionType.addParameter("parent.name",'"Request Action Type"', Condition.EQUAL);
AutocompleteDynamicComboVal("requestedActionTypeDTO", comboReqActionType);

var fChannel = new Filter();
fChannel.addParameter("channelName", '$("#channelDTO").val()', Condition.CONTAINS);
AutocompleteDynamicChannel("channelDTO", fChannel);
 
var fSite = new Filter();
fSite.addParameter("channel.channelName", '$("#channelDTO").val()', Condition.CONTAINS);
fSite.addParameter("siteName", '$("#siteDTO").val()', Condition.CONTAINS);
AutocompleteDynamicSite("siteDTO", fSite);

var fUser = new Filter();
fUser.addParameter("fullTitle", '$("#userDTO").val()', Condition.CONTAINS);
AutocompleteDynamicUser("userDTO", fUser);

var fCountry = new Filter();
fCountry.addParameter("type.name", "'Country'", Condition.CONTAINS);
fCountry.addParameter("name", '$("#countryDTO").val()', Condition.CONTAINS);
AutocompleteDynamicCountry("countryDTO", fCountry);

var fCity = new Filter();
fCity.addParameter("type.name", "'City'", Condition.CONTAINS);
fCity.addParameter("name", '$("#cityDTO").val()', Condition.CONTAINS);
AutocompleteDynamicCountry("cityDTO", fCity);

});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/customerServiceCase/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
	if(dto.productDTO){
		$("#productDTO").val(dto.productDTO.productTitle);
        $("#productDTO").attr("entityId", dto.productDTO.rowId);
	}
	if(dto.productProblemDTO){
		$("#productProblemDTO").val(dto.productProblemDTO.description);
        $("#productProblemDTO").attr("entityId", dto.productProblemDTO.rowId);
	}
	if(dto.caseTypeDTO){
		$("#caseTypeDTO").val(dto.caseTypeDTO.name);
        $("#caseTypeDTO").attr("entityId", dto.caseTypeDTO.rowId);
	}
	if(dto.caseSatusTypeDTO){
		$("#caseSatusTypeDTO").val(dto.caseSatusTypeDTO.name);
        $("#caseSatusTypeDTO").attr("entityId", dto.caseSatusTypeDTO.rowId);
	}
	if(dto.caseReasonTypeDTO){
		$("#caseReasonTypeDTO").val(dto.caseReasonTypeDTO.name);
		$("#caseReasonTypeDTO").attr("entityId", dto.caseReasonTypeDTO.rowId);
	}
	if(dto.channelDTO){
		$('#channelDTO').val(dto.channelDTO.channelName);
		$('#channelDTO').attr("entityId",dto.channelDTO.rowId);
	}
	if(dto.siteDTO){
		$('#siteDTO').val(dto.siteDTO.siteName);
		$('#siteDTO').attr("entityId",dto.siteDTO.rowId);
	}
	if(dto.userDTO){
		$('#userDTO').val(dto.userDTO.fullName);
		$('#userDTO').attr("entityId",dto.userDTO.rowId);
	}
	if(dto.countryDTO){
		$('#countryDTO').val(dto.countryDTO.name);
		$('#countryDTO').attr("entityId",dto.countryDTO.rowId);
	}
	if(dto.stateDTO){
		$('#stateDTO').val(dto.stateDTO.name);
		$('#stateDTO').attr("entityId",dto.stateDTO.rowId);
	}
	if(dto.cityDTO){
		$('#cityDTO').val(dto.cityDTO.name);
		$('#cityDTO').attr("entityId",dto.cityDTO.rowId);
	}
	if(dto.requestedActionTypeDTO){
		$('#cityDTO').val(dto.requestedActionTypeDTO.name);
		$('#cityDTO').attr("entityId",dto.requestedActionTypeDTO.rowId);
	}
	$("#customerName").val(dto.customerName);
	$("#caseDate").val(dto.caseDate);
	$("#caseDescription").val(dto.caseDescription);
	$("#orderId").val(dto.orderId);
	
	if(dto.createdBy){
    	$("#createdBy").val(dto.createdBy.fullTitle);
		$("#createdBy").attr("entityId", dto.createdBy.rowId);
	}
    if(dto.updatedBy){
    	$("#updatedBy").val(dto.updatedBy.fullTitle);
		$("#updatedBy").attr("entityId", dto.updatedBy.rowId);
	}
    $("#created").val(dto.created);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    $('#other-problem-btn').show();
    Log(dto.active)
}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $('#other-problem-btn').hide();
    $('#userDTO').val(user.fullName);
    $('#userDTO').attr("entityId",user.userId);
    $('#caseDate').val(today);
    $('#caseTypeDTO').val('Complain');
	$('#caseTypeDTO').attr('entityId',100014);
	$("#siteDTO").attr("entityId",10001);
	$("#siteDTO").val('Amazon.com');
	$("#channelDTO").attr("entityId",10001);
    $("#channelDTO").val('Amazon');
    $("#productProblemDTO").attr("entityId",'');
    $("#productProblemDTO").val('Not Categorized');
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/customerServiceCase/list");
    pageNo = oldPageNo;
	showGrid();
}
function loadProblem(){
	
	var h = new Handler();
	h.beforeSend = function beforeSend() {

	}
	h.success = function success(result) {
	    if (result.done){
	    	entities = result.result;
	    	 entities.forEach(function (item, index) {
	    			$("#productProblemDTO").val(item.description);
	    	        $("#productProblemDTO").attr("entityId", item.rowId);
	    	 })
	    }
	}
	h.error = function error(jqXHR, textStatus) {
		
	}
	h.complete = function complete() {
	    unlockPage();
	}
	
	var f = new Filter();
	f.addParameter("product.rowId",$("#productDTO").attr("entityId"), Condition.CONTAINS);
	f.addParameter("description",'"Not Categorized"', Condition.CONTAINS);
	
	ServiceInvoker.call(f.getFilters(), h, "/productProblem/list");
}
function handleAutoCompleteSelect(selecetdObj, element) {
    if (element == 'productDTO') {
    	loadProblem();
    }
}
/*--------------------------------------------------------------------------------------- End ------------------------*/

