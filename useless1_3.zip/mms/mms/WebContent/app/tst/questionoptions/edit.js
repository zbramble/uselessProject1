$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    var hSave = new Handler();
    hSave.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد ذخیره گردید');
            $("#questionOptionId").val(result.result);
        } else {
            errorHandle(result)
        }
    }
    hSave.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus);
    }

    function saveRow() {
        var formData = '{"questionOptionId": "' + $("#questionOptionId").val() + '"' +
            ', "optionText" : "' + $("#optionText").val() + '"' +
            ', "isAnswer" : "' + $("#isAnswer").prop('checked') + '"' +
            ', "solution" : "' + $("#solution").val() + '"' +
            ', "description" : "' + $("#description").val() + '"' +

            ( $("#question").attr("entityId") != "" ?
            ', "question": { "questionId" : ' + $("#question").attr("entityId") + ' }' : '') +

            ', "isActive" : "' + $("#isActive").prop('checked') + '"' +
            ', "ticket" : "' + user.ticket + '"}';

        ServiceInvoker.call(formData, hSave, "/questionoptions/save");
    }

    /*----------------------------------------------------------------------------------- Delete ---------------------*/
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد حذف گردید');
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus);
    }

    var dFilter = new Filter();
    dFilter.addParameter("questionOptionId", '$("#questionOptionId").val()', Condition.EQUAL);

    function deleteRow() {
        ServiceInvoker.call(dFilter.getFilters(), hDelete, "/questionoptions/delete");
    }

    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var fQuestion = new Filter();
    fQuestion.addParameter("questionText", '$("#question").val()', Condition.CONTAINS);
    AutocompleteDynamicQuestion("question", fQuestion);

    /*----------------------------------------------------------------------------------- Listener -------------------*/
    $('#sendDeleteBTN').click(function () {
        deleteRow();
    });

    $('#sendSaveBTN').click(function () {
        saveRow();
    });

    $('#sendBackBTN').click(function () {
        parent.hideEdit();
    });
});

/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    addNew();
    $("#questionOptionId").val(dto.questionOptionId);
    if (dto.question != undefined) {
        $("#question").val(dto.question.questionText);
        $("#question").attr("entityId", dto.question.questionId);
    }
    $("#optionText").val(dto.optionText);
    $("#isAnswer").attr("checked", dto.isAnswer);
    $("#solution").val(dto.solution);
    $("#description").val(dto.description);
    $("#isActive").attr("checked", dto.isActive);
}

/*--------------------------------------------------------------------------------------- Add New --------------------*/
function addNew() {
    $("#questionOptionId").val("");
    $("#question").val("");
    $("#question").attr("entityId", "");
    $("#optionText").val("");
    $("#isAnswer").attr("checked", false);
    $("#solution").val("");
    $("#description").val("");
    $("#isActive").attr("checked", true);
}
/*--------------------------------------------------------------------------------------- End ------------------------*/