/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
pageSize = 50;
var searchFields = [
                { key: 'rowId', propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'ID', maxlength: 20 },
                { key: 'buyerInfoMatched',propName: 'e.buyerInfoMatched', type: SearchPropertyType.BOOLEAN, title: 'Matched', maxlength: -1},
                { key: 'content',propName: 'e.content', type: SearchPropertyType.TEXT, title: 'Content', maxlength: 20 },
                { key: 'customerId',propName: 'e."customerId"', type: SearchPropertyType.TEXT, title: 'Customer Id', maxlength: 20 },
                { key: 'customerName',propName: 'e.customerName', type: SearchPropertyType.TEXT, title: 'Customer Name', maxlength: 20 },
                { key: 'fullRating', propName: 'e.fullRating', type: SearchPropertyType.NUMBER, title: 'Full Rating', maxlength: 20 },
                { key: 'helpfulVotes', propName: 'e.helpfulVotes', type: SearchPropertyType.NUMBER, title: 'Helpful Votes', maxlength: 20 },
                { key: 'itemId',propName: 'e."itemId"', type: SearchPropertyType.TEXT, title: 'Item Id', maxlength: 20 },
                { key: 'rating',propName: 'e."rating"', type: SearchPropertyType.NUMBER, title: 'Rating', maxlength: 20 },
                { key: 'realName',propName: 'e."realName"', type: SearchPropertyType.TEXT, title: 'Real Name', maxlength: 20 },
                { key: 'responded', propName: 'e.responded', type: SearchPropertyType.NUMBER, title: 'Responded', maxlength: 20 },
                {
                	key: 'channelSkuId',
                	propName: 'e.channelSkuId.rowId',
                    autocompleteInstance: 'AutocompleteDynamicProductChannelSKU',
                    type: SearchPropertyType.AUTOCOMPLETE,
                    title: 'Channel SKU',
                    maxlength: 50,
                    autocompleteProp: 'fullTitle',
                    autocompleteCondition: Condition.CONTAINS
                },
                {
                	key: 'productId',
                	propName: 'e.productId.rowId',
                    autocompleteInstance: 'AutocompleteDynamicProduct',
                    type: SearchPropertyType.AUTOCOMPLETE,
                    title: 'Product',
                    maxlength: 50,
                    autocompleteProp: 'productTitle',
                    autocompleteCondition: Condition.CONTAINS
                },
                { key: 'reviewDate',propName: 'e.reviewDate', type: SearchPropertyType.DATE, title: 'Review Date', maxlength: 8 },
                { key: 'reviewId',propName: 'e."reviewId"', type: SearchPropertyType.TEXT, title: 'Review Id', maxlength: 20 },
                { key: 'specificNote',propName: 'e."specificNote"', type: SearchPropertyType.TEXT, title: 'Specific Note', maxlength: 20 },
                {
                	key:'status',
                	propName: 'e.status.rowId',
                    autocompleteInstance: 'AutocompleteDynamicComboVal',
                    type: SearchPropertyType.AUTOCOMPLETE,
                    title: 'Status',
                    maxlength: 50,
                    autocompleteProp: 'name',
                    autocompleteCondition: Condition.CONTAINS,
                    initialFilter: {key: 'val', value: 'REVIEW_STATUS', condition: Condition.EQUAL}
                },
                {
                	key: 'createdBy',
                	propName: 'e.createdBy.rowId',
                    autocompleteInstance: 'AutocompleteDynamicUser',
                    type: SearchPropertyType.AUTOCOMPLETE,
                    title: 'Created By',
                    maxlength: 50,
                    autocompleteProp: 'lastName',
                    autocompleteCondition: Condition.CONTAINS
                },
                {
                	key: 'updatedBy',
                	propName: 'e.updatedBy.rowId',
                    autocompleteInstance: 'AutocompleteDynamicUser',
                    type: SearchPropertyType.AUTOCOMPLETE,
                    title: 'Updated By',
                    maxlength: 50,
                    autocompleteProp: 'lastName',
                    autocompleteCondition: Condition.CONTAINS
                },
                { key: 'created',propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created', maxlength: 8 },
                { key: 'updated',propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated', maxlength: 8 },
                { key: 'active',propName: 'e.active', type: SearchPropertyType.BOOLEAN, title: 'Active', maxlength: -1}
                
             ]


/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#buyerInfoMatched").attr("id", 'buyerInfoMatched-' + id).find('span').html(item.buyerInfoMatched ? "Matched" : "Unmatched");
        patternRow.find('#channelSkuId').attr("id", 'channelSkuId-' + id).find('span').html(item.channelSkuId ? item.channelSkuId.SKU : '');
        patternRow.find("#content").attr("id", 'content-' + id).find('span').html(item.content);
        patternRow.find("#realName").attr("id", 'realName-' + id).find('span').html(item.realName);
        patternRow.find("#customerId").attr("id", 'customerId-' + id).find('span').html(item.customerId);
        patternRow.find("#customerName").attr("id", 'customerName-' + id).find('span').html(item.customerName);
        patternRow.find("#fullRating").attr("id", 'fullRating-' + id).find('span').html(item.fullRating);
        patternRow.find("#helpfulVotes").attr("id", 'helpfulVotes-' + id).find('span').html(item.helpfulVotes);
        patternRow.find("#itemId").attr("id", 'itemId-' + id).find('span').html(item.itemId);
        patternRow.find('#productId').attr("id", 'productId-' + id).find('span').html(item.productId ? item.productId.productTitle : '');
        patternRow.find("#rating").attr("id", 'rating-' + id).find('span').html(item.rating);
        patternRow.find("#responded").attr("id", 'responded-' + id).find('span').html(item.responded);
        patternRow.find("#reviewDate").attr("id", 'reviewDate-' + id).find('span').html(item.reviewDate);
        patternRow.find("#reviewId").attr("id", 'reviewId-' + id).find('span').html(item.reviewId);
        patternRow.find("#specificNote").attr("id", 'specificNote-' + id).find('span').html(item.specificNote);
        patternRow.find("#status").attr("id", 'status-' + id).find('span').html(item.status);
        patternRow.find("#title").attr("id", 'title-' + id).find('span').html(item.title);
        patternRow.find("#totalVotes").attr("id", 'totalVotes-' + id).find('span').html(item.totalVotes);
        patternRow.find("#verifiedPurchase").attr("id", 'verifiedPurchase-' + id).find('span').html(item.verifiedPurchase);
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
	
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        if(item.buyerInfoMatched)
        	patternRow.find("#buyerInfoMatched").attr("id", 'buyerInfoMatched-' + id).find('span').addClass("ion-checkmark").css({'color':'#51da51'});
        else
        	patternRow.find("#buyerInfoMatched").attr("id", 'buyerInfoMatched-' + id).find('span').addClass("ion-close").css({'color':'red'});
        
        patternRow.find('#channelSkuId').attr("id", 'channelSkuId-' + id).find('span').html(item.channelSkuId ? item.channelSkuId.SKU : '');
        patternRow.find("#content").attr("id", 'content-' + id).find('span').html(item.content);
        patternRow.find("#customerId").attr("id", 'customerId-' + id).find('span').html(item.customerId);
        patternRow.find("#customerName").attr("id", 'customerName-' + id).find('span').html(item.customerName);
        patternRow.find("#fullRating").attr("id", 'fullRating-' + id).find('span').html(item.fullRating);
        patternRow.find("#helpfulVotes").attr("id", 'helpfulVotes-' + id).find('span').html(item.helpfulVotes);
        patternRow.find("#itemId").attr("id", 'itemId-' + id).find('span').html(item.itemId);
        patternRow.find('#productId').attr("id", 'productId-' + id).find('span').html(item.channelSkuId.fullTitle.length > 40 ? item.channelSkuId.fullTitle.substring(0, 40) + '...': item.channelSkuId.fullTitle);
        patternRow.find("#responded").attr("id", 'responded-' + id).find('span').html(item.responded);
        patternRow.find("#reviewDate").attr("id", 'reviewDate-' + id).find('span').html(item.reviewDate);
        patternRow.find("#reviewId").attr("id", 'reviewId-' + id).find('span').html(item.reviewId);
        patternRow.find("#specificNote").attr("id", 'specificNote-' + id).find('span').html(item.specificNote);
        patternRow.find("#status").attr("id", 'status-' + id).find('span').html(item.statusDTO.name);
        patternRow.find("#title").attr("id", 'title-' + id).find('span').html(item.title);
        patternRow.find("#totalVotes").attr("id", 'totalVotes-' + id).find('span').html(item.totalVotes);
        patternRow.find("#realName").attr("id", 'realName-' + id).find('span').html(item.realName);
        
        var ratingElm = patternRow.find("#rating").attr("id", 'rating-' + id).find('div');
        ratingElm.addClass("star" + item.rating);
        ratingElm.attr('title', item.rating + ' Start(S)');
        
        var verifiedPurchaseElm = patternRow.find("#verifiedPurchase").attr("id", 'verifiedPurchase-' + id).find('span')
        if(item.verifiedPurchase)
        	verifiedPurchaseElm.addClass("ion-checkmark").css({'color':'#51da51'});
        else
        	verifiedPurchaseElm.addClass("ion-close").css({'color':'red'});
        rating
        
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
    	searchResultEntities = result.result;
        if (result.result) {
            fillGrid(result.result);
        } else {
            hideLoading();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("channelSkuId.product.sku", '$("#productSKU_Searcher").val()', Condition.CONTAINS);
fSearch.addParameter("channelSkuId.SKU", '$("#channelSKU_Searcher").val()', Condition.CONTAINS);
fSearch.addParameter("buyerInfoMatched", '$("#matched").val()', Condition.BOOLEAN_EQUAL);
fSearch.addParameter("reviewDate", '$("#fromDate").val()', Condition.FROM_DATE);
fSearch.addParameter("reviewDate", '$("#toDate").val()', Condition.TO_DATE);
fSearch.addParameter("rating", '$("#fromRate").val()', Condition.GREATER_OR_EQUAL);
fSearch.addParameter("rating", '$("#toRate").val()', Condition.LESS_OR_EQUAL);
fSearch.addParameter("status.rowId", '$("#status").val()', Condition.EQUAL);

var pageOrderField="reviewDate desc";
function search(orderField) {
	//debugger;
	pageOrderField = orderField;
	//alert(fSearch.getFilters(orderField))
    ServiceInvoker.call(fSearch.getFilters(orderField), hSearch, "/review/list");
}
/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
	$(".error-container").hide();
    window.frames['editFrame'].showRow(id);
}


$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
			
    $('#search').on('click', function () {
    	pageNo = 1;
        if(AdvanceSearch.initializeFilter().length > 0) {
            fSearch.removeParameter(Condition.WHERE);
            fSearch.addParameter(Condition.WHERE, AdvanceSearch.initializeFilter(), Condition.WHERE);
            $('.win-content-header').removeClass('full-search compact')
            $('#clear-filter').removeClass('hide');
        } else if($('.simple-search input').val().trim().length > 0 || $("#matched").val() != "" || $("#fromDate").val() != "" || $("#toDate").val() != "" || $("#fromRate").val() != "" || $("#toRate").val() != "" || $("#status").val() != "" || $("#productSKU_Searcher").val() != "" || $("#channelSKU_Searcher").val() != "" || $("#product_Searcher").val() != "" ) {
            $('#clear-filter').removeClass('hide');
        }
        search(pageOrderField);
        $('.win-content-header').removeClass('compact full-search');

    })

    $('#clear-filter').on('click', function () {
       	pageNo = 1;
        // Remove Advance Filter Key From Filter Object & Clear Advanced Form & Clear Simple Search From
        $('#filter-item-container').empty();
        $('.simple-search input').val('');
        fSearch.removeParameter(Condition.WHERE);
        $("#matched").val("") ;
        //jQuery('#matched option:selected').attr('label','All');
        $("#fromDate").val("");
        $("#toDate").val("");
        $("#fromRate").val("");
        $("#toRate").val("");
        $("#status").val("");
        $("#product_Searcher").attr("entityId","");
        $("#channelSKU_Searcher").val("") ;
        $("#productSKU_Searcher").val("") ;
        this.classList.add('hide');
        search(pageOrderField)
    })
    $('#product_Searcher').on('click',function(){
	 	var fproduct = new Filter();
	 	fproduct.addParameter("productTitle", '$("#product_Searcher").val()', Condition.CONTAINS);
	 	AutocompleteDynamicProduct("product_Searcher", fproduct);
	 	fSearch.addParameter("channelSkuId.product", '$("#product_Searcher").attr("entityId")', Condition.CONTAINS);
	})
    
    /*----------------------------------------------------------------------------------- Initialization -------------*/
	AdvanceSearch.init();
    setIndexListeners();
    

    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    if('1' == getParamValue('negative')){
    	$("#fromRate").val(1);
    	$("#toRate").val(3);
    }
    search(pageOrderField);
    
});
	function exportExcel() {
		var filter = fSearch.getFilters(pageOrderField);
		$.ajax({
			url : servicePath + "/service/review/downloadExcel",
			type : "POST",
			data : filter,
			contentType : "application/json",
			xhrFields : {
				responseType : 'blob'
			},
			success : function(data) {
				if(data){
				var blob = new Blob([ data ]);
				var link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);
				link.download = "Reviews_" + new Date().yyyymmdd() + ".xls";
				link.click();
				}else{
					alert(' Error!');
				}
			},
			fail: function(data){
				alert(data);
			}
		});
	}
/*--------------------------------------------------------------------------------------- End ------------------------*/