var entity;

$(document).ready(function () {
    setEditListeners();

    /*----------------------------------------------------------------------------------- Save -----------------------*/
    
	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/


});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/orderItem/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
	//debugger;
    entity = dto;
    clearForm();
    /********** from orderItem********/
    $("#rowId").val(dto.rowId);
    $("#quantity").html(dto.quantityDTO ? dto.quantityDTO :'');
    $("#productTitle").html(dto.productChannelSKUDTO? dto.productChannelSKUDTO.fullTitle :'');
    $("#channelOrderItemId").html(dto.channelOrderItemIdDTO? dto.channelOrderItemIdDTO :'');
    $("#channelSKU").html(dto.channelSKUDTO? dto.channelSKUDTO :'');
    /********** from order************/
    $("#channelOrderId").html(dto.orderDTO ? dto.orderDTO.channelOrderIdDTO :'');
    $("#purchaseDate").html(dto.orderDTO? dto.orderDTO.purchaseDateDTO : '');
    $("#buyerName").html(dto.orderDTO ?dto.orderDTO.buyerNameDTO :'');
    $("#siteName").html(dto.orderDTO ? dto.orderDTO.siteDTO.siteName : '');
    //$("#buyerId").html(dto.orderDTO ? dto.orderDTO.buyerIdDTO : '');
    $("#buyerEmail").html(dto.orderDTO ? dto.orderDTO.buyerEmailDTO : '');
    $("#orderStatus").html(dto.orderDTO ? dto.orderDTO.orderStatusDTO : '');
    $("#orderType").html(dto.orderDTO ? dto.orderDTO.orderTypeDTO : '');
    
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $("#productDTO").val(parent.title);
	$("#productDTO").attr("entityId", parent.id);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/orderItem/list");
    pageNo = oldPageNo;
}

/*--------------------------------------------------------------------------------------- End ------------------------*/

