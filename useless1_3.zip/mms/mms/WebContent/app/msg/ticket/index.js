/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var searchFields = [];

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#name").attr("id", 'name-' + id).find('span').html(item.name);
        if (item.type) {
            patternRow.find("#type").attr("id", 'type-' + id).find('span').html(item.type.name);
        }
        if (item.priority) {
            patternRow.find("#priority").attr("id", 'priority-' + id).find('span').html(item.priority.name);
        }
        patternRow.find("#lastStatus").attr("id", 'lastStatus-' + id).find('span').html(translateLastStatus(item.lastStatus));
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
hSearch.success = function (data) {
    if (data.done) {
        if (data.result) {
            fillGrid(data.result);
        } else {
            hideLoading();
            $('.edit-container').addClass('animated fadeIn').css({'display': 'block'})
            window.frames['editFrame'].clearForm();
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(data);
        }, 300)
    }
}
var fSearch = new Filter();
fSearch.addParameter("name", '$("#name_Searcher").val()', Condition.CONTAINS);
fSearch.addParameter("category.rowId", "'100065'", Condition.EQUAL); //Ticket

function search(orderField) {
    ServiceInvoker.call(fSearch.getFilters(orderField), hSearch, "/conversationroom/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
function showRow(id) {
    window.frames['editFrame'].showRow(id)
}

$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    $('#search').on('click', function () {
        search();
    })

    /*----------------------------------------------------------------------------------- Initialization -------------*/
    setIndexListeners();
    search();
});

/*--------------------------------------------------------------------------------------- Translate Last Status ------*/
function translateLastStatus(lastStatusValue) {
    var lastStatusName;
    switch (lastStatusValue) {
        case 'NEW_MESSAGE':
            lastStatusName = 'Unread';
            break;
        case 'SEE':
            lastStatusName = 'Seen';
            break;
        case 'ANSWERED':
            lastStatusName = 'Answered';
            break;
        default:
            lastStatusName = '-';
    }
    return lastStatusName;
}
/*--------------------------------------------------------------------------------------- End ------------------------*/
