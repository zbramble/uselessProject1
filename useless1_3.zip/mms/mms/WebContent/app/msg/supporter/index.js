/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var searchFields = [
    {propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'Identity', maxlength: 7},
    {propName: 'e.active', type: SearchPropertyType.BOOLEAN, title: 'Active', maxlength: 20},
    {
        propName: 'e.user.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'User',
        maxlength: 50,
        autocompleteProp: 'fullTitle',
        autocompleteCondition: Condition.CONTAINS
    },
    {
        propName: 'e.createdBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Created by ',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    {
        propName: 'e.updatedBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Updated by ',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    {propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created ', maxlength: 8},
    {propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated ', maxlength: 8},
]
var selectedId;
/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find('#user').attr("id", 'user-' + id).find('span').html(item.user.fullTitle);
        patternRow.find('#type').attr("id", 'type-' + id).find('span').html(item.type.name);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var fSearch = new Filter();
fSearch.addParameter("user.fullTitle", '$("#userName_Searcher").val()', Condition.CONTAINS);

function search(orderField) {
    ServiceInvoker.call(fSearch.getFilters(orderField), hSearch, "/supporter/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
function showRow(id) {
    window.frames['editFrame'].showRow(id)
}

$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Initialization -------------*/
    setIndexListeners();
    search();

});

/*--------------------------------------------------------------------------------------- End ------------------------*/