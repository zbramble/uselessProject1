var entity;

$(document).ready(function () {
    setEditListeners();

    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            } else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }

        saveRow('edit-form', hSave, "/supporter/save");
    });

    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var fUser = new Filter();
    fUser.addParameter("fullTitle", '$("#user").val()', Condition.CONTAINS);
    AutocompleteDynamicUser("user", fUser);

    var fType = new Filter();
    fType.addParameter("parent.val", "'SUPPORT_PROBLEM_TYPE'", Condition.CONTAINS);
    AutocompleteStaticComboVal("type", fType, 'SUPPORT_PROBLEM_TYPE');

});

/*--------------------------------------------------------------------------------------- Delete ---------------------*/
var hDelete = new Handler();
hDelete.error = function error(jqXHR, textStatus) {
    alert("Error: " + textStatus);
}

function deleteRow(id) {
    hDelete.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' Item deleted');
            if (id == undefined) {
            } else {
                parent.$('tr#row-' + id).remove();
            }
        } else {
            errorHandle(result)
        }
    }

    var dFilter = new Filter();
    if (id == undefined) {
        dFilter.addParameter("rowId", '$("#rowId").val()', Condition.EQUAL);
    } else {
        dFilter.addParameter("rowId", id, Condition.EQUAL);
    }
    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/supporter/delete");
}

/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    if (dto.user != undefined) {
        $("#user").val(dto.user.fullTitle);
        $("#user").attr("entityId", dto.user.rowId);
    }
    if (dto.type != undefined) {
        $("#type").val(dto.type.name);
        $("#type").attr("entityId", dto.type.rowId);
    }
    $("#active").prop("checked", dto.active);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/supporter/list");
    pageNo = oldPageNo;
}

/*--------------------------------------------------------------------------------------- End ------------------------*/