//----------------------------------------------------------------------------- Variable -------------------------------
var rooms = new Map();
var currentRoom;

//----------------------------------------------------------------------------- Create Conversation Room Item ----------
function createConversationRoomItems(items) {
    $('#conversationsRoomList').empty();
    $('#conversationsList').empty();
    rooms.clear();
    var otherUserId;
    var otherUserStatus;

    items.sort(function (a, b) {
        return b.updated > a.updated;
    });

    $.each(items, function (index, value) {
            rooms.put(value.rowId, value);

            if (value.category.val != "GROUP") {
                $.each(value.conversationUsersLists, function (index, inValue) {
                    if (inValue.user.rowId != user.userId) {
                        value.name = inValue.user.fullTitle;
                        otherUserId = inValue.user.rowId;
                        otherUserStatus = inValue.user.status;
                    }
                });
                value.name = value.name ? value.name : 'You';
            }

            <!--Contact Item-->
            var divContactItem = document.createElement('div');
            divContactItem.setAttribute('class', 'contact-item');
            divContactItem.setAttribute('data-category', value.category.val);
            if (value.category.val != 'GROUP') {
                divContactItem.setAttribute('data-other-user', otherUserId);
            }
            divContactItem.setAttribute('id', value.rowId);

            <!-- --img-->
            var img = document.createElement('img');
            img.setAttribute('src', 'user.jpg');
            $.each(value.conversationUsersLists, function (index, inValue) {
                if (inValue.user.rowId == user.userId) {
                    if (inValue.unseen > value.unseen) {
                        value.unseen = inValue.unseen;
                    }
                } else {
                    if (inValue.user.file) {
                        img.setAttribute('src', 'data:image/png;base64,' + inValue.user.file.imageContent);
                    }
                }
            });
            if (otherUserStatus && otherUserStatus == "ONLINE") {
                img.setAttribute('class', 'online');
            }
            divContactItem.append(img);

            <!-- --span Badge-->
            var spanBadge = document.createElement('span');
            spanBadge.setAttribute('class', 'badge');
            if (value.unseen > 0) {
                spanBadge.style.display = '';
                spanBadge.innerHTML = value.unseen;
            } else {
                spanBadge.style.display = 'none';
            }
            divContactItem.append(spanBadge);

            <!-- --div Info-->
            var divInfo = document.createElement('div');
            divInfo.setAttribute('class', 'info');
            divContactItem.append(divInfo);

            <!-- -- --h4 Name-->
            var h4Info = document.createElement('h4');
            h4Info.innerHTML = value.name;
            divInfo.append(h4Info);

            <!-- -- --h6 Last Conversation-->
            var h6Info = document.createElement('h6');
            if (value.lastConversation) {
                if (value.updatedBy.username != '') {
                    h6Info.innerHTML = value.updatedBy.username + ": " + value.lastConversation.replaceAll('|.|', ' ');
                } else {
                    h6Info.innerHTML = value.lastConversation.replaceAll('|.|', ' ');
                }
            } else {
                h6Info.innerHTML = '';
            }
            divInfo.append(h6Info);

            <!-- --div Details-->
            var divDetails = document.createElement('div');
            divDetails.setAttribute('class', 'details');
            divContactItem.append(divDetails);

            <!-- -- --h6-->
            var h6Details = document.createElement('h6');
            h6Details.innerHTML = value.updated.substr(0, 10);
            divDetails.append(h6Details);

            <!-- -- --span trash-->
            var spanTrash = document.createElement('span');
            spanTrash.setAttribute('class', 'ion ion-trash-b');

            spanTrash.addEventListener("click", function (e) {
                e.stopPropagation();
                var hDelete = new Handler();
                hDelete.success = function success(result) {
                    
                    if (result.done) {
                        searchConversationsRoom();
                        $('#conversationRoomTitle').empty();
                        currentRoom = 0;
                    } else {
                        errorHandle(result)
                    }
                }
                var dFilter = new Filter();
                dFilter.addParameter("rowId", value.rowId, Condition.EQUAL);

                ServiceInvoker.call(dFilter.getFilters(), hDelete, "/conversationroom/delete");
            })
            divDetails.append(spanTrash);

            <!-------------------------------------------------Event Listener-->
            divContactItem.addEventListener("click", function () {
                searchConversations(value.rowId)
                $("#conversationRoomTitle").html(value.name);
                $("#conversations").removeAttr("style");
                $("#createConversationsRoom").css("display", "none");
                $('#conversationsList').empty();
                $('.contact-item').removeClass("active");
                $('#' + value.rowId).addClass("active");
                currentRoom = value.rowId;
                var room = rooms.get(value.rowId);
                room.unseen = 0;
                rooms.put(value.rowId, room);
                $("#" + value.rowId).find('.badge').css("display", "none");
            });

            var ulConversationsRoomList = $('#conversationsRoomList');
            ulConversationsRoomList.append(divContactItem);

            if (currentRoom == value.rowId) {
                $('#' + value.rowId).find('a').addClass("active");
            }
        }
    )

    if (currentRoom) {
        $('#' + currentRoom).trigger("click");
    }
}

//----------------------------------------------------------------------------- Create Conversation Item ---------------
function createConversationItem(items) {
    $('#conversationsList').empty();
    items.sort(function (a, b) {
        return a.rowId - b.rowId;
    });

    var dicConversationsList = $('#conversationsList');

    $.each(items, function (index, value) {
        if (value.createdBy.rowId == user.userId) {
            <!--Conversation Content-->
            var divOwn = document.createElement('div');
            divOwn.setAttribute('class', "own");
            divOwn.setAttribute('id', "conversation-" + value.rowId);

            <!-- --p Text-->
            var pText = document.createElement('p');
            pText.setAttribute('class', 'text');
            if (value.text && value.text.length > 0) {
                pText.innerHTML = value.text.replaceAll('|.|', '<br>');
            }
            if (value.text && value.text.length > 0 && value.text.charCodeAt(0) > 1000) {
                pText.style.textAlign = "right";
            } else {
                pText.style.textAlign = "left";
            }
            divOwn.append(pText);

            if (value.attache) {
                <!-- --a Attache File-->
                var aAttacheFile = document.createElement('a');
                aAttacheFile.setAttribute('class', 'attache-file');
                aAttacheFile.setAttribute('href', '');
                aAttacheFile.innerHTML = value.attache.fullTitle;
                divOwn.append(aAttacheFile);
                aAttacheFile.addEventListener("click", function (e) {
                    e.preventDefault();
                    downloadFile(value.attache.rowId);
                });

                <!-- -- --span-->
                var spanAttacheFile = document.createElement('span');
                spanAttacheFile.setAttribute('class', 'ion ion-paperclip');
                spanAttacheFile.setAttribute("entityId", value.attache.rowId);
                aAttacheFile.append(spanAttacheFile);
            }

            <!-- --p Time-->
            var pTime = document.createElement('p');
            pTime.setAttribute('class', 'timestamp');
            pTime.innerHTML = value.created;
            divOwn.append(pTime);

            dicConversationsList.append(divOwn);
        } else {
            <!--Conversation Content-->
            var divOther = document.createElement('div');
            divOther.setAttribute('class', "other");
            divOther.setAttribute('id', "conversation-" + value.rowId);

            <!-- --img-->
            var img = document.createElement('img');
            if (value.createdBy.file) {
                img.setAttribute('src', 'data:image/png;base64,' + value.createdBy.file.imageContent);
            } else {
                img.setAttribute('src', 'user.jpg');
            }
            divOther.append(img);

            <!-- --p Text-->
            var pText = document.createElement('p');
            pText.setAttribute('class', 'text');
            pText.innerHTML = value.text.replaceAll('|.|', '<br>');
            if (value.text && value.text.length > 0 && value.text.charCodeAt(0) > 1000) {
                pText.style.textAlign = "right";
            } else {
                pText.style.textAlign = "left";
            }
            divOther.append(pText);

            if (value.attache) {
                <!-- --br Attache File-->
                var brAttacheFile = document.createElement('br');
                divOther.append(brAttacheFile);

                <!-- --a Attache File-->
                var aAttacheFile = document.createElement('a');
                aAttacheFile.setAttribute('class', 'attache-file');
                aAttacheFile.setAttribute('href', '');
                aAttacheFile.innerHTML = value.attache.fullTitle;
                divOther.append(aAttacheFile);
                aAttacheFile.addEventListener("click", function (e) {
                    e.preventDefault();
                    downloadFile(value.attache.rowId);
                });

                <!-- -- --span-->
                var spanAttacheFile = document.createElement('span');
                spanAttacheFile.setAttribute('class', 'ion ion-paperclip');
                spanAttacheFile.setAttribute("entityId", value.attache.rowId);
                aAttacheFile.append(spanAttacheFile);
            }

            <!-- --p Time-->
            var pTime = document.createElement('p');
            pTime.setAttribute('class', 'timestamp');
            divOther.append(pTime);

            <!-- -- --span Time-->
            var spanTime = document.createElement('span');
            spanTime.setAttribute('class', 'timestamp-val');
            spanTime.innerHTML = value.created;
            pTime.append(spanTime);

            <!-- -- --span User-->
            var spanUser = document.createElement('span');
            spanUser.setAttribute('class', 'user');
            spanUser.innerHTML = " . " + value.createdBy.fullTitle;
            pTime.append(spanUser);

            dicConversationsList.append(divOther);
        }
    });
    $("#conversationsList").scrollTop(9999);
}

//----------------------------------------------------------------------------- Create User Item -----------------------
function createUserItem(items) {
    $("#user-list").empty();
    items.sort(function (a, b) {
        return a.rowId - b.rowId;
    });

    $.each(items, function (index, value) {
        if (value.rowId == user.userId) {
            return true;
        }
        <!--User Item-->
        var li = document.createElement('li');
        li.setAttribute('id', value.rowId);

        <!-- --a-->
        var a = document.createElement('a');
        li.append(a);

        <!-- -- --img-->
        var img = document.createElement('img');
        if (value.file) {
            img.setAttribute('src', 'data:image/png;base64,' + value.file.imageContent);
        } else {
            img.setAttribute('src', 'user.jpg');
        }
        if (value.status == "ONLINE") {
            img.setAttribute('class', 'online');
        }
        a.append(img);

        <!-- -- --div-->
        var div = document.createElement('div');
        a.append(div);

        <!-- -- -- --h5-->
        var h5Name = document.createElement('h5');
        h5Name.setAttribute('class', 'name');
        h5Name.innerHTML = value.fullTitle;
        div.append(h5Name);

        <!-- -- -- --h6-->
        var h6Username = document.createElement('h6');
        h6Username.setAttribute('class', 'username');
        h6Username.innerHTML = value.username;
        div.append(h6Username);

        li.addEventListener("click", function () {
            var users = [value.rowId];
            var category = 100079; // category type private.
            saveConversationRoom(users, category);
            $('.tab-container').removeClass('show');
        });

        $("#user-list").append(li);
    });
}

//----------------------------------------------------------------------------- Search Conversations Room --------------
var hConversationsRoom = new Handler();
hConversationsRoom.success = function success(result) {
    if (result.done) {
        if (result.result) {
            createConversationRoomItems(result.result);
        } else {
            $('#conversationsRoomList').empty();
            $('#conversationsList').empty();
            hideLoading();
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}

var fConversationsRoom = new Filter();
fConversationsRoom.addParameter("category.rowId", "'100078'", Condition.NOT_IN); //TICKET
function searchConversationsRoom() {
    var oldPageSize = pageSize;
    pageSize = 500;
    ServiceInvoker.call(fConversationsRoom.getFilters(), hConversationsRoom, "/conversationroom/list");
    pageSize = oldPageSize;
}

//----------------------------------------------------------------------------- Search Conversations -------------------
var hConversations = new Handler();
hConversations.success = function success(result) {
    if (result.done) {
        if (result.result) {
            createConversationItem(result.result);
        }
    }
    hideLoading();
}

function searchConversations(conversationsRoomId) {
    var fConversationsRoom = new Filter();
    fConversationsRoom.addParameter("conversationRoom.rowId", conversationsRoomId, Condition.EQUAL);
    var orderField = " rowId desc, e.created asc";
    pageSize = 100;
    ServiceInvoker.call(fConversationsRoom.getFilters(orderField), hConversations, "/conversation/list");
}

//----------------------------------------------------------------------------- Search User ----------------------------
var hUser = new Handler();
hUser.success = function success(result) {
    if (result.done) {
        if (result.result) {
            createUserItem(result.result);
        } else {
            $("#user-list").empty();
        }
    }
    hideLoading();
}

var fUser = new Filter();

function searchUser(userType) {
    pageSize = 100;

    switch (userType.trim()) {
        case "Colleagues":
            ServiceInvoker.call(fUser.getFilters(), hUser, "/user/list");
            break;
        case "Contacts":
            ServiceInvoker.call(fUser.getFilters(), hUser, "/contact/userlist");
            break;
    }
}

//----------------------------------------------------------------------------- Save Conversation Data -----------------
function saveConversationData() {
    if ($("#file-input")[0].files.length > 0) {
        saveAttacheFile();
    } else {
        saveConversation();
    }
}

//----------------------------------------------------------------------------- Save Conversation ----------------------
function saveConversation(fileId) {
	if (fileId && $('#conversationContent').val() == "")
        $('#conversationContent').val("attached file");
    if (!($('#conversationContent').val() && currentRoom)) {
        return;
    }

    var hSaveConversation = new Handler();
    hSaveConversation.success = function success(result) {
        if (result.done) {
            $("#conversationContent").val('');
        } else {
            errorHandle(result);
        }
    }

    var text = $("#conversationContent").val().replaceAll('\n', '|.|');

    var formData = '{"text":"' + text + '"' +
        ',"active":"true"' +
        (fileId ? ',"attache" : {"rowId": ' + fileId + '}' : "") +
        ',"ticket":"' + user.ticket + '"' +
        ',"conversationRoom": {"rowId":"' + currentRoom + '"}}';

    ServiceInvoker.call(formData, hSaveConversation, "/conversation/save");
}

//----------------------------------------------------------------------------- Save Conversation Room -----------------
function saveConversationRoom(users, category, roomName) {
    var hSaveConversationRoom = new Handler();
    hSaveConversationRoom.success = function success(result) {
        if (result.done) {
            currentRoom = result.result;
            searchConversationsRoom();
        } else {
            errorHandle(result);
        }
    }

    var conversationUserList = '';
    $.each(users, function (index, value) {
        conversationUserList += conversationUserList.length > 0 ? ',' : '';
        conversationUserList += '{"user":{"rowId": "' + value + '"}}';
    });

    var formData = '{ "active":"true" ' +
        ',"conversationRoom":{ "category":{"rowId":' + category + '} ' +
        (roomName ? ',"name":"' + roomName + '"' : '' ) + '}' +
        ',"conversationUsers": [ ' + conversationUserList + ']' +
        ',"ticket":"' + user.ticket + '"}';

    ServiceInvoker.call(formData, hSaveConversationRoom, "/conversationroom/savelist");
}

//----------------------------------------------------------------------------- Save Attache file ----------------------
function saveAttacheFile() {
    var hImageSave = new Handler;
    hImageSave.success = function (result) {
        if (result.done) {
            fileRowId = result.result[0];
            $("#file-input").val("");
            $(".attache-list").find("span").html("");
            saveConversation(result.result);
        }
        else {
            errorHandle(result);
        }
    }
    hImageSave.error = function (jqXHR, textStatus) {
        dialog('ذخیره', textStatus + 'خطا: ');
    }

    var files = $('#file-input')[0].files;

    var formData = new FormData;
    formData.append('rowId', "");
    formData.append('title', "-");
    formData.append('description', "گفتگو آنلاین")
    formData.append('useTitle', "گفتگو آنلاین");
    formData.append('useEntity', "Messaging");
    formData.append('path', $("#file-input").attr("path"));
    formData.append('active', $("#active").prop("checked"));

    ServiceInvoker.upload(files, formData, hImageSave, "/conversation/upload");
}

//----------------------------------------------------------------------------- Download File --------------------------
function downloadFile(fileId) {
    var fSearch = new Filter();
    fSearch.addParameter("id", fileId, Condition.EQUAL);
    ServiceInvoker.download(fSearch.getFilters(), "/conversation/download");
}

/*----------------------------------------------------------------------------- Filter User --------------------------*/
function filterUser(element) {
    var value = $(element).val();
    $("#user-list > li").each(function () {
        if ($(this).text().search(value) > -1) {
            $(this).show();
        } else {
            $(this).hide();
        }
    });
}

/*----------------------------------------------------------------------------- Document ready -----------------------*/
$(document).ready(function () {

    searchConversationsRoom();

    //----------------------------------------------------- Open Menu Tab
    $('#compose').on('click', function (e) {
        e.stopPropagation();
        showTabs();
    });

    Mousetrap.bind('shift+n', function (e, combo) {
        showTabs();
    });


    function showTabs() {
        $('.tab-container').addClass('show');
        var dataName = $(".tab-list").find(".active").attr("data-name");
        searchUser(dataName);
    }

    //----------------------------------------------------- Close Menu Tab
    $('.close-btn').on('click', function () {
        closeTabs();
    });

    Mousetrap.bind('esc', function (e, combo) {
        closeTabs();
    });

    $(window).on('click', function () {
        closeTabs();
    });

    function closeTabs() {
        $('.tab-container').removeClass('show');
    }

    //----------------------------------------------------- Save Conversation
    $("#send-btn").on('click', function () {
        saveConversationData();
    });

    Mousetrap($('#conversationContent').get(0)).bind('enter', function (e, combo) {
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            // internet explorer
            e.returnValue = false;
        }
        saveConversationData();
    });

    //----------------------------------------------------- Handle Active Tab
    $('.tab-list li').on('click', function () {
        $(this).siblings().removeClass('active');
        $(this).addClass('active');
        searchUser(this.innerText);
    });

    //----------------------------------------------------- Save Conversation Room
    $("#saveConversationRoom").on('click', function () {
        var conversationRoomName = $("#conversationRoomName").val();
        var users = [];
        users.push($("#userSearch").attr("entityId"));
        saveConversationRoom(users, conversationRoomName);
    });

    //------------------------------------------------------------------------- Other ----------------------------------
    $('.tab-container').on('click', function (e) {
        e.stopPropagation();
    });

    $("#conversationContent").on('keyup', function (e) {
        var msgText = $("#conversationContent").val();
        if (msgText && msgText.length > 0 && msgText.charCodeAt(0) > 1000) {
            this.style.direction = "rtl";
        } else {
            this.style.direction = "ltr";
        }
        e.stopPropagation();
    });

    //------------------------------------------------------------------------- Filter User ----------------------------
    $("#search-user").on('keyup', function () {
        filterUser(this);
    });

    //------------------------------------------------------------------------- Input User ----------------------------
    $('#file-input').on('change', function (e) {
        e.preventDefault();
        var filesArray = [].slice.call(this.files);
        filesArray.forEach(function (file) {
            var fileName = file.name.shortenFileName(25);
            $(".attache-list").find("span").html(fileName);
        })
    })
    //------------------------------------------------------------------------- Notification ---------------------------
    notificationHandlerConfig();
    top.$("#notification-badges").css({'display': 'none'});
    top.$("#message-badges").css({'display': 'none'});

    //------------------------------------------------------------------------- Notification Handler -------------------
    var NotificationHandler = (function () {
        var
            newMessage = function (notification) {
                if (notification.id == currentRoom) {
                    searchConversations(notification.id);
                } else {
                    var room = rooms.get(notification.id);
                    room.unseen = room.unseen + 1;
                    room.lastConversation = notification.content;
                    room.updatedBy.username = '';
                    room.updated = notification.time;
                    rooms.put(notification.id, room);

                    createConversationRoomItems(rooms.values());
                }
            },
            addUser = function (notification) {
                searchConversationsRoom();
                if (currentRoom) {
                    $('#' + currentRoom).find('a').addClass("active");
                }
            },
            otherUserStatus = function (notification) {
                var item = $("[data-other-user = " + notification.id + "]").find('img');
                if (notification.content == "ONLINE") {
                    item.addClass("online");
                } else {
                    item.removeClass("online");
                }
            };
        return {
            newMessage: newMessage,
            addUser: addUser,
            otherUserStatus: otherUserStatus
        }
    })();

    //------------------------------------------------------------------------- Notification Handler Config ------------
    function notificationHandlerConfig() {
        var SSE = new EventSource(progPath + "/service/events/updatestate/USER-" + user.userId);
        SSE.onmessage = function (event) {
            var notification = JSON.parse(event.data);
            switch (notification.type) {
                case NotificationType.NEW_MESSAGE:
                    NotificationHandler.newMessage(notification);
                    break;
                case NotificationType.ADD_USER_TO_CONVERSATION_ROOM:
                    NotificationHandler.addUser(notification);
                    break;
                case NotificationType.NEWS:
                    notificationHandlerNews(notification);
                    break;
                case NotificationType.USER_STATUS:
                    NotificationHandler.otherUserStatus(notification);
            }

            top.$("#notification-badges").css({'display': 'none'});
            top.$("#message-badges").css({'display': 'none'});
        };
    };

});

//----------------------------------------------------------------------------- End ------------------------------------