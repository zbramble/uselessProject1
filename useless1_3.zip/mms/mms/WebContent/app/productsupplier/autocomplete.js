/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicProduct(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/product/list",
        mapPattern: {
            label: "productTitle",
            value: "productTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicCompany(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/company/list",
        mapPattern: {
            label: "companyName",
            value: "companyName",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};