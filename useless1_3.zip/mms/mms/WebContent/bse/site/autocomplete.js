/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicChannel(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/channel/list",
        mapPattern: {
            label: "channelName",
            value: "channelName",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};