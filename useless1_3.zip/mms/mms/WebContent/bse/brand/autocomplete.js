/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicBrand(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/brand/list",
        mapPattern: {
            label: "brandTitle",
            value: "brandTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};