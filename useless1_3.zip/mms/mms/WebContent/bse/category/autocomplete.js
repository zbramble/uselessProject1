/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicCategory(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/category/list",
        mapPattern: {
            label: "categoryDescription",
            value: "categoryDescription",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};