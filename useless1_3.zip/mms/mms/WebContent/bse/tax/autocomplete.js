/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicTax(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/tax/list",
        mapPattern: {
            label: "taxClassTitle",
            value: "taxClassTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};