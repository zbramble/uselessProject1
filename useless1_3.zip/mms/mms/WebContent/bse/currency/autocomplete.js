/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicCurrency(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/currency/list",
        mapPattern: {
            label: "title",
            value: "title",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};