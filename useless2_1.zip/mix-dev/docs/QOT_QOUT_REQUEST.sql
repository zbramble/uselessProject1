----------------------------------------------------
-- Export file for user MIX                       --
-- Created by Default on 11/06/2017, 02:52:00 �.� --
----------------------------------------------------

spool 2.log

prompt
prompt Creating table QOT_QOUT_REQUEST
prompt ===============================
prompt
create table MIX.QOT_QOUT_REQUEST
(
  qoute_request_id               NUMBER(38) not null,
  qout_request_status_type_id    NUMBER(19),
  origion_location_id            NUMBER(19),
  destination_location_id        NUMBER(19),
  origion_port_location_id       NUMBER(19),
  location_id                    NUMBER(19),
  co__location_id                NUMBER(19),
  co__location_id2               NUMBER(19),
  freight_method_type_id         NUMBER(19),
  freight_type_id                NUMBER(19),
  incoterm_type_id               NUMBER(19),
  shipment_type_id               NUMBER(19),
  rfq_measurement_units_type_id  NUMBER(19),
  is_active                      NUMBER(1),
  created                        TIMESTAMP(6),
  is_deleted                     NUMBER(19),
  full_title                     VARCHAR2(200 CHAR),
  updated                        TIMESTAMP(6),
  access_key                     VARCHAR2(110 CHAR),
  created_by                     NUMBER(19),
  updated_by                     NUMBER(19),
  pickup_date                    DATE,
  target_delivery_date           DATE,
  shipment_name                  NVARCHAR2(500) not null,
  is_packaging_details_known     NUMBER(1),
  total_weight                   NUMBER(10,2),
  total_volume                   NUMBER(10,2),
  total_pieces                   INTEGER,
  memo                           NVARCHAR2(2000),
  description_of_products        NVARCHAR2(2000),
  contains_lithium_ion_batteries NUMBER(1) not null,
  contains_magnetic_properties   NUMBER(1) not null,
  contains_hazardous_material    NUMBER(1) not null,
  is_cpsc_certified              NUMBER(1),
  has_you_comany_assisted_produc NUMBER(1),
  contains_encryption_technologi NUMBER(1),
  contains_wood                  NUMBER(1),
  is_your_comapny_fda_registered NUMBER(1),
  fcc_registered                 NUMBER(1),
  destination_port_location_id   NUMBER(19),
  payment_terms_id               NUMBER(19)
)
tablespace MIX_TBLS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 256K
    next 256K
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
alter table MIX.QOT_QOUT_REQUEST
  add constraint PK_QOT_QOUT_REQUEST primary key (QOUTE_REQUEST_ID)
  using index 
  tablespace MIX_TBLS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 256K
    next 256K
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK1MI1KUXP7Y62DOO74NLG0J8OS foreign key (UPDATED_BY)
  references MIX.CO_USER (USER_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK9HVMN6FRPQWFOIECR19MIDJJN foreign key (CREATED_BY)
  references MIX.CO_USER (USER_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_DESTINATION_LOCAT foreign key (DESTINATION_LOCATION_ID)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_DESTINATION_PORT foreign key (DESTINATION_PORT_LOCATION_ID)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_FREIGHT_METHOD foreign key (FREIGHT_METHOD_TYPE_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_FREIGHT_TYPE_COMBO foreign key (FREIGHT_TYPE_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_INCOTERM_TYPE foreign key (INCOTERM_TYPE_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_LOCATION foreign key (LOCATION_ID)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_LOCATION1 foreign key (CO__LOCATION_ID)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_LOCATION2 foreign key (CO__LOCATION_ID2)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_MEASUREMENT_UNIT foreign key (RFQ_MEASUREMENT_UNITS_TYPE_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_ORIGION_LOCAT foreign key (ORIGION_LOCATION_ID)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_ORIGION_PORT_LOCAT foreign key (ORIGION_PORT_LOCATION_ID)
  references MIX.CO_LOCATION (LOCATION_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_PAYMENT_TERMS_COMB foreign key (PAYMENT_TERMS_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_REQUEST_STATUS foreign key (QOUT_REQUEST_STATUS_TYPE_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);
alter table MIX.QOT_QOUT_REQUEST
  add constraint FK_QOT_QOUT_SHIPMENT_TYPE foreign key (SHIPMENT_TYPE_ID)
  references MIX.CO_COMBO_VAL (COMBO_VAL_ID);


spool off
