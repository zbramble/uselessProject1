--create table space and datafile together
CREATE TABLESPACE mix_tbls DATAFILE
'D:\oracle\data\mix1.dbf' SIZE 150M
AUTOEXTEND ON
BLOCKSIZE 8192
FORCE LOGGING
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 256K
FLASHBACK ON;



create user mix
  identified by "mix"
  default tablespace mix_TBLS
  temporary tablespace TEMP
  profile DEFAULT;
--  password expire;
-- Grant/Revoke role privileges 

--revoke dba from nes;
grant connect to mix;
--grant dba to ntnet;
grant create table to mix;
grant create synonym to mix;
grant unlimited tablespace to mix;
--alter user <user_name> quota unlimited on <tablespace_name>
