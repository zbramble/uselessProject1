package org.mega.quoterelateddocument;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.quote.QuoteDTO;

public class QuoteRelatedDocumnetDTO extends BaseDTO{
	private long rowId;
	private String documentName;
	private QuoteDTO quoteDTO;
	private ComboValDTO documnetTypeDTO;
	private FileDTO documentFileDTO;
	
	public FileDTO getDocumentFileDTO() {
		return documentFileDTO;
	}
	public void setDocumentFileDTO(FileDTO documentFileDTO) {
		this.documentFileDTO = documentFileDTO;
	}
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public QuoteDTO getQuoteDTO() {
		return quoteDTO;
	}
	public void setQuoteDTO(QuoteDTO quoteDTO) {
		this.quoteDTO = quoteDTO;
	}
	public ComboValDTO getDocumnetTypeDTO() {
		return documnetTypeDTO;
	}
	public void setDocumnetTypeDTO(ComboValDTO documnetTypeDTO) {
		this.documnetTypeDTO = documnetTypeDTO;
	}	
}
