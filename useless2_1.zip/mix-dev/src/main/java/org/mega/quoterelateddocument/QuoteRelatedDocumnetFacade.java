package org.mega.quoterelateddocument;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class QuoteRelatedDocumnetFacade extends BaseFacade{
	private static QuoteRelatedDocumnetCopier copier = new QuoteRelatedDocumnetCopier();
	private static QuoteRelatedDocumnetFacade facade = new QuoteRelatedDocumnetFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static QuoteRelatedDocumnetFacade getInstance() {
		return facade;
	}
}
