package org.mega.quoterelateddocument;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.file.File;
import org.mega.quote.Quote;

@Entity
@Table(name = "QOT_QUOTE_RELATED_DOCUMENT", uniqueConstraints = @UniqueConstraint(name = "PK_QUOTE_RELATED_DOCUMENT", columnNames = "QUOTE_RELATED_DOCUMENT_ID"))
public class QuoteRelatedDocumnet extends BaseEntity{

	@Id
	@Column(name = "QUOTE_RELATED_DOCUMENT_ID")
	private long rowId;
	
	@Column(name="DOCUMENT_NAME",length=100)
	private String documentName;
	
	@ManyToOne()
	@JoinColumn(name = "QUOTE_ID", foreignKey = @ForeignKey(name = "FK_DOCUMENT_QOT_QUOTE"), nullable = true)
	private Quote quote;

	@ManyToOne()
	@JoinColumn(name = "DOCUMENT_TYPE_ID", foreignKey = @ForeignKey(name = "FK_DOCUMENT_TYPE_COMBO"), nullable = true)
	private ComboVal documnetType;

	@ManyToOne
    @JoinColumn(name = "DOCUMENT_FILE", nullable = true)
    private File documentFile;
	
	public File getDocumentFile() {
		return documentFile;
	}

	public void setDocumentFile(File documentFile) {
		this.documentFile = documentFile;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Quote getQuote() {
		return quote;
	}

	public void setQuote(Quote quote) {
		this.quote = quote;
	}

	public ComboVal getDocumnetType() {
		return documnetType;
	}

	public void setDocumnetType(ComboVal documnetType) {
		this.documnetType = documnetType;
	}

	
	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = documentName;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = documentName;
	}

}
