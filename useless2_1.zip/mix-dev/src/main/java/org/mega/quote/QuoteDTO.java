package org.mega.quote;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.LocationDTO;
import org.mega.qot.quotrequest.QuotRequestDTO;
import org.mega.quoteitem.QuoteItemDTO;

public class QuoteDTO extends BaseDTO{
	private long rowId;
	private QuotRequestDTO qouteRequestDTO;
	private ComboValDTO freightMethodDTO;
	private ComboValDTO freightTypeDTO;
	private ComboValDTO quoteStatusTypeDTO;
	private LocationDTO departureLocationDTO;
	private LocationDTO arrivalLocationDTO;
	private String quoteReference;
	private String carrierName;
	private String transitTimeDays;
	private String closingDays;
	private String departureDays;
	private String origionAddress;	
	private String destinationAddress;
	private String estimatedEmisssions;
	private double total;
	private double discountAmount;
	private double discountPercentage;
	private String quoteDate;
	private String expirationDate;
	private String note;
	private ComboValDTO payMents;
	private List<QuoteItemDTO> quoteItems;
	
	public List<QuoteItemDTO> getQuoteItems() {
		return quoteItems;
	}
	
	public void setQuoteItems(List<QuoteItemDTO> quoteItems) {
		this.quoteItems = quoteItems;
	}
	
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public ComboValDTO getPayMents() {
		return payMents;
	}
	public void setPayMents(ComboValDTO payMents) {
		this.payMents = payMents;
	}
	public ComboValDTO getQuoteStatusTypeDTO() {
		return quoteStatusTypeDTO;
	}
	public void setQuoteStatusTypeDTO(ComboValDTO quoteStatusTypeDTO) {
		this.quoteStatusTypeDTO = quoteStatusTypeDTO;
	}
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public QuotRequestDTO getQouteRequestDTO() {
		return qouteRequestDTO;
	}
	public void setQouteRequestDTO(QuotRequestDTO qouteRequestDTO) {
		this.qouteRequestDTO = qouteRequestDTO;
	}
	public ComboValDTO getFreightMethodDTO() {
		return freightMethodDTO;
	}
	public void setFreightMethodDTO(ComboValDTO freightMethodDTO) {
		this.freightMethodDTO = freightMethodDTO;
	}
	public ComboValDTO getFreightTypeDTO() {
		return freightTypeDTO;
	}
	public void setFreightTypeDTO(ComboValDTO freightTypeDTO) {
		this.freightTypeDTO = freightTypeDTO;
	}
	public LocationDTO getDepartureLocationDTO() {
		return departureLocationDTO;
	}
	public void setDepartureLocationDTO(LocationDTO departureLocationDTO) {
		this.departureLocationDTO = departureLocationDTO;
	}
	public LocationDTO getArrivalLocationDTO() {
		return arrivalLocationDTO;
	}
	public void setArrivalLocationDTO(LocationDTO arrivalLocationDTO) {
		this.arrivalLocationDTO = arrivalLocationDTO;
	}
	public String getQuoteReference() {
		return quoteReference;
	}
	public void setQuoteReference(String quoteReference) {
		this.quoteReference = quoteReference;
	}
	public String getCarrierName() {
		return carrierName;
	}
	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}
	public String getTransitTimeDays() {
		return transitTimeDays;
	}
	public void setTransitTimeDays(String transitTimeDays) {
		this.transitTimeDays = transitTimeDays;
	}
	public String getClosingDays() {
		return closingDays;
	}
	public void setClosingDays(String closingDays) {
		this.closingDays = closingDays;
	}
	public String getDepartureDays() {
		return departureDays;
	}
	public void setDepartureDays(String departureDays) {
		this.departureDays = departureDays;
	}
	public String getOrigionAddress() {
		return origionAddress;
	}
	public void setOrigionAddress(String origionAddress) {
		this.origionAddress = origionAddress;
	}
	public String getDestinationAddress() {
		return destinationAddress;
	}
	public void setDestinationAddress(String destinationAddress) {
		this.destinationAddress = destinationAddress;
	}
	public String getEstimatedEmisssions() {
		return estimatedEmisssions;
	}
	public void setEstimatedEmisssions(String estimatedEmisssions) {
		this.estimatedEmisssions = estimatedEmisssions;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public double getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}
	public double getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public String getQuoteDate() {
		return quoteDate;
	}
	public void setQuoteDate(String quoteDate) {
		this.quoteDate = quoteDate;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	
}
