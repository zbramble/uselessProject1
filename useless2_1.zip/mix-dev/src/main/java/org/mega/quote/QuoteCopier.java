package org.mega.quote;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotrequest.QuotRequest;
import org.mega.qot.quotrequest.QuotRequestDTO;
import org.mega.qot.rfqpackage.RfqPackageFacade;
import org.mega.quoteitem.QuoteItemFacade;
import org.mega.util.DateUtil;

public class QuoteCopier extends BaseCopier<Quote, QuoteDTO>{

	@Override
	public QuoteDTO copyFromEntity(Quote quote) {
		QuoteDTO quoteDTO = new QuoteDTO();
		quoteDTO.setRowId(quote.getRowId());
		quoteDTO.setCarrierName(quote.getCarrierName());
		quoteDTO.setClosingDays(quote.getClosingDays());
		quoteDTO.setDepartureDays(quote.getDepartureDays());
		quoteDTO.setDestinationAddress(quote.getDestinationAddress());
		quoteDTO.setDiscountAmount(quote.getDiscountAmount());
		quoteDTO.setDiscountPercentage(quote.getDiscountPercentage());
		quoteDTO.setEstimatedEmisssions(quote.getEstimatedEmisssions());
		quoteDTO.setOrigionAddress(quote.getOrigionAddress());
		quoteDTO.setQuoteReference(quote.getQuoteReference());
		quoteDTO.setTotal(quote.getTotal());
		quoteDTO.setTransitTimeDays(quote.getTransitTimeDays());
		quoteDTO.setNote(quote.getNote());
		if(quote.getPayMents() != null){
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(quote.getPayMents().getRowId());
			cDTO.setName(quote.getPayMents().getName());
			quoteDTO.setPayMents(cDTO);
		}
		if(quote.getArrivalLocation() != null){
			LocationDTO arrivalLocationDTO = new LocationDTO();
			arrivalLocationDTO.setRowId(quote.getArrivalLocation().getRowId());
			arrivalLocationDTO.setName(quote.getArrivalLocation().getName());
			quoteDTO.setArrivalLocationDTO(arrivalLocationDTO);
		}
		if(quote.getDepartureLocation() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(quote.getDepartureLocation().getRowId());
			locationDTO.setName(quote.getDepartureLocation().getName());
			quoteDTO.setDepartureLocationDTO(locationDTO);
		}
		if(quote.getQuoteStatusType() != null){
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(quote.getQuoteStatusType().getRowId());
			cDTO.setName(quote.getQuoteStatusType().getName());
			quoteDTO.setQuoteStatusTypeDTO(cDTO);
		}
		if(quote.getFreightMethod() != null){
			ComboValDTO freightMethodDTO = new ComboValDTO();
			freightMethodDTO.setRowId(quote.getFreightMethod().getRowId());
			freightMethodDTO.setName(quote.getFreightMethod().getName());
			quoteDTO.setFreightMethodDTO(freightMethodDTO);
		}
		if(quote.getFreightType() != null){
			ComboValDTO freightTypeDTO = new ComboValDTO();
			freightTypeDTO.setRowId(quote.getFreightType().getRowId());
			freightTypeDTO.setName(quote.getFreightType().getName());
			quoteDTO.setFreightTypeDTO(freightTypeDTO);
		}
		if(quote.getQouteRequest() != null){
			QuotRequestDTO quotRequestDTO = new QuotRequestDTO();
			quotRequestDTO.setRowId(quote.getQouteRequest().getRowId());
			quotRequestDTO.setShipmentName(quote.getQouteRequest().getShipmentName());
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(quote.getQouteRequest().getQoutReqStatusType().getRowId());
			cDTO.setName(quote.getQouteRequest().getQoutReqStatusType().getName());
			quotRequestDTO.setQoutReqStatusTypeDTO(cDTO);
			quoteDTO.setQouteRequestDTO(quotRequestDTO);
		}
		quoteDTO.setExpirationDate(DateUtil.getDateString(quote.getExpirationDate(),"en"));
		quoteDTO.setQuoteDate(DateUtil.getDateString(quote.getQuoteDate(), "en"));
		if(quote.getQuoteItems() != null)
			quoteDTO.setQuoteItems(QuoteItemFacade.getInstance().getCopier().copyFromEntity(quote.getQuoteItems()));
		copyFromEntityBaseField(quote, quoteDTO);
		/*
		 * create by
		 */
		if(quote.getCreatedBy() != null){
			UserDTO u = new UserDTO();
			u.setRowId(quote.getCreatedBy().getRowId());
			u.setCompanyName(quote.getCreatedBy().getCompanyName());
			u.setFullName(quote.getCreatedBy().getFullName());
			u.setEmail(quote.getCreatedBy().getEmail());
			if(quote.getCreatedBy().getFile() != null){
				FileDTO f = new FileDTO();
				f.setRowId(quote.getCreatedBy().getFile().getRowId());
				f.setPath(quote.getCreatedBy().getFile().getPath());
				f.setImageContent(quote.getCreatedBy().getFile().getImageContent());
				u.setFile(f);
			}
			quoteDTO.setCreatedBy(u);
		}
		return quoteDTO;
	}

	@Override
	public Quote copyToEntity(QuoteDTO quoteDTO) throws Exception {
		Quote quote = new Quote();
		quote.setRowId(quoteDTO.getRowId());
		quote.setCarrierName(quoteDTO.getCarrierName());
		quote.setClosingDays(quoteDTO.getClosingDays());
		quote.setDepartureDays(quoteDTO.getDepartureDays());
		quote.setDestinationAddress(quoteDTO.getDestinationAddress());
		quote.setDiscountAmount(quoteDTO.getDiscountAmount());
		quote.setDiscountPercentage(quoteDTO.getDiscountPercentage());
		quote.setEstimatedEmisssions(quoteDTO.getEstimatedEmisssions());
		quote.setOrigionAddress(quoteDTO.getOrigionAddress());
		quote.setQuoteReference(quoteDTO.getQuoteReference());
		quote.setTotal(quoteDTO.getTotal());
		quote.setTransitTimeDays(quoteDTO.getTransitTimeDays());
		quote.setNote(quoteDTO.getNote());
		if(quoteDTO.getPayMents() != null){
			ComboVal c = new ComboVal();
			c.setRowId(quoteDTO.getPayMents().getRowId());
			c.setName(quoteDTO.getPayMents().getName());
			quote.setPayMents(c);
		}
		if(quoteDTO.getArrivalLocationDTO() != null){
			Location arrivalLocation = new Location();
			arrivalLocation.setRowId(quoteDTO.getArrivalLocationDTO().getRowId());
			arrivalLocation.setName(quoteDTO.getArrivalLocationDTO().getName());
			quote.setArrivalLocation(arrivalLocation);
		}
		if(quoteDTO.getDepartureLocationDTO() != null){
			Location location = new Location();
			location.setRowId(quoteDTO.getDepartureLocationDTO().getRowId());
			location.setName(quoteDTO.getDepartureLocationDTO().getName());
			quote.setDepartureLocation(location);
		}
		if(quoteDTO.getQuoteStatusTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(quoteDTO.getQuoteStatusTypeDTO().getRowId());
			c.setName(quoteDTO.getQuoteStatusTypeDTO().getName());
			quote.setQuoteStatusType(c);
		}
		if(quoteDTO.getFreightMethodDTO() != null){
			ComboVal freightMethod = new ComboVal();
			freightMethod.setRowId(quoteDTO.getFreightMethodDTO().getRowId());
			freightMethod.setName(quoteDTO.getFreightMethodDTO().getName());
			quote.setFreightMethod(freightMethod);
		}
		if(quoteDTO.getFreightTypeDTO() != null){
			ComboVal freightType = new ComboVal();
			freightType.setRowId(quoteDTO.getFreightTypeDTO().getRowId());
			freightType.setName(quoteDTO.getFreightTypeDTO().getName());
			quote.setFreightType(freightType);
		}
		if(quoteDTO.getQouteRequestDTO() != null){
			QuotRequest quotRequest = new QuotRequest();
			quotRequest.setRowId(quoteDTO.getQouteRequestDTO().getRowId());
			quotRequest.setShipmentName(quoteDTO.getQouteRequestDTO().getShipmentName());
			quote.setQouteRequest(quotRequest);
		}
		quote.setExpirationDate(DateUtil.getDate(quoteDTO.getExpirationDate(),"en"));
		quote.setQuoteDate(DateUtil.getDate(quoteDTO.getQuoteDate(),"en"));
		copyToEntityBaseField(quote, quoteDTO);
		return quote;
	}

}
