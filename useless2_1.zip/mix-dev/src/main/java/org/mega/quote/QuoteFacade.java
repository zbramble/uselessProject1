package org.mega.quote;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.comboval.ComboVal;
import org.mega.core.sec.UserSession;
import org.mega.util.DateUtil;

public class QuoteFacade extends BaseFacade{
	private static QuoteCopier copier = new QuoteCopier();
	private static QuoteFacade facade = new QuoteFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static QuoteFacade getInstance() {
		return facade;
	}
	
	public ServiceResult updateStatus(QuoteDTO quotDTO,BusinessParam businessParam){
		Long id = quotDTO.getRowId();
		Long statusId = quotDTO.getQuoteStatusTypeDTO().getRowId();
		try {
			BaseDB db = businessParam.getDB();
			db.runNativeQuery("update QOT_QOUTE e set e.QUOTE_STATUS_TYPE_ID = "+statusId+" where e.QUOTE_ID= " +  id);
			
			//وقتی کوت ویرایش شد و وضعیت آن ریوارد گردید باید درخواست ارشیو شود
			if(statusId == 100028 || statusId == 100029)
				db.runNativeQuery("update QOT_QOUT_REQUEST e set e.QOUT_REQUEST_STATUS_TYPE_ID = 100029 where e.QOUTE_REQUEST_ID= " +  quotDTO.getQouteRequestDTO().getRowId());
			businessParam.releaseDB();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ServiceResult(id, 1);
		
	}
	
	@Override
	public String getConstraint(BusinessParam businessParam) {
		UserSession userSession = businessParam.getUserSession();
		if(userSession.getUserInfo().getRoleId() == 10005){//Shiper
			return " e.accessKey is null or e.qouteRequest.rowId = "+businessParam.getFilter().getParams().get(1).getValue().toString();
		}else
			return super.getConstraint(businessParam);
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		QuoteDTO quoteDTO = (QuoteDTO) baseDTO;
		if(quoteDTO.getRowId() != 0 ){//update
			if(quoteDTO.getQuoteReference() == null){
				try {
					Quote quote = QuoteFacade.getInstance().findEntityById(Quote.class, quoteDTO.getRowId(), businessParam);
					quote.setNote(quoteDTO.getNote());
					if(quoteDTO.getPayMents() != null){
						ComboVal c = new ComboVal();
						c.setRowId(quoteDTO.getPayMents().getRowId());
						c.setName(quoteDTO.getPayMents().getName());
						quote.setPayMents(c);
					}
					quote.setExpirationDate(DateUtil.getDate(quoteDTO.getExpirationDate(), "en"));
					long id = QuoteFacade.getInstance().saveEntity(quote, businessParam);
					return new ServiceResult(id,1);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}else
				return super.save(baseDTO, businessParam);
		}
		return super.save(baseDTO, businessParam);
	}
}
