package org.mega.msg.sse;

import java.util.concurrent.ConcurrentHashMap;

import javax.inject.Singleton;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

//import org.glassfish.jersey.media.sse.EventOutput;
//import org.glassfish.jersey.media.sse.OutboundEvent;
//import org.glassfish.jersey.media.sse.SseBroadcaster;
//import org.glassfish.jersey.media.sse.SseFeature;

@Singleton
@Path("/events")
public class NotificationHandler {

	// private static final ConcurrentHashMap<String, SseBroadcaster>
	// SSE_BROADCASTER = new ConcurrentHashMap<>();
	//
	// @GET
	// @Path("/updatestate/{eventId}")
	// @Produces(SseFeature.SERVER_SENT_EVENTS)
	// public EventOutput updateState(@PathParam("eventId") String eventId) {
	// EventOutput eventOutput = new EventOutput();
	// registerRoom(eventId);
	// SSE_BROADCASTER.get(eventId).add(eventOutput);
	// return eventOutput;
	// }
	//
	// public static void updateRoom(String eventId, Notification notification) {
	// if (SSE_BROADCASTER.containsKey(eventId)) {
	// SSE_BROADCASTER.get(eventId).broadcast(buildEvent(notification));
	// }
	// }
	//
	// public void registerRoom(String eventId) {
	// if (!SSE_BROADCASTER.containsKey(eventId)) {
	// SSE_BROADCASTER.put(eventId, new SseBroadcaster());
	// }
	// }
	//
	// private static OutboundEvent buildEvent(Notification notification) {
	// OutboundEvent.Builder builder = new OutboundEvent.Builder();
	// OutboundEvent event =
	// builder.mediaType(MediaType.APPLICATION_JSON_TYPE).data(Object.class,
	// notification)
	// .build();
	// return event;
	// }
}