package org.mega.msg.conversationuser;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.user.UserDTO;
import org.mega.msg.conversationroom.ConversationRoomDTO;

public class ConversationUserDTO extends BaseDTO {
    private long rowId;
    private ConversationRoomDTO conversationRoom;
    private UserDTO user;
    private ComboValDTO userType;
    private int unseen;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public ConversationRoomDTO getConversationRoom() {
        return conversationRoom;
    }

    public void setConversationRoom(ConversationRoomDTO conversationRoom) {
        this.conversationRoom = conversationRoom;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public ComboValDTO getUserType() {
        return userType;
    }

    public void setUserType(ComboValDTO userType) {
        this.userType = userType;
    }

    public int getUnseen() {
        return unseen;
    }

    public void setUnseen(int unseen) {
        this.unseen = unseen;
    }
}