package org.mega.msg.conversation;

import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;

import org.mega.core.SystemConfig;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.core.file.FileFacade;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.msg.conversationroom.ConversationRoom;
import org.mega.msg.conversationroom.ConversationRoomDTO;
import org.mega.msg.conversationroom.ConversationRoomFacade;
import org.mega.msg.conversationroom.ConversationRoomStatus;
import org.mega.msg.conversationuser.ConversationUser;
import org.mega.msg.conversationuser.ConversationUserDTO;
import org.mega.msg.conversationuser.ConversationUserFacade;
import org.mega.msg.sse.Notification;
import org.mega.msg.sse.NotificationHandler;
import org.mega.msg.sse.NotificationType;
import org.mega.util.DateUtil;
import org.mega.util.WebUtil;

public class ConversationFacade extends BaseFacade {
    private static ConversationCopier copier = new ConversationCopier();
    private static ConversationFacade facade = new ConversationFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static ConversationFacade getInstance() {
        return facade;
    }

    public ServiceResult save(ConversationDTO conversation, BusinessParam businessParam) {
        ServiceResult serviceResult = super.save(conversation, businessParam);

        if (serviceResult.isDone()) {
            try {
                long userRowId = businessParam.getUserSession().getUserInfo().getUserId();
                long conversationRoomId = conversation.getConversationRoom().getRowId();

                businessParam.getDB();

                // Set Last data in a conversationRoom.
                ConversationRoom conversationRoom = ConversationRoomFacade.getInstance()
                        .findEntityById(ConversationRoom.class, conversationRoomId, businessParam);
                conversationRoom.setLastConversation(conversation.getText());
                if (conversationRoom.getCreatedBy().getRowId() == userRowId) {
                    conversationRoom.setLastStatus(ConversationRoomStatus.NEW_MESSAGE);
                } else {
                    conversationRoom.setLastStatus(ConversationRoomStatus.ANSWERED);
                }
                conversationRoom.setUpdated(new Date(System.currentTimeMillis()));
                User user = new User();
                user.setRowId(businessParam.getUserSession().getUserInfo().getUserId());
                conversationRoom.setUpdatedBy(user);
                ConversationRoomFacade.getInstance().saveEntity(conversationRoom, businessParam);

                // Get unseen conversation count for a user in a conversation room and increase.
                List<ConversationUser> conversationUsers = ConversationUserFacade.getInstance()
                        .findByConversationRoomId(conversationRoomId, businessParam);
                for (ConversationUser conversationUser : conversationUsers) {
                    conversationUser.setUnseen(conversationUser.getUnseen() + 1);
                    saveEntity(conversationUser, businessParam);

                    // Send Notification to all user in a conversationRoom
                    Notification notification = new Notification(conversationRoomId, conversationUser.getUnseen()
                            , NotificationType.NEW_MESSAGE
                            , businessParam.getUserSession().getUserInfo().getUsername() + ":" + conversation.getText());
                    notification.setTime(DateUtil.getDateString(new Date(System.currentTimeMillis()), "fa"));
					// NotificationHandler.updateRoom("USER-" +
					// conversationUser.getUser().getRowId(), notification);
					// NotificationHandler.updateRoom("APP-" +
					// conversationUser.getUser().getRowId(), notification);

                   
                }
                
                // Ticket
                if (conversationRoom.getCategory() != null && conversationRoom.getCategory().getRowId() == 100065 &&
                         businessParam.getUserSession().getUserInfo().getRoleId() != SystemConfig.SUPPORT_USER_ROLE_ID ) {
                                        
                	String email = SystemConfig.SUPPORT_EMAIL;
                    //Desc: دریافت فایل بیوست در صورت وجود
                    String filePath = null;
                    if (conversation.getAttache() != null) {
                        try {
                            File file = FileFacade.getInstance().findEntityById(File.class, conversation.getAttache().getRowId(), businessParam);
                            filePath = SystemConfig.UPLAUD_FOLDER + file.getPath();
                        } catch (Exception e) {
                            System.out.println("#Error: ConversationFacade.save -> get Attache");
                        }
                    }
                    WebUtil.sendEmail(email, "", conversation.getText(), filePath);
                }
                
                businessParam.releaseDB();
            } catch (Exception e) {
                businessParam.rolback();
                long errorId = System.nanoTime();
                BaseLogger.getLogger().info("#Error Id:" + errorId + "\n " + Arrays.toString(e.getStackTrace()));
                return new ServiceResult(ServiceResult.ERROR_CODE.BUSINESS_MESSAGE, "Error save entity. error code:" + errorId, "");
            }

        }
        return serviceResult;
    }

    public ServiceResult list(BusinessParam businessParam) {
        long userRowId = businessParam.getUserSession().getUserInfo().getUserId();

        long conversationRoomRowId = 0;
        for (PairValue pairValue : businessParam.getFilter().getParams()) {
            if (pairValue.getKey().contains("conversationRoom.rowId")) {
                conversationRoomRowId = Long.parseLong(pairValue.getValue());
            }
        }
        if (conversationRoomRowId == 0) {
            return new ServiceResult(ServiceResult.ERROR_CODE.INVALID_FILTER_PARAMETER,
                    "شناسه گفتگو مشخص نگردیده است", "");
        }

        ServiceResult serviceResult;
        try {
            serviceResult = super.list(businessParam);
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.BUSINESS_MESSAGE,
                    "اطلاعاتی برای نمایش یافت نشد", "");
        }

        if (serviceResult.isDone()) {
            //-------------------------------------------------
            try {
                businessParam.getDB();
                // find Conversation User for set Unseen.
                ConversationUser conversationUser = ConversationUserFacade.getInstance()
                        .findByConversationRoomIdAndUserId(conversationRoomRowId, userRowId, businessParam);

                // Set Unseen Conversation for a user in the one Conversation Room.
                if (conversationUser.getUnseen() > 0) {
                    conversationUser.setUnseen(0);
                    ConversationUserFacade.getInstance().update(conversationUser, businessParam);
                }
                businessParam.releaseDB();
            } catch (NoResultException e) {
                ConversationUserDTO conversationUser = new ConversationUserDTO();
                conversationUser.setUser(new UserDTO(userRowId));
                conversationUser.setConversationRoom(new ConversationRoomDTO(conversationRoomRowId));
                ConversationUserFacade.getInstance().save(conversationUser, businessParam);
            } catch (Exception e) {
                businessParam.rolback();
                e.printStackTrace();
            }

            //-------------------------------------------------
            try {
                businessParam.getDB();
                // find Conversation Room for set last status.
                ConversationRoom conversationRoom = ConversationRoomFacade.getInstance()
                        .findEntityById(ConversationRoom.class, conversationRoomRowId, businessParam);

                // Set last status for a Conversation Room.
                if (conversationRoom.getCreatedBy().getRowId() != userRowId
                        && conversationRoom.getLastStatus().equals(ConversationRoomStatus.NEW_MESSAGE)) {
                    conversationRoom.setLastStatus(ConversationRoomStatus.SEE);
                    ConversationRoomFacade.getInstance().saveEntity(conversationRoom, businessParam);
                }
                businessParam.releaseDB();
            } catch (Exception e) {
                businessParam.rolback();
                e.printStackTrace();
            }
        }

        return serviceResult;
    }
}