package org.mega.msg.sse;

public enum NotificationType {
    NEW_MESSAGE("New message"),
    ADD_USER_TO_CONVERSATION_ROOM("Add user to conversation room"),
    NEWS("News"),
    USER_STATUS("User Status");
    
    private String value;

    NotificationType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}