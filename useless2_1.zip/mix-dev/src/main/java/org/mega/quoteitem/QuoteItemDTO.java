package org.mega.quoteitem;

import org.mega.bse.freightchargetype.FreightChargeTypeDTO;
import org.mega.core.base.BaseDTO;
import org.mega.quote.QuoteDTO;

public class QuoteItemDTO extends BaseDTO {

	private long rowId;
	private QuoteDTO quoteDTO;
	private FreightChargeTypeDTO freightChargeTypeDTO;
	private int quantity;
	private double buyPrice;
	private double sellPrice;
	private String legFrom;
	private String legTo;
	private String fuel;
	private String peakSeason;
	private String tax1;
	private String tax2;

	public String getTax1() {
		return tax1;
	}

	public void setTax1(String tax1) {
		this.tax1 = tax1;
	}

	public String getTax2() {
		return tax2;
	}

	public void setTax2(String tax2) {
		this.tax2 = tax2;
	}

	public String getFuel() {
		return fuel;
	}

	public void setFuel(String fuel) {
		this.fuel = fuel;
	}

	public String getPeakSeason() {
		return peakSeason;
	}

	public void setPeakSeason(String peakSeason) {
		this.peakSeason = peakSeason;
	}

	public String getLegFrom() {
		return legFrom;
	}

	public void setLegFrom(String legFrom) {
		this.legFrom = legFrom;
	}

	public String getLegTo() {
		return legTo;
	}

	public void setLegTo(String legTo) {
		this.legTo = legTo;
	}

	public double getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public double getSellPrice() {
		return sellPrice;
	}

	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public QuoteDTO getQuoteDTO() {
		return quoteDTO;
	}

	public void setQuoteDTO(QuoteDTO quoteDTO) {
		this.quoteDTO = quoteDTO;
	}

	public FreightChargeTypeDTO getFreightChargeTypeDTO() {
		return freightChargeTypeDTO;
	}

	public void setFreightChargeTypeDTO(FreightChargeTypeDTO freightChargeTypeDTO) {
		this.freightChargeTypeDTO = freightChargeTypeDTO;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
