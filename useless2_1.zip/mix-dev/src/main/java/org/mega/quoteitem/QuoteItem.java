package org.mega.quoteitem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.freightchargetype.FreightChargeType;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.quote.Quote;

@Entity
@Table(name = "QOT_QOUT_ITEM", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_QOUT_ITEM", columnNames = "QOT_QOUT_ITEM_ID"))
public class QuoteItem extends BaseEntity {
	@Id
	@Column(name = "QOT_QOUT_ITEM_ID")
	private long rowId;

	@ManyToOne()
	@JoinColumn(name = "QUOTE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT"), nullable = true)
	private Quote quote;

	@ManyToOne()
	@JoinColumn(name = "BSE_FREIGHT_CHARGE_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_REFERENCE_BSE_FREI"), nullable = true)
	private FreightChargeType freightChargeType;

	@Column(name = "QUANTITY", length = 2)
	private int quantity;

	@Column(name = "BUY_PRICE")
	private double buyPrice;

	@Column(name = "SELL_PRICE")
	private double sellPrice;

	@Column(name = "LEG_FROM")
	private String legFrom;

	@Column(name = "LEG_TO")
	private String legTo;

	@Column(name = "FUEL", length = 10)
	private String fuel;

	@Column(name = "PEAK_SEASON", length = 10)
	private String peakSeason;

	@Column(name = "TAX1", length = 50)
	private String tax1;

	@Column(name = "TAX2", length = 50)
	private String tax2;

	public String getTax1() {
		return tax1;
	}

	public void setTax1(String tax1) {
		this.tax1 = tax1;
	}

	public String getTax2() {
		return tax2;
	}

	public void setTax2(String tax2) {
		this.tax2 = tax2;
	}

	public String getLegFrom() {
		return legFrom;
	}

	public void setLegFrom(String legFrom) {
		this.legFrom = legFrom;
	}

	public String getLegTo() {
		return legTo;
	}

	public void setLegTo(String legTo) {
		this.legTo = legTo;
	}

	public String getFuel() {
		return fuel;
	}

	public void setFuel(String fuel) {
		this.fuel = fuel;
	}

	public String getPeakSeason() {
		return peakSeason;
	}

	public void setPeakSeason(String peakSeason) {
		this.peakSeason = peakSeason;
	}

	public double getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public double getSellPrice() {
		return sellPrice;
	}

	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Quote getQuote() {
		return quote;
	}

	public void setQuote(Quote quote) {
		this.quote = quote;
	}

	public FreightChargeType getFreightChargeType() {
		return freightChargeType;
	}

	public void setFreightChargeType(FreightChargeType freightChargeType) {
		this.freightChargeType = freightChargeType;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = quote.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = quote.getFullTitle();
	}
}
