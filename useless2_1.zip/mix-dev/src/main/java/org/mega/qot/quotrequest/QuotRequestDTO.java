package org.mega.qot.quotrequest;

import java.util.List;

import javax.persistence.Column;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.contact.ContactDTO;
import org.mega.core.location.LocationDTO;
import org.mega.qot.rfqpackage.RfqPackageDTO;

public class QuotRequestDTO extends BaseDTO{

	private long rowId;
	private LocationDTO origionLocationDTO;
	private LocationDTO destinationLocationDTO;
	private LocationDTO origionPortLocationDTO;
	private LocationDTO destinationPortLocationDTO;
	private LocationDTO locationDTO;
	private LocationDTO location1;
	private LocationDTO location2;
	private ComboValDTO qoutReqStatusTypeDTO;
	private ComboValDTO freightMethodTypeDTO;
	private ComboValDTO incotermTypeDTO;
	private ComboValDTO rfqMeasurementUnitDTO;
	private ComboValDTO freightTypeDTO;
	private ComboValDTO shipmentTypeDTO;
	private ComboValDTO paymentTermsDTO;
	private String pickupDate;
	private String targetDeliveryDate;
	private String shipmentName;
	private String memo;
	private String descriptionOfProducts;
	private double totalWeight;
	private double totalVolume;
	private int totalPieces;
	private boolean packagingDetailsKnown;
	private boolean containtsLithiumIonBatteries;
	private boolean containsMagneticProperties;
	private boolean containsHazardousMaterial;
	private boolean cpscCertified;
	private boolean comanyAssistedProduct;
	private boolean containsEncryptionTechnologi;
	private boolean containsWood;
	private boolean companyFdaRegistered;
	private boolean fccRegistered;
	private List<RfqPackageDTO> qouteRequests;
	private ContactDTO customerName;
	private boolean refrigeration;
	private boolean freezing;
	
	public boolean isRefrigeration() {
		return refrigeration;
	}
	public void setRefrigeration(boolean refrigeration) {
		this.refrigeration = refrigeration;
	}
	public boolean isFreezing() {
		return freezing;
	}
	public void setFreezing(boolean freezing) {
		this.freezing = freezing;
	}
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ComboValDTO getQoutReqStatusTypeDTO() {
		return qoutReqStatusTypeDTO;
	}
	public void setQoutReqStatusTypeDTO(ComboValDTO qoutReqStatusTypeDTO) {
		this.qoutReqStatusTypeDTO = qoutReqStatusTypeDTO;
	}
	public LocationDTO getOrigionLocationDTO() {
		return origionLocationDTO;
	}
	public void setOrigionLocationDTO(LocationDTO origionLocationDTO) {
		this.origionLocationDTO = origionLocationDTO;
	}
	public LocationDTO getDestinationLocationDTO() {
		return destinationLocationDTO;
	}
	public void setDestinationLocationDTO(LocationDTO destinationLocationDTO) {
		this.destinationLocationDTO = destinationLocationDTO;
	}
	public LocationDTO getOrigionPortLocationDTO() {
		return origionPortLocationDTO;
	}
	public void setOrigionPortLocationDTO(LocationDTO origionPortLocationDTO) {
		this.origionPortLocationDTO = origionPortLocationDTO;
	}
	public LocationDTO getLocationDTO() {
		return locationDTO;
	}
	public void setLocationDTO(LocationDTO locationDTO) {
		this.locationDTO = locationDTO;
	}
	public ComboValDTO getFreightMethodTypeDTO() {
		return freightMethodTypeDTO;
	}
	public void setFreightMethodTypeDTO(ComboValDTO freightMethodTypeDTO) {
		this.freightMethodTypeDTO = freightMethodTypeDTO;
	}
	public ComboValDTO getIncotermTypeDTO() {
		return incotermTypeDTO;
	}
	public void setIncotermTypeDTO(ComboValDTO incotermTypeDTO) {
		this.incotermTypeDTO = incotermTypeDTO;
	}
	public ComboValDTO getRfqMeasurementUnitDTO() {
		return rfqMeasurementUnitDTO;
	}
	public void setRfqMeasurementUnitDTO(ComboValDTO rfqMeasurementUnitDTO) {
		this.rfqMeasurementUnitDTO = rfqMeasurementUnitDTO;
	}
	public String getPickupDate() {
		return pickupDate;
	}
	public void setPickupDate(String pickupDate) {
		this.pickupDate = pickupDate;
	}
	public String getTargetDeliveryDate() {
		return targetDeliveryDate;
	}
	public void setTargetDeliveryDate(String targetDeliveryDate) {
		this.targetDeliveryDate = targetDeliveryDate;
	}
	public String getShipmentName() {
		return shipmentName;
	}
	public void setShipmentName(String shipmentName) {
		this.shipmentName = shipmentName;
	}
	public boolean isPackagingDetailsKnown() {
		return packagingDetailsKnown;
	}
	public void setPackagingDetailsKnown(boolean packagingDetailsKnown) {
		this.packagingDetailsKnown = packagingDetailsKnown;
	}
	public double getTotalWeight() {
		return totalWeight;
	}
	public void setTotalWeight(double totalWeight) {
		this.totalWeight = totalWeight;
	}
	public double getTotalVolume() {
		return totalVolume;
	}
	public void setTotalVolume(double totalVolume) {
		this.totalVolume = totalVolume;
	}
	public int getTotalPieces() {
		return totalPieces;
	}
	public void setTotalPieces(int totalPieces) {
		this.totalPieces = totalPieces;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getDescriptionOfProducts() {
		return descriptionOfProducts;
	}
	public void setDescriptionOfProducts(String descriptionOfProducts) {
		this.descriptionOfProducts = descriptionOfProducts;
	}
	public boolean isContaintsLithiumIonBatteries() {
		return containtsLithiumIonBatteries;
	}
	public void setContaintsLithiumIonBatteries(boolean containtsLithiumIonBatteries) {
		this.containtsLithiumIonBatteries = containtsLithiumIonBatteries;
	}
	public boolean isContainsMagneticProperties() {
		return containsMagneticProperties;
	}
	public void setContainsMagneticProperties(boolean containsMagneticProperties) {
		this.containsMagneticProperties = containsMagneticProperties;
	}
	public boolean isContainsHazardousMaterial() {
		return containsHazardousMaterial;
	}
	public void setContainsHazardousMaterial(boolean containsHazardousMaterial) {
		this.containsHazardousMaterial = containsHazardousMaterial;
	}
	public boolean isCpscCertified() {
		return cpscCertified;
	}
	public void setCpscCertified(boolean cpscCertified) {
		this.cpscCertified = cpscCertified;
	}
	public boolean isComanyAssistedProduct() {
		return comanyAssistedProduct;
	}
	public void setComanyAssistedProduct(boolean comanyAssistedProduct) {
		this.comanyAssistedProduct = comanyAssistedProduct;
	}
	public boolean isContainsEncryptionTechnologi() {
		return containsEncryptionTechnologi;
	}
	public void setContainsEncryptionTechnologi(boolean containsEncryptionTechnologi) {
		this.containsEncryptionTechnologi = containsEncryptionTechnologi;
	}
	public boolean isContainsWood() {
		return containsWood;
	}
	public void setContainsWood(boolean containsWood) {
		this.containsWood = containsWood;
	}
	public boolean isCompanyFdaRegistered() {
		return companyFdaRegistered;
	}
	public void setCompanyFdaRegistered(boolean companyFdaRegistered) {
		this.companyFdaRegistered = companyFdaRegistered;
	}
	public boolean isFccRegistered() {
		return fccRegistered;
	}
	public void setFccRegistered(boolean fccRegistered) {
		this.fccRegistered = fccRegistered;
	}
	public LocationDTO getLocation1() {
		return location1;
	}
	public void setLocation1(LocationDTO location1) {
		this.location1 = location1;
	}
	public LocationDTO getLocation2() {
		return location2;
	}
	public void setLocation2(LocationDTO location2) {
		this.location2 = location2;
	}
	public ComboValDTO getFreightTypeDTO() {
		return freightTypeDTO;
	}
	public void setFreightTypeDTO(ComboValDTO freightTypeDTO) {
		this.freightTypeDTO = freightTypeDTO;
	}
	public ComboValDTO getShipmentTypeDTO() {
		return shipmentTypeDTO;
	}
	public void setShipmentTypeDTO(ComboValDTO shipmentTypeDTO) {
		this.shipmentTypeDTO = shipmentTypeDTO;
	}
	public LocationDTO getDestinationPortLocationDTO() {
		return destinationPortLocationDTO;
	}
	public void setDestinationPortLocationDTO(LocationDTO destinationPortLocationDTO) {
		this.destinationPortLocationDTO = destinationPortLocationDTO;
	}
	public ComboValDTO getPaymentTermsDTO() {
		return paymentTermsDTO;
	}
	public void setPaymentTermsDTO(ComboValDTO paymentTermsDTO) {
		this.paymentTermsDTO = paymentTermsDTO;
	}
	public List<RfqPackageDTO> getQouteRequests() {
		return qouteRequests;
	}
	public void setQouteRequests(List<RfqPackageDTO> qouteRequests) {
		this.qouteRequests = qouteRequests;
	}
	public ContactDTO getCustomerName() {
		return customerName;
	}
	public void setCustomerName(ContactDTO customerName) {
		this.customerName = customerName;
	}
	
}
