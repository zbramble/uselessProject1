package org.mega.qot.rfqlog;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotelogreply.QuoteLogReplyDTO;
import org.mega.qot.quotrequest.QuotRequestDTO;
import org.mega.qot.rfqlogreply.RfqLogReplyDTO;

public class RfqLogDTO extends BaseDTO{
	private long rowId;
	private QuotRequestDTO qouteRequestDTO;
	private UserDTO logUserDTO;
	private String logDate;
	private String logNotes;
	private List<RfqLogReplyDTO> rfqLogReply;
	
	public List<RfqLogReplyDTO> getRfqLogReply() {
		return rfqLogReply;
	}
	public void setRfqLogReply(List<RfqLogReplyDTO> rfqLogReply) {
		this.rfqLogReply = rfqLogReply;
	}
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public QuotRequestDTO getQouteRequestDTO() {
		return qouteRequestDTO;
	}
	public void setQouteRequestDTO(QuotRequestDTO qouteRequestDTO) {
		this.qouteRequestDTO = qouteRequestDTO;
	}
	public UserDTO getLogUserDTO() {
		return logUserDTO;
	}
	public void setLogUserDTO(UserDTO logUserDTO) {
		this.logUserDTO = logUserDTO;
	}
	public String getLogDate() {
		return logDate;
	}
	public void setLogDate(String logDate) {
		this.logDate = logDate;
	}
	public String getLogNotes() {
		return logNotes;
	}
	public void setLogNotes(String logNotes) {
		this.logNotes = logNotes;
	}
	
	

}
