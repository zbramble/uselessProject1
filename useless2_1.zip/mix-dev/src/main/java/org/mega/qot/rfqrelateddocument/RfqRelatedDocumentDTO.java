package org.mega.qot.rfqrelateddocument;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.qot.quotrequest.QuotRequestDTO;


public class RfqRelatedDocumentDTO extends BaseDTO{
	private long rowId;
	private QuotRequestDTO quotRequestDTO;
	private ComboValDTO relatedDocumentTypeDTO;
	private String relatedDocumentTitle;
	private FileDTO documentFileDTO;
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public QuotRequestDTO getQuotRequestDTO() {
		return quotRequestDTO;
	}
	public void setQuotRequestDTO(QuotRequestDTO quotRequestDTO) {
		this.quotRequestDTO = quotRequestDTO;
	}
	public ComboValDTO getRelatedDocumentTypeDTO() {
		return relatedDocumentTypeDTO;
	}
	public void setRelatedDocumentTypeDTO(ComboValDTO relatedDocumentTypeDTO) {
		this.relatedDocumentTypeDTO = relatedDocumentTypeDTO;
	}
	public String getRelatedDocumentTitle() {
		return relatedDocumentTitle;
	}
	public void setRelatedDocumentTitle(String relatedDocumentTitle) {
		this.relatedDocumentTitle = relatedDocumentTitle;
	}
	public FileDTO getDocumentFileDTO() {
		return documentFileDTO;
	}
	public void setDocumentFileDTO(FileDTO documentFileDTO) {
		this.documentFileDTO = documentFileDTO;
	}
	
}
