package org.mega.qot.quotrequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.core.sec.UserSessionManager;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/qoutRequest")
public class QuotRequestService {
	@POST
    @Path("/save")
    public ServiceResult save(QuotRequestDTO qoutRequestDTO) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(qoutRequestDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try {
			return QuotRequestFacade.getInstance().save(qoutRequestDTO, new BusinessParam(userSession));
		} catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
		}
    }
	@POST
    @Path("/list")
    public ServiceResult list(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return QuotRequestFacade.getInstance().list(new BusinessParam(userSession, filter));
    }
	@POST
    @Path("/delete")
    public ServiceResult delete(Filter filter) {
        UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(filter.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, e.getMessage(), e.getLocalizedMessage());
        }
        return QuotRequestFacade.getInstance().delete(new BusinessParam(userSession, filter));
    }
	
	@POST
    @Path("/manyToManySave")
    public ServiceResult manyToMantSave(ManyToManySaveDTO dto){
		UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(dto.getQoutRequestDTO().getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try {
			return QuotRequestFacade.getInstance().manyToMantSave(dto.getQoutRequestDTO(),dto.getRfqPackageDTOs(), new BusinessParam(userSession));
		} catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
		}
	}
	@POST
    @Path("/updateStatus")
    public ServiceResult updateStatus(QuotRequestDTO quotRequestDTO){
		UserSession userSession;
        try {
            userSession = UserSessionManager.getUserSession(quotRequestDTO.getTicket());
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.USER_EXPIRED, "", e.getLocalizedMessage());
        }
        try {
			return QuotRequestFacade.getInstance().updateStatus(quotRequestDTO, new BusinessParam(userSession));
		} catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "", e);
		}
		
	}
	
}
