package org.mega.qot.quotrequest;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.contact.Contact;
import org.mega.core.location.Location;
import org.mega.core.user.User;
import org.mega.qot.rfqpackage.RfqPackage;

@Entity
@Table(name = "QOT_QOUT_REQUEST", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_QOUT_REQUEST", columnNames = "QOUTE_REQUEST_ID"))
public class QuotRequest extends BaseEntity {

	@Id
	@Column(name = "QOUTE_REQUEST_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CUSTOMER_NAME_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_CUSTOMER_NAME"), nullable = true)
	private Contact customerName;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ORIGION_LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_ORIGION_LOCAT"), nullable = true)
	private Location origionLocation;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "DESTINATION_LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_DESTINATION_LOCAT"), nullable = true)
	private Location destinationLocation;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ORIGION_PORT_LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_ORIGION_PORT_LOCAT"), nullable = true)
	private Location origionPortLocation;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "DESTINATION_PORT_LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_DESTINATION_PORT"), nullable = true)
	private Location destinationPortLocation;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CO__LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_LOCATION1"), nullable = true)
	private Location location;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "LOCATION_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_LOCATION"), nullable = true)
	private Location location1;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CO__LOCATION_ID2", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_LOCATION2"), nullable = true)
	private Location location2;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "QOUT_REQUEST_STATUS_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_REQUEST_STATUS"), nullable = true)
	private ComboVal qoutReqStatusType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "FREIGHT_METHOD_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_FREIGHT_METHOD"), nullable = true)
	private ComboVal freightMethodType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "INCOTERM_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_INCOTERM_TYPE"), nullable = true)
	private ComboVal incotermType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "RFQ_MEASUREMENT_UNITS_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_MEASUREMENT_UNIT"), nullable = true)
	private ComboVal rfqMeasurementUnit;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "FREIGHT_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_FREIGHT_TYPE_COMBO"), nullable = true)
	private ComboVal freightType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SHIPMENT_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_SHIPMENT_TYPE"), nullable = true)
	private ComboVal shipmentType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PAYMENT_TERMS_ID", foreignKey = @ForeignKey(name = "FK_QOT_QOUT_PAYMENT_TERMS_COMB"), nullable = true)
	private ComboVal paymentTerms;

	@Temporal(TemporalType.DATE)
	@Column(name = "PICKUP_DATE")
	private Date pickupDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "TARGET_DELIVERY_DATE")
	private Date targetDeliveryDate;

	@Column(name = "TOTAL_WEIGHT")
	private double totalWeight;

	@Column(name = "TOTAL_VOLUME")
	private double totalVolume;

	@Column(name = "TOTAL_PIECES")
	private int totalPieces;

	@Column(name = "MEMO", length = 3000)
	private String memo;

	@Column(name = "DESCRIPTION_OF_PRODUCTS", length = 4000)
	private String descriptionOfProducts;

	@Column(name = "SHIPMENT_NAME", length = 500, nullable = false)
	private String shipmentName;

	@Column(name = "IS_PACKAGING_DETAILS_KNOWN")
	private boolean packagingDetailsKnown;

	@Column(name = "CONTAINS_LITHIUM_ION_BATTERIES")
	private boolean containtsLithiumIonBatteries;

	@Column(name = "CONTAINS_MAGNETIC_PROPERTIES")
	private boolean containsMagneticProperties;

	@Column(name = "CONTAINS_HAZARDOUS_MATERIAL")
	private boolean containsHazardousMaterial;

	@Column(name = "IS_CPSC_CERTIFIED")
	private boolean cpscCertified;

	@Column(name = "HAS_YOU_COMANY_ASSISTED_PRODUC")
	private boolean comanyAssistedProduct;

	@Column(name = "CONTAINS_ENCRYPTION_TECHNOLOGI")
	private boolean containsEncryptionTechnologi;

	@Column(name = "CONTAINS_WOOD")
	private boolean containsWood;

	@Column(name = "IS_YOUR_COMAPNY_FDA_REGISTERED")
	private boolean companyFdaRegistered;

	@Column(name = "FCC_REGISTERED")
	private boolean fccRegistered;
	
	@Column(name = "REFRIGERATION")
	private boolean refrigeration;
	
	@Column(name = "FREEZING")
	private boolean freezing;
	
		
	public boolean isRefrigeration() {
		return refrigeration;
	}

	public void setRefrigeration(boolean refrigeration) {
		this.refrigeration = refrigeration;
	}

	public boolean isFreezing() {
		return freezing;
	}

	public void setFreezing(boolean freezing) {
		this.freezing = freezing;
	}

	@OneToMany(mappedBy = "qouteRequest")
    private List<RfqPackage> qouteRequests;

	public Location getLocation1() {
		return location1;
	}

	public void setLocation1(Location location1) {
		this.location1 = location1;
	}

	public Location getLocation2() {
		return location2;
	}

	public void setLocation2(Location location2) {
		this.location2 = location2;
	}

	public ComboVal getFreightType() {
		return freightType;
	}

	public void setFreightType(ComboVal freightType) {
		this.freightType = freightType;
	}

	public ComboVal getShipmentType() {
		return shipmentType;
	}

	public void setShipmentType(ComboVal shipmentType) {
		this.shipmentType = shipmentType;
	}

	public ComboVal getQoutReqStatusType() {
		return qoutReqStatusType;
	}

	public void setQoutReqStatusType(ComboVal qoutReqStatusType) {
		this.qoutReqStatusType = qoutReqStatusType;
	}

	public Location getOrigionLocation() {
		return origionLocation;
	}

	public void setOrigionLocation(Location origionLocation) {
		this.origionLocation = origionLocation;
	}

	public Location getDestinationLocation() {
		return destinationLocation;
	}

	public void setDestinationLocation(Location destinationLocation) {
		this.destinationLocation = destinationLocation;
	}

	public Location getOrigionPortLocation() {
		return origionPortLocation;
	}

	public void setOrigionPortLocation(Location origionPortLocation) {
		this.origionPortLocation = origionPortLocation;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public ComboVal getFreightMethodType() {
		return freightMethodType;
	}

	public void setFreightMethodType(ComboVal freightMethodType) {
		this.freightMethodType = freightMethodType;
	}

	public ComboVal getIncotermType() {
		return incotermType;
	}

	public void setIncotermType(ComboVal incotermType) {
		this.incotermType = incotermType;
	}

	public ComboVal getRfqMeasurementUnit() {
		return rfqMeasurementUnit;
	}

	public void setRfqMeasurementUnit(ComboVal rfqMeasurementUnit) {
		this.rfqMeasurementUnit = rfqMeasurementUnit;
	}

	public Date getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}

	public Date getTargetDeliveryDate() {
		return targetDeliveryDate;
	}

	public void setTargetDeliveryDate(Date targetDeliveryDate) {
		this.targetDeliveryDate = targetDeliveryDate;
	}

	public String getShipmentName() {
		return shipmentName;
	}

	public void setShipmentName(String shipmentName) {
		this.shipmentName = shipmentName;
	}

	public boolean isPackagingDetailsKnown() {
		return packagingDetailsKnown;
	}

	public void setPackagingDetailsKnown(boolean packagingDetailsKnown) {
		this.packagingDetailsKnown = packagingDetailsKnown;
	}

	public double getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(double totalWeight) {
		this.totalWeight = totalWeight;
	}

	public double getTotalVolume() {
		return totalVolume;
	}

	public void setTotalVolume(double totalVolume) {
		this.totalVolume = totalVolume;
	}

	public int getTotalPieces() {
		return totalPieces;
	}

	public void setTotalPieces(int totalPieces) {
		this.totalPieces = totalPieces;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getDescriptionOfProducts() {
		return descriptionOfProducts;
	}

	public void setDescriptionOfProducts(String descriptionOfProducts) {
		this.descriptionOfProducts = descriptionOfProducts;
	}

	public boolean isContaintsLithiumIonBatteries() {
		return containtsLithiumIonBatteries;
	}

	public void setContaintsLithiumIonBatteries(boolean containtsLithiumIonBatteries) {
		this.containtsLithiumIonBatteries = containtsLithiumIonBatteries;
	}

	public boolean isContainsMagneticProperties() {
		return containsMagneticProperties;
	}

	public void setContainsMagneticProperties(boolean containsMagneticProperties) {
		this.containsMagneticProperties = containsMagneticProperties;
	}

	public boolean isContainsHazardousMaterial() {
		return containsHazardousMaterial;
	}

	public void setContainsHazardousMaterial(boolean containsHazardousMaterial) {
		this.containsHazardousMaterial = containsHazardousMaterial;
	}

	public boolean isCpscCertified() {
		return cpscCertified;
	}

	public void setCpscCertified(boolean cpscCertified) {
		this.cpscCertified = cpscCertified;
	}

	public boolean isComanyAssistedProduct() {
		return comanyAssistedProduct;
	}

	public void setComanyAssistedProduct(boolean comanyAssistedProduct) {
		this.comanyAssistedProduct = comanyAssistedProduct;
	}

	public boolean isContainsEncryptionTechnologi() {
		return containsEncryptionTechnologi;
	}

	public void setContainsEncryptionTechnologi(boolean containsEncryptionTechnologi) {
		this.containsEncryptionTechnologi = containsEncryptionTechnologi;
	}

	public boolean isContainsWood() {
		return containsWood;
	}

	public void setContainsWood(boolean containsWood) {
		this.containsWood = containsWood;
	}

	public boolean isCompanyFdaRegistered() {
		return companyFdaRegistered;
	}

	public void setCompanyFdaRegistered(boolean companyFdaRegistered) {
		this.companyFdaRegistered = companyFdaRegistered;
	}

	public boolean isFccRegistered() {
		return fccRegistered;
	}

	public void setFccRegistered(boolean fccRegistered) {
		this.fccRegistered = fccRegistered;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Location getDestinationPortLocation() {
		return destinationPortLocation;
	}

	public void setDestinationPortLocation(Location destinationPortLocation) {
		this.destinationPortLocation = destinationPortLocation;
	}

	public ComboVal getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(ComboVal paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	
	public List<RfqPackage> getQouteRequests() {
		return qouteRequests;
	}

	public void setQouteRequests(List<RfqPackage> qouteRequests) {
		this.qouteRequests = qouteRequests;
	}
	
	public Contact getCustomerName() {
		return customerName;
	}

	public void setCustomerName(Contact customerName) {
		this.customerName = customerName;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = shipmentName;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = shipmentName;
	}

}
