package org.mega.qot.rfqpackage;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.cartontype.CartonType;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.qot.quotrequest.QuotRequest;

@Entity
@Table(name = "QOT_RFQ_PACKAGE", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_RFQ_PACKAGE", columnNames = "QOT_RFQ_PACKAGE"))
public class RfqPackage extends BaseEntity{

	@Id
	@Column(name = "QOT_RFQ_PACKAGE")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "QOUTE_REQUEST_ID", foreignKey = @ForeignKey(name = "FK_QOT_RFQ__REFERENCE_QOT_QOUT"), nullable = true)
	private QuotRequest qouteRequest;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BSE_CARTON_TYPE_ID", foreignKey = @ForeignKey(name = "FK_QOT_RFQ__REFERENCE_BSE_CART"), nullable = true)
	private CartonType cartonType;
	
	@Column(name="PACKAGE_NAME",length=300)
	private String packageName;
	
	@Column(name="IS_PALLETIZED")
	private boolean palletized;

	@Column(name="CARTON_COUNT")
	private int carrtonCount;		

		
	@Column(name="CARTON_LENGTH")
	private double cartonLength;
	
	@Column(name="CARTON_WIDTH")
	private double cartonWidth;
	
	@Column(name="CARTON_HEIGHT")
	private double cartonHeight;
	
	@Column(name="CARTON_WEIGHT")
	private double cartonWeight;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public QuotRequest getQouteRequest() {
		return qouteRequest;
	}

	public void setQouteRequest(QuotRequest qouteRequest) {
		this.qouteRequest = qouteRequest;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public boolean isPalletized() {
		return palletized;
	}

	public void setPalletized(boolean palletized) {
		this.palletized = palletized;
	}

	public int getCarrtonCount() {
		return carrtonCount;
	}

	public void setCarrtonCount(int carrtonCount) {
		this.carrtonCount = carrtonCount;
	}

	public double getCartonLength() {
		return cartonLength;
	}

	public void setCartonLength(double cartonLength) {
		this.cartonLength = cartonLength;
	}

	public double getCartonWidth() {
		return cartonWidth;
	}

	public void setCartonWidth(double cartonWidth) {
		this.cartonWidth = cartonWidth;
	}

	public double getCartonHeight() {
		return cartonHeight;
	}

	public void setCartonHeight(double cartonHeight) {
		this.cartonHeight = cartonHeight;
	}

	public double getCartonWeight() {
		return cartonWeight;
	}

	public void setCartonWeight(double cartonWeight) {
		this.cartonWeight = cartonWeight;
	}
	
	public CartonType getCartonType() {
		return cartonType;
	}

	public void setCartonType(CartonType cartonType) {
		this.cartonType = cartonType;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = packageName;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = packageName;
	}
		

}
