package org.mega.qot.quotelogreply;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.qot.quotelog.QuoteLog;

@Entity
@Table(name = "QOT_QUOTE_LOG_REPLY", uniqueConstraints = @UniqueConstraint(name = "PK_QUOTE_LOG_REPLY", columnNames = "REPLY_ID"))
public class QuoteLogReply extends BaseEntity{

	@Id
	@Column(name = "REPLY_ID")
	private long rowId;
	
	@Column(name="REPLY_NOTES",length=2000)
	private String replyNotes;
	
	@ManyToOne()
	@JoinColumn(name = "QOT_QUOTE_LOG_ID", foreignKey = @ForeignKey(name = "FK_QOT_QUOTE_LOG"), nullable = true)
	private QuoteLog quoteLog;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getReplyNotes() {
		return replyNotes;
	}

	public void setReplyNotes(String replyNotes) {
		this.replyNotes = replyNotes;
	}

	public QuoteLog getQuoteLog() {
		return quoteLog;
	}

	public void setQuoteLog(QuoteLog quoteLog) {
		this.quoteLog = quoteLog;
	}
	
	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = quoteLog.getQuote().getCarrierName();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = quoteLog.getQuote().getCarrierName();
	}		

}
