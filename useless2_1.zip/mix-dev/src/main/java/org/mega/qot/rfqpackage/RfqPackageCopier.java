package org.mega.qot.rfqpackage;

import org.mega.bse.cartontype.CartonType;
import org.mega.bse.cartontype.CartonTypeDTO;
import org.mega.core.base.BaseCopier;
import org.mega.qot.quotrequest.QuotRequest;
import org.mega.qot.quotrequest.QuotRequestDTO;

public class RfqPackageCopier extends BaseCopier<RfqPackage, RfqPackageDTO>{

	@Override
	public RfqPackageDTO copyFromEntity(RfqPackage rfqPackage) {
		RfqPackageDTO rfqPackageDTO = new RfqPackageDTO();
		rfqPackageDTO.setRowId(rfqPackage.getRowId());
		rfqPackageDTO.setCarrtonCount(rfqPackage.getCarrtonCount());
		rfqPackageDTO.setCartonHeight(rfqPackage.getCartonHeight());
		rfqPackageDTO.setCartonLength(rfqPackage.getCartonLength());
		rfqPackageDTO.setCartonWeight(rfqPackage.getCartonWeight());
		rfqPackageDTO.setCartonWidth(rfqPackage.getCartonWidth());
		rfqPackageDTO.setPackageName(rfqPackage.getPackageName());
		rfqPackageDTO.setPalletized(rfqPackage.isPalletized());
		if(rfqPackage.getCartonType() != null){
			CartonTypeDTO cartonTypeDTO = new CartonTypeDTO();
			cartonTypeDTO.setRowId(rfqPackage.getCartonType().getRowId());
			cartonTypeDTO.setCartonTypeTitle(rfqPackage.getCartonType().getCartonTypeTitle());
			rfqPackageDTO.setCartonTypeDTO(cartonTypeDTO);
		}
		if(rfqPackage.getQouteRequest() != null){
			QuotRequestDTO qoutRequestDTO = new QuotRequestDTO();
			qoutRequestDTO.setRowId(rfqPackage.getQouteRequest().getRowId());
			qoutRequestDTO.setShipmentName(rfqPackage.getQouteRequest().getShipmentName());
			rfqPackageDTO.setQouteRequestDTO(qoutRequestDTO);
		}
		copyFromEntityBaseField(rfqPackage, rfqPackageDTO);
		return rfqPackageDTO;
	}

	@Override
	public RfqPackage copyToEntity(RfqPackageDTO rfqPackageDTO) throws Exception {
		RfqPackage rfqPackage = new RfqPackage();
		rfqPackage.setRowId(rfqPackageDTO.getRowId());
		rfqPackage.setCarrtonCount(rfqPackageDTO.getCarrtonCount());
		rfqPackage.setCartonHeight(rfqPackageDTO.getCartonHeight());
		rfqPackage.setCartonLength(rfqPackageDTO.getCartonLength());
		rfqPackage.setCartonWeight(rfqPackageDTO.getCartonWeight());
		rfqPackage.setCartonWidth(rfqPackageDTO.getCartonWidth());
		rfqPackage.setPackageName(rfqPackageDTO.getPackageName());
		rfqPackage.setPalletized(rfqPackageDTO.isPalletized());
		if(rfqPackageDTO.getCartonTypeDTO() != null){
			CartonType cartonType = new CartonType();
			cartonType.setRowId(rfqPackageDTO.getCartonTypeDTO().getRowId());
			cartonType.setCartonTypeTitle(rfqPackageDTO.getCartonTypeDTO().getCartonTypeTitle());
			rfqPackage.setCartonType(cartonType);
		}
		if(rfqPackageDTO.getQouteRequestDTO() != null){
			QuotRequest qoutRequest = new QuotRequest();
			qoutRequest.setRowId(rfqPackageDTO.getQouteRequestDTO().getRowId());
			qoutRequest.setShipmentName(rfqPackageDTO.getQouteRequestDTO().getShipmentName());
			rfqPackage.setQouteRequest(qoutRequest);
		}
		copyToEntityBaseField(rfqPackage, rfqPackageDTO);
		return rfqPackage;
	}

}
