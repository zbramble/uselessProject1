package org.mega.qot.rfqlogreply;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.sec.UserSession;

public class RfqLogReplyFacade extends BaseFacade{
	private static RfqLogReplyCopier copier = new RfqLogReplyCopier();
	private static RfqLogReplyFacade facade = new RfqLogReplyFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static RfqLogReplyFacade getInstance() {
		return facade;
	}
	
	@Override
	public String getConstraint(BusinessParam businessParam) {
		// TODO Auto-generated method stub
		UserSession userSession = businessParam.getUserSession();
		if(userSession.getUserInfo().getRoleId() == 10004){//forwarder
			return null;
		}else
			return super.getConstraint(businessParam);
	}
}
