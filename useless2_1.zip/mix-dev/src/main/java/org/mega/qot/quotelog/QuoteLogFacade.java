package org.mega.qot.quotelog;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class QuoteLogFacade extends BaseFacade{
	private static QuoteLogCopier copier = new QuoteLogCopier();
	private static QuoteLogFacade facade = new QuoteLogFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static QuoteLogFacade getInstance() {
		return facade;
	}
}
