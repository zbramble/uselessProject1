package org.mega.qot.rfqlogrelateddoc;


import org.mega.core.base.BaseCopier;
import org.mega.qot.rfqlog.RfqLog;
import org.mega.qot.rfqlog.RfqLogDTO;


public class RfqLogRelatedDocCopier extends BaseCopier<RfqLogRelatedDoc, RfqLogRelatedDocDTO>{

	@Override
	public RfqLogRelatedDocDTO copyFromEntity(RfqLogRelatedDoc rfgLogRelatedDoc) {
		RfqLogRelatedDocDTO logRelatedDocDTO = new RfqLogRelatedDocDTO();
		logRelatedDocDTO.setRowId(rfgLogRelatedDoc.getRowId());
		logRelatedDocDTO.setRelatedDoc1(rfgLogRelatedDoc.getRelatedDoc1());
		logRelatedDocDTO.setRelatedDoc2(rfgLogRelatedDoc.getRelatedDoc2());
		logRelatedDocDTO.setRelatedDoc3(rfgLogRelatedDoc.getRelatedDoc3());
		logRelatedDocDTO.setRelatedDoc4(rfgLogRelatedDoc.getRelatedDoc4());
		logRelatedDocDTO.setRelatedDoc5(rfgLogRelatedDoc.getRelatedDoc5());
		
		if(rfgLogRelatedDoc.getRfqLog() != null){
			RfqLogDTO rfqLogDTO = new RfqLogDTO();
			rfqLogDTO.setRowId(rfgLogRelatedDoc.getRfqLog().getRowId());
			rfqLogDTO.setLogNotes(rfgLogRelatedDoc.getRfqLog().getLogNotes());
			logRelatedDocDTO.setRfqLogDTO(rfqLogDTO);
		}
		copyFromEntityBaseField(rfgLogRelatedDoc, logRelatedDocDTO);
		return logRelatedDocDTO;
	}

	@Override
	public RfqLogRelatedDoc copyToEntity(RfqLogRelatedDocDTO rfgLogRelatedDocDTO) throws Exception {
		
		RfqLogRelatedDoc logRelatedDoc = new RfqLogRelatedDoc();
		logRelatedDoc.setRowId(rfgLogRelatedDocDTO.getRowId());
		logRelatedDoc.setRelatedDoc1(rfgLogRelatedDocDTO.getRelatedDoc1());
		logRelatedDoc.setRelatedDoc2(rfgLogRelatedDocDTO.getRelatedDoc2());
		logRelatedDoc.setRelatedDoc3(rfgLogRelatedDocDTO.getRelatedDoc3());
		logRelatedDoc.setRelatedDoc4(rfgLogRelatedDocDTO.getRelatedDoc4());
		logRelatedDoc.setRelatedDoc5(rfgLogRelatedDocDTO.getRelatedDoc5());
		
		if(rfgLogRelatedDocDTO.getRfqLogDTO() != null){
			RfqLog rfqLog = new RfqLog();
			rfqLog.setRowId(rfgLogRelatedDocDTO.getRfqLogDTO().getRowId());
			
			logRelatedDoc.setRfqLog(rfqLog);
		}
		copyToEntityBaseField(logRelatedDoc, rfgLogRelatedDocDTO);
		return logRelatedDoc;
	}

}
