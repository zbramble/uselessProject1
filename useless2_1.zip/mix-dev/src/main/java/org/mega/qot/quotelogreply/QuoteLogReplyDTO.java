package org.mega.qot.quotelogreply;

import org.mega.core.base.BaseDTO;
import org.mega.qot.quotelog.QuoteLogDTO;

public class QuoteLogReplyDTO extends BaseDTO{

	private long rowId;
	private String replyNotes;
	private QuoteLogDTO quoteLogDTO;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getReplyNotes() {
		return replyNotes;
	}
	public void setReplyNotes(String replyNotes) {
		this.replyNotes = replyNotes;
	}
	public QuoteLogDTO getQuoteLogDTO() {
		return quoteLogDTO;
	}
	public void setQuoteLogDTO(QuoteLogDTO quoteLogDTO) {
		this.quoteLogDTO = quoteLogDTO;
	}
	
}
