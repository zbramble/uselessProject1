package org.mega.qot.rfqrelateddocument;


import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.qot.quotrequest.QuotRequest;
import org.mega.qot.quotrequest.QuotRequestDTO;



public class RfqRelatedDocumentCopier extends BaseCopier<RfqRelatedDocument, RfqRelatedDocumentDTO>{

	@Override
	public RfqRelatedDocumentDTO copyFromEntity(RfqRelatedDocument rfgRelatedDoc) {
		RfqRelatedDocumentDTO RelatedDocDTO = new RfqRelatedDocumentDTO();
		RelatedDocDTO.setRowId(rfgRelatedDoc.getRowId());
		RelatedDocDTO.setRelatedDocumentTitle(rfgRelatedDoc.getRelatedDocumentTitle());
		if(rfgRelatedDoc.getQuotRequest() != null){
			QuotRequestDTO quotRequestDTO = new QuotRequestDTO();
			quotRequestDTO.setRowId(rfgRelatedDoc.getQuotRequest().getRowId());
			quotRequestDTO.setShipmentName(rfgRelatedDoc.getQuotRequest().getShipmentName());
			RelatedDocDTO.setQuotRequestDTO(quotRequestDTO);
		}
		if(rfgRelatedDoc.getRelatedDocumentType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(rfgRelatedDoc.getRelatedDocumentType().getRowId());
			comboValDTO.setName(rfgRelatedDoc.getRelatedDocumentType().getName());
			RelatedDocDTO.setRelatedDocumentTypeDTO(comboValDTO);
		}
		 if (rfgRelatedDoc.getDocumentFile() != null) {
	            FileDTO fDTO = new FileDTO();
	            fDTO.setRowId(rfgRelatedDoc.getDocumentFile().getRowId());
	            fDTO.setPath(rfgRelatedDoc.getDocumentFile().getPath());
	            fDTO.setImageContent(rfgRelatedDoc.getDocumentFile().getImageContent());
	            RelatedDocDTO.setDocumentFileDTO(fDTO);
	        }
		
		copyFromEntityBaseField(rfgRelatedDoc, RelatedDocDTO);
		return RelatedDocDTO;
	}

	@Override
	public RfqRelatedDocument copyToEntity(RfqRelatedDocumentDTO rfgRelatedDocDTO) throws Exception {
		
		RfqRelatedDocument relatedDoc = new RfqRelatedDocument();
		relatedDoc.setRowId(rfgRelatedDocDTO.getRowId());
		relatedDoc.setRelatedDocumentTitle(rfgRelatedDocDTO.getRelatedDocumentTitle());
		if(rfgRelatedDocDTO.getQuotRequestDTO() != null){
			QuotRequest quotRequest = new QuotRequest();
			quotRequest.setRowId(rfgRelatedDocDTO.getQuotRequestDTO().getRowId());
			quotRequest.setShipmentName(rfgRelatedDocDTO.getQuotRequestDTO().getShipmentName());
			relatedDoc.setQuotRequest(quotRequest);
		}
		if(rfgRelatedDocDTO.getRelatedDocumentTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(rfgRelatedDocDTO.getRelatedDocumentTypeDTO().getRowId());
			comboVal.setName(rfgRelatedDocDTO.getRelatedDocumentTypeDTO().getName());
			relatedDoc.setRelatedDocumentType(comboVal);
		}
		 if (rfgRelatedDocDTO.getDocumentFileDTO() != null) {
	            File f = new File();
	            f.setRowId(rfgRelatedDocDTO.getDocumentFileDTO().getRowId());
	            relatedDoc.setDocumentFile(f);
	        }
		copyToEntityBaseField(relatedDoc, rfgRelatedDocDTO);
		return relatedDoc;
	}

}
