package org.mega.qot.rfqlogreply;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.qot.rfqlog.RfqLog;

@Entity
@Table(name = "QOT_RFQ_LOG_REPLY", uniqueConstraints = @UniqueConstraint(name = "PK_RFQ_LOG_REPLY", columnNames = "REPLY_ID"))
public class RfqLogReply extends BaseEntity{

	@Id
	@Column(name = "REPLY_ID")
	private long rowId;
	
	@Column(name="REPLY_NOTES",length=2000)
	private String replyNotes;
	
	@ManyToOne()
	@JoinColumn(name = "QOT_RFQ_LOG_ID", foreignKey = @ForeignKey(name = "FK_QOT_RFQ_LOG"), nullable = true)
	private RfqLog rfqLog;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getReplyNotes() {
		return replyNotes;
	}

	public void setReplyNotes(String replyNotes) {
		this.replyNotes = replyNotes;
	}

	public RfqLog getRfqLog() {
		return rfqLog;
	}
	
	public void setRfqLog(RfqLog rfqLog) {
		this.rfqLog = rfqLog;
	}
	
	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = rfqLog.getQouteRequest().getShipmentName();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = rfqLog.getQouteRequest().getShipmentName();
	}		

}
