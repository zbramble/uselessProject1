package org.mega.qot.rfqlog;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.core.location.LocationDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotrequest.QuotRequest;
import org.mega.qot.quotrequest.QuotRequestDTO;
import org.mega.qot.rfqlogreply.RfqLogReplyFacade;
import org.mega.util.DateUtil;

public class RfqLogCopier extends BaseCopier<RfqLog, RfqLogDTO>{

	@Override
	public RfqLogDTO copyFromEntity(RfqLog log) {
		RfqLogDTO logDTO = new RfqLogDTO();
		logDTO.setRowId(log.getRowId());
		logDTO.setLogNotes(log.getLogNotes());
		logDTO.setLogDate(DateUtil.getDateString(log.getLogDate(), "en"));
		if(log.getLogUser() != null){
			UserDTO userDTO = new UserDTO();
			userDTO.setRowId(log.getLogUser().getRowId());
			userDTO.setFullName(log.getLogUser().getFullName());
			logDTO.setLogUserDTO(userDTO);
		}
		if(log.getQouteRequest() != null){
			QuotRequestDTO qoutRequestDTO = new QuotRequestDTO();
			qoutRequestDTO.setRowId(log.getQouteRequest().getRowId());
			qoutRequestDTO.setShipmentName(log.getQouteRequest().getShipmentName());
			if(log.getQouteRequest().getFreightMethodType() != null){
				ComboValDTO comboValDTO = new ComboValDTO();
				comboValDTO.setRowId(log.getQouteRequest().getFreightMethodType().getRowId());
				comboValDTO.setName(log.getQouteRequest().getFreightMethodType().getName());
				qoutRequestDTO.setFreightMethodTypeDTO(comboValDTO);
			}
			if(log.getQouteRequest().getFreightType() != null){
				ComboValDTO comboValDTO = new ComboValDTO();
				comboValDTO.setRowId(log.getQouteRequest().getFreightType().getRowId());
				comboValDTO.setName(log.getQouteRequest().getFreightType().getName());
				qoutRequestDTO.setFreightTypeDTO(comboValDTO);
			}
			if(log.getQouteRequest().getOrigionLocation() != null){
				LocationDTO locationDTO = new LocationDTO();
				locationDTO.setRowId(log.getQouteRequest().getOrigionLocation().getRowId());
				locationDTO.setName(log.getQouteRequest().getOrigionLocation().getName());
				qoutRequestDTO.setOrigionLocationDTO(locationDTO);
			}
			if(log.getQouteRequest().getDestinationLocation() != null){
				LocationDTO locationDTO = new LocationDTO();
				locationDTO.setRowId(log.getQouteRequest().getDestinationLocation().getRowId());
				locationDTO.setName(log.getQouteRequest().getDestinationLocation().getName());
				qoutRequestDTO.setDestinationLocationDTO(locationDTO);
			}
			if(log.getQouteRequest().getCreatedBy() != null){
				UserDTO u = new UserDTO();
				u.setRowId(log.getQouteRequest().getCreatedBy().getRowId());
				u.setCompanyName(log.getQouteRequest().getCreatedBy().getCompanyName());
				u.setFullName(log.getQouteRequest().getCreatedBy().getFullName());
				u.setEmail(log.getQouteRequest().getCreatedBy().getEmail());
				if(log.getQouteRequest().getCreatedBy().getFile() != null){
					FileDTO f = new FileDTO();
					f.setRowId(log.getQouteRequest().getCreatedBy().getFile().getRowId());
					f.setPath(log.getQouteRequest().getCreatedBy().getFile().getPath());
					f.setImageContent(log.getQouteRequest().getCreatedBy().getFile().getImageContent());
					u.setFile(f);
				}
				qoutRequestDTO.setCreatedBy(u);
			}
			qoutRequestDTO.setPickupDate(DateUtil.getDateString(log.getQouteRequest().getPickupDate(),"en"));
			qoutRequestDTO.setTargetDeliveryDate(DateUtil.getDateString(log.getQouteRequest().getTargetDeliveryDate(),"en"));
			logDTO.setQouteRequestDTO(qoutRequestDTO);
		}
		if(log.getRfqLogReply() != null)
			logDTO.setRfqLogReply(RfqLogReplyFacade.getInstance().getCopier().copyFromEntity(log.getRfqLogReply()));
		
		copyFromEntityBaseField(log, logDTO);
		UserDTO u = new UserDTO();
		u.setRowId(log.getCreatedBy().getRowId());
		u.setCompanyName(log.getCreatedBy().getCompanyName());
		u.setFullName(log.getCreatedBy().getFullName());
		u.setEmail(log.getCreatedBy().getEmail());
		if(log.getCreatedBy().getFile() != null){
			FileDTO f = new FileDTO();
			f.setRowId(log.getCreatedBy().getFile().getRowId());
			f.setPath(log.getCreatedBy().getFile().getPath());
			f.setImageContent(log.getCreatedBy().getFile().getImageContent());
			u.setFile(f);
		}
		logDTO.setCreatedBy(u);
		return logDTO;
	}

	@Override
	public RfqLog copyToEntity(RfqLogDTO logDTO) throws Exception {
		RfqLog log = new RfqLog();
		log.setRowId(logDTO.getRowId());
		log.setLogDate(DateUtil.getDate(logDTO.getLogDate(), "en"));
		log.setLogNotes(logDTO.getLogNotes());
		if(logDTO.getLogUserDTO() != null){
			User user = new User();
			user.setRowId(logDTO.getLogUserDTO().getRowId());
			log.setLogUser(user);
		}
		if(logDTO.getQouteRequestDTO() != null){
			QuotRequest qoutRequest = new QuotRequest();
			qoutRequest.setRowId(logDTO.getQouteRequestDTO().getRowId());
			log.setQouteRequest(qoutRequest);
		}
		copyToEntityBaseField(log, logDTO);
		return log;
	}

}
