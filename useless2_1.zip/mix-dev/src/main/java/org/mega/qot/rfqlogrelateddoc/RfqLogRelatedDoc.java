package org.mega.qot.rfqlogrelateddoc;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.qot.rfqlog.RfqLog;

@Entity
@Table(name = "QOT_RFQ_LOG_RELATED_DOC", uniqueConstraints = @UniqueConstraint(name = "PK_QOT_RFQ_LOG_RELATED_DOC", columnNames = "QOT_RFQ_LOG_RELATED_DOC_ID"))
public class RfqLogRelatedDoc extends BaseEntity{
	@Id
	@Column(name = "QOT_RFQ_LOG_RELATED_DOC_ID")
	private long rowId;
	
	@ManyToOne()
	@JoinColumn(name = "QOT_RFQ_LOG_ID", foreignKey = @ForeignKey(name = "FK_QOT_RFQ__REFERENCE_QOT_RFQ_"), nullable = true)
	private RfqLog rfqLog;
	
	@Column(name = "RELATED_DOC1")
	private int relatedDoc1;
	
	@Column(name = "RELATED_DOC2")
	private int relatedDoc2;
	
	@Column(name = "RELATED_DOC3")
	private int relatedDoc3;
	
	@Column(name = "RELATED_DOC4")
	private int relatedDoc4;
	
	@Column(name = "RELATED_DOC5")
	private int relatedDoc5;
	
	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public RfqLog getRfqLog() {
		return rfqLog;
	}

	public void setRfqLog(RfqLog rfqLog) {
		this.rfqLog = rfqLog;
	}

	public int getRelatedDoc1() {
		return relatedDoc1;
	}

	public void setRelatedDoc1(int relatedDoc1) {
		this.relatedDoc1 = relatedDoc1;
	}

	public int getRelatedDoc2() {
		return relatedDoc2;
	}

	public void setRelatedDoc2(int relatedDoc2) {
		this.relatedDoc2 = relatedDoc2;
	}

	public int getRelatedDoc3() {
		return relatedDoc3;
	}

	public void setRelatedDoc3(int relatedDoc3) {
		this.relatedDoc3 = relatedDoc3;
	}

	public int getRelatedDoc4() {
		return relatedDoc4;
	}

	public void setRelatedDoc4(int relatedDoc4) {
		this.relatedDoc4 = relatedDoc4;
	}

	public int getRelatedDoc5() {
		return relatedDoc5;
	}

	public void setRelatedDoc5(int relatedDoc5) {
		this.relatedDoc5 = relatedDoc5;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		if(rfqLog != null)
		    fullTitle = rfqLog.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		if(rfqLog != null)
		    fullTitle = rfqLog.getFullTitle();
	}


}
