package org.mega.qot.rfqlogreply;

import org.mega.core.base.BaseCopier;
import org.mega.core.file.FileDTO;
import org.mega.core.user.UserDTO;
import org.mega.qot.quotelog.QuoteLog;
import org.mega.qot.quotelog.QuoteLogDTO;
import org.mega.qot.rfqlog.RfqLog;
import org.mega.qot.rfqlog.RfqLogDTO;

public class RfqLogReplyCopier extends BaseCopier<RfqLogReply, RfqLogReplyDTO>{

	@Override
	public RfqLogReplyDTO copyFromEntity(RfqLogReply logReply) {
		RfqLogReplyDTO logReplyDTO = new RfqLogReplyDTO();
		logReplyDTO.setRowId(logReply.getRowId());
		logReplyDTO.setReplyNotes(logReply.getReplyNotes());
		if(logReply.getRfqLog() != null){
			RfqLogDTO rfqLogDTO = new RfqLogDTO();
			rfqLogDTO.setRowId(logReply.getRfqLog().getRowId());
			logReplyDTO.setRfqLogDTO(rfqLogDTO);	
		}
		copyFromEntityBaseField(logReply, logReplyDTO);
		UserDTO u = new UserDTO();
		u.setRowId(logReply.getCreatedBy().getRowId());
		u.setCompanyName(logReply.getCreatedBy().getCompanyName());
		u.setFullName(logReply.getCreatedBy().getFullName());
		u.setEmail(logReply.getCreatedBy().getEmail());
		if(logReply.getCreatedBy().getFile() != null){
			FileDTO f = new FileDTO();
			f.setRowId(logReply.getCreatedBy().getFile().getRowId());
			f.setPath(logReply.getCreatedBy().getFile().getPath());
			f.setImageContent(logReply.getCreatedBy().getFile().getImageContent());
			u.setFile(f);
		}
		logReplyDTO.setCreatedBy(u);
		return logReplyDTO;
	}

	@Override
	public RfqLogReply copyToEntity(RfqLogReplyDTO logReplyDTO) throws Exception {
		RfqLogReply logReply = new RfqLogReply();
		logReply.setRowId(logReplyDTO.getRowId());
		logReply.setReplyNotes(logReplyDTO.getReplyNotes());
		if(logReplyDTO.getRfqLogDTO() != null){
			RfqLog rfqLog = new RfqLog();
			rfqLog.setRowId(logReplyDTO.getRfqLogDTO().getRowId());
			logReply.setRfqLog(rfqLog);
		}
		copyToEntityBaseField(logReply, logReplyDTO);
		return logReply;
	}
}
