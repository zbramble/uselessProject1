package org.mega.core.action;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class ActionFacade extends BaseFacade {
    private static ActionCopier copier = new ActionCopier();
    private static ActionFacade facade = new ActionFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static ActionFacade getInstance() {
        return facade;
    }
}