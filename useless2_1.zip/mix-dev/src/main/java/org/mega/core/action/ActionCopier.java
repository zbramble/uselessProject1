package org.mega.core.action;

import org.mega.core.base.BaseCopier;
import org.mega.core.usecaseaction.UseCaseActionFacade;

public class ActionCopier extends BaseCopier<Action, ActionDTO> {
    @Override
    public ActionDTO copyFromEntity(Action action) {
        ActionDTO actionDTO = new ActionDTO();

        actionDTO.setRowId(action.getRowId());
        actionDTO.setActionName(action.getActionName());
        actionDTO.setCode(action.getCode());
        if (action.getUseCaseActions() != null) {
            actionDTO.setUseCaseActions(
                    UseCaseActionFacade.getInstance().getCopier().copyFromEntity(action.getUseCaseActions()));
        }
        copyFromEntityBaseField(action, actionDTO);

        return actionDTO;
    }

    @Override
    public Action copyToEntity(ActionDTO actionDTO) throws Exception {
        Action action = new Action();

        action.setRowId(actionDTO.getRowId());
        action.setActionName(actionDTO.getActionName());
        action.setCode(actionDTO.getCode());
        if (actionDTO.getUseCaseActions() != null) {
            action.setUseCaseActions(
                    UseCaseActionFacade.getInstance().getCopier().copyToEntity(actionDTO.getUseCaseActions()));
        }
        copyToEntityBaseField(action, actionDTO);

        return action;
    }
}