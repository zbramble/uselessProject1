package org.mega.core.userrole;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class UserRoleFacade extends BaseFacade {
    private static UserRoleCopier copier = new UserRoleCopier();
    private static UserRoleFacade facade = new UserRoleFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static UserRoleFacade getInstance() {
        return facade;
    }
}