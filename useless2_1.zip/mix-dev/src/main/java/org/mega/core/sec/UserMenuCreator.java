package org.mega.core.sec;

import java.util.HashMap;
import java.util.Map;

import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO;

public class UserMenuCreator implements UserMenuCreatorI{

	private static Map<Long,String> menuTreeCache = new HashMap<Long, String>();
	private static Map<Long,String> menuDataCache = new HashMap<Long, String>();

	UserInfo userInfo;
	Map<String, Integer> access;
	StringBuilder menuTree = new StringBuilder();
	StringBuilder menuData = new StringBuilder();

	@Override
	public UserMenuCreatorI init(UserInfo userInfo) {
		UserMenuCreator creator = new UserMenuCreator();
		creator.userInfo = userInfo;
		creator.access = userInfo.getAccess();
		creator.createMenu();
		return creator;
	}

	public void createMenu() {
		int showInMenuAct = ActionDTO.ACTION.showInMenu.ordinal();

		menuData.append("{");
		menuTree.append("[");

		addItem("Dashboard"				     , "#"		  	       , "Dashboard"				    ,null		      					,"ion-android-globe"	, -1, -1, false, showInMenuAct);
		addItem("MyWallet"				     , "#"		  	       , "My Wallet"				    ,null						      	,"ion-bag"				, -1, -1, false, showInMenuAct);
		addItem("MarketPlace"				 , "#"				    , "Quotes"			    		,"app/marketplace/index.html"		,"ion-ios-list-outline"		, -1, -1, false, showInMenuAct);
		addItem("QuotRequest"				 , "#"				    , "Quote Request"			    ,"app/quoterequest/index.html"		,"ion-document-text"		, -1, -1, false, showInMenuAct);
		addItem("Quote"					 , "#"				   		, "My Quotes"			    	,"app/quote/index.html"				,"ion-clipboard"		, -1, -1, false, showInMenuAct);
		addItem("Shipment"					 , "#"		            , "Shipment"				    , null				,"ion-android-boat"				, -1, -1, false, showInMenuAct);
		//addItem("ShipmentTracking"			 , "#"		            , "Shipment Tracking"		    , null				,"ion-eye"						, -1, -1, false, showInMenuAct);
		//addItem("ContractManagement"	     , "#"					, "Contract Management"	        , null				,"ion-clock"					, -1, -1, false, showInMenuAct);
		//addItem("Accounting"	    		 , "#"					, "Accounting"	        		, null				,"ion-clock"					, -1, -1, false, showInMenuAct);
		//addItem("ToDo"	    	 			, "#"					, "To Do"	        			, null				,"ion-clock"					, -1, -1, false, showInMenuAct);
		addItem("Messaging"					, "#"		   		 	, "Messaging"			   		, "app/msg/messaging/index.html"		,"ion-paper-airplane"	, 900, 550, false, showInMenuAct);
		addItem("Product"					 , "#"				    , "Product"				        ,"app/product"		,"ion-ios-game-controller-b"	, -1, -1, false, showInMenuAct);
		addItem("Reports" 				     , "#"		            , "Reports"	   				    , null				,"ion-ios-speedometer"			, -1, -1, false, showInMenuAct);
		addItem("TicketingSupport"			, "#"				 	,"Ticketing & Support"			, "app/msg/ticket"	,"ion-ios-email"		, -1, -1, false, showInMenuAct);
		addItem("Contacts"				, "#"		   		 , "Contacts"			   		, "core/page/contact/index.html"		,"ion-android-contacts"	, -1, -1, false, showInMenuAct);
		addItem("Help"						, "#"					,"Help"							, null				,"ion-ios-help"		, -1, -1, false, showInMenuAct);
		addItem("UserManagement"			 , "#"		            , "User Management"			, null				,"ion-person-stalker"			, -1, -1, false, showInMenuAct);

		if(userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID) {
		    addItem("Action"			     , "UserManagement"	, "Action"				, "core/page/action"				, null		, -1, -1, false, showInMenuAct);
			addItem("UseCase"			     , "UserManagement"	, "Usecase"				, "core/page/usecase"				, null		, -1, -1, false, showInMenuAct);
			addItem("AccessGroup"		     , "UserManagement"	, "Access group"		, "core/page/accessgrp"			, null		, -1, -1, false, showInMenuAct);
			addItem("Role"				     , "UserManagement"	, "Role"				, "core/page/role"					, null		, -1, -1, false, showInMenuAct);
		}
		addItem("User"					     , "UserManagement"  , "User"			  	, "core/masterdetail.html?urlPath=/core/page/user/index.html&isMaster=1" , null	    , -1, -1,false, showInMenuAct);
		if(userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID) {
			addItem("Supporters"			 , "UserManagement"	, "Supporters"			, "app/msg/supporter"				,null	, -1, -1, false, showInMenuAct);
			addItem("feedbackmanager"    , "UserManagement"    , "Feed Back"          , "core/page/feedBackManager/"	    ,null			, -1, -1, false, showInMenuAct);
			addItem("systemLog"          , "UserManagement"    , "Log"                , "core/page/log/"	    ,null			, -1, -1, false, showInMenuAct);
		}
		
		addItem("Settings"				, "#"		         , "Settings"				    , null				,"ion-gear-b"		, -1, -1, false, showInMenuAct);
		addItem("Location"				, "Settings"	     , "Location"				    , "core/page/location"	,null				, -1, -1, false, showInMenuAct);
		addItem("Profile"				, "Settings"	     , "Profile"				    , "core/page/profile/index.html"		,null				, -1, -1, false, showInMenuAct);
		addItem("ComboVal"				, "Settings"	     , "Combo values"				, "core/page/comboval"	,null		    , -1, -1, false, showInMenuAct);
		addItem("ChangePassword"		, "Settings"        , "Change Password"		    , "ui/change_pass.html"	,null			, 400, 300, false, showInMenuAct);
		addItem("Brand"		            , "Settings"        , "Brand"		                , "bse/brand"	        ,null			, -1, -1, false, showInMenuAct);
		addItem("Currency"		        , "Settings"        , "Currency"		            , "bse/currency"	     ,null			, -1, -1, false, showInMenuAct);
		addItem("Tax"		            , "Settings"        , "Tax"		                , "bse/tax"	             ,null			, -1, -1, false, showInMenuAct);
		addItem("Category"		        , "Settings"        , "Category"		            , "bse/category"	      ,null			, -1, -1, false, showInMenuAct);
		addItem("BseQuote"		        , "Settings"        , "Bse Quote"		            , null	      		,"ion-settings"			, -1, -1, false, showInMenuAct);
		addItem("CartonType"		    , "BseQuote"        , "Carton type"		            , "bse/cartontype"	      ,null			, -1, -1, false, showInMenuAct);
		addItem("MeasurementUnitType"	, "BseQuote"        , "Measurement unit type"		, "bse/measurementunittype",null			, -1, -1, false, showInMenuAct);
		addItem("ChargeClassification"	, "BseQuote"        , "Charge Classification"		, "bse/chargeclassificat"  ,null			, -1, -1, false, showInMenuAct);
		addItem("ChargeType"			, "BseQuote"        , "Charge Type"					, "bse/chargetype"	      ,null			, -1, -1, false, showInMenuAct);
		menuData.append("}");
		menuTree.append("]");

		menuTreeCache.put(userInfo.getRoleId(), menuTree.toString());
		menuDataCache.put(userInfo.getRoleId(), menuData.toString());
	}

	private void addItem(String usecase, String parentUC, String title, String path, String icon, int width, int height, boolean createNew, int actionToCheck) {
		if(!hasAccess(usecase, actionToCheck))
			return;
		if(menuTree.length() > 1){
			menuTree.append(",");
			menuData.append(",");
		}

		menuTree.append("{ \"id\" : \"").append(usecase).append("\", \"parent\" : \"")
			.append(parentUC).append("\", \"text\" : \"").append(title).append("\"")
			.append(",\"icon\": \"").append(icon != null ? icon : "none").append("\"");
		if (path != null)
			menuTree.append(",\"li_attr\": {\"data-name\": \"").append(usecase).append("\"}");

		menuTree.append(" }");

		//return such this:    "CUSTOMER": {"EN": "customer", "FA": "فروشندگان", "COUNT": "0", "PATH":"app/merchant", "WIDTH": "-1", "HEIGHT": "-1", "CREATE_NEW": "true"}
		menuData.append("\"").append(usecase).append("\": {\"EN\": \"").append(usecase).append("\", \"FA\": \"").append(title)
			.append("\", \"COUNT\": 0, \"PATH\":\"").append(path).append("\", \"WIDTH\": \"").append(width)
			.append("\", \"HEIGHT\": \"").append(height).append("\", \"CREATE_NEW\": \"").append(createNew).append("\"}");
	}


	@Override
	public String getMenuData() {
		return menuData.toString();
	}

	@Override
	public String getMenuTree() {
		return menuTree.toString();
	}

	private boolean hasAccess(String userCase, int action){
		if(!SystemConfig.CHECK_ACCESSES || userInfo.getRoleId() == SystemConfig.ADMIN_USER_ROLE_ID || userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID || userInfo.getRoleId() == SystemConfig.SYSTEM_ROLE_ID)
			return true;
		Integer acs = access.get(userCase);
		int p =(int) Math.pow(2, action);
		return acs != null && (acs.intValue() | p) == acs;
	}

}
