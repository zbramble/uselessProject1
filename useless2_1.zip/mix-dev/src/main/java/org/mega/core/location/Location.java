package org.mega.core.location;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.company.Company;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;

@Entity
@Table(name = "CO_LOCATION", uniqueConstraints = @UniqueConstraint(name = "PK_CO_LOCATION_ID", columnNames = "LOCATION_ID"))
public class Location extends BaseEntity {
    @Id
    @Column(name = "LOCATION_ID")
    private long rowId;

    @Column(name = "NAME", length = 50)
    private String name;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "TYPE_ID", foreignKey = @ForeignKey(name = "FK_LOC_2_COM__TYP_ID"), nullable = false)
    private ComboVal type;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "PARENT_ID", foreignKey = @ForeignKey(name = "FK_LOC_2_LOC__PARENT_ID"))
    private Location parent;

    /*@OneToMany(mappedBy = "parent")
    private List<Location> locations;*/
    
    @Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;
    
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "COMPANY_ID", foreignKey = @ForeignKey(name = "FK_COMPANY") , nullable = true)
	private Company company;
    
    @Column(name = "FIRST_ADDRESS", length = 500,nullable = true)
	private String firstAddress;
    
    @Column(name = "SECOND_ADDRESS", length = 500,nullable = true)
	private String secondAddress;
    
    @Column(name = "COUNTRY", length = 100,nullable = true)
   	private String country;
    
    @Column(name = "CITY", length = 100,nullable = true)
   	private String city;
    
    @Column(name = "POSTAL_CODE", length = 100,nullable = true)
   	private String postalCode;
    
    @ManyToOne()
	@JoinColumn(name = "RELATED_STATE_ID", foreignKey = @ForeignKey(name = "FK_STATE_CO_COMBO"), nullable = true)
	private ComboVal state;
    
    public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ComboVal getType() {
        return type;
    }

    public void setType(ComboVal type) {
        this.type = type;
    }

    public Location getParent() {
        return parent;
    }

    public void setParent(Location parent) {
        this.parent = parent;
    }

    /*public List<Location> getLocations() {
        return locations;
    }

    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }
*/
    
    public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public String getFirstAddress() {
		return firstAddress;
	}

	public void setFirstAddress(String firstAddress) {
		this.firstAddress = firstAddress;
	}

	public String getSecondAddress() {
		return secondAddress;
	}

	public void setSecondAddress(String secondAddress) {
		this.secondAddress = secondAddress;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public ComboVal getState() {
		return state;
	}

	public void setState(ComboVal state) {
		this.state = state;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        
         fullTitle = (parent == null || parent.getFullTitle() == null ||  parent.getFullTitle().equals("-")) ? name : parent.getFullTitle() + "/" + name;
        
    }
	
	@PreUpdate
    @Override
    public void preUpdate() throws Exception {
		fullTitle = (parent == null || parent.getFullTitle() == null || parent.getFullTitle().equals("-")) ? name
				: parent.getFullTitle() + "/" + name;
    }
}