package org.mega.core.file;

import org.mega.core.base.BaseCopier;

public class FileCopier extends BaseCopier<File, FileDTO> {
    @Override
    public FileDTO copyFromEntity(File file) {
        FileDTO fileDTO = new FileDTO();

        fileDTO.setRowId(file.getRowId());
        fileDTO.setName(file.getName());
        fileDTO.setPath(file.getPath());
        fileDTO.setTitle(file.getTitle());
        fileDTO.setUseTitle(file.getUseTitle());
        fileDTO.setUseEntity(file.getUseEntity());
        fileDTO.setDataSize(file.getDataSize());
        fileDTO.setDataType(file.getDataType());
        fileDTO.setDescription(file.getDescription());
        fileDTO.setImageContent(file.getImageContent());

        copyFromEntityBaseField(file, fileDTO);
        return fileDTO;
    }

    @Override
    public File copyToEntity(FileDTO fileDTO) {
        File file = new File();

        file.setRowId(fileDTO.getRowId());
        file.setName(fileDTO.getName());
        file.setPath(fileDTO.getPath());
        file.setTitle(fileDTO.getTitle());
        file.setUseTitle(fileDTO.getUseTitle());
        file.setUseEntity(fileDTO.getUseEntity());
        file.setDataSize(fileDTO.getDataSize());
        file.setDataType(fileDTO.getDataType());
        file.setDescription(fileDTO.getDescription());
        file.setImageContent(fileDTO.getImageContent());

        copyToEntityBaseField(file, fileDTO);
        return file;
    }
}