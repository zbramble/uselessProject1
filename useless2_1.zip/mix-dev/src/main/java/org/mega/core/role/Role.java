package org.mega.core.role;

import org.mega.core.accessgrp.AccessGrp;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.userrole.UserRole;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_ROLE", uniqueConstraints = @UniqueConstraint(name = "PK_CO_ROLE", columnNames = "ROLE_ID"))
public class Role extends BaseEntity {
    @Id
    @Column(name = "ROLE_ID")
    private long rowId;

    @Column(name = "CODE", nullable = false, length = 20)
    private String code;

    @Column(name = "ROLE_NAME", nullable = false, length = 100)
    private String roleName;

    @Column(name = "EXPIRE_MINUTE")
    private long expireMinute;

    @OneToMany(mappedBy = "role")
    private List<UserRole> userRoles;

    @ManyToMany(mappedBy = "roles")
    private List<AccessGrp> accessGrps;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public long getExpireMinute() {
        return expireMinute;
    }

    public void setExpireMinute(long expireMinute) {
        this.expireMinute = expireMinute;
    }

    public List<UserRole> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public List<AccessGrp> getAccessGrps() {
        return accessGrps;
    }

    public void setAccessGrps(List<AccessGrp> accessGrps) {
        this.accessGrps = accessGrps;
    }

    public UserRole addCoUserRole(UserRole coUserRole) {
        getUserRoles().add(coUserRole);
        coUserRole.setRole(this);
        return coUserRole;
    }

    public UserRole removeCoUserRole(UserRole coUserRole) {
        getUserRoles().remove(coUserRole);
        coUserRole.setRole(null);
        return coUserRole;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = rowId + " " + roleName.toLowerCase();
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = rowId + " " + roleName.toLowerCase();
    }
}