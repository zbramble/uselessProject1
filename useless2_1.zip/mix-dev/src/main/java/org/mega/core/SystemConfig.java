package org.mega.core;

import java.io.IOException;
import java.util.Properties;

public class SystemConfig {
	
	public static String ID_PREFIX;
	public static long	SYSTEM_ROLE_ID;// = 10000;	//System do some things with this role. No access checks for system or admin role 
	public static long	SYSTEM_USER_ID;// = 10000;	//System do some things with this user. No access checks for system or admin role 
	public static long	SYS_ADMIN_ROLE_ID; //= 10001; // Administrator of system. He has access to all things for repair and backup and ...
	public static long	RICH_USER_ROLE_ID;// = 10002; // End user with high accesses
	public static long	POOR_USER_ROLE_ID;// = 10003; //End user with little accesses
	public static long	ADMIN_USER_ROLE_ID;// = 10004;//Users and system manager
	public static int	REPORT_EXCEL_MAX_SIZE;// = 10000;
	public static String UPLAUD_FOLDER;// = "g:/mega_uplaod/file";
	public static String TEMP_FOLDER;// = "g:/mega_uplaod/temp";
	public static boolean INFOMR_SERVER_IP;// = true; //Email server last ip to admin
	public static long EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS;//=60;
	public static long EXPIRE_CACHE_MAX_SIZE;// = 400;
	public static int USER_EXPIRE_MINUTE;
	public static String SERVER_URL;
	public static long ORGANOZATION_ROOT_ID;
	public static long SUPPORT_USER_ROLE_ID;
	public static String SUPPORT_EMAIL;
	public static boolean CHECK_ACCESSES;
	
	public static String SYSTEM_EMAIL_SERVER;
	public static String SYSTEM_EMAIL;
	public static String SYSTEM_EMAIL_USER;
	public static String SYSTEM_EMAIL_PASS;
	public static boolean SYSTEM_EMAIL_USE_SSL;
	public static String SYSTEM_EMAIL_SMTP_PORT;

	private static Properties properties = new Properties();

	public static void init(){
		try {
			properties.load(SystemConfig.class.getClassLoader().getResourceAsStream("system.properties"));
			
			ID_PREFIX  								= SystemConfig.getProp("ID_PREFIX");
			SYSTEM_ROLE_ID  						= SystemConfig.getLongProp("SYSTEM_ROLE_ID");
			SYS_ADMIN_ROLE_ID  						= SystemConfig.getLongProp("SYS_ADMIN_ROLE_ID");
			RICH_USER_ROLE_ID 						= SystemConfig.getLongProp("RICH_USER_ROLE_ID");
			POOR_USER_ROLE_ID  						= SystemConfig.getLongProp("POOR_USER_ROLE_ID");
			ADMIN_USER_ROLE_ID  					= SystemConfig.getLongProp("ADMIN_USER_ROLE_ID");
			REPORT_EXCEL_MAX_SIZE  					= SystemConfig.getIntProp("REPORT_EXCEL_MAX_SIZE");
			UPLAUD_FOLDER 		 					= SystemConfig.getProp("UPLAUD_FOLDER");
			TEMP_FOLDER  							= SystemConfig.getProp("TEMP_FOLDER");
			INFOMR_SERVER_IP  						= SystemConfig.getBooleanProp("INFOMR_SERVER_IP");
			EXPIRE_CACHE_MAX_SIZE  					= SystemConfig.getLongProp("EXPIRE_CACHE_MAX_SIZE");
			SYSTEM_USER_ID  						= SystemConfig.getLongProp("SYSTEM_USER_ID");
			EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS	= SystemConfig.getLongProp("EXPIRE_CACHE_DEFAULT_TIMEOUT_SECONDS");
			USER_EXPIRE_MINUTE  					= SystemConfig.getIntProp("USER_EXPIRE_MINUTE");
			SERVER_URL  							= SystemConfig.getProp("SERVER_URL");
			ORGANOZATION_ROOT_ID  					= SystemConfig.getLongProp("ORGANOZATION_ROOT_ID");
			SUPPORT_USER_ROLE_ID  					= SystemConfig.getLongProp("SUPPORT_USER_ROLE_ID");
			SUPPORT_EMAIL							= SystemConfig.getProp("SUPPORT_EMAIL");
			CHECK_ACCESSES  						= SystemConfig.getBooleanProp("CHECK_ACCESSES");
			
			SYSTEM_EMAIL_SERVER                     = SystemConfig.getProp("SYSTEM_EMAIL_SERVER");
			SYSTEM_EMAIL                            = SystemConfig.getProp("SYSTEM_EMAIL");
			SYSTEM_EMAIL_USER                       = SystemConfig.getProp("SYSTEM_EMAIL_USER");
			SYSTEM_EMAIL_PASS                       = SystemConfig.getProp("SYSTEM_EMAIL_PASS");
			SYSTEM_EMAIL_USE_SSL                    = SystemConfig.getBooleanProp("SYSTEM_EMAIL_USE_SSL");
			SYSTEM_EMAIL_SMTP_PORT                  = SystemConfig.getProp("SYSTEM_EMAIL_SMTP_PORT");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static boolean getBooleanProp(String propName) {
		return "true".equals(properties.getProperty(propName).trim());
	}

	public static String getProp(String propName){
		return properties.getProperty(propName).trim();
	}
	
	public static long getLongProp(String propName){
		return Long.parseLong(properties.getProperty(propName).trim());
	}
	
	public static int getIntProp(String propName) {
		return Integer.parseInt(properties.getProperty(propName).trim());
	}
	
}