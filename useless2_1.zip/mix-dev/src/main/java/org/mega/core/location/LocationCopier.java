package org.mega.core.location;

import org.mega.bse.company.Company;
import org.mega.bse.company.CompanyDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;

public class LocationCopier extends BaseCopier<Location, LocationDTO> {

	@Override
	public LocationDTO copyFromEntity(Location location) {
		LocationDTO locationDTO = new LocationDTO();

		locationDTO.setRowId(location.getRowId());
		locationDTO.setName(location.getName());
		if (location.getType() != null) {
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(location.getType().getRowId());
			comboValDTO.setName(location.getType().getName());
			comboValDTO.setVal(location.getType().getVal());
			locationDTO.setType(comboValDTO);
			locationDTO.setAccessKey(location.getAccessKey());
		}
		if (location.getParent() != null) {
			LocationDTO parentLocationDTO = new LocationDTO();
			parentLocationDTO.setRowId(location.getParent().getRowId());
			parentLocationDTO.setName(location.getParent().getName());
			locationDTO.setParent(parentLocationDTO);
			locationDTO.setAccessKey(location.getAccessKey());
		}
		locationDTO.setFirstAddress(location.getFirstAddress());
		locationDTO.setSecondAddress(location.getSecondAddress());
		locationDTO.setCountry(location.getCountry());
		locationDTO.setCity(location.getCity());
		locationDTO.setPostalCode(location.getPostalCode());
		if (location.getCompany() != null) {
			CompanyDTO companyDTO = new CompanyDTO();
			companyDTO.setRowId(location.getCompany().getRowId());
			companyDTO.setCompanyName(location.getCompany().getCompanyName());
			locationDTO.setCompanyDTO(companyDTO);
			locationDTO.setAccessKey(location.getAccessKey());
		}
		if(location.getState() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(location.getState().getRowId());
			comboValDTO.setName(location.getState().getName());
			locationDTO.setState(comboValDTO);
		}
		copyFromEntityBaseField(location, locationDTO);

		return locationDTO;
	}

	@Override
	public Location copyToEntity(LocationDTO locationDTO) {
		Location location = new Location();

		location.setRowId(locationDTO.getRowId());
		location.setName(locationDTO.getName());
		if (locationDTO.getType() != null) {
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(locationDTO.getType().getRowId());
			comboVal.setName(locationDTO.getType().getName());
			location.setType(comboVal);
			location.setAccessKey(locationDTO.getAccessKey());
		}
		if (locationDTO.getParent() != null) {
			Location parentLocation = new Location();
			parentLocation.setRowId(locationDTO.getParent().getRowId());
			location.setParent(parentLocation);
			location.setAccessKey(locationDTO.getAccessKey());
		}
		if(locationDTO.getState() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(locationDTO.getState().getRowId());
			comboVal.setName(locationDTO.getState().getName());
			location.setState(comboVal);
		}
		if (locationDTO.getCompanyDTO() != null) {
			Company company = new Company();
			company.setRowId(locationDTO.getCompanyDTO().getRowId());
			company.setCompanyName(locationDTO.getCompanyDTO().getCompanyName());
			location.setCompany(company);
			location.setAccessKey(locationDTO.getAccessKey());
		}
		location.setFirstAddress(locationDTO.getFirstAddress());
		location.setSecondAddress(locationDTO.getSecondAddress());
		location.setCountry(locationDTO.getCountry());
		location.setCity(locationDTO.getCity());
		location.setPostalCode(locationDTO.getPostalCode());
		
		copyToEntityBaseField(location, locationDTO);

		return location;
	}
}