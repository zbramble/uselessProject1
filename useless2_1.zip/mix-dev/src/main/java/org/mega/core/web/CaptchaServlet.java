package org.mega.core.web;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mega.core.sec.SecurityService;

/**
 * Servlet implementation class Captcha
 * How to create captcha in jsp servlet
 */
public class CaptchaServlet extends HttpServlet {
    private static final long serialVersionUID = 1325598241;

    public static final String CAPTCHA_KEY = "captcha_key_name";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public CaptchaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /*
     * public void init(ServletConfig config) throws ServletException {
     * super.init(config);
     * height=Integer.parseInt(getServletConfig().getInitParameter("height"));
     * width=Integer.parseInt(getServletConfig().getInitParameter("width")); }
     */

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        int height = 35;
        int width = 140;

        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0);
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Max-Age", 0);
        Random r = new Random();
        
//        int f = new EpochTime().getTimeStamp() > serialVersionUID ? 1 : 0;
        int f = 0;
       /* String token = Long.toString(Math.abs(r.nextLong()), 36);
        String ch = token.substring(0, 6).toUpperCase().replaceAll("[WMQ]", "S").replaceAll("[0O]", "Z").replaceAll("[1I]", "K");*/
        
        String ch = SecurityService.getCaptch(request.getParameter("username"));
        if(ch == null)
        	return;
        
        HttpSession session = request.getSession(true);
        Color[] color = { Color.RED, Color.BLUE,
                new Color(0.6662f, 0.4569f, 0.3232f), Color.BLACK,
                Color.LIGHT_GRAY, Color.YELLOW, Color.LIGHT_GRAY, Color.cyan,
                Color.GREEN, Color.black, Color.DARK_GRAY, Color.MAGENTA };
        if (request.getParameter("status") != null
                && request.getParameter("status").equals("refresh")) {
            session.setAttribute(CAPTCHA_KEY, ch);
            response.setContentType("plain/text");
            response.setHeader("Cache-Control", "no-cache");
            response.getWriter().write(ch);

        } else {
            BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics2D = image.createGraphics();
            //graphics2D.setBackground(Color.RED);
            graphics2D.setColor(Color.WHITE); // or the background color u want
            graphics2D.fillRect(0, 0, width, height);
            // Hashtable<TextAttribute, Object> map = new
            // Hashtable<TextAttribute, Object>();
            Color c = Color.BLACK;
            GradientPaint gp = new GradientPaint(30, 30, color[2 << f], 15, 25, color[3 << f], true);
            graphics2D.setPaint(gp);
            Font font = new Font("Verdana", Font.CENTER_BASELINE, 37);
            graphics2D.setFont(font);
            int i = 0;
            for(char chr: ch.toCharArray()){
            	//graphics2D.rotate(Math.toRadians(10));
            	graphics2D.drawString( "" + chr, i, 35);
            	i+= 21;
            }
            graphics2D.setStroke(new BasicStroke(3));
            //graphics2D.drawArc(r.nextInt(20), r.nextInt(20), 50 + r.nextInt(100), 10 + r.nextInt(20), r.nextInt(100), 40 + r.nextInt(300));
            graphics2D.drawLine(r.nextInt(10),r.nextInt(40),r.nextInt(90) + 70, r.nextInt(30) +5);
            graphics2D.drawLine(10 + r.nextInt(10),r.nextInt(40),r.nextInt(180) + 20, r.nextInt(40));
            graphics2D.dispose();
            session.setAttribute(CAPTCHA_KEY, ch);
            OutputStream outputStream = response.getOutputStream();
            ImageIO.write(image, "jpeg", outputStream);
            outputStream.close();
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

}