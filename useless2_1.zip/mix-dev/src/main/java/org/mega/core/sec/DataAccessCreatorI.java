package org.mega.core.sec;

/**
 * به ازای هر دسترسی که باید در پروژه چک شود یک مورد در 
 * DataAccaess
 * باید اضافه شود.
 * از این رو هر پروژه باید کلاسی که اینترفیس ِ
 *	DataAccessCreatorI
 *	را پیاده کرده باشد داشته باشد
 * @author golnari@gmail.com
 *
 */

public interface DataAccessCreatorI {
	public DataAccess createDataAccess(UserInfo userInfo);
}
