package org.mega.core.role;

import java.util.List;

import org.mega.core.accessgrp.AccessGrpFacade;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BusinessParam;
import org.mega.core.userrole.UserRoleFacade;

public class RoleCopier extends BaseCopier<Role, RoleDTO> {

    @Override
    public RoleDTO copyFromEntity(Role role) {
        RoleDTO roleDTO = new RoleDTO();

        roleDTO.setRowId(role.getRowId());
        roleDTO.setCode(role.getCode());
        roleDTO.setActive(role.isActive());
        roleDTO.setRoleName(role.getRoleName());
        roleDTO.setExpireMinute(role.getExpireMinute());
        if (role.getUserRoles() != null) {
            roleDTO.setUserRoles(UserRoleFacade.getInstance().getCopier().copyFromEntity(role.getUserRoles()));
        }
        if (role.getAccessGrps() != null) {
            roleDTO.setAccessGrps(
                    AccessGrpFacade.getInstance().getCopier().copyFromEntity(role.getAccessGrps()));
        }
        copyFromEntityBaseField(role, roleDTO);

        return roleDTO;
    }

    @Override
    public Role copyToEntity(RoleDTO roleDTO) throws Exception {
        Role role = new Role();
        if(roleDTO.getRowId() != 0)
            role = RoleFacade.getInstance().findEntityById(Role.class, roleDTO.getRowId(), BusinessParam.getSystemBusinessParam());
        role.setRowId(roleDTO.getRowId());
        role.setCode(roleDTO.getCode());
        role.setActive(roleDTO.isActive());
        role.setRoleName(roleDTO.getRoleName());
        role.setExpireMinute(roleDTO.getExpireMinute());
        if (roleDTO.getUserRoles() != null) {
            role.setUserRoles(UserRoleFacade.getInstance().getCopier().copyToEntity(roleDTO.getUserRoles()));
        }
        if (roleDTO.getAccessGrps() != null) {
            List newAccessGrps = AccessGrpFacade.getInstance().getCopier().copyToEntity(roleDTO.getAccessGrps());
            role.getAccessGrps().addAll(newAccessGrps);
        }
        copyToEntityBaseField(role, roleDTO);

        return role;
    }
}