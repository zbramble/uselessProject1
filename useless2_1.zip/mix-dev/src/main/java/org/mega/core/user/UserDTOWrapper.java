package org.mega.core.user;

import java.util.List;

import org.mega.core.userrole.UserRoleDTO;

public class UserDTOWrapper {
    private UserDTO userDTO;
    private List<UserRoleDTO> listChild;
    private List<String> listId;

    public UserDTO getUserDTO() {
        return userDTO;
    }

    public void setUserDTO(UserDTO userDTO) {
        this.userDTO = userDTO;
    }

    public List<UserRoleDTO> getListChild() {
        return listChild;
    }

    public void setListChild(List<UserRoleDTO> listChild) {
        this.listChild = listChild;
    }

    public List<String> getListId() {
        return listId;
    }

    public void setListId(List<String> listId) {
        this.listId = listId;
    }
}
