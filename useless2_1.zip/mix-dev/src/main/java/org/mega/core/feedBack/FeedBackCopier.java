package org.mega.core.feedBack;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;


public class FeedBackCopier extends BaseCopier<FeedBack, FeedBackDTO> {
    @Override
    public FeedBackDTO copyFromEntity(FeedBack feedBack) {
        FeedBackDTO feedBackDTO = new FeedBackDTO();

        feedBackDTO.setRowId(feedBack.getRowId());
        feedBackDTO.setWindowName(feedBack.getWindowName());
        feedBackDTO.setSatisfaction(feedBack.isSatisfaction());
        feedBackDTO.setOffer(feedBack.getOffer());
        if (feedBack.getCondition() != null) {
            ComboValDTO comboDTO = new ComboValDTO();
            comboDTO.setRowId(feedBack.getCondition().getRowId());
            comboDTO.setName(feedBack.getCondition().getName());
            feedBackDTO.setCondition(comboDTO);
        }
        feedBackDTO.setDescription(feedBack.getDescription());

        copyFromEntityBaseField(feedBack, feedBackDTO);

        return feedBackDTO;
    }

    @Override
    public FeedBack copyToEntity(FeedBackDTO feedBackDTO) throws Exception {
        FeedBack feedBack = new FeedBack();

        feedBack.setRowId(feedBackDTO.getRowId());
        feedBack.setWindowName(feedBackDTO.getWindowName());
        feedBack.setSatisfaction(feedBackDTO.isSatisfaction());
        feedBack.setOffer(feedBackDTO.getOffer());
        if (feedBackDTO.getCondition() != null) {
            ComboVal comboCondition = new ComboVal();
            comboCondition.setRowId(feedBackDTO.getCondition().getRowId());
            feedBack.setCondition(comboCondition);
        }
        feedBack.setDescription(feedBackDTO.getDescription());

        copyToEntityBaseField(feedBack, feedBackDTO);

        return feedBack;
    }
}