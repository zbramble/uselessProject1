package org.mega.core.comboval;

import java.util.List;

import org.mega.core.base.BaseDTO;

public class ComboValDTO extends BaseDTO {
    private long rowId;
    private String name;
    private String val;
    private String code;
    private List<ComboValDTO> comboVals;
    private ComboValDTO parent;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<ComboValDTO> getComboVals() {
        return comboVals;
    }

    public void setComboVals(List<ComboValDTO> comboVals) {
        this.comboVals = comboVals;
    }

    public ComboValDTO getParent() {
        return parent;
    }

    public void setParent(ComboValDTO parent) {
        this.parent = parent;
    }
}