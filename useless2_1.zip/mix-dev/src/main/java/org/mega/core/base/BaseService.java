package org.mega.core.base;

import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;


public class BaseService {
	
	Logger logger = BaseLogger.getLogger(BaseService.class);
	
	public static BaseService getInstance(){
		BaseService baseService = new BaseService();

		return baseService;
	}
	

	
	
	@SuppressWarnings("unchecked")
	public List<Object> nativeQuery(String sql) throws Exception{
		BaseDB baseDB = BaseDB.open("BaseService.nativeQuery");
		Query query = baseDB.createNativeQuery(sql);
		List<Object> ret = query.getResultList();
		baseDB.commitAndclose();
		return ret ;
	}
	
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}
}
