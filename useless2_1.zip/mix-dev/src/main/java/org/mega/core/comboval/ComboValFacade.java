package org.mega.core.comboval;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class ComboValFacade extends BaseFacade {
    private static ComboValCopier copier = new ComboValCopier();
    private static ComboValFacade facade = new ComboValFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static ComboValFacade getInstance() {
        return facade;
    }
}