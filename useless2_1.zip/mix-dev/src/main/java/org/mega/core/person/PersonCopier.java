package org.mega.core.person;

import org.mega.core.base.BaseCopier;
import org.mega.util.DateUtil;

public class PersonCopier extends BaseCopier<Person, PersonDTO> {
    @Override
    public PersonDTO copyFromEntity(Person person) {
        PersonDTO personDTO = new PersonDTO();

        personDTO.setRowId(person.getRowId());
        personDTO.setNationalId(person.getNationalId());
        personDTO.setFirstName(person.getFirstName());
        personDTO.setLastName(person.getLastName());
        personDTO.setFatherName(person.getFatherName());
        personDTO.setBirthDate(DateUtil.getDateString(person.getBirthDate(), "fa"));
        personDTO.setBirthPlace(person.getBirthPlace());
        personDTO.setBloodType(person.getBloodType());
        copyFromEntityBaseField(person, personDTO);

        return personDTO;
    }

    @Override
    public Person copyToEntity(PersonDTO personDTO) {
        Person person = new Person();

        person.setRowId(personDTO.getRowId());
        person.setNationalId(personDTO.getNationalId());
        person.setFirstName(personDTO.getFirstName());
        person.setLastName(personDTO.getLastName());
        person.setFatherName(personDTO.getFatherName());
        person.setBirthDate(DateUtil.getDate(personDTO.getBirthDate(), "fa"));
        person.setBirthPlace(personDTO.getBirthPlace());
        person.setBloodType(personDTO.getBloodType());
        copyToEntityBaseField(person, personDTO);

        return person;
    }
}