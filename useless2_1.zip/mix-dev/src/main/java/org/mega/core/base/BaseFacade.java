package org.mega.core.base;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.exception.AccessDeniedException;
import org.mega.core.exception.DeleteParamsException;
import org.mega.core.log.Log;
import org.mega.core.sec.UserSession;
import org.mega.core.user.User;
import org.mega.util.BeanUtil;
import org.mega.util.QueryUtil;

public abstract class BaseFacade {
    protected static Logger logger = BaseLogger.getLogger();

    /**
     * Save an entity. If businessParam.getBaseDB() is not null, transaction controller is out of method so method don't commit.
     *
     * @param entity
     * @param businessParam
     * @return
     * @throws Exception
     */
    public long saveEntity(BaseEntity entity, BusinessParam businessParam) throws Exception {

        String entityName = BeanUtil.getEntityClass(this).getSimpleName();
        Log log = new Log(entityName, entity.getRowId(), entity.getUpdatedBy());

        try {
            if (entity.getRowId() == null || entity.getRowId() == 0L) {
                log.setAction(ACTION.insert);
                businessParam.getUserSession().checkAccess(entity.getClass().getSimpleName(), ACTION.insert);
            } else {
                log.setAction(ACTION.update);
                businessParam.getUserSession().checkAccess(entity.getClass().getSimpleName(), ACTION.update);
            }
            BaseDB db = businessParam.getDB();
            entity = db.merge(entity);
            businessParam.releaseDB();
            log.setDescription("Successful");
            logger(log);
            return entity.getRowId();
        } catch (AccessDeniedException e) {
            log.setDescription("Access denied exception");
            logger(log);
            throw e;
        } catch (Exception e) {
            businessParam.rolback();
            log.setDescription("Failed");
            logger(log);
            throw e;
        }
    }

    public <E> E findEntityById(Class<E> entityClass, long id, BusinessParam businessParam) throws Exception {
        try {
            BaseDB db = businessParam.getDB();
            Query query = db.createQuery("select e from " + entityClass.getSimpleName() + " e where e.rowId= :id and (e.accessKey is null or e.accessKey like '" +
            		businessParam.getUserSession().getUserInfo().getAccessKey() + "%')");
			query.setParameter("id", id);
			
            E e = (E) query.getSingleResult();
            businessParam.releaseDB();
            return e;
        } catch (Exception e) {
            businessParam.rolback();
            logger.error("Error: findEntity ", e);
            throw new Exception("Error find entity " + entityClass.getName(), e);
        }
    }

    public ServiceResult list(BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);
        Filter filter = businessParam.getFilter();
        if (filter == null)
            return new ServiceResult(ServiceResult.ERROR_CODE.IS_NULL, "filter is null", "");

        try {
            BaseDB db = businessParam.getDB();
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.search);
            //UserSessionManager.checkAccess(filter.getTicket(), entityClass.getSimpleName(), UserSession.ACTION.search);

            Query query = db.createQuery(QueryUtil.genQuery(entityClass, filter, QueryUtil.QUERY_TYPE.SELECT, getConstraint(businessParam)));
            query.setFirstResult((filter.getPageNo() - 1) * filter.getPageSize());
            query.setMaxResults(filter.getPageSize());
            List<BaseEntity> result = query.getResultList();

            List<BaseDTO> ret = new ArrayList<>(result.size());

            for (BaseEntity entity : result) {
                BaseDTO dto = getCopier().copyFromEntity(entity);
                ret.add(dto);
            }
            businessParam.releaseDB();
            return new ServiceResult(ret, ret.size());
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error getList " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error getList LocationDTO", e);
        }
    }

    public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);
        try {
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.insert);

            BaseEntity entity = getCopier().copyToEntity(baseDTO, businessParam);

            if (baseDTO.getRowId() == 0) {
                entity.setCreated(new Date(System.currentTimeMillis()));
                entity.setCreatedBy(findEntityById(User.class, businessParam.getUserSession().getUserInfo().getUserId(), businessParam));
            }
            entity.setUpdated(new Date(System.currentTimeMillis()));
            entity.setUpdatedBy(findEntityById(User.class, businessParam.getUserSession().getUserInfo().getUserId(), businessParam));

            long id = saveEntity(entity, businessParam);
            BaseLogger.getLogger(this.getClass()).info("saved id=" + id);
            return new ServiceResult(id, 1);
        } catch (Exception e) {
            BaseLogger.getLogger().info("Error saving " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving " + entityClass.getSimpleName(), e);
        }
    }

    public ServiceResult delete(BusinessParam businessParam) {
        try {
            PairValue pairValue = businessParam.getFilter().getParams().get(0);
            if (pairValue.getKey().indexOf("rowId") == -1
                    || pairValue.getValue().isEmpty()
                    || !(pairValue.getCondition() == PairValue.CONDITION.EQUAL || pairValue.getCondition() == PairValue.CONDITION.IN)) {
                throw new DeleteParamsException();
            }
        } catch (IndexOutOfBoundsException | DeleteParamsException e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.INVALID_FILTER_PARAMETER
                    , "شناسه مشخص نگردیده است", e.getLocalizedMessage());
        }

        Class<?> entityClass = BeanUtil.getEntityClass(this);
        try {
            BaseDB db = businessParam.getDB();
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.delete);
            Query query = db.createQuery(QueryUtil.genQuery(entityClass, businessParam.getFilter(), QueryUtil.QUERY_TYPE.DELETE));
            int result = query.executeUpdate();
            businessParam.releaseDB();
            return new ServiceResult("Deleted", result);
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error " + entityClass.getSimpleName() + " delete", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, "Error delete " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }

    protected void logger(Log log) {
        BusinessParam businessParam = BusinessParam.getSystemBusinessParam();
        try {
            businessParam.getDB().merge(log);
            businessParam.releaseDB();
        } catch (Exception e) {
            businessParam.rolback();
            logger.error("#logger:" + log.toString());
        }
    }

    public abstract BaseCopier getCopier();

    /**
     * Override this method for access filtering
     *
     * @param businessParam
     * @return
     */
    public String getConstraint(BusinessParam businessParam) {
        UserSession userSession = businessParam.getUserSession();
        if (userSession.dontCheckAccess())
            return null;

        return " e.accessKey is null OR  e.accessKey like '" + userSession.getUserInfo().getAccessKey() + "%'";
    }
}
