package org.mega.core.person;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class PersonFacade extends BaseFacade {
    private static PersonFacade facade = new PersonFacade();
    private static PersonCopier copier = new PersonCopier();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static PersonFacade getInstance() {
        return facade;
    }
}