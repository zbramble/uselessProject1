package org.mega.core.base;
public class BaseProperties {
	public static final String THIRD_PARTY_ENCODER_CLASS = null;
	public static String LANGUAGE_PARAMETER_NAME = "fa";
	public static String USER_SESSION_ATTRIBUTE_NAME = "admin";
}
