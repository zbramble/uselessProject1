/*
 * Created on Dec 21, 2005
 *
 * 
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.mega.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ColorConvertOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.LookupOp;
import java.awt.image.RenderedImage;
import java.awt.image.RescaleOp;
import java.awt.image.ShortLookupTable;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

//import com.sun.image.codec.jpeg.JPEGCodec;
//import com.sun.image.codec.jpeg.JPEGDecodeParam;
//import com.sun.image.codec.jpeg.JPEGEncodeParam;
//import com.sun.image.codec.jpeg.JPEGImageEncoder;

/**
 * @author Nasser Sadeqi (nasser) & Golnari
 */
public class ImageUtil {

	public enum Format {
		JPG, GIF, BMP, PNG;

		public static boolean support(String fileNameSufix) {
			return "JPG, GIF, BMP, PNG".indexOf(fileNameSufix.toUpperCase().trim()) != -1;
		}
	}

	;

	/*
	 * public static void main(String[] args) {
	 * System.out.println(ImageUtil.Format.support("bmp")); }
	 */

	/**
	 * Creates image using its content
	 *
	 * @param content
	 * @return
	 */
	public static BufferedImage getImage(byte[] content) throws IOException {
		ByteArrayInputStream is = new ByteArrayInputStream(content);
		return ImageIO.read(is);
	}

	/**
	 * Resize image with specified scale
	 *
	 * @param widthScale
	 * @param heightScale
	 * @param img
	 * @return
	 */
	public static BufferedImage resizeImage(double widthScale, double heightScale, BufferedImage img) {
		if (widthScale == 1 && heightScale == 1)
			return img;
		try {
			Image destImg2 = img.getScaledInstance((int) (img.getWidth() * widthScale),
					(int) (img.getHeight() * heightScale), Image.SCALE_SMOOTH);
			BufferedImage destImgTmp = new BufferedImage(destImg2.getWidth(null), destImg2.getHeight(null),
					BufferedImage.TYPE_INT_RGB);
			destImgTmp.getGraphics().drawImage(destImg2, 0, 0, null);
			return destImgTmp;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Resize image with specified scale
	 *
	 * @param originalImage
	 * @param newWidth
	 * @return
	 */
	public static BufferedImage resizeImage(BufferedImage originalImage, int newWidth) {
		float oldWidth = originalImage.getWidth();
		int oldHeight = originalImage.getHeight();
		int newHeight = (int) (oldHeight / (oldWidth / newWidth));

		int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();

		BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
		g.dispose();

		return resizedImage;
	}

	public static BufferedImage resizeImage(double scale, BufferedImage img) {
		if (scale == 1)
			return img;
		return resizeImage(scale, scale, img);
	}

	/**
	 * Resize image to fit in bound width * height
	 *
	 * @param image
	 * @param boundEidth
	 * @param boundHeight
	 * @return
	 */
	public static BufferedImage resizeToBound(BufferedImage image, int boundWidth, int boundHeight) {
		if (image == null)
			return null;
		if (boundWidth == -1 || boundHeight == -1 || (image.getHeight() < boundHeight && image.getWidth() < boundWidth))
			return image;
		double scale = boundScale(image.getWidth(), image.getHeight(), boundWidth, boundHeight);
		return resizeImage(scale, image);
	}

	/**
	 * Resize image to fit in bound width * height
	 *
	 * @param image
	 * @param boundEidth
	 * @param boundHeight
	 * @return
	 * @throws IOException
	 */
	public static byte[] resizeToBound(byte[] image, int boundWidth, int boundHeight) throws IOException {
		if (image == null)
			return null;
		BufferedImage bi = ImageUtil.getImage(image);
		if (bi.getHeight() < boundHeight && bi.getWidth() < boundWidth)
			return image;
		double scale = boundScale(bi.getWidth(), bi.getHeight(), boundWidth, boundHeight);
		bi = ImageUtil.resizeImage(scale, bi);
		return ImageUtil.getImageContent(bi, Format.JPG);
	}

	/**
	 * Resize image to fit in bound width * height
	 *
	 * @param image
	 * @param boundEidth
	 * @param boundHeight
	 * @return
	 * @throws IOException
	 */
	public static BufferedImage resizeToBound2(byte[] image, int boundWidth, int boundHeight) throws IOException {
		if (image == null)
			return null;
		BufferedImage bi = ImageUtil.getImage(image);

		if (bi.getHeight() <= boundHeight && bi.getWidth() <= boundWidth)
			return getImage(image);
		double scale = boundScale(bi.getWidth(), bi.getHeight(), boundWidth, boundHeight);
		bi = ImageUtil.resizeImage(scale, bi);
		return bi;
	}

	/**
	 * <span dir="rtl" style="font-family:tahoma"> نسبتي كه عكس بايد تغيير اندازه
	 * كند تا در يك طول و عرض بگنجد را برمي گرداند
	 *
	 * @param width
	 *            عرض عكس
	 * @param height
	 *            طول عكس
	 * @param boundWidth
	 *            عرض محدوده
	 * @param boundHeight
	 *            طول محدوده
	 * @return نسبت تغيير اندازه </span>
	 */
	public static double boundScale(int width, int height, int boundWidth, int boundHeight) {
		double wScale = boundWidth >= width ? 1 : (double) boundWidth / width;
		double hScale = boundHeight >= height ? 1 : (double) boundHeight / height;
		return wScale > hScale ? hScale : wScale;// return scale = minimum of wScale and hScale
	}

	/**
	 * @param img
	 * @return
	 */
	public static byte[] getImageContent(BufferedImage img, Format format) {
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream(60000);
			ImageIO.write(img, format.name(), out);
			return out.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Write rendered image to output by a format name
	 *
	 * @param im
	 * @param formatName
	 * @param outputx
	 * @return
	 * @throws IOException
	 */
	public static boolean write(RenderedImage im, Format format, OutputStream outputx) throws IOException {
		if (im == null) {
			throw new IllegalArgumentException("im == null!");
		}
		if (format == null) {
			throw new IllegalArgumentException("formatName == null!");
		}
		if (outputx == null) {
			throw new IllegalArgumentException("output == null!");
		}
		ImageWriter writer = null;
		ImageTypeSpecifier type = ImageTypeSpecifier.createFromRenderedImage(im);
		Iterator iter = ImageIO.getImageWriters(type, format.name());
		if (iter.hasNext()) {
			writer = (ImageWriter) iter.next();
		}
		if (writer == null) {
			return false;
		}
		ImageOutputStream output = ImageIO.createImageOutputStream(outputx);
		writer.setOutput(output);
		writer.write(im);
		output.flush();
		writer.dispose();
		return true;
	}

	/**
	 * <span dir="rtl" style="font-family:tahoma"> روي عكس مي نويسد
	 *
	 * @param uploadImage
	 * @return </span>
	 */
	public BufferedImage grafitiTextOnImage(BufferedImage uploadImage, String text, Font... font) {
		Font f = null;
		if (font.length == 0)
			f = new Font("Arial Black", 1, 10);
		else
			f = font[0];
		Graphics2D g2d = uploadImage.createGraphics();
		g2d.setFont(f);
		g2d.setColor(decodeHtmlColorString("FFFFFF"));
		g2d.drawString(text, 3, uploadImage.getHeight() - 3);
		g2d.setColor(decodeHtmlColorString("000000"));
		g2d.drawString(text, uploadImage.getWidth() - 40, uploadImage.getHeight() - 3);
		return uploadImage;
	}

	/**
	 * <span dir="rtl" style="font-family:tahoma;"> رنگهاي htmlي مانند FFFFFF را به
	 * كلاس Color تبديل مي كند
	 *
	 * @param colorString
	 * @return </span>
	 */
	public static Color decodeHtmlColorString(String colorString) {
		if (colorString.startsWith("#"))
			colorString = colorString.substring(1);
		if (colorString.endsWith(";"))
			colorString = colorString.substring(0, colorString.length() - 1);
		Color color;
		switch (colorString.length()) {
		case 6: // '\006'
		{
			int red = Integer.parseInt(colorString.substring(0, 2), 16);
			int green = Integer.parseInt(colorString.substring(2, 4), 16);
			int blue = Integer.parseInt(colorString.substring(4, 6), 16);
			color = new Color(red, green, blue);
			break;
		}
		case 3: // '\003'
		{
			int red = Integer.parseInt(colorString.substring(0, 1), 16);
			int green = Integer.parseInt(colorString.substring(1, 2), 16);
			int blue = Integer.parseInt(colorString.substring(2, 3), 16);
			color = new Color(red, green, blue);
			break;
		}
		case 1: // '\001'
		{
			int green;
			int blue;
			int red = green = blue = Integer.parseInt(colorString.substring(0, 1), 16);
			color = new Color(red, green, blue);
			break;
		}
		default: {
			throw new IllegalArgumentException(
					(new StringBuilder()).append("Invalid color: ").append(colorString).toString());
		}
		}
		return color;
	}

	private static float[] sharpKernel = { 0.0f, -1.0f, 0.0f, -1.0f, 5.0f, -1.0f, 0.0f, -1.0f, 0.0f };
	private static float[] filterMatrix = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	private static float ninth = 1.0f / 9.0f;
	private static float[] blurKernel = { ninth, ninth, ninth, ninth, ninth, ninth, ninth, ninth, ninth, };
	private static float[] edgeKernel = { 0.0f, -1.0f, 0.0f, -1.0f, 4.0f, -1.0f, 0.0f, -1.0f, 0.0f };

	public static BufferedImage sharpenImage(BufferedImage imageSrc) {
		BufferedImageOp filterer = createFilterOp(sharpKernel);
		return processImage(imageSrc, filterer);
	}

	public static BufferedImage grayscaleImage(BufferedImage imageSrc) {
		ColorSpace colorSpace = ColorSpace.getInstance(ColorSpace.CS_GRAY);
		ColorConvertOp op = new ColorConvertOp(colorSpace, null);
		BufferedImage tmp = createImageCopy(imageSrc);
		BufferedImage dest = null;
		dest = op.filter(tmp, dest);
		return dest;
	}

	/**
	 * @param imageSrc
	 * @param scaleFactor
	 *            1=same,positive less than 1 =darken,greater than 1 = lighten
	 * @return
	 */
	public static BufferedImage resacle(BufferedImage imageSrc, float scaleFactor) {
		BufferedImage dstImage = null;
		RescaleOp op = new RescaleOp(scaleFactor, 0.0f, null);
		BufferedImage tmp = createImageCopy(imageSrc);
		dstImage = op.filter(tmp, null);
		return dstImage;
	}

	public static BufferedImage blurImage(BufferedImage imageSrc) {
		BufferedImageOp filterer = createFilterOp(blurKernel);
		return processImage(imageSrc, filterer);
	}

	/**
	 * @param imageSrc
	 * @return
	 */
	public static BufferedImage thresholdImage(BufferedImage imageSrc) {
		BufferedImageOp filterer = createThresholdOp(128, 0, 255);
		return processImage(imageSrc, filterer);
	}

	/**
	 * @param imageSrc
	 * @param filterer
	 * @return
	 */
	public static BufferedImage processImage(BufferedImage imageSrc, BufferedImageOp filterer) {
		BufferedImage tmp = createImageCopy(imageSrc);
		BufferedImage dest = null;
		dest = filterer.filter(tmp, dest);
		return dest;
	}

	private static BufferedImage createImageCopy(BufferedImage imageSrc) {
		int width = imageSrc.getWidth();
		int height = imageSrc.getHeight();
		BufferedImage tmp = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++)
				tmp.setRGB(i, j, imageSrc.getRGB(i, j));
		}
		return tmp;
	}

	private static BufferedImageOp createFilterOp(float[] matrix) {
		BufferedImageOp filterer = new ConvolveOp(new Kernel(3, 3, matrix));
		return filterer;
	}

	private static BufferedImageOp createThresholdOp(int threshold, int minimum, int maximum) {
		short[] thresholdArray = new short[256];
		for (int i = 0; i < 256; i++) {
			if (i < threshold)
				thresholdArray[i] = (short) minimum;
			else
				thresholdArray[i] = (short) maximum;
		}
		return new LookupOp(new ShortLookupTable(0, thresholdArray), null);
	}

	public static BufferedImage resize(BufferedImage srcImage, double scale) {
		int width = (new Double(srcImage.getWidth() * scale)).intValue();
		int height = (new Double(srcImage.getHeight() * scale)).intValue();
		BufferedImage scaledImage = new BufferedImage(width, height, srcImage.getType());
		Graphics2D graphics2D = scaledImage.createGraphics();
		AffineTransform xform = AffineTransform.getScaleInstance(scale, scale);
		graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		graphics2D.drawImage(srcImage, xform, null);
		graphics2D.dispose();
		return scaledImage;
	}

	// public static byte[] setDPI(BufferedImage bufferedImage, int dpi) throws
	// IOException {
	// JPEGEncodeParam jpegEncodeParam =
	// JPEGCodec.getDefaultJPEGEncodeParam(bufferedImage);
	// jpegEncodeParam.setXDensity(dpi);
	// jpegEncodeParam.setYDensity(dpi);
	// jpegEncodeParam.setDensityUnit(JPEGDecodeParam.DENSITY_UNIT_DOTS_INCH);
	// jpegEncodeParam.setQuality(1f, false);
	//
	// ByteArrayOutputStream out = new ByteArrayOutputStream();
	// JPEGImageEncoder jpegEncoder = JPEGCodec.createJPEGEncoder(out);
	// jpegEncoder.encode(bufferedImage, jpegEncodeParam);
	// out.flush();
	// out.close();
	// return out.toByteArray();
	// }

}