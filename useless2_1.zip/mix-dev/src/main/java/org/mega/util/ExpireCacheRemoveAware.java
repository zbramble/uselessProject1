package org.mega.util;
/**
 * 
 * @author Golnari
 * ExpireCache class remove expired objects. Classes that use this cache should implement this interface method to
 * aware of removed object automaticly when it expires. 
 */
public interface ExpireCacheRemoveAware {
	void removed(String key, Object val);
}
