/**
 * 
 */
package org.mega.util;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Salarkia & Golnari
 * 
 */

public class TextUtil {
//	static ThirdPartyEncoder encoder;
//
//	static{
//		try {
//			TextUtil.encoder=(ThirdPartyEncoder)Class.forName(Config.THIRD_PARTY_ENCODER_CLASS).newInstance();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
	/**
	 * tools use in write for jsp pages
	 * 
	 * @param input
	 * @return an empty String in Case input String is null
	 */
	public static String write(Object input) {
		return write(input, "en");
	}
	// *********************************************************************************************************
	public static String write(Object input, String language) {
		if (input == null || "null".equals(input)
				|| input.toString().trim().length() == 0) {
			return "";
		}
		if ((input instanceof Double) || (input instanceof Integer)
				|| (input instanceof Long) || (input instanceof BigDecimal))
			return getLocaleNumber(DecimalFormat.getInstance().format(input),
					language);
		return getLocaleNumber(input.toString(), language);
	}
	// *********************************************************************************************************
	public static String write(Object input, Locale locale) {
		return write(input, locale == null ? "en" : locale.getLanguage());
	}
	// ********************************************************************************************************
	public static String getLocaleNumber(String number, Locale locale) {
		return getLocaleNumber(number, locale == null ? "en" : locale
				.getLanguage());
	}
	// ********************************************************************************************************
	public static String getLocaleNumber(String number, String language) {
		if (number == null || number.trim().length() == 0)
			return "";
		if ("fa".equals(language) || "ar".equals(language)) {
			char[] input = number.toCharArray();
			StringBuffer result = number.startsWith("-") ? // if negative number
			new StringBuffer("\u200E")
					: new StringBuffer();
			for (int i = 0; i < input.length; i++) {
				char c = input[i];
				if (Character.isDigit(c)) {
					result
							.append(toRigthToLeftNumber(Integer
									.parseInt(c + "")));
				} else {
					result.append(c);
				}
			}
			return result.toString().trim();
		}
		return number;
	}
	// ********************************************************************************************************
	public static String getLocaleNumber(Object number, Locale locale) {
		return getLocaleNumber(number, locale == null ? "en" : locale
				.getLanguage());
	}
	// ********************************************************************************************************
	public static String getLocaleNumber(Object number, String language) {
		if (number == null)
			return "";
		return getLocaleNumber(number.toString(), language);
	}
	// ********************************************************************************************************
	public static String toRigthToLeftNumber(int c) {
		switch (c) {
		case 0:
			return "\u06f0";
		case 1:
			return "\u06f1";
		case 2:
			return "\u06f2";
		case 3:
			return "\u06f3";
		case 4:
			return "\u06f4";
		case 5:
			return "\u06f5";
		case 6:
			return "\u06f6";
		case 7:
			return "\u06f7";
		case 8:
			return "\u06f8";
		case 9:
			return "\u06f9";
		}
		return "";
	}
	// ********************************************************************************************************
	public static String formatStringNumbersToAnsi(String input) {
		if (input == null || input.trim().length() == 0)
			return input;
		StringBuffer result = new StringBuffer();
		for (char c : input.toCharArray()) {
			if (Character.isDigit(c)) {
				result.append(Character.getNumericValue(c));
			} else {
				result.append(c);
			}
		}
		return result.toString();
	}
	// ********************************************************************************************************
	/**
	 * 
	 * @param imageName
	 * @return
	 */
	public static synchronized String getImage(String imageName) {
		if (imageName == null || imageName.trim().length() == 0)
			return "";
		return "../../images/" + imageName;
	}
	// *********************************************************************************************************

	// *********************************************************************************************************
	/**
	 * 
	 * @param language
	 * @return
	 */
	public static synchronized boolean isRigthToLeft(String language) {
		return "fa".equals(language);
	}
	// *********************************************************************************************************
	// *********************************************************************************************************
	public static synchronized String getDirection(String language) {
		return isRigthToLeft(language) ? "rtl" : "ltr";
	}
	// *********************************************************************************************************
	/**
	 * 
	 * @param s
	 * @return
	 */
	public static String encrypt(String s) {
		return s;
	}
	// *********************************************************************************************************
	/**
	 * 
	 * @param l
	 * @return
	 */
	public static String encript(long l) {
		return String.valueOf(l);
	}
	// *********************************************************************************************************
	/**
	 * 
	 * @param l
	 * @return
	 */
	public static String encript(String l) {
		return String.valueOf(l);
	}
	// *********************************************************************************************************
	/**
	 * 
	 * @param jsName
	 * @return
	 */
	public static String getJsFile(String jsFileName) {
		return "../../js/" + jsFileName;
	}
	// *********************************************************************************************************
	static String[] yekan = { "صفر", "يک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه" };
    static String[] dahgan = { "", "", "بيست", "سي", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود" };
    static String[] dahyek = {"ده", "يازده", "دوازده", "سيزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"};
    static String[] sadgan ={"", "يکصد", "دويست", "سيصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد" };
    static String[] basex  = { "", "هزار", "ميليون", "ميليارد", "تريليون"};

    public static String getnum3(long b)
    {
        String s = "";
        int d3;
        int d12;
        d12 = (int) (b % 100);
        d3 = (int) (b / 100);
        if (d3 != 0)
            s = sadgan[d3] + " و ";
        if ((d12 >= 10) && (d12 <= 19)){
            s = s + dahyek[d12 - 10];
        }
        else{
        	int d2 = d12 / 10;
            if (d2 != 0)
                s = s + dahgan[d2] + " و ";
            int d1 = d12 % 10;
            if (d1 != 0)
                s = s + yekan[d1] + " و ";
            s = s.substring(0, s.length() - 3);
        }
        return s;
    }

    public static String num2str(String snum){
        String stotal = "";
        if (snum == "0"){
            return yekan[0];
        }else{
            for (int i = snum.length(); i < (((snum.length() - 1) / 3) + 1) * 3; i++)
                snum = "0" + snum;
            long L = (snum.length() / 3) - 1;
            for (int i = 0; i <= L; i++){
                float b = Float.parseFloat(snum.substring(i * 3, (i + 1) * 3));
                if (b != 0)
                    stotal = stotal + getnum3((long) b) + " " + basex[(int) (L - i)] + " و ";
            }
            stotal = stotal.substring(0, stotal.length() - 3);
        }
        return stotal;
    }
    
    
    public static  String numberToString(long num) {
    	String str = String.valueOf(num); 
    	return TextUtil.num2str(str);
	}
    //end of number to string
	/**
	<span dir="rtl" style="font-family:tahoma">
	@param cut string to fit len
	@return
	</span>
	 */
	public static String cut(String str, int len) {
		try{
			return str.substring(0, str.indexOf(" ", len)) + " ...";
		}catch (Exception e) {
			return str;
		}
	}
	
	public static String toFarsi(String src){
		if(src == null)
			return null;
		return src.replaceAll("\\ك", "ک").replaceAll("\\ي", "ي");
	}
	
	public static String encryptPass(String pass) {
		pass += "`";
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("SHA");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return pass;
		}
		md.reset();
		md.update(pass.getBytes());
		byte[] d = md.digest();
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < d.length; i++) {
			buffer.append(Integer.toHexString(0xFF & d[i]));
		}
		return buffer.toString();
	}
	
	public static String justify(String src, int len, char gap, boolean rtl){
		StringBuilder s = new StringBuilder();
		for(int i =0; i < len - src.length(); i++){
			s.append(gap);
		}
		if(rtl)
			s.append(src);
		else
			s.insert(0,src);
		return s.toString();
	}
	
	public static Object setToString(Set<String> set, String containChar, String seperatorChar) {
		StringBuilder buf = new StringBuilder();
		for(String key:set){
			if(buf.length() > 0)
				buf.append(seperatorChar);	
			buf.append(containChar).append(key).append(containChar);
		}
		return buf.toString();
	}
	public static String getUserinfo(HttpServletRequest request) {
		if(request == null){
			return "NULL REQUEST";
		}
        String info = "Client: ";
		String s = request.getRemoteAddr();
		if (s != null && s.length() > 0 && !"unknown".equalsIgnoreCase(s)) {
			info += "ip = " + s + " | ";
		}
		s = request.getRemoteHost();
		if (s != null && s.length() > 0 && !"unknown".equalsIgnoreCase(s)) {
			info += "name = " + s + " | ";;
		}
		
		s = request.getAttribute("javax.servlet.error.request_uri") == null ? null : request.getAttribute("javax.servlet.error.request_uri").toString();
		if (s != null && s.length() > 0 && !"unknown".equalsIgnoreCase(s)) {
			info += "uri = " + s + " | ";;
		}
		;
		
		String[] names = {"user-agent", "X-Forwarded-For", "x-forwarded-for", "Proxy-Client-IP", "WL-Proxy-Client-IP","HTTP_CLIENT_IP","HTTP_X_FORWARDED_FOR","X-CLIENT-IP"};
		for(String name:names){
			s = request.getHeader(name);  
			if (s != null && s.length() > 0 && !"unknown".equalsIgnoreCase(s)) {
				info += name + " = " + s + " | ";
			}
        }  

        return info;  
	}
	
	public static String createTicket(int size) {
		StringBuilder buf = new StringBuilder();
		for(int i = 0; i < size; i++){
			buf.append((char)((Math.random() * ('~' - '!')) + '!'));
		}
		return buf.toString();
	}
	
	/*
	 * Make First Letter Upper Case After get for Getters and set after Setter
	 * Methods.
	 */
	public static String getFirstLetterUpperCase(String s) {
		return s.substring(0, 1).toUpperCase() + s.substring(1, s.length());
	}



}
