package org.mega.bse.currency;

import org.mega.core.base.BaseCopier;

public class CurrencyCopier extends BaseCopier<Currency, CurrencyDTO>{

	@Override
	public CurrencyDTO copyFromEntity(Currency currency) {
		CurrencyDTO currencyDTO = new CurrencyDTO();
		currencyDTO.setRowId(currency.getRowId());
		currencyDTO.setTitle(currency.getTitle());
		currencyDTO.setRate(currency.getRate());
		currencyDTO.setCurrencyAbbreviation(currency.getCurrencyAbbreviation());
		currencyDTO.setBaseCurrency(currency.isBaseCurrency());
		currencyDTO.setDescription(currency.getDescription());
		currencyDTO.setAccessKey(currency.getAccessKey());
		copyFromEntityBaseField(currency, currencyDTO);
		return currencyDTO;
	}

	@Override
	public Currency copyToEntity(CurrencyDTO currencyDTO) throws Exception {
		Currency currency = new Currency();
		currency.setRowId(currencyDTO.getRowId());
		currency.setTitle(currencyDTO.getTitle());
		currency.setRate(currencyDTO.getRate());
		currency.setCurrencyAbbreviation(currencyDTO.getCurrencyAbbreviation());
		currency.setBaseCurrency(currencyDTO.isBaseCurrency());
		currency.setDescription(currencyDTO.getDescription());
		currency.setAccessKey(currencyDTO.getAccessKey());
		copyToEntityBaseField(currency, currencyDTO);
		return currency;
	}

}
