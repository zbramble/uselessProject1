package org.mega.bse.versselcodes;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class VersselCodesFacade extends BaseFacade{
	private static VersselCodesCopier copier = new VersselCodesCopier();
	private static VersselCodesFacade facade = new VersselCodesFacade();
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static VersselCodesFacade getInstance() {
		return facade;
	}
}
