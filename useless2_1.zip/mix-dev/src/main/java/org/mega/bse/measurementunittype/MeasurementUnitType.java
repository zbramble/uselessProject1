package org.mega.bse.measurementunittype;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_MEASUREMENT_UNIT_TYPE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_MEASUREMENT_UNIT_TYPE", columnNames = "MEASUREMENT_UNIT_TYPE_ID") )
public class MeasurementUnitType extends BaseEntity{

	@Id
	@Column(name = "MEASUREMENT_UNIT_TYPE_ID")
	private long rowId;
	
	@Column(name = "MEASUREMENT_UNIT_TYPE_NAME", length = 110,nullable = false,updatable=false)
	private String measurementUnitName;
	
	@Column(name = "IS_DEFAULT")
	private boolean unitDefault;
	
	@Column(name = "CONVERSION_RATE")
	private double conversionRate;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getMeasurementUnitName() {
		return measurementUnitName;
	}

	public void setMeasurementUnitName(String measurementUnitName) {
		this.measurementUnitName = measurementUnitName;
	}

	public boolean isUnitDefault() {
		return unitDefault;
	}

	public void setUnitDefault(boolean unitDefault) {
		this.unitDefault = unitDefault;
	}

	public double getConversionRate() {
		return conversionRate;
	}

	public void setConversionRate(double conversionRate) {
		this.conversionRate = conversionRate;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = measurementUnitName;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = measurementUnitName;
    }
}
