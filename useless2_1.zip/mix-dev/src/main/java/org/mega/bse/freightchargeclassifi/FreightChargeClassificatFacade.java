package org.mega.bse.freightchargeclassifi;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class FreightChargeClassificatFacade extends BaseFacade{

	private static FreightChargeClassificatCopier copier = new FreightChargeClassificatCopier();
	private static FreightChargeClassificatFacade facade = new FreightChargeClassificatFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static FreightChargeClassificatFacade getInstance() {
		return facade;
	}
}
