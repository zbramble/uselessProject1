package org.mega.bse.measurementunittype;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class MeasurementUnitTypeFacade extends BaseFacade{
	private static MeasurementUnitTypeCopier copier = new MeasurementUnitTypeCopier();
	private static MeasurementUnitTypeFacade facade = new MeasurementUnitTypeFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static MeasurementUnitTypeFacade getInstance() {
		return facade;
	}
}
