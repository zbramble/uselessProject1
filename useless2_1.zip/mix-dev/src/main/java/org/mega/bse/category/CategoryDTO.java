package org.mega.bse.category;

import org.mega.core.base.BaseDTO;

public class CategoryDTO extends BaseDTO {
	private long rowId;
	private CategoryDTO topCategoryDTO;
	private String categoryDescription;
	private String description;
	private boolean enable;
	private String accessKey;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public CategoryDTO getTopCategoryDTO() {
		return topCategoryDTO;
	}
	public void setTopCategoryDTO(CategoryDTO topCategoryDTO) {
		this.topCategoryDTO = topCategoryDTO;
	}
	public String getCategoryDescription() {
		return categoryDescription;
	}
	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isEnable() {
		return enable;
	}
	public void setEnable(boolean enable) {
		this.enable = enable;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	
}
