package org.mega.bse.brand;

import org.mega.core.base.BaseCopier;

public class BrandCopier extends BaseCopier<Brand, BrandDTO>{

	@Override
	public BrandDTO copyFromEntity(Brand brand) {
		BrandDTO brandDTO = new BrandDTO();
		brandDTO.setRowId(brand.getRowId());
		brandDTO.setAccessKey(brand.getAccessKey());
		brandDTO.setBrandTitle(brand.getBrandTitle());
		brandDTO.setSlogan(brand.getSlogan());
		brandDTO.setDescription(brand.getDescription());
		copyFromEntityBaseField(brand, brandDTO);
		return brandDTO;
	}

	@Override
	public Brand copyToEntity(BrandDTO brandDTO) throws Exception {
		Brand brand = new Brand();
		brand.setRowId(brandDTO.getRowId());
		brand.setBrandTitle(brandDTO.getBrandTitle());
		brand.setAccessKey(brandDTO.getAccessKey());
		brand.setDescription(brandDTO.getDescription());
		brand.setSlogan(brandDTO.getSlogan());
		copyToEntityBaseField(brand, brandDTO);
		return brand;
	}

}
