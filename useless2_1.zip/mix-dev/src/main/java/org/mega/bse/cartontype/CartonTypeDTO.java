package org.mega.bse.cartontype;

import javax.persistence.Column;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.mega.bse.measurementunittype.MeasurementUnitType;
import org.mega.bse.measurementunittype.MeasurementUnitTypeDTO;
import org.mega.core.base.BaseDTO;

public class CartonTypeDTO extends BaseDTO{

	private long rowId;
	private MeasurementUnitTypeDTO measurementUnitTypeDTO;
	private String cartonTypeTitle;
	private double height;
	private double width;
	private double length;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public MeasurementUnitTypeDTO getMeasurementUnitTypeDTO() {
		return measurementUnitTypeDTO;
	}
	public void setMeasurementUnitTypeDTO(MeasurementUnitTypeDTO measurementUnitTypeDTO) {
		this.measurementUnitTypeDTO = measurementUnitTypeDTO;
	}
	public String getCartonTypeTitle() {
		return cartonTypeTitle;
	}
	public void setCartonTypeTitle(String cartonTypeTitle) {
		this.cartonTypeTitle = cartonTypeTitle;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	
}
