package org.mega.bse.cartontype;

import org.mega.bse.measurementunittype.MeasurementUnitType;
import org.mega.bse.measurementunittype.MeasurementUnitTypeDTO;
import org.mega.core.base.BaseCopier;

public class CartonTypeCopier extends BaseCopier<CartonType, CartonTypeDTO>{

	@Override
	public CartonTypeDTO copyFromEntity(CartonType cartonType) {
		CartonTypeDTO cartonTypeDTO = new CartonTypeDTO();
		cartonTypeDTO.setRowId(cartonType.getRowId());
		cartonTypeDTO.setCartonTypeTitle(cartonType.getCartonTypeTitle());
		cartonTypeDTO.setHeight(cartonType.getHeight());
		cartonTypeDTO.setLength(cartonType.getLength());
		cartonTypeDTO.setWidth(cartonType.getWidth());
		if(cartonType.getMeasurementUnitType() != null){
			MeasurementUnitTypeDTO measurementUnitTypeDTO = new MeasurementUnitTypeDTO();
			measurementUnitTypeDTO.setRowId(cartonType.getMeasurementUnitType().getRowId());
			measurementUnitTypeDTO.setMeasurementUnitName(cartonType.getMeasurementUnitType().getMeasurementUnitName());
			cartonTypeDTO.setMeasurementUnitTypeDTO(measurementUnitTypeDTO);
		}
		copyFromEntityBaseField(cartonType, cartonTypeDTO);
		return cartonTypeDTO;
	}

	@Override
	public CartonType copyToEntity(CartonTypeDTO cartonTypeDTO) throws Exception {
		CartonType cartonType = new CartonType();
		cartonType.setRowId(cartonTypeDTO.getRowId());
		cartonType.setCartonTypeTitle(cartonTypeDTO.getCartonTypeTitle());
		cartonType.setHeight(cartonTypeDTO.getHeight());
		cartonType.setLength(cartonTypeDTO.getLength());
		cartonType.setWidth(cartonTypeDTO.getWidth());
		if(cartonTypeDTO.getMeasurementUnitTypeDTO() != null){
			MeasurementUnitType measurementUnitType = new MeasurementUnitType();
			measurementUnitType.setRowId(cartonTypeDTO.getMeasurementUnitTypeDTO().getRowId());
			measurementUnitType.setMeasurementUnitName(cartonTypeDTO.getMeasurementUnitTypeDTO().getMeasurementUnitName());
			cartonType.setMeasurementUnitType(measurementUnitType);
		}
		copyToEntityBaseField(cartonType, cartonTypeDTO);
		return cartonType;
	}

}
