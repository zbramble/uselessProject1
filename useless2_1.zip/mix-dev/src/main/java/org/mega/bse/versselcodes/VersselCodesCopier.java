package org.mega.bse.versselcodes;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;

public class VersselCodesCopier extends BaseCopier<VersselCodes, VersselCodesDTO> {

	@Override
	public VersselCodesDTO copyFromEntity(VersselCodes versselCodes) {
		VersselCodesDTO versselCodesDTO = new VersselCodesDTO();
		versselCodesDTO.setRowId(versselCodes.getRowId());
		versselCodesDTO.setName(versselCodes.getName());
		versselCodesDTO.setMmsi(versselCodes.getMmsi());
		versselCodesDTO.setImo(versselCodes.getImo());
		if(versselCodes.getType() != null){
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(versselCodes.getType().getRowId());
			cDTO.setName(versselCodes.getType().getName());
			versselCodesDTO.setTypeDTO(cDTO);
		}
		if(versselCodes.getFlag() != null){
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(versselCodes.getFlag().getRowId());
			cDTO.setName(versselCodes.getFlag().getName());
			versselCodesDTO.setFlagDTO(cDTO);
		}
		copyFromEntityBaseField(versselCodes, versselCodesDTO);
		return versselCodesDTO;
	}

	@Override
	public VersselCodes copyToEntity(VersselCodesDTO versselCodesDTO) throws Exception {
		VersselCodes versselCodes = new VersselCodes();
		versselCodes.setRowId(versselCodesDTO.getRowId());
		versselCodes.setName(versselCodesDTO.getName());
		versselCodes.setMmsi(versselCodesDTO.getMmsi());
		versselCodes.setImo(versselCodesDTO.getImo());
		if(versselCodesDTO.getTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(versselCodesDTO.getTypeDTO().getRowId());
			c.setName(versselCodesDTO.getTypeDTO().getName());
			versselCodes.setType(c);
		}
		if(versselCodesDTO.getFlagDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(versselCodesDTO.getFlagDTO().getRowId());
			c.setName(versselCodesDTO.getFlagDTO().getName());
			versselCodes.setFlag(c);
		}
		copyToEntityBaseField(versselCodes, versselCodesDTO);
		return versselCodes;
	}

}
