package org.mega.bse.freightchargetype;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class FreightChargeTypeFacade extends BaseFacade{
	private static FreightChargeTypeCopier copier = new FreightChargeTypeCopier();
	private static FreightChargeTypeFacade facade = new FreightChargeTypeFacade();

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static FreightChargeTypeFacade getInstance() {
		return facade;
	}
}
