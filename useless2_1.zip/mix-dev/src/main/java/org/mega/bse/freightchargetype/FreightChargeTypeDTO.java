package org.mega.bse.freightchargetype;

import org.mega.bse.currency.CurrencyDTO;
import org.mega.bse.freightchargeclassifi.FreightChargeClassificatDTO;
import org.mega.core.base.BaseDTO;

public class FreightChargeTypeDTO extends BaseDTO{

	private long rowId;
	private FreightChargeClassificatDTO classificatDTO;
	private CurrencyDTO currencyTypeDTO;
	private String chargeTypeTitle;
	private double rate;
	private double specialRate;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public FreightChargeClassificatDTO getClassificatDTO() {
		return classificatDTO;
	}
	public void setClassificatDTO(FreightChargeClassificatDTO classificatDTO) {
		this.classificatDTO = classificatDTO;
	}
	public CurrencyDTO getCurrencyTypeDTO() {
		return currencyTypeDTO;
	}
	public void setCurrencyTypeDTO(CurrencyDTO currencyTypeDTO) {
		this.currencyTypeDTO = currencyTypeDTO;
	}
	public String getChargeTypeTitle() {
		return chargeTypeTitle;
	}
	public void setChargeTypeTitle(String chargeTypeTitle) {
		this.chargeTypeTitle = chargeTypeTitle;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public double getSpecialRate() {
		return specialRate;
	}
	public void setSpecialRate(double specialRate) {
		this.specialRate = specialRate;
	}

}
