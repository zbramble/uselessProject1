package org.mega.bse.freightchargetype;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.currency.Currency;
import org.mega.bse.freightchargeclassifi.FreightChargeClassificat;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_FREIGHT_CHARGE_TYPE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_FREIGHT_CHARGE_TYPE", columnNames = "BSE_FREIGHT_CHARGE_TYPE_ID"))
public class FreightChargeType extends BaseEntity {

	@Id
	@Column(name = "BSE_FREIGHT_CHARGE_TYPE_ID")
	private long rowId;

	@ManyToOne()
	@JoinColumn(name = "CLASSIFICATION_ID", foreignKey = @ForeignKey(name = "FK_BSE_FREI_CLASSIFICAT"), nullable = true)
	private FreightChargeClassificat classificat;

	@ManyToOne()
	@JoinColumn(name = "CURRENCY_TYPE_ID", foreignKey = @ForeignKey(name = "FK_BSE_FREI_REFERENCE_BSE_CURR"), nullable = true)
	private Currency currencyType;

	@Column(name = "FREIGHT_CHARGE_TYPE_TITLE", length = 200)
	private String chargeTypeTitle;

	@Column(name = "RATE")
	private double rate;

	@Column(name = "SPECIAL_RATE")
	private double specialRate;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public FreightChargeClassificat getClassificat() {
		return classificat;
	}

	public void setClassificat(FreightChargeClassificat classificat) {
		this.classificat = classificat;
	}

	public Currency getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(Currency currencyType) {
		this.currencyType = currencyType;
	}

	public String getChargeTypeTitle() {
		return chargeTypeTitle;
	}

	public void setChargeTypeTitle(String chargeTypeTitle) {
		this.chargeTypeTitle = chargeTypeTitle;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getSpecialRate() {
		return specialRate;
	}

	public void setSpecialRate(double specialRate) {
		this.specialRate = specialRate;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = chargeTypeTitle;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = chargeTypeTitle;
	}

}
