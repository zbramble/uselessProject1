package org.mega.bse.versselcodes;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;

public class VersselCodesDTO extends BaseDTO {
	private long rowId;
	private String name;
	private int imo;
	private int mmsi;
	private ComboValDTO typeDTO;
	private ComboValDTO flagDTO;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getImo() {
		return imo;
	}

	public void setImo(int imo) {
		this.imo = imo;
	}

	public int getMmsi() {
		return mmsi;
	}

	public void setMmsi(int mmsi) {
		this.mmsi = mmsi;
	}

	public ComboValDTO getTypeDTO() {
		return typeDTO;
	}

	public void setTypeDTO(ComboValDTO typeDTO) {
		this.typeDTO = typeDTO;
	}

	public ComboValDTO getFlagDTO() {
		return flagDTO;
	}

	public void setFlagDTO(ComboValDTO flagDTO) {
		this.flagDTO = flagDTO;
	}

}
