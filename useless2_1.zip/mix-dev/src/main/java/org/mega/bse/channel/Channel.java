package org.mega.bse.channel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
@Entity
@Table(name = "BSE_CHANNEL", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_CHANNEL", columnNames = "BSE_CHANNEL_ID") )
public class Channel extends BaseEntity{

	
	@Id
	@Column(name = "BSE_CHANNEL_ID")
	private long rowId;
	
	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;

	@Column(name = "DESCRIPTION", length = 500,nullable = true)
	private String description;

	@Column(name = "CHANNEL_NAME", length = 300,nullable = true)
	private String channelName;
	
	
	
	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = channelName;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = channelName;
    }
}
