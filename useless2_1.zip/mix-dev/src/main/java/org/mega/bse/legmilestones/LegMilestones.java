package org.mega.bse.legmilestones;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;

@Entity
@Table(name = "BSE_LEG_MILESTONE", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_LEG_MILESTONE", columnNames = "BSE_LEG_MILESTONE"))
public class LegMilestones extends BaseEntity {

	@Id
	@Column(name = "BSE_LEG_MILESTONE")
	private long rowId;

	@Column(name = "BSE_LEG_MILESTONE_NAME", length = 50)
	private String milestoneName;

	@Column(name = "DEFAULT_DAYS_DUE_BEFORE_DEPART")
	private int departureDays;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SHIPMENT_LEG_TYPE_ID", foreignKey = @ForeignKey(name = "FK_SHIPMENT_LEG_TYPE_COMBO"), nullable = true)
	private ComboVal legType;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SCOPE_TYPE_ID", foreignKey = @ForeignKey(name = "FK_SCOPE_TYPE_COMBO"), nullable = true)
	private ComboVal scopeType;

	@Column(name = "NEED_TRACKING_INFO")
	private boolean trackingInfo;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public String getMilestoneName() {
		return milestoneName;
	}

	public void setMilestoneName(String milestoneName) {
		this.milestoneName = milestoneName;
	}

	public int getDepartureDays() {
		return departureDays;
	}

	public void setDepartureDays(int departureDays) {
		this.departureDays = departureDays;
	}

	public ComboVal getLegType() {
		return legType;
	}

	public void setLegType(ComboVal legType) {
		this.legType = legType;
	}

	public boolean isTrackingInfo() {
		return trackingInfo;
	}

	public void setTrackingInfo(boolean trackingInfo) {
		this.trackingInfo = trackingInfo;
	}

	public ComboVal getScopeType() {
		return scopeType;
	}

	public void setScopeType(ComboVal scopeType) {
		this.scopeType = scopeType;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = milestoneName;
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = milestoneName;
	}

}
