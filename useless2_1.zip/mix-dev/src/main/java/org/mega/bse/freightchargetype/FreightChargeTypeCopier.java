package org.mega.bse.freightchargetype;

import org.mega.bse.currency.Currency;
import org.mega.bse.currency.CurrencyDTO;
import org.mega.bse.freightchargeclassifi.FreightChargeClassificat;
import org.mega.bse.freightchargeclassifi.FreightChargeClassificatDTO;
import org.mega.core.base.BaseCopier;

public class FreightChargeTypeCopier extends BaseCopier<FreightChargeType, FreightChargeTypeDTO>{

	@Override
	public FreightChargeTypeDTO copyFromEntity(FreightChargeType chargeType) {
		FreightChargeTypeDTO chargeTypeDTO = new FreightChargeTypeDTO();
		chargeTypeDTO.setRowId(chargeType.getRowId());
		chargeTypeDTO.setChargeTypeTitle(chargeType.getChargeTypeTitle());
		chargeTypeDTO.setRate(chargeType.getRate());
		chargeTypeDTO.setSpecialRate(chargeType.getSpecialRate());
		if(chargeType.getClassificat() != null){
			FreightChargeClassificatDTO classificatDTO = new FreightChargeClassificatDTO();
			classificatDTO.setRowId(chargeType.getClassificat().getRowId());
			classificatDTO.setClassificationTitle(chargeType.getClassificat().getClassificationTitle());
			chargeTypeDTO.setClassificatDTO(classificatDTO);
		}
		if(chargeType.getCurrencyType() != null){
			CurrencyDTO currencyDTO = new CurrencyDTO();
			currencyDTO.setRowId(chargeType.getCurrencyType().getRowId());
			currencyDTO.setTitle(chargeType.getCurrencyType().getTitle());
			chargeTypeDTO.setCurrencyTypeDTO(currencyDTO);
		}
		copyFromEntityBaseField(chargeType, chargeTypeDTO);
		return chargeTypeDTO;
	}

	@Override
	public FreightChargeType copyToEntity(FreightChargeTypeDTO chargeTypeDTO) throws Exception {
		FreightChargeType chargeType = new FreightChargeType();
		chargeType.setRowId(chargeTypeDTO.getRowId());
		chargeType.setChargeTypeTitle(chargeTypeDTO.getChargeTypeTitle());
		if(chargeTypeDTO.getClassificatDTO() != null){
			FreightChargeClassificat classificat = new FreightChargeClassificat();
			classificat.setRowId(chargeTypeDTO.getClassificatDTO().getRowId());
			classificat.setClassificationTitle(chargeTypeDTO.getClassificatDTO().getClassificationTitle());
			chargeType.setClassificat(classificat);
		}
		if(chargeTypeDTO.getCurrencyTypeDTO() != null){
			Currency currency = new Currency();
			currency.setRowId(chargeTypeDTO.getCurrencyTypeDTO().getRowId());
			currency.setTitle(chargeTypeDTO.getCurrencyTypeDTO().getTitle());
			chargeType.setCurrencyType(currency);
		}
		chargeType.setRate(chargeTypeDTO.getRate());
		chargeType.setSpecialRate(chargeTypeDTO.getSpecialRate());	
		copyToEntityBaseField(chargeType, chargeTypeDTO);
		return chargeType;
	}

}
