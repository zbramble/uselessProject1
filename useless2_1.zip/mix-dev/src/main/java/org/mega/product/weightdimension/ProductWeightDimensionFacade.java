package org.mega.product.weightdimension;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class ProductWeightDimensionFacade extends BaseFacade{
	private static ProductWeightDimensionCopier copier = new ProductWeightDimensionCopier();
	private static ProductWeightDimensionFacade facade = new ProductWeightDimensionFacade();
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductWeightDimensionDTO productWeight = (ProductWeightDimensionDTO) baseDTO;
		if(productWeight.getRowId() == 0)
			productWeight.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductWeightDimensionFacade getInstance() {
		return facade;
	}
}
