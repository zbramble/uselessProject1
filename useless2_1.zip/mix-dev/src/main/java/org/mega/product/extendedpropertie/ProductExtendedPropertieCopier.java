package org.mega.product.extendedpropertie;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.File;
import org.mega.core.file.FileDTO;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductExtendedPropertieCopier extends BaseCopier<ProductExtendedPropertie, ProductExtendedPropertieDTO>{

	@Override
	public ProductExtendedPropertieDTO copyFromEntity(ProductExtendedPropertie extendedPropertie) {
		ProductExtendedPropertieDTO extendedPropertieDTO = new ProductExtendedPropertieDTO();
		extendedPropertieDTO.setAccessKey(extendedPropertie.getAccessKey());
		extendedPropertieDTO.setDescription(extendedPropertie.getDescription());
		if(extendedPropertie.getDataType() != null){
			ComboValDTO cDTO = new ComboValDTO();
			cDTO.setRowId(extendedPropertie.getDataType().getRowId());
			cDTO.setName(extendedPropertie.getDataType().getName());
			extendedPropertieDTO.setDataTypeDTO(cDTO);
		}
		if(extendedPropertie.getPropertyFile() != null){
			FileDTO fDTO = new FileDTO();
			fDTO.setRowId(extendedPropertie.getPropertyFile().getRowId());
			extendedPropertieDTO.setPropertyFile(fDTO);
		}
		if(extendedPropertie.getProduct() != null){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(extendedPropertie.getProduct().getRowId());
			pDTO.setProductTitle(extendedPropertie.getProduct().getProductTitle());
			extendedPropertieDTO.setProductDTO(pDTO);
		}
		extendedPropertieDTO.setPropertyName(extendedPropertie.getPropertyName());
		extendedPropertieDTO.setPropertyValue(extendedPropertie.getPropertyValue());
		extendedPropertieDTO.setRowId(extendedPropertie.getRowId());
		copyFromEntityBaseField(extendedPropertie, extendedPropertieDTO);
		return extendedPropertieDTO;
	}

	@Override
	public ProductExtendedPropertie copyToEntity(ProductExtendedPropertieDTO extendedPropertieDTO) throws Exception {
		ProductExtendedPropertie extendedPropertie = new ProductExtendedPropertie();
		extendedPropertie.setAccessKey(extendedPropertieDTO.getAccessKey());
		extendedPropertie.setDescription(extendedPropertieDTO.getDescription());
		if(extendedPropertieDTO.getDataTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(extendedPropertieDTO.getDataTypeDTO().getRowId());
			c.setName(extendedPropertieDTO.getDataTypeDTO().getName());
			extendedPropertie.setDataType(c);
		}
		//extendedPropertie.setPropertyFile(extendedPropertieDTO.getPropertyFile());
		if(extendedPropertieDTO.getPropertyFile() != null){
			File f = new File();
			f.setRowId(extendedPropertieDTO.getPropertyFile().getRowId());
			extendedPropertie.setPropertyFile(f);
		}
		if(extendedPropertieDTO.getProductDTO() != null){
			Product p = new Product();
			p.setRowId(extendedPropertieDTO.getProductDTO().getRowId());
			p.setProductTitle(extendedPropertieDTO.getProductDTO().getProductTitle());
			extendedPropertie.setProduct(p);
		}
		extendedPropertie.setPropertyName(extendedPropertieDTO.getPropertyName());
		extendedPropertie.setPropertyValue(extendedPropertieDTO.getPropertyValue());
		extendedPropertie.setRowId(extendedPropertieDTO.getRowId());
		copyToEntityBaseField(extendedPropertie, extendedPropertieDTO);
		return extendedPropertie;
	}

}
