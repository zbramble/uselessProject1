package org.mega.product.channelsku;

import org.mega.bse.site.Site;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductChannelSKUCopier extends BaseCopier<ProductChannelSKU, ProductChannelSKUDTO>{

	@Override
	public ProductChannelSKUDTO copyFromEntity(ProductChannelSKU channelSKU) {
		ProductChannelSKUDTO channelSKUDTO = new ProductChannelSKUDTO();
		channelSKUDTO.setRowId(channelSKU.getRowId());
		channelSKUDTO.setAccessKey(channelSKU.getAccessKey());
		channelSKUDTO.setDescription(channelSKU.getDescription());
		channelSKUDTO.setNotes(channelSKU.getNotes());
		if(channelSKU.getProduct() != null){
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(channelSKU.getProduct().getRowId());
			channelSKUDTO.setProductDTO(pDTO);
		}
		if(channelSKU.getSite() != null){
			SiteDTO sDTO = new SiteDTO();
			sDTO.setRowId(channelSKU.getSite().getRowId());
			channelSKUDTO.setSiteDTO(sDTO);
		}
		copyFromEntityBaseField(channelSKU, channelSKUDTO);
		return channelSKUDTO;
	}

	@Override
	public ProductChannelSKU copyToEntity(ProductChannelSKUDTO channelSKUDTO) throws Exception {
		ProductChannelSKU channelSKU = new ProductChannelSKU();
		channelSKU.setRowId(channelSKUDTO.getRowId());
		channelSKU.setAccessKey(channelSKUDTO.getAccessKey());
		channelSKU.setDescription(channelSKUDTO.getDescription());
		channelSKU.setNotes(channelSKUDTO.getNotes());
		if(channelSKUDTO.getProductDTO() != null){
			Product p = new Product();
			p.setRowId(channelSKUDTO.getProductDTO().getRowId());
			channelSKU.setProduct(p);
		}
		if(channelSKUDTO.getSiteDTO() != null){
			Site s = new Site();
			s.setRowId(channelSKUDTO.getSiteDTO().getRowId());
			channelSKU.setSite(s);
		}
		copyToEntityBaseField(channelSKU, channelSKUDTO);
		return channelSKU;
	}
	
	
}
