package org.mega.product.channelsku;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class ProductChannelSKUFacade extends BaseFacade{
	
	private static ProductChannelSKUCopier copier = new ProductChannelSKUCopier();
	private static ProductChannelSKUFacade facade = new ProductChannelSKUFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductChannelSKUFacade getInstance() {
		return facade;
	}

}
