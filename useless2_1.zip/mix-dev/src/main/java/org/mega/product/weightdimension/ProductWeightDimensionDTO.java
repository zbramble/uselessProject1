package org.mega.product.weightdimension;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductWeightDimensionDTO extends BaseDTO{
	private long rowId;
	private ProductDTO productDTO;
	private ComboValDTO weightUnitDTO;
	private ComboValDTO dimensionUnitDTO;
	private ComboValDTO volumeUnitDTO;
	private double weight;
	private double width;
	private double height;
	private double depth;
	private double volume;
	private int unitsInCarton; 
	private double cartonWidth;
	private double cartonheight;
	private double cartonDepth;
	private double cartonVolume;
	private String description;
	private String accessKey;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public ComboValDTO getWeightUnitDTO() {
		return weightUnitDTO;
	}
	public void setWeightUnitDTO(ComboValDTO weightUnitDTO) {
		this.weightUnitDTO = weightUnitDTO;
	}
	public ComboValDTO getDimensionUnitDTO() {
		return dimensionUnitDTO;
	}
	
	public ComboValDTO getVolumeUnitDTO() {
		return volumeUnitDTO;
	}
	public void setVolumeUnitDTO(ComboValDTO volumeUnitDTO) {
		this.volumeUnitDTO = volumeUnitDTO;
	}
	public void setDimensionUnitDTO(ComboValDTO dimensionUnitDTO) {
		this.dimensionUnitDTO = dimensionUnitDTO;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getDepth() {
		return depth;
	}
	public void setDepth(double depth) {
		this.depth = depth;
	}
	public double getVolume() {
		return volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}
	public int getUnitsInCarton() {
		return unitsInCarton;
	}
	public void setUnitsInCarton(int unitsInCarton) {
		this.unitsInCarton = unitsInCarton;
	}
	public double getCartonWidth() {
		return cartonWidth;
	}
	public void setCartonWidth(double cartonWidth) {
		this.cartonWidth = cartonWidth;
	}
	public double getCartonheight() {
		return cartonheight;
	}
	public void setCartonheight(double cartonheight) {
		this.cartonheight = cartonheight;
	}
	public double getCartonDepth() {
		return cartonDepth;
	}
	public void setCartonDepth(double cartonDepth) {
		this.cartonDepth = cartonDepth;
	}
	public double getCartonVolume() {
		return cartonVolume;
	}
	public void setCartonVolume(double cartonVolume) {
		this.cartonVolume = cartonVolume;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	

}
