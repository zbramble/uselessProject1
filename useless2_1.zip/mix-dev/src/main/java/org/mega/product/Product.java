package org.mega.product;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.brand.Brand;
import org.mega.bse.category.Category;
import org.mega.bse.currency.Currency;
import org.mega.bse.tax.Tax;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;

@Entity
@Table(name = "PRODUCT", uniqueConstraints = @UniqueConstraint(name = "PK_PRODUCT", columnNames = "PRODUCT_ID") )
public class Product extends BaseEntity {

	@Id
	@Column(name = "PRODUCT_ID")
	private long rowId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "RELATED_PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERENCE_PRODUCT") , nullable = true)
	private Product relatedProduct;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CATEGORY_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERENCE_BSE_PROD") , nullable = true)
	private Category category;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_RELATIONSHIP_TYPE_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_RELATIONSHIP_TYPE") , nullable = true)
	private ComboVal relationShipType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TAX_CLASS_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERENCE_BSE_TAX_") , nullable = true)
	private Tax taxClass;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CURRENCY_TYPE_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERENCE_BSE_CURR") , nullable = true)
	private Currency currencyType;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BRAND_ID", foreignKey = @ForeignKey(name = "FK_PRODUCT_REFERENCE_BSE_BRAN") , nullable = true)
	private Brand brand;

	@Column(name = "MBI_SKU", length = 30,nullable = false)
	private String sku;

	@Column(name = "MANUFACTURER_SKU", length = 30)
	private String manufactureSku;

	@Column(name = "BARCODE", length = 30)
	private String barcode;

	@Column(name = "PRODUCT_TITLE", length = 500,nullable = false)
	private String productTitle;

	@Column(name = "RETAIL_PRICE")
	private double realPrice;

	@Column(name = "SALE_PRICE")
	private double salePrice;

	@Column(name = "TAX_AMOUNT")
	private double taxAmount;

	@Column(name = "ACCESS_KEY", length = 110,nullable = false,updatable=false)
	private String accessKey;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Product getRelatedProduct() {
		return relatedProduct;
	}

	public void setRelatedProduct(Product relatedProduct) {
		this.relatedProduct = relatedProduct;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	public ComboVal getRelationShipType() {
		return relationShipType;
	}
	
	public void setRelationShipType(ComboVal relationShipType) {
		this.relationShipType = relationShipType;
	}
	
	public Tax getTaxClass() {
		return taxClass;
	}

	public void setTaxClass(Tax taxClass) {
		this.taxClass = taxClass;
	}

	public Currency getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(Currency currencyType) {
		this.currencyType = currencyType;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getManufactureSku() {
		return manufactureSku;
	}

	public void setManufactureSku(String manufactureSku) {
		this.manufactureSku = manufactureSku;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public double getRealPrice() {
		return realPrice;
	}

	public void setRealPrice(double realPrice) {
		this.realPrice = realPrice;
	}

	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getAccessKey() {
		return accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = productTitle;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = productTitle;
    }
}
