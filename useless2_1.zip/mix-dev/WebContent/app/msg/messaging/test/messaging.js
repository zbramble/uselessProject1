/*----------------------------------------------------------------------------- Variable -----------------------------*/
var lastRecordShowed = new Map();
var firstRecordShowed = new Map();
var rooms = new Map();
var currentRoom;

/*----------------------------------------------------------------------------- Create Conversation Room Item --------*/
function createConversationRoomItem(data) {
    <!--Conversation Room Item-->
    var li = document.createElement('li');
    li.setAttribute('class', 'msg-conversations-container__convo-item');
    li.setAttribute('id', data.rowId);

    <!-- --a-->
    var a = document.createElement('a');
    a.setAttribute('href', '#');
    a.setAttribute('class', 'msg-conversations-container__convo-item-link');
    li.append(a);

    <!-- --Conversation Room-->
    var divConversationRoom = document.createElement('div');
    divConversationRoom.setAttribute('class', 'msg-conversation-card');
    a.append(divConversationRoom);

    <!-- -- --Conversation Room Image-->
    var divConversationRoomImage = document.createElement('div');
    divConversationRoomImage.setAttribute('class', 'msg-facepile-grid msg-facepile-grid--group-size-1');
    divConversationRoom.append(divConversationRoomImage);

    <!-- -- -- --Image-->
    var img = document.createElement('img');
    img.setAttribute('class', 'lazy-image msg-facepile-grid__img loaded');
    img.setAttribute('src', 'user1.jpg');
    divConversationRoomImage.append(img);

    <!-- -- --Conversation Room Content-->
    var divConversationRoomContent = document.createElement('div');
    divConversationRoomContent.setAttribute('class', 'msg-conversation-card__content');
    divConversationRoom.append(divConversationRoomContent);

    <!-- -- -- --Top-->
    var divConversationRoomContentTop = document.createElement('div');
    divConversationRoomContentTop.setAttribute('class', 'msg-conversation-card__row pr2');
    divConversationRoomContent.append(divConversationRoomContentTop);

    <!-- -- -- -- --Conversation Room Name-->
    var h3ConversationRoomName = document.createElement('h3');
    h3ConversationRoomName.setAttribute('class', 'msg-conversation-card__participant-names Sans-17px-black-70% truncate pr1 mb1');

    if (!data.name) {
        $.each(data.conversationUsersLists, function (index, value) {
            if (value.user.rowId != user.userId) {
                data.name = value.user.fullTitle;
            }
        });
    }
    data.name = data.name ? data.name : 'You' ;
    h3ConversationRoomName.innerHTML = data.name ;
    divConversationRoomContentTop.append(h3ConversationRoomName);
    a.setAttribute('title', "User:" + data.name + " - LastMessageTime:" + data.updated);

    <!-- -- -- -- --Conversation Room Action-->
    var divConversationRoomAction = document.createElement('div');
    divConversationRoomAction.setAttribute('class', 'msg-conversation-card__convo-utility');
    divConversationRoomContentTop.append(divConversationRoomAction);

    <!-- -- -- -- -- --Conversation Room delete-->
    var buttonConversationRoomDelete = document.createElement('button');
    buttonConversationRoomDelete.setAttribute('class', 'msg-conversation-card__list-action msg-conversation-card__delete');
    buttonConversationRoomDelete.setAttribute('id', 'clear_conversation_' + "1");
    divConversationRoomAction.append(buttonConversationRoomDelete);

    <!-- -- -- -- -- -- -- --span-->
    var span = document.createElement("span");
    span.setAttribute('class', 'ion-trash-b');
    span.style.fontSize = '20px';
    span.style.color = 'rgba(86, 86, 87, 0.73)';
    buttonConversationRoomDelete.append(span);

    <!-- -- -- -- -- --Conversation Room Last Time-->
    var time = document.createElement('time');
    time.setAttribute('class', 'msg-conversation-card__time-stamp Sans-15px-black-55%');
    time.innerHTML = data.updated.substr(0, 10);
    divConversationRoomAction.append(time);

    <!-- -- -- --Bottom-->
    var divConversationRoomContentBottom = document.createElement('div');
    divConversationRoomContentBottom.setAttribute('class', 'msg-conversation-card__row pr2');
    divConversationRoomContent.append(divConversationRoomContentBottom);

    <!--  -- -- -- --Last conversation-->
    var p = document.createElement('p');
    p.setAttribute('class', 'msg-conversation-listitem__message-snippet msg-conversation-card__message-snippet Sans-15px-black-55% m0');
    divConversationRoomContentBottom.append(p);

    <!--  -- -- -- -- --span-->
    var span = document.createElement('span');
    span.setAttribute('class', 'msg-conversation-card__message-snippet-body');
    span.innerHTML = data.lastConversation ? data.updatedBy.username + ": " + data.lastConversation : "";
    p.append(span);

    a.addEventListener("click", function () {
        searchConversations(data.rowId)
        $("#conversationRoomTitle").html(data.name);
        $("#conversations").removeAttr("style");
        $("#createConversationsRoom").css("display", "none");
        $('#conversationsList').empty();
        $('.msg-conversations-container__convo-item-link').removeClass("active");
        $('#' + data.rowId).find('a').addClass("active");
        currentRoom = data.rowId;
    });
    var ulConversationsRoomList = $('#conversationsRoomList');
    ulConversationsRoomList.append(li);
}

/*----------------------------------------------------------------------------- Create Conversation Room Item --------*/
function createConversationItem(items) {
    $('#conversationsList').empty();
    $.each(items.values(), function (index, value) {
        if (value.createdBy.rowId == user.userId) {
            <!--Conversation Items-->
            var liItem = document.createElement('li');
            liItem.setAttribute('id', "conversation-" + value.rowId);

            <!-- --Top-->
            var ulTop = document.createElement('ul');
            ulTop.setAttribute('class', 'clearfix msg-s-message-group msg-s-message-group--other');
            liItem.append(ulTop);

            <!-- -- --li-->
            var li = document.createElement('li');
            li.setAttribute('class', 'msg-s-message-listitem ember-view');
            ulTop.append(li);

            <!-- -- -- --div-->
            var div = document.createElement('div');
            div.setAttribute('class', 'msg-s-message-listitem__message-bubble');
            li.append(div);

            <!-- -- -- -- --p-->
            var p = document.createElement('p');
            p.setAttribute('class', 'msg-s-message-listitem__body Sans-15px-black-70%');
            p.innerHTML = value.text;
            div.append(p);

            <!-- --Bottom-->
            var divBottom = document.createElement('div');
            divBottom.setAttribute('class', 'Sans-13px-black-55% clearfix msg-s-message-group__meta');
            divBottom.setAttribute('aria-hidden', 'true');
            liItem.append(divBottom);

            <!-- -- --time-->
            var time = document.createElement('time');
            time.setAttribute('class', 'msg-s-message-group__timestamp');
            time.innerHTML = value.created;
            divBottom.append(time);

        } else {
            <!--Conversation Items-->
            var liItem = document.createElement('li');
            liItem.setAttribute('class', 'msg-s-message-list__date-group');
            liItem.setAttribute('id', "conversation-" + value.rowId);

            <!-- --Top-->
            var ulTop = document.createElement('ul');
            ulTop.setAttribute('class', 'clearfix msg-s-message-group msg-s-message-group--other');
            liItem.append(ulTop);

            <!-- -- --li-->
            var li = document.createElement('li');
            li.setAttribute('class', 'msg-s-message-listitem msg-s-message-listitem--other ember-view');
            ulTop.append(li);

            <!-- -- -- --img-->
            var img = document.createElement('img');
            img.setAttribute('class', 'msg-s-message-listitem__profile-picture EntityPhoto-circle-1');
            img.setAttribute('src', 'user1.jpg');
            img.setAttribute('alt', 'Mehdi Golnari');
            li.append(img);

            <!-- -- -- --div-->
            var div = document.createElement('div');
            div.setAttribute('class', 'msg-s-message-listitem__message-bubble');
            li.append(div);

            <!-- -- -- -- --p-->
            var p = document.createElement('p');
            p.setAttribute('class', 'msg-s-message-listitem__body Sans-15px-black-70%');
            p.innerHTML = value.text;
            div.append(p);

            <!-- --Bottom-->
            var divBottom = document.createElement('div');
            divBottom.setAttribute('class', 'Sans-13px-black-55% clearfix msg-s-message-group__meta msg-s-message-group__meta--other');
            divBottom.setAttribute('aria-hidden', 'true');
            liItem.append(divBottom);

            <!-- -- --span-->
            var span = document.createElement('span');
            span.setAttribute('class', 'msg-s-message-group__user-name');
            span.innerHTML = value.createdBy.firstName + " " + value.createdBy.lastName;
            divBottom.append(span);

            <!-- -- --time-->
            var time = document.createElement('time');
            time.setAttribute('class', 'msg-s-message-group__timestamp');
            time.innerHTML = value.created;
            divBottom.append(time);
        }

        var ulConversationsList = $('#conversationsList');
        ulConversationsList.append(liItem);
    });
    $("#conversationsList").scrollTop(9999);
}

/*----------------------------------------------------------------------------- Search Conversations Room ------------*/
var hConversationsRoom = new Handler();
hConversationsRoom.success = function success(result) {
    if (result.done) {
        if (result.result) {
            lastRecordShowed.clear();
            firstRecordShowed.clear();
            $('#conversationsRoomList').empty();
            $('#conversationsList').empty();

            $.each(result.result, function (index, value) {
                createConversationRoomItem(value);
                rooms.put(value.rowId, new Map());
            });
        } else {
            hideLoading();
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}

var fConversationsRoom = new Filter();
function searchConversationsRoom() {
    fConversationsRoom.clearParams()
    fConversationsRoom.addParameter("category.rowId", "'0'", Condition.IS_NULL);
    var oldPageSize = pageSize;
    pageSize = 500;
    ServiceInvoker.call(fConversationsRoom.getFilters(), hConversationsRoom, "/conversationroom/list");
    pageSize = oldPageSize;
}

/*----------------------------------------------------------------------------- Search Conversations -----------------*/
var hConversations = new Handler();
hConversations.success = function success(result) {
    if (result.done) {
        if (result.result) {
            var roomId = result.result[0].conversationRoom.rowId;
            var conversations = rooms.get(roomId);
            $.each(result.result, function (index, value) {
                conversations.put(value.rowId, value);

                if (lastRecordShowed.get(roomId) == undefined) {
                    lastRecordShowed.put(roomId, value.rowId);
                    firstRecordShowed.put(roomId, value.rowId);
                } else {
                    if (lastRecordShowed.get(roomId) < value.rowId) {
                        lastRecordShowed.put(roomId, value.rowId);
                    }
                    if (firstRecordShowed.get(roomId) > value.rowId) {
                        firstRecordShowed.put(roomId, value.rowId);
                    }
                }
            });
            rooms.put(conversations);
            createConversationItem(conversations);
        }
    }
    hideLoading();
}

function searchConversations(conversationsRoomId) {
    var fConversationsRoom = new Filter();
    fConversationsRoom.addParameter("conversationRoom.rowId", conversationsRoomId, Condition.EQUAL);
    var orderField = " rowId desc, e.created asc";
    pageSize = 100;
    ServiceInvoker.call(fConversationsRoom.getFilters(orderField), hConversations, "/conversation/list");
}

/*----------------------------------------------------------------------------- Save Conversation --------------------*/
function saveConversation() {
    var hSaveConversation = new Handler();
    hSaveConversation.success = function success(result) {
        if (result.done) {
            $("#conversationContent").val('');
        } else {
            errorHandle(result);
        }
    }

    var formData = '{"text":"' + $("#conversationContent").val() + '"' +
        ',"active":"true"' +
        ',"ticket":"' + user.ticket + '"' +
        ',"conversationRoom": {"rowId":"' + currentRoom + '"}}';

    ServiceInvoker.call(formData, hSaveConversation, "/conversation/save");
}

/*----------------------------------------------------------------------------- Save Conversation Room ---------------*/
function saveConversationRoom() {
    var hSaveConversationRoom = new Handler();
    hSaveConversationRoom.success = function success(result) {
        if (result.done) {
            searchConversationsRoom();
            $("#conversationRoomName").val('');
            $("#userSearch").attr("entityId", '');
            $("#userSearch").val('');
        } else {
            errorHandle(result);
        }
    }

    var formData = '{ "conversationRoom": {"name":"' + $("#conversationRoomName").val() + '"}' +
        ',"conversationUsers": [ ' +

        '{"user":{"rowId": "' + $("#userSearch").attr("entityId") + '"}}' +

        ']' +
        ',"active":"true"' +
        ',"ticket":"' + user.ticket + '"}';

    ServiceInvoker.call(formData, hSaveConversationRoom, "/conversationroom/savelist");
}

/*----------------------------------------------------------------------------- Document ready -----------------------*/
$(document).ready(function () {

    searchConversationsRoom();

    $("#show-menu").on('click', function (e) {
        e.stopPropagation();
        $("#menu").toggle();
    });

    $("#new-group").on('click', function () {
        $(".msg-thread").css("display", "none");
        $("#createConversationsRoom").removeAttr("style");
    });

    $("#contacts").on('click', function () {
        $(".msg-thread").css("display", "none");
        $("#contactsList").removeAttr("style");
    });

    $("#colleagues").on('click', function () {
        $(".msg-thread").css("display", "none");
        $("#colleaguesList").removeAttr("style");

    });

    $(window).on('click', function () {
        $("#menu").css("display", "none");
    })

    $("#supporter").on('click', function () {

    });

    $("#sendConversation").on('click', function () {
        if ($('#conversationContent').val() && currentRoom) {
            saveConversation();
        }
    });

    $("#saveConversationRoom").on('click', function () {
        saveConversationRoom();
    });

    /*------------------------------------------------------------------------- Autocomplete -------------------------*/
    var fUser = new Filter();
    fUser.addParameter("fullTitle", '$("#userSearch").val()', Condition.CONTAINS);
    AutocompleteDynamicUser("userSearch", fUser);

    /*------------------------------------------------------------------------- Notification -------------------------*/
    notificationHandlerConfig();

});

/*----------------------------------------------------------------------------- Notification Handler Config ----------*/
function notificationHandlerConfig() {
    var SSE = new EventSource(progPath + "/service/events/updatestate/USER-" + user.userId);
    SSE.onmessage = function (event) {
        var notification = JSON.parse(event.data);

        if (notification.type == NotificationType.NEW_MESSAGE) {
            notificationHandlerMessage(notification);
        } else if (notification.type == NotificationType.ADD_USER_TO_CONVERSATION_ROOM) {
            notificationHandlerAddUser(notification);
        } else if (notification.type == NotificationType.NEWS) {
            notificationHandlerNews(notification);
        }
    };
};

/*------------------------------------------------------------------------- Notification Handler Message -------------*/
function notificationHandlerMessage(notification) {
    if (notification.id == currentRoom) {
        searchConversations(notification.id);
    }
}

/*------------------------------------------------------------------------- Notification Handler Add User ------------*/
function notificationHandlerAddUser(notification) {
    if (notification.id == currentRoom) {
        searchConversationsRoom();
    }
}

/*----------------------------------------------------------------------------- End ----------------------------------*/