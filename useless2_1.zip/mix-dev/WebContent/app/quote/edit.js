var entity;
$(document).ready(function () {
    setEditListeners();
    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        
        saveRow('edit-form', hSave, "/quote/save");
    });
/*-----------------------------------------------------------------------------------Mask-----------------------*/
    
	$('#total').number( true, 2, '.', ',');
	$('#discountAmount').number( true, 2, '.', ',');
	$('#discountPercentage').number( true, 2, '.', ',');

	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
	var fRFQ = new Filter();
	fRFQ.addParameter("fullTitle", '$("#qouteRequestDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicQuoteRequest("qouteRequestDTO", fRFQ);

	var fLocate1 = new Filter();
	fLocate1.addParameter("name", '$("#departureLocationDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicLocation("departureLocationDTO", fLocate1);

	var fLocate2 = new Filter();
	fLocate2.addParameter("name", '$("#arrivalLocationDTO").val()', Condition.CONTAINS);
	AutocompleteDynamicLocation("arrivalLocationDTO", fLocate2);

	var fComboMethod = new Filter();
	fComboMethod.addParameter("parent.name", '"Freight Method"', Condition.CONTAINS);
	AutocompleteDynamicComboVal("freightMethodDTO", fComboMethod);

	var fComboType = new Filter();
	fComboType.addParameter("parent.name", '"Freight Type"', Condition.CONTAINS);
	AutocompleteDynamicComboVal("freightTypeDTO", fComboType);

});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/quote/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
   if(dto.qouteRequestDTO){
	   $("#qouteRequestDTO").val(dto.qouteRequestDTO.shipmentName);
	   $("#qouteRequestDTO").attr('entityId',dto.qouteRequestDTO.rowId);
   }
   if(dto.quoteStatusTypeDTO){
	   $("#quoteStatusTypeDTO").val(dto.quoteStatusTypeDTO.shipmentName);
	   $("#quoteStatusTypeDTO").attr('entityId',dto.quoteStatusTypeDTO.rowId);
   }
   if(dto.freightMethodDTO){
	   $("#freightMethodDTO").val(dto.freightMethodDTO.name);
	   $("#freightMethodDTO").attr('entityId',dto.freightMethodDTO.rowId);
   }
   if(dto.freightTypeDTO){
	   $("#freightTypeDTO").val(dto.freightTypeDTO.name);
	   $("#freightTypeDTO").attr('entityId',dto.freightTypeDTO.rowId);
   }
   if(dto.departureLocationDTO){
	   $("#departureLocationDTO").val(dto.departureLocationDTO.name);
	   $("#departureLocationDTO").attr('entityId',dto.departureLocationDTO.rowId);
   }
   if(dto.arrivalLocationDTO){
	   $("#arrivalLocationDTO").val(dto.arrivalLocationDTO.name);
	   $("#arrivalLocationDTO").attr('entityId',dto.arrivalLocationDTO.rowId);
   }
    $("#quoteReference").val(dto.quoteReference);
    $("#carrierName").val(dto.carrierName); 
    $("#transitTimeDays").val(dto.transitTimeDays); 
    $("#closingDays").val(dto.closingDays); 
    $("#departureDays").val(dto.departureDays); 
    $("#origionAddress").val(dto.origionAddress); 
    $("#destinationAddress").val(dto.destinationAddress); 
    $("#estimatedEmisssions").val(dto.estimatedEmisssions); 
    
    $("#quoteDate").val(dto.quoteDate); 
    $("#expirationDate").val(dto.expirationDate); 
    
    $("#total").val(dto.total); 
    $("#discountAmount").val(dto.discountAmount); 
    $("#discountPercentage").val(dto.discountPercentage); 
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active);

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $('#qouteRequestDTO').val(parent.title);
    $('#qouteRequestDTO').attr('entityId',parent.id);
    
    $('#freightMethodDTO').val(parent.methodName);
    $('#freightMethodDTO').attr('entityId',parent.methodId);
    
    $('#freightTypeDTO').val(parent.freightTypeName);
    $('#freightTypeDTO').attr('entityId',parent.freightTypeId);
    
    $('#arrivalLocationDTO').val(parent.origionLocationName);
    $('#arrivalLocationDTO').attr('entityId',parent.origionLocationId);
    
    $('#departureLocationDTO').val(parent.destinationLocationname);
    $('#departureLocationDTO').attr('entityId',parent.destinationLocationId);
}
/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
        	//if(tabID != null && tabID != 0) {
        		//showEdit(result.result[0])
        	//}else
        		parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/quote/list");
    pageNo = oldPageNo;
}
function showRowByQuoteRequestId(id){
	fShrSearche.clearParams();
    fShrSearche.addParameter("qouteRequest.rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/quote/list");
    pageNo = oldPageNo;
}
/*--------------------------------------------------------------------------------------- End ------------------------*/