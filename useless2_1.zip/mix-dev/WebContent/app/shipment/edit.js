var entity;

$(document).ready(function () {
    setEditListeners();
    $(".date" ).datepicker({dateFormat: 'yy/mm/dd' });
    $('.date').mask('0000/00/00', {placeholder: "____/__/__"});
    $( function() {
        $( "#tabs" ).tabs();
        
      } );
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/product/save");
    });
    
});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/product/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    $("#sku").val(dto.sku);
    $("#manufactureSku").val(dto.manufactureSku);
    $("#barcode").val(dto.barcode);
	$("#productTitle").val(dto.productTitle);
	if(dto.currencyTypeDTO){
		$("#currencyTypeDTO").val(dto.currencyTypeDTO.title);
        $("#currencyTypeDTO").attr("entityId", dto.currencyTypeDTO.rowId);
	}
	if(dto.relatedProductDTO){
		$("#relatedProductDTO").val(dto.relatedProductDTO.productTitle);
        $("#relatedProductDTO").attr("entityId", dto.relatedProductDTO.rowId);
	}
	$("#taxAmount").val(dto.taxAmount);
	if(dto.brandDTO){
		$("#brandDTO").val(dto.brandDTO.brandTitle);
        $("#brandDTO").attr("entityId", dto.brandDTO.rowId);
	}
	if(dto.categoryDTO){
		$("#categoryDTO").val(dto.categoryDTO.categoryDescription);
		$("#categoryDTO").attr("entityId", dto.categoryDTO.rowId);
	}
	
	$("#salePrice").val(dto.salePrice);
	$("#realPrice").val(dto.realPrice);
	if(dto.taxClassDTO){
		$("#taxClassDTO").val(dto.taxClassDTO.taxClassTitle);
        $("#taxClassDTO").attr("entityId", dto.taxClassDTO.rowId);
	}
	if(dto.relationShipTypeDTO){
		$("#relationShipTypeDTO").val(dto.relationShipTypeDTO.name);
        $("#relationShipTypeDTO").attr("entityId", dto.relationShipTypeDTO.rowId);
	}
	if(dto.createdBy){
    	$("#createdBy").val(dto.createdBy.fullTitle);
		$("#createdBy").attr("entityId", dto.createdBy.rowId);
	}
    if(dto.updatedBy){
    	$("#updatedBy").val(dto.updatedBy.fullTitle);
		$("#updatedBy").attr("entityId", dto.updatedBy.rowId);
	}
    $("#created").val(dto.created);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/quote/list");
    pageNo = oldPageNo;
}
function activeBtn(id){
	if(id == 'detail-btn'){
		$('#detail-btn').addClass('btn-danger');
		$('#summary-btn').removeClass('btn-danger');
	}else{
		$('#detail-btn').removeClass('btn-danger');
		$('#summary-btn').addClass('btn-danger');
	}
}
/*--------------------------------------------------------------------------------------- End ------------------------*/