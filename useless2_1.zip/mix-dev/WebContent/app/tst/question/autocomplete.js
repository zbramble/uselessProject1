/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicQuestion(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/question/list",
        mapPattern: {
            label: "questionText",
            value: "questionText",
            entityId: "questionId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};