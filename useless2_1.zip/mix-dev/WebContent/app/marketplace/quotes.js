var entity;
var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
var ret = parent.window.frames['quote'].location.toString();
var resultId = ret.split("?id=");
var pageState = PageState.READY;
var entityCatch=[];
$(document).ready(function () {
    setEditListeners();
    search();
    $( function() {
        $( "#tabs" ).tabs();
      } );
    $('#tabs').click('tabsselect', function (event, ui) {
    	var $tabs = $("#tabs").tabs();
        var selected = $tabs.tabs("option", "active"); // => 0
        switch (selected) {
		case 0:

			break;
		case 1:
			
			break;
		default:
			break;
		}
     });
    $('#btn-return').on('click',function(){
    	parent.hideEdit();
    	parent.search();
    	parent.$('#quote').css('display','none');
    })

});
function fillTable(entities) {
    $('.row > table').css({"display": "table"});
    var tableBody = $('.row > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        var sumPrice = 0;
        if(item.quoteItems){
        	item.quoteItems.forEach(function (data) {
        		sumPrice += ((data.quantity)*(data.sellPrice));
        	});
        }
        patternRow.attr('id', 'row-' + id);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        if(item.createdBy.file)
        	patternRow.find("#logo").attr("id", 'logo-' + id).find('span').html('<img src="data:image/png;base64,'+ item.createdBy.file.imageContent+'" style="width: 100px;" id="logo" class="img-rounded">');
        else
        	patternRow.find("#logo").attr("id", 'logo-' + id).find('span').html('<img src="../../core/img/image01.png" style="width: 100px;" id="logo" class="img-rounded">');
        patternRow.find("#companyName").attr("id", 'companyName-' + id).find('span').html('<br><div class="col-md-8 col-lg-8">'+
        																				'<div class="row">'+
																	    					'<div class="col-lg-6" style="padding-bottom:20px;">'+
																	    						'<b>'+item.createdBy.companyName +' has submitted a proposal</b>'+
																	    					'</div>'+
																	    				'</div>'+
																	    				'<div class="row">'+
																	    					'<div class="col-lg-6" >'+
																	    								'<span style="padding:5px;"><button type="button" class="btn btn-danger" id="view'+id+'" onclick=\"writePDF('+id+')\">VIEW</button></span>'+
																	    								'<span style="padding:5px;"><button type="button" class="btn btn-danger" onclick=\"award('+id+')\">AWARD</button></span>'+
																	    								'<span style="padding:5px;"><button type="button" class="btn btn-primary">CHAT</button></span>'+
																	    					'</div>'+
																	    				'</div>'+
																	    			'</div>'
																	    				);
        patternRow.find("#grandTotal").attr("id", 'grandTotal-' + id).find('span').html('<div class="col-md-2 col-lg-2">'+
																							'<div class="row">'+
																							'<b>$'+sumPrice+'</b>'+
																						'</div>'+
																						'<div class="row">'+
																							'<div class="stars" id="rating"></div>'+
																						'</div>'+
																						'<div class="row">'+
																							'<b>12 Reviews</b>'+
																						'</div>'+
																					'</div>'
																					);
               
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        /*
         * load hameye etelate quote baraye chap
         */
        entityCatch[id] = item;
        patternRow.appendTo(tableBody);
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}
/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
    	searchResultEntities = result.result;
        if (result.result) {
        	$('#total').show();
        	fillGrid(result.result);
        } else {
        	hideLoading();
        	$('#total').hide();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}
var fSearch = new Filter();
function search(){
	loadRequoest();
	fSearch.addParameter(Condition.WHERE,"(e.quoteStatusType.rowId =1000134 or e.quoteStatusType.rowId =100028 )" , Condition.WHERE);
	fSearch.addParameter("qouteRequest.rowId", resultId[1] , Condition.EQUAL);
    ServiceInvoker.call(fSearch.getFilters(), hSearch, "/quote/list");
}
function loadRequoest(){
	var h = new Handler();
	h.beforeSend = function beforeSend() {
	    showLoading();
	}
	h.success = function success(result) {
	    if (result.done) {
	        if (result.result) {
	        	var entities = result.result;
	        	entities.forEach(function (item, index) {
	        	 $('#shipmentName').html(item.shipmentName);
	             $('#freightType').html(item.freightTypeDTO ? item.freightTypeDTO.name : '');
	             $('#date').html(item.pickupDate);
	             $('#originLocation').html(item.origionLocationDTO ? item.origionLocationDTO.name : '' );
	             $('#destinationLocation').html(item.destinationLocationDTO ? item.destinationLocationDTO.name : '');
	        	});
	        } 
	    } else {
	        hideLoading();
	        setTimeout(function () {
	            errorHandle(result);
	        }, 300)
	    }
	}
	h.error = function error(jqXHR, textStatus) {
	    hideLoading();
	    setTimeout(function () {
	        showError("Error: " + ResponseCode[jqXHR.status]);
	    }, 300)
	}
	h.complete = function complete() {
	    unlockPage();
	}
	
     var f = new Filter();
     f.addParameter("rowId", resultId[1] , Condition.EQUAL);
     ServiceInvoker.call(f.getFilters(), h, "/qoutRequest/list");
}
function writePDF(id) {
	if(entityCatch[id].createdBy.file)
		var image = 'data:image/png;base64,'+entityCatch[id].createdBy.file.imageContent;
	else
		var image = "../../core/img/image01.png";
	var shipmentName = entityCatch[id].qouteRequestDTO.shipmentName;
	var shipmentId = entityCatch[id].qouteRequestDTO.rowId;
	var quoteId = id;
	var carrier = entityCatch[id].carrierName;
	var expireDate = entityCatch[id].expirationDate;
	var email = entityCatch[id].createdBy.email;
	if(entityCatch[id].freightMethodDTO) var mod = entityCatch[id].freightMethodDTO.name;
	if(entityCatch[id].freightTypeDTO) var service = entityCatch[id].freightTypeDTO.name;
	var transitTime = entityCatch[id].transitTimeDays;
	var closing = entityCatch[id].closingDays ;
	var departure = entityCatch[id].departureDays;
    var doc = new jsPDF();
    doc.setFont("times");
    doc.setFontType("bold");
    doc.setFontSize(8);
    doc.setFillColor(207,209,214);
    doc.text(10, 20, 'ADDRESS :');
    doc.text(10, 30, 'INTERNATIONAL :');
    doc.text(10, 35, 'EMAIL :');
    doc.text(150, 10, 'SHIPMENT NAME :');
    doc.text(150, 15, 'SHIPMENT ID :');
    doc.text(150, 20, 'QUOTE ID :');
    doc.text(150, 25, 'CARRIER :');
    doc.text(150, 30, 'EXPIRATION DATE :');
    var imgData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMwAAADKCAYAAADpe6/vAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAFzlJREFUeNrtnQmYVMW5hntANtlRLlxAxXBBSJAtBHFh8RoNGlEEInATIiaCEKOD4ELkqohETUAh4hKXK7gk4sJVybgwaASUiLJ4RRAYQCEqIIoLiyDLcGv5eqa753SfOqdP9Tnd+d7n+Z8HZnr61KlTX52qv/76KxYjhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghpIApLj1KWKOQrY6wai7lrCesdYjWxLWMwT6XehF4Lg2F1crR/VYT1l7YQGHjhN0t7HlhbwpbI2yrsK+FHRJ2JIPJ3+/CZ78QtkXYRmH/J2yZsNeEPSPsYWF3CpsobKSwC4X1ENZcaSJDQXsL2+9SCNt2m7BmLhU6MOQyzhHWIYeNZ2vI9yvtM2FjLN5jLzz7RcJ2R+B+47YLApst7Gxh1RML/iNhm0Mu4JWqN8tcwV1DLqPs5X6WI8H0ikjDWSdsaID3VSSsm7A/CCuLkEAy2a2pgjlZ2FshF2qQ66tfDxHCLONBYZNzMkTRQ4UoNBbZLvoF9DY5R9hLwvbkiVDiz3xi6s20FTY3xEIdENZHmEnFfxlyBf6vsM6WxSJ74X9GpMG8LOyULO+nM+otn4QSNzlMHJ96Q62E3RNiobaoyZZZ5a8IuQLl5PEXlgXTM0IN5q/C2vm8j1rCrhb2SR4KJW47hF2RemPHwlMQVqGWCutk+BCeDbkCD2P8XfdfYDgm7V5h/+bjHmSbmoXJ85E8Nvmm/3XqzdVRvWZ4hXpKWBvDB3FrBCpxobAzLYmlITxTUWgs0j07KbOLtUr5awjrK+wNYd/luVjiTo9hThOyszHBCaNQM4S1NHwgv4qIq/UqTw3JvMH1j1Bj+UrYWI8T+x7oUApBLEfgWh7gdLOnYrwWRqGuV4uCZg+lb0Qq8kFjkXsTzKMRaiwfCrvEQ9lPxOT+2wIRS3y60M/pZtvDUyZfQR/DG/Wdpde89DxswwT6Payw1jF8KMdhtfYDOAvkSu6+kNytPwlYLEeHvFh5AG8VOUlfj9XwMw3LXh9zuy9yXOZytKmDCXYo4OF3X6cbrqnmEcWl5ymvQHHpNGElaNhBimUJeucJwobgFd5AuVLNXa6ynD8WdhlWiZ8MYTgpO5Rr1Jg9OMH0CFEsnwt7FcPjYgwN2ysRmz2TC3O0ELkXHeW7aEuvw/VdkmAv4+cLEVbzNryrq/BC+MSDqF5RXkvDB9gaoQFB3az0w59hYRhTPaSwitlqGBLcfVyXl+st0otWXPqC5fCqPRiNPIa4r06I7avh0i4aYtmkA6Yd8oXwO2E7Da8rY9m6FJpgGofUyFYKu8BowdVsOPZciIKRXq2zfJQ7hga8xbJr9xGEcBUFUNc/wJDe5NpPqjdtgQmmU4irwBMDCZXRw7H3QhTMu2pY5S+iusSiV0wO8y5PjuXKuq7bYDhncv1ZSgcFJphzQ2xosgc6KaDh2LYQ72ODsJ/7FHqZxTfLhRbaS0thLxqW4X4V7l9ggrksxIa2WkUwZzMs0wvHz4W8drFV9eTe546y9//G0uTe1rYCOfd5wrAc01XQb4EJ5uYQG5p0ad9i5E1KX/4fYoEs7P0f4z2Wu6nFGMQXAvVAVp0vzjQsx+3mQ+78EcxDEYhg7pRF+eXuwk8jEAZzs6cdpcWlpwtbYEm8XS3G6lVHiNVhg7jBm80dDfkjmJdCbmzr1fjfjwenuLQ2AkrD3vEq7Y/GQaXaOzZC2EcWyjE3B/uNxhsEhu5TUSgevjRfBPNeyA1NrpDfoVa7vZe9WwSGY3G7zzgyWS9032xh3nU48AiK9DGJbq7wr9QibkEJRq8y74xAYytR6wT5ORyLm1wU/J6HEKWHLTkf6uRAMD9FNMC2DCYjA35ZaII5GvFEXsfrewN+0B+h16qWw+HYXh/3HsxcTEYF2BkKPx7LBTpQdDhCtNLZb7zNTfNDMN/3UY6PEVgY9FDiQRWGYV72M5FYw+81nw94g9ZrKvmGWdkHoQcOWjDDYnlLfgjmHB8NW67yXoq5R5AP+x+qPN7c4dlsqRge8KLh22oR2KzsoyxFVrelYOwK5lKPZZDDn6eFdc+yd3eynfC+VDcod0PMe/yKVkZLtxC2OPBFWPPIhKD3vexWzgQKxqpg/tuHj/9+RLDeaymCubFBuXujgfp3MujveTrAsm9WHZB72WtgHaM84LpbF8tr8kMwf/ax72MKwlGGWth8tsIotqy49KYs9+5fiu+5O8Cyf6ESKpq9Hadb6GwWUDD2BVPisQyfwpUbz6T5bsAP/RvMq46yOBz7Rrl19XfdEGDZ92OviFudt7LkUn6cgrEvmJU+3L+X4G9bWEppdINKM2RvOPZKRVRBsElByvH2relS5+2E/cVCvd1DwdgXjNdhzXq1/bZyHWSQhYyMryl3d/oy35jlcGxUygJc0Bl8GrnUeUdL+eGmenz2dbEXqqdF65Kx88srwehFS697+d8XdlpCPFQnZAYJOj3R+Y49tU4WMS+LkJLdSRuadKRzkGV/2HUtSTei560k/fb2/NvAcfOKRZul8kcUiGBa+5yUt0/4jmbCfm/h4U+JOR3fIcWqRZvN26so4ftaBlzuOa5bcrVLvsRCnU3y+Py75CAOb4sa9haIYE73ubjYNCWIUGZI+dpCGqZOVSbQen6zPYvv/U3K99UKOGNOiRJE5nrvid73X0EwnyYNgfNcMEN8TGpfrzJU0kkRFlrIcjJIzZOSh2MvZDEc2+sYHKld5ZbzcCVd71RLgpkSQcE4JCPPX8GM9xGG/7zD9zTFukjQlX2X8sQFNxxb5Bjcmd13ptpyNf8KRzDTIiiYL81D/KMvmDt9XP+RNCvX/SxkbXwXaz1FAQ3HrkpTD0HuelwbcztxTCe+eNFC47wvgoLZrRI2FohgnvLRW0xN810yy+N8C/v9/wvevGyHY/vSBibKBb/gyvyxSiqSud674V6CbpxPRFAw+1Wof4EIZpmPzUnXpvmu+ojALbfgdWqjdhHq3jubpBBFacoepJdvl4qEyFzvJ1tahymNoGAOq+F6gQjGa3h5+uBCfVSDnGNsCrjCt8X0Aa93ZDnkG56hHq7MaTIMGSun87EFf7SEt+cvN4E9gFzJ5RZFM9lsY2CUBaPdwV7dqWUZE8MFf7/xHmoy3oaHsvCONctQ7p9ZSIZxdIbr2dqevNNjG6ilvIZ6eeEXiFJ408ISwW1mqZaiLZjjfVz//YzX16EWIyz0Vluy3BL9skuP3yvwyXemZBj6NOsZllI9NfTRFoowT2yJsJ2z8NaVyfo+DMR7J1Pi5rlgTvW5yv99l4rvEQv+ENNsBfhrl7pom9NkGNqrOMXS8KdLAG0jnrW/a0DbH6abCTnaghnkc/W9mcGba4HliaRX79i/u5S5fk4TE+qO5fqYnZPGhgc4xz3WxwZDJzM8GDfaghnrcxXbLXS9DnqUwxERzALXCad2WATZeOdXBKimv+bllvb03xVBwTzg2mnlgWCmerz2QUQJFxmMh38Fj1oUBDPakscwu2QexaWDA44wqEzEET3BPKJGHnkumL/48DTNNvzuHhFIPxtfNGtlWObVAV5XZhId6HK9XoicDvqevzXOvpk7wTym1tLyXDCLfOxRucvwuxvAtXowZMG8bpwYMNjsMZtcMz7qxdjHLd33sIgJ5q9GeRoiLhivC4wyhmuiBzelzPm1MWTBXOmhPoLc0PVZlW0Ezpv3bo8Fe2Jx3OZFTDDPKnd13grG3yRXnmY1xsM1ulqKlzI1GXN2gofyPhLgtfeqvGPuncooS3mhd2V0/+deMPKwq875LJhjfKxtbDROUle5iPn7WHingr0R83Kuo15cCzI64RbX6xeX/qePobGp3R8hwbyo5rV5LJjOPq79QczLKcG6Bx2aZcBkNjbOY53cEPD171RzuczXbIF80jbuf6fKPR0NwcxXC+V5LJjzfO5N6eLxOh0tJC03dYG38VjW0QGXwX3tQeZe0yEoeyzVwzsx0+M37Arm78L65LNgrvBx7aVJux/N3zLXYBNRbs+a8V4nAy1sS+hgcN1OMfMz7/3Y577bTHCCedMsc0x0BXOHj2svjhkf7pl0rX4W0jBlFzuWfj5RHqho3ZJhVMZtzbU815NzqkdVL+/loNjgBLNUtQMHz1MT1aClN0lHrC6JBXukdDnmBE/hRi5AeHZNl8n3j7D6LiNkX/UZvr0borkXw5fTjRK02UuLmmk41sSgXM2FnS3sauTOWhewYPZic9Zs5E74CeriKIeyXIAEibmqH7krdBXa58IMtiQWzBmcK9U9OrhR3w9pgntpLN1hpMFv6EqtiJMNGmcxtjfnoi5eMShP95Cek/OCpp7LPBoL/lS3qJjsOAak3vRpFpJAeMlFfEya9Rabq+1rYyYHkOr9FW9EJnYs+A1jXnIiXJXBQbK8QAWzLjkxiG6Y54RYoLsdY6b0sMPmdSsTk2duoM0wRLVdD+VGcVT6MKMwntPhjNuXoxW0GqSVqWQmKWEOl4RYIBl68B9pVtttXnebcUYQfUDoDsvlWWlYlj+H+Kymx9IlK9cd760BJxaMgm1WO3FTVs6vD7FASxxjdfytt3ixr9XbzayR9rYUnZucOd+sLKUhPqvZscRk6FXLVhPOma8KSDCfJKee0nuh/xRigTbFnM64l+5V++Hzzxg20iaW66hc7SI1K8uGEJ/VC+rNn7l8NTB0+6xABLM9eW6pQ7WfDrFA+2JOx13L6GL7115o7NsvLh1pYb9/3Fa5NsTKYc+BEJ/VIqOQFb3oOxiLmofzXDAp6WK1h2NxyIUaUKXh2jm0teoOv/jxd+6NwFZO4fSOD+ecA2E+p1Wum8uSyytTMs1EbFi+CuZrtd6V4tcPe+/H6CrBfnoF2fZ13zOLRK1INjHNUjkujiVm+k9fhj4hP6d/+oxE6AJP4w7LSfdykC5WbzcNe9FpcpJLVSdpy8Vbr6zqolTGBz8ioNXj1Ejqbh6uH+Zz2q1W/rPbmiHv4W8WEu7ZsgPJmw91Yra+IVvbpFgv7W3ploPr9lTrPeYPvDHc3UGWoaPKVmN2/VYReFatA9oRWQ9D8VvhTNhsaQdnEDYpRkjk0E6NY9WOS92ZySiL/nAgDFahOfoNlWvrwodDCCGEEEIIIYQQQgghhBBCCCGRQ68y18Xel4YIz2G9kIJv+E0R83SKayolKQgZJaz3BJ2JMIhrVbIHHefUEd/XDhG36bbnFiGUvRdCOhpkFJs+675PmlitXjijpgOCFYtS/ra7h7ivM9T2b32y2g8cft81434gmf1S30/qd7aCnZHyu+4VB6imjwds6ytHHLEmmOKE04tHpm24upE3QqzSHGSi34J0U2uws3E+tm8/i81mfdN8V30EEe7FDr2zHXN4VX5+NoIN9yXkEv4E9hEylcityL9DXrbaCX87H7m59uNvv8D/U+0z/G4GkjI+gLLtS0hq8Y5jPgV9nXgq2G347GFEGK9RW3a1bULA5CFcb74SZmXHNQ/XPJBQ1ilmR+CRXIilHva47EUo+ty0SbX1W+CX2Au0HaIYiSR/sif8LTJAbsCDziSY09DAv0VqqNsyRkEXl56PxBqr0RBnISnfldhpOgtpi3YjSd7AioSHOkn6bxO2Kj+I/6faH/GZGRhingtRfwCx7UAHMSpNGeXW9Ycg5p24t7moo86wSeho9uLIjeEVb3WdXGUwvmMHbAbqth4bazQE0z/hMNUy5B47N03veTrEtR1HWzR2+FxHnLS1L61g9N6dcXg7LE7IzHiKwYGuJRDY0CobyPTQZRYa4w71fcm/X1ixW9X5u7tDdDMSftYeu0a3oveXySqecByWaYG9hW3Ji/F2GZvymboQyi68Ndsl3bMeUj6EOp5hfAQhyYlYauJsyoPokaeiQdxbJR2tDiG/EUJ4LuNcR/eSqzMIpgPS365D4o556MGviLmd755JMPr3dbDZ6ghOGaueVjA6+UQLNNpaSBQu//YmB8FswFtwNTKAHu9Ql9ehE5gJ4VYVTKUwF0E04yGS+HeMxtDzNZSniA01OoI5D2PpBXhYvTDcWlMlcYMeTizHGHyYy/ceDyfABNXgqr5dirF19x402Itx3eWY9Bb5Foz+TDsI8JD6d3rBNMV8ax7mLHJe9cOkOUqyYMYoMek8YkMc6uc5XGMocqE5C0Z/vh+OFNkKkTRW36k7kcVwDtRgI42OWKqjN61MV6S9ODPxlpmeNAnXc44vjc6N0T13U2TiTB02nYRDQ8swfq+GTJkvoscdpRpudoKplpBzYZCDYCajwQ5D9p9lGSbyiYIZhiTjWzERb5DgDBmOxv4nvBncBFMbbyT5XSswF/t7Qr3UZyONlmC6YoK8pmIYpHv/CzD+fyvp3ETt0j0EL1Frn9eshsZQBtG0T/jdOEyG5yW9FfwIRn8unt9gjINg1uNIhhW4pqlgBkPwJdgi3A2faYLhbBmGmC1cBVPZQT2GEx82ot5vp0csmoKZmXC82oAEG4sHv1Wtr1R+vjcaavrG5X7NFpgf7cEcZkjCdSfAA7UT/6+dpWD+gfsb6SCYOfBWTUPSdC+CaYQ62oh0wUUJ6aT+hvlJcyPBVNbrSnj+SvB2qs4GGi2xHIee9TDEsTTBVmIdYT8cAs3xNz3x89Wux7FpT9AJwk5MGlpo1/ByOA42pFx3GYaC5RDVcVkMyWpB8EeSDvapOodpjsOmvAimOhr5pxDcsRhGlsFz2MCjYGpg7vMdhNiIDTR6grk6wYs0wcGmYjFyU8WxBXrV+3U0xGtcvv9UHJI6WfWY+meNMO7fnuG6t8MZsAlDwOo+BdMHwtut1kbSC6YBRDwODb85Ihd+nFYw+mcnYsgn384XwXmxSjkvKoVoJhj9+TnoRC7jekv0xNIAD3efems4f6YZGvcerKnUxST+JvzdS2kPYdWfnYChVWVeYb2GswDzhv4ZyjYXC343OLqu3d3KLRPcys8kedyqCqYa3ND18e9uGMpNcxFMPYhkMxq7HNY9WTEno2AKSjAXofd9Na3bUg8T+mESugru5vjC5Ur8fDpS+yQuutWBq3ohhleT8GapjfWGrcjm2DJD+a7AQuZSxKIVGQmmMlfcfQgrWV/l6OvsFi4TBSPnLZdDMLIuPkQnUZuCKSyv2NiERlOK/3dN+VwTiGoqxulfoacegRitEXAt70CvWqxct3ot5Tq4Rj/Hm6InbCKGMPvR+4+uGKolN/hhmL/E47fuw6FD8o13IdZ21iQcenot7mECVsUXYpV/UYXLWn/3zxMm6vLe/wf/T7U78ZkZKM9PMUxci3uahYl+65S80W+jo6iLvGA34UiS+CLvGId6boEyjkV9HoRwrkddHsNGG65ghqLXXoP1ghX4/9CUz52ABvMO5jFrEQ7zLE4ebowH+ijOMvwIv1+FXngZPHC9Mfm+DD97HzFZK7HmcpGDi3UWrrsaZVwJ4XVAY16SUKYVaKhL8VZ4G2W8BVHUiSv8j+Nzq1PufamD42EphoOtsLK/LCG4dAW8ez1RDxPx8z/AkRI/N+gd1MlaiOFVh3ruDNf60oR7Won7eEAd/ktCFcxJEE2qneQwj+jj8LnzKzxXesj2PbxZrkaPeiPeAP2x0h/v3Ts6fNeAKl4pPS84J811m0CAQ9Lcw2DEcXVMM6/pl+bvnGwQ5jL1MARN/f15COEvwpD0Ygwdj8LQs3ua70yt56Yos1MZznINESKEFB7/D+SR67mTFv9UAAAAAElFTkSuQmCC';
    doc.addImage(image, 'PNG', 5, -2, 20, 20,null);

    doc.setTextColor(0,0,0);
    if(email) doc.text(40, 25, email);
    doc.text(180, 10, shipmentName);
    doc.text(180, 15, shipmentId.toString());
    doc.text(180, 20, quoteId.toString());
    if(carrier) doc.text(180, 25, carrier);
    if(expireDate) doc.text(180, 30, expireDate);
    
    //Quote Detail
    doc.setFontSize(10);
    doc.setTextColor(20,52,129);
    doc.text(10, 55, 'Quote Detail');
    doc.setTextColor(91,89,89);
    doc.setFontSize(8);
    doc.text(10, 60, 'TRANSPORTATION MODE');
    doc.text(10, 75, 'FREIGHT SERVICE');
    
    doc.text(70, 60, 'FREIGHT PRICE / KG');
    doc.text(70, 75, 'TRANSIT TIME');
    doc.text(120, 60, 'TOTAL PRICE / KG');
    doc.text(120, 75, 'CLOSING DAYS');
    doc.text(160, 60, 'TOTAL PRICE');
    doc.text(160, 75, 'DEPARTURE DAYS');
    
    doc.setTextColor(0,0,0);
    doc.text(10, 65, mod);
    if(service) doc.text(10, 80, service);
    if(transitTime) doc.text(70, 80, transitTime);
    if(closing) doc.text(120, 80, closing);
    if(departure) doc.text(160, 80, departure);
    
    //Items
    doc.setFontSize(9);
    doc.setTextColor(20,52,129);
    doc.text(10, 90, 'Items');
    doc.text(160, 90, 'Route Information');
    doc.text(160, 95, 'Origion Address');
    doc.text(160, 105, 'Departure Port');
    doc.text(160, 115, ' Arrival Port');
    doc.text(160, 125, 'Destination Address');

    
    doc.setTextColor(0,0,0);
    doc.text(10, 95, 'Description');
    doc.text(80, 95, 'Rate');
    doc.text(100, 95, 'Quantity');
    doc.text(120, 95, 'Amount In USD');
    
    if(entityCatch[id].qouteRequestDTO.origionLocationDTO) doc.text(160, 100, entityCatch[id].qouteRequestDTO.origionLocationDTO.name);
    if(entityCatch[id].departureLocationDTO)  doc.text(160, 110, entityCatch[id].departureLocationDTO.name);
    if( entityCatch[id].arrivalLocationDTO) doc.text(160, 120, entityCatch[id].arrivalLocationDTO.name);
    if(entityCatch[id].qouteRequestDTO.destinationLocationDTO) doc.text(160, 130, entityCatch[id].qouteRequestDTO.destinationLocationDTO.name);
    
    if(entityCatch[id].quoteItems){
    	var y = 95;
    	var list=[];
    	var count=0;
    	var subTotal = 0;
    	for (var i = 0; i < entityCatch[id].quoteItems.length; i++) {
    		//chap classification title
    		doc.setFontType("bold");
    		if(i == 0)
    			list[count] =entityCatch[id].quoteItems[i].freightChargeTypeDTO.classificatDTO.classificationTitle;
    		if(list[count] != entityCatch[id].quoteItems[i].freightChargeTypeDTO.classificatDTO.classificationTitle){
    			count++;
    			list[count] = entityCatch[id].quoteItems[i].freightChargeTypeDTO.classificatDTO.classificationTitle;
    			doc.text(10, y+5, list[count]);
    		}else if(list[count] == entityCatch[id].quoteItems[i].freightChargeTypeDTO.classificatDTO.classificationTitle && i ==0)
    			doc.text(10, y+5,list[count]);
    		
    		
    		if(entityCatch[id].quoteItems[i].freightChargeTypeDTO) 
    			doc.text(15, y+10, entityCatch[id].quoteItems[i].freightChargeTypeDTO.chargeTypeTitle);
    		doc.text(80, y+10, entityCatch[id].quoteItems[i].sellPrice.toString());
    		doc.text(100, y+10, entityCatch[id].quoteItems[i].quantity.toString());
    		var result = (entityCatch[id].quoteItems[i].sellPrice)*(entityCatch[id].quoteItems[i].quantity);
    		doc.text(120, y+10,"$ "+ result.toString());
    		y = y+10;
    		//sub total
    		subTotal += result;
    	}
    	doc.text(10, y+5, "Total");
    	doc.text(120, y+5, "$ "+subTotal.toString());
    }
    
    doc.save("report_Quote"+today+'.pdf');
}
function award(id){
	var saveHandler = new Handler();
	saveHandler.success = function success(result) {
   	 if (result.done) {
        	searchResultEntities = result.result;
            if (result.result) {
            	search();
            } else {
                hideLoading();
                setTimeout(function () {
                    showError("No things to show");
                }, 300)
            }
        }
        else {
            errorHandle(result);
        }
    }
	saveHandler.error = function error(jqXHR, textStatus) {
   	 setTimeout(function () {
   	        showError("Error: " + ResponseCode[jqXHR.status]);
   	    }, 300)
    }
	var today = new Date().toJSON().slice(0,10).replace(/-/g,'/');
	var temp = '<br>';
	temp += '<span>shipmentName :'+entityCatch[id].qouteRequestDTO.shipmentName+'</span>';
	if(today <= entityCatch[id].expirationDate){
	dialog('Confirm', 'Do you sure for award ?'+temp, function () {
    		statusId = 100028 ; //Rewarded
        		var data = '{"rowId": "' + id + '"' +
        	    ', "quoteStatusTypeDTO" : {"rowId":' + statusId + '}'+
        	    ', "qouteRequestDTO" : {"rowId":' + entityCatch[id].qouteRequestDTO.rowId + '}'+
        	    ',"expirationDate" : "'+entityCatch[id].expirationDate+'"'+
        	    ', "ticket":"' + user.ticket + '"}';
            	ServiceInvoker.call(data , saveHandler, "/quote/updateStatus");
    }, function () {
    })
	}else{
		dialog('Expire Date','Expiration Date');
	}
	//}
}
/*--------------------------------------------------------------------------------------- End ------------------------*/