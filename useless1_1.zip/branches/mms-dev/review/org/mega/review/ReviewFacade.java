package org.mega.review;

import java.util.Date;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.comboval.ComboVal;
import org.mega.core.emailsmsqueue.EmailSmsQueue;
import org.mega.core.user.User;
import org.mega.order.order.Order;
import org.mega.pmt.reviewtargetsetting.ReviewTargetSetting;

public class ReviewFacade extends BaseFacade{
	
	private static ReviewCopier copier = new ReviewCopier();
	private static ReviewFacade facade = new ReviewFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ReviewFacade getInstace() {
		return facade;
	}

	public void sendEmailToAmazonCustomer(MailDTO mailDTO, BusinessParam businessParam){
		BaseDB db = null;
		try{
			db = businessParam.getDB();
			EmailSmsQueue esq = new EmailSmsQueue();
			esq.setActive(true);
			esq.setTypeId((long) EmailSmsQueue.TYPE.AMAZON_EMAIL.ordinal());//Amazon email
			esq.setContent(mailDTO.getContent());
			
			Review review = findEntityById(Review.class, mailDTO.getReviewId(), businessParam);
			Order order = review.getOrder();
			
			esq.setToAdress(order.getBuyerEmail());
			esq.setTitle(order.getChannelOrderId());//amazon order Id 
			
			User user = new User();
			user.setRowId(businessParam.getUserSession().getUserInfo().getUserId());
			
			esq.setCreatedBy(user);
			esq.setUpdatedBy(user);
			
			Date date = new Date();
			date.setTime(System.currentTimeMillis());
			esq.setCreated(date);
			esq.setUpdated(date);
			
			db.persist(esq);
			
			ComboVal status = new ComboVal();
			status.setRowId(100064L);//replied
			review.setStatus(status);
			
			saveEntity(review, businessParam);
			businessParam.releaseDB();
			
		}catch (Exception e) {
			e.printStackTrace();
			businessParam.rolback();
		}
	}

private String makeEmailContent(Review review, ReviewTargetSetting setting) {
StringBuilder s = new StringBuilder();
s.append("Hi,<br>A negative review recorded for \"").append(setting.getFullTitle()).append("\"<br>")
	.append("Date:").append((1900+review.getReviewDate().getYear())+"/"+ (review.getReviewDate().getMonth()+1)+"/"+review.getReviewDate().getDate()).append("<br>")
	.append("Rate:").append(review.getRating()).append("<br><br>").append("Review:").append(review.getTitle()).append("<br>")
	.append("").append(review.getContent()).append("<br><br>")
	.append(review.getLinkOnSite()).append("<br><br>")
	.append("-- MILO Marketing Suite --");

return s.toString();
}

}
