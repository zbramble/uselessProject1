alter table "mmsuite".TEAM_MEMBER
   drop constraint FK_TEAM_MEMBER_REFERENCE_PMT_MARK;

alter table "mmsuite".TEAM_MEMBER
   drop constraint FK_TEAM_MEMBER_REFERENCE_CO_USER;

drop table "mmsuite".TEAM_MEMBER cascade constraints;

/*==============================================================*/
/* Table: TEAM_MEMBER                                              */
/*==============================================================*/
create table "mmsuite".TEAM_MEMBER 
(
   PMT_TEAM_MEMBER_ID   NUMBER(40)           not null,
   TEAM_ID              NUMBER(40),
   USER_ID              NUMBER(19,0),
   IS_ACTIVE            NUMBER(1,0),
   CREATED              TIMESTAMP (6),
   IS_DELETED           NUMBER(19,0),
   FULL_TITLE           VARCHAR2(200 BYTE),
   UPDATED              TIMESTAMP (6),
   ACCESS_KEY           VARCHAR2(110 BYTE),
   DESCRIPTION          VARCHAR2(500 BYTE),
   CREATED_BY           NUMBER(19,0),
   UPDATED_BY           NUMBER(19,0),
   constraint PK_TEAM_MEMBER primary key (PMT_TEAM_MEMBER_ID)
);

alter table "mmsuite".TEAM_MEMBER
   add constraint FK_TEAM_MEM_REFERENCE_PMT_MARK foreign key (TEAM_ID)
      references "mmsuite".PMT_MARKETING_TEAM (TEAM_ID);

alter table "mmsuite".TEAM_MEMBER
   add constraint FK_TEAM_MEM_REFERENCE_CO_USER foreign key (USER_ID)
      references "mmsuite".CO_USER (USER_ID);
