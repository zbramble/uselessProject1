


CREATE TABLE "MMS"."BSE_BRAND"
(
   BRAND_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110),
   BRAND_TITLE varchar2(300) NOT NULL,
   DESCRIPTION varchar2(500),
   SLOGAN varchar2(1000),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."BSE_CHANNEL"
(
   BSE_CHANNEL_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   CHANNEL_NAME varchar2(300),
   DESCRIPTION varchar2(500),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."BSE_COMPANY"
(
   BSE_COMPANY_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   ADDRESS1 varchar2(1000),
   ADDRESS2 varchar2(100),
   COMPANY_EMAIL varchar2(500),
   COMPANY_LOGO blob,
   COMPANY_NAME varchar2(300),
   CONTACT_PERSON_NAME varchar2(300),
   COMPANY_PHONE varchar2(20),
   COMPANY_WEBSITE varchar2(2000),
   DESCRIPTION varchar2(500),
   CONTACT_PERSON_ROLE varchar2(300),
   ZIPCODE varchar2(20),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   CITY_ID decimal(19,0),
   COUNTRY_ID decimal(19,0),
   PROVINCE_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."BSE_CURRENCY_TYPE"
(
   CURRENCY_TYPE_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110),
   CURRENCY_ABBREVIATION varchar2(5),
   DESCRIPTION varchar2(500),
   IS_BASE_CURRENCY decimal(1,0),
   RATE decimal(10,0),
   TITLE varchar2(200) NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."BSE_PRODUCT_CATEGORY"
(
   CATEGORY_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110),
   CATEGOTY_DESCRIPTION varchar2(300),
   DESCRIPTION varchar2(500),
   IS_ENABLE decimal(1,0),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   TOP_CATEGORY_ID decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."BSE_SITE"
(
   BSE_SITE_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   DESCRIPTION varchar2(500),
   SITE_NAME varchar2(500),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   BSE_CHANNEL_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."BSE_TAX_CLASS"
(
   TAX_CLASS_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110),
   DESCRIPTION varchar2(500),
   RATE decimal(19,0),
   TAX_CLASS_TITLE varchar2(300),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   IS_DEFAULT decimal(1,0)
)
;
CREATE TABLE "MMS"."CO_ACCESS_GRP"
(
   ACCESS_GRP_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   CODE varchar2(255),
   NAME varchar2(100) NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_ACCESS_GRP_USECASE_ACT"
(
   ACCESS_GRP_ID decimal(19,0) NOT NULL,
   USECASE_ACTION_ID decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."CO_ACTION"
(
   ACTION_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   ACTION_NAME varchar2(50) NOT NULL,
   CODE varchar2(20),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_COMBO_VAL"
(
   COMBO_VAL_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   CODE varchar2(100),
   NAME varchar2(50),
   VAL varchar2(20),
   PARENT_ID decimal(19,0),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_FILE"
(
   ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp NOT NULL,
   DATA_SIZE varchar2(100),
   DATA_TYPE varchar2(50),
   DESCRIPTION varchar2(500),
   NAME varchar2(100),
   PATH varchar2(100),
   USE_ENTITY varchar2(100),
   USE_TITLE varchar2(100),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   TITLE varchar2(100),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150),
   IMAGE_CONTENT blob
)
;
CREATE TABLE "MMS"."CO_LOCATION"
(
   LOCATION_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   NAME varchar2(50),
   PARENT_ID decimal(19,0),
   TYPE_ID decimal(19,0) NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150),
   ACCESS_KEY varchar2(110)
)
;
CREATE TABLE "MMS"."CO_ORGANIZATION"
(
   ORGANIZATION_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   ACCESS_KEY varchar2(50),
   ADDRESS varchar2(400),
   CODE varchar2(50),
   DESCRIPTION varchar2(400),
   ESTABLISHING_YEAR decimal(10,0) DEFAULT 2000,
   FAX varchar2(15),
   FULL_NAME varchar2(800),
   IMAGENAME varchar2(100),
   LATITUDE decimal(19,0),
   LOGO_IMAGE blob,
   LONGITUDE decimal(19,0),
   NAME varchar2(160),
   ORDERR decimal(19,0),
   TEL varchar2(15),
   ORG_GRADE_ID decimal(19,0),
   ORG_STATUS_ID decimal(19,0),
   OWNERSHIP_TYPE_ID decimal(19,0),
   PARENT_ORG_ID decimal(19,0),
   ROAD_TYPE_ID decimal(19,0),
   TYPE_ID decimal(19,0),
   RICH_USER_URL varchar2(100),
   POOR_USER_URL varchar2(100),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_PERSON"
(
   PERSON_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   BIRTH_DATE timestamp,
   BIRTH_PLACE varchar2(50),
   BLOOD_TYPE varchar2(5),
   FATHER_NAME varchar2(50),
   FIRST_NAME varchar2(50),
   LAST_NAME varchar2(50),
   NATIONAL_ID varchar2(10),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_REGISTR_USER"
(
   REGISTR_USER_ID decimal(36,0) PRIMARY KEY NOT NULL,
   EMAIL varchar2(100) NOT NULL,
   PASSWORD varchar2(100) NOT NULL,
   CODE varchar2(10),
   IMPORTED decimal(1,0) DEFAULT 0,
   CREATED timestamp NOT NULL,
   IS_ACTIVE decimal(1,0) DEFAULT 0   NOT NULL,
   UPDATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."CO_ROLE"
(
   ROLE_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   CODE varchar2(20),
   ROLE_NAME varchar2(100) NOT NULL,
   IS_DELETED decimal(19,0),
   EXPIRE_MINUTE decimal(3,0) DEFAULT 15,
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_ROLE_ACCESS_GRP"
(
   ACCESS_GRP_ID decimal(19,0) NOT NULL,
   ROLE_ID decimal(19,0) NOT NULL
)
;
CREATE TABLE "MMS"."CO_USECASE"
(
   USECASE_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   CLAZZ varchar2(100),
   CODE varchar2(20),
   TABLE_NAME varchar2(100),
   USECASE_NAME varchar2(50) NOT NULL,
   PARENT_ID decimal(19,0),
   HAS_CHILD decimal(1,0) DEFAULT 0   NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_USECASE_ACTION"
(
   USECASE_ACTION_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   CODE varchar2(20),
   ACTION_ID decimal(19,0),
   USECASE_ID decimal(19,0),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_USER"
(
   USER_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   COMPANY_NAME varchar2(50) NOT NULL,
   IS_ACTIVE decimal(3,0),
   FULL_NAME varchar2(50) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   USER_PASSWORD varchar2(100),
   USERNAME varchar2(30) NOT NULL,
   PERSON_ID decimal(19,0),
   IS_DELETED decimal(19,0),
   EMAIL varchar2(100),
   EMAIL_IS_CONFIRMED decimal(1,0),
   ACTIVE_CODE varchar2(100),
   ACTIVE_CODE_TIME timestamp,
   FULL_TITLE varchar2(150),
   ACCESS_KEY varchar2(30),
   FAILED_LOGIN decimal(10,0) DEFAULT 0

)
;
CREATE TABLE "MMS"."CO_USER_ROLE"
(
   USER_ROLE_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp,
   UPDATED_BY decimal(19,0),
   CODE varchar2(20),
   ORGANIZATION_ID decimal(19,0),
   ROLE_ID decimal(19,0),
   USER_ID decimal(19,0),
   ORGS_ACCESS varchar2(1000),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CO_USER_ROLE_DATA_ACCESS"
(
   USER_ROLE_ACCESS_ID decimal(19,0) PRIMARY KEY NOT NULL,
   CREATED timestamp NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   UPDATED timestamp NOT NULL,
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   FILTER varchar2(4000),
   NAME varchar2(40),
   TYPE decimal(3,0),
   USER_ROL_ID decimal(19,0),
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(150)
)
;
CREATE TABLE "MMS"."CORE_SEQ"
(
   ID decimal(10,0),
   TABLE_NAME varchar2(30)
)
;
CREATE TABLE "MMS"."PRODUCT"
(
   PRODUCT_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   BARCODE varchar2(30),
   IS_ENABLE decimal(1,0),
   MANUFACTURER_SKU varchar2(30),
   PRODUCT_TITLE varchar2(500) NOT NULL,
   RETAIL_PRICE float(126),
   SALE_PRICE float(126),
   MBI_SKU varchar2(30) NOT NULL,
   TAX_AMOUNT float(126),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   BRAND_ID decimal(19,0),
   CATEGORY_ID decimal(19,0),
   CURRENCY_TYPE_ID decimal(19,0),
   RELATED_PRODUCT_ID decimal(19,0),
   TAX_CLASS_ID decimal(19,0),
   PRODUCT_RELATIONSHIP_TYPE_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_CHANNEL_SKU"
(
   PRODUCT_CHANNEL_SKU_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   DESCRIPTION varchar2(500),
   NOTES varchar2(300),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   PRODUCT_ID decimal(19,0),
   BSE_SITE_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_DESC_KEYWORDS_FEATURES"
(
   PRODUCT_DESC_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   DEFAULT_FULL_DESCRIPTION varchar2(1000),
   DEFAULT_SHORT_DESCRIPTION varchar2(1000),
   DEFAULT_SLOGAN varchar2(1000),
   DEFAULT_TAGLINE varchar2(1000),
   DESCRIPTION varchar2(500),
   FEATURE_1 varchar2(1000),
   FEATURE_2 varchar2(1000),
   FEATURE_3 varchar2(1000),
   FEATURE_4 varchar2(1000),
   FEATURE_5 varchar2(1000),
   KEYWORD1 varchar2(1000),
   KEYWORD2 varchar2(1000),
   KEYWORD3 varchar2(1000),
   KEYWORD4 varchar2(1000),
   MAJOR_KEYWORD varchar2(2000),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   PRODUCT_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_EXTENDED_PROPERTIES"
(
   PRODUCT_EXTENDED_PROPERTIE_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   DESCRIPTION varchar2(500),
   EXTENDED_PROPERTY_NAME varchar2(300),
   EXTENDED_PROPERTY_VALUE varchar2(1000),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   EXTENDED_PROPERTY_DATA_TYPE decimal(19,0),
   PRODUCT_ID decimal(19,0),
   EXTENDED_PROPERTY_FILE decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_MULTIMEDIA"
(
   PRODUCT_MULTIMEDIA_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   IS_DEFAULT_MULTIMEDIA decimal(1,0),
   DESCRIPTION varchar2(500),
   MULTIMEDIA_DESCRIPTION varchar2(1000),
   MULTIMEDIA_PRIORITY decimal(10,0),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   MULTIMEDIA_TYPE decimal(19,0),
   PRODUCT_ID decimal(19,0),
   MULTIMEDIA_FILE decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_STANDARD_PROPERTIES"
(
   PRODUCT_STANDARD_PROPERTIES_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   IS_DANGEROUS decimal(1,0),
   DESCRIPTION varchar2(500),
   IS_FDA_REGULATED decimal(1,0),
   FIRDT_AVAILABLE_DATE timestamp,
   HS_CODE varchar2(20),
   HTS_CODE varchar2(20),
   MANUFACTURER varchar2(500),
   MODEL varchar2(500),
   PRODUCT_CETIFICATIONS varchar2(2000),
   IS_USDA_LACEY_ACT decimal(1,0),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   COLOR_ID decimal(19,0),
   LOCATION_ID decimal(19,0),
   PRODUCT_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_SUPPLIER"
(
   PRODUCT_SUPPLIER_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   IS_DEFAULT_SUPPLIER decimal(1,0),
   DESCRIPTION varchar2(500),
   LEAD_TIME_DAYS decimal(10,0),
   MIN_ORDER_QTY decimal(10,0),
   NOTE varchar2(1000),
   PRICE float(126),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   BSE_COMPANY_ID decimal(19,0),
   PRODUCT_ID decimal(19,0)
)
;
CREATE TABLE "MMS"."PRODUCT_WEIGHT_DIMENSION"
(
   PRODUCT_WEIGHT_DIMENSION_ID decimal(19,0) PRIMARY KEY NOT NULL,
   IS_ACTIVE decimal(1,0) NOT NULL,
   CREATED timestamp NOT NULL,
   IS_DELETED decimal(19,0),
   FULL_TITLE varchar2(200),
   UPDATED timestamp NOT NULL,
   ACCESS_KEY varchar2(110) NOT NULL,
   CARTON_DEPTH decimal(12,2),
   CARTON_VOLUME decimal(12,2),
   CARTON_WIDTH decimal(10,2),
   CARTON_HEIGHT decimal(12,2),
   DEPTH float(126),
   DESCRIPTION varchar2(500),
   HEIGHT float(126),
   UNITS_IN_CARTON decimal(10,0),
   VOLUME float(126),
   WEIGHT float(126),
   WIDTH float(126),
   CREATED_BY decimal(19,0) NOT NULL,
   UPDATED_BY decimal(19,0) NOT NULL,
   DIMENSION_UINIT_ID decimal(19,0),
   PRODUCT_ID decimal(19,0),
   VOLUME_UNIT_ID decimal(19,0),
   WEIGHT_UNIT_ID decimal(19,0)
)
;