package org.mega.pmt.caseaction;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.product.customerservicecase.CustomerServiceCase;
import org.mega.product.customerservicecase.CustomerServiceCaseDTO;
import org.mega.util.DateUtil;

public class CaseActionCopier extends BaseCopier<CaseAction, CaseActionDTO>{

	@Override
	public CaseActionDTO copyFromEntity(CaseAction caseAction) {
		CaseActionDTO caseActionDTO = new CaseActionDTO();
		caseActionDTO.setRowId(caseAction.getRowId());
		caseActionDTO.setActionDate(DateUtil.getDateString(caseAction.getActionDate(), "en"));
		caseActionDTO.setActionDesc(caseAction.getActionDesc());
		caseActionDTO.setActionEmail(caseAction.getActionEmail());
		if(caseAction.getActionType() != null){
			ComboValDTO cDto = new ComboValDTO();
			cDto.setRowId(caseAction.getActionType().getRowId());
			cDto.setName(caseAction.getActionType().getName());
			caseActionDTO.setActionTypeDTO(cDto);
		}
		if(caseAction.getActionUser() != null){
			UserDTO userDTO = new UserDTO();
			userDTO.setRowId(caseAction.getActionUser().getRowId());
			userDTO.setFullName(caseAction.getActionUser().getFullName());
			caseActionDTO.setActionUserDTO(userDTO);
		}
		if(caseAction.getCustomerServiceCase() != null){
			CustomerServiceCaseDTO customerServiceCaseDTO = new CustomerServiceCaseDTO();
			customerServiceCaseDTO.setRowId(caseAction.getCustomerServiceCase().getRowId());
			customerServiceCaseDTO.setCustomerName(caseAction.getCustomerServiceCase().getCustomerName());
			caseActionDTO.setCustomerServiceCaseDTO(customerServiceCaseDTO);
		}
		
		copyFromEntityBaseField(caseAction, caseActionDTO);
		return caseActionDTO;
	}

	@Override
	public CaseAction copyToEntity(CaseActionDTO caseActionDTO) throws Exception {
		CaseAction caseAction = new CaseAction();
		caseAction.setRowId(caseActionDTO.getRowId());
		caseAction.setActionDesc(caseActionDTO.getActionDesc());
		caseAction.setActionEmail(caseActionDTO.getActionEmail());
		caseAction.setActionDate(DateUtil.getDate(caseActionDTO.getActionDate(), "en"));
		if(caseActionDTO.getActionTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(caseActionDTO.getActionTypeDTO().getRowId());
			c.setName(caseActionDTO.getActionTypeDTO().getName());
			caseAction.setActionType(c);
		}
		if(caseActionDTO.getActionUserDTO() != null){
			User user = new User();
			user.setRowId(caseActionDTO.getActionUserDTO().getRowId());
			caseAction.setActionUser(user);
		}
		if(caseActionDTO.getCustomerServiceCaseDTO() != null){
			CustomerServiceCase customerServiceCase = new CustomerServiceCase();
			customerServiceCase.setRowId(caseActionDTO.getCustomerServiceCaseDTO().getRowId());
			caseAction.setCustomerServiceCase(customerServiceCase);
		}
		copyToEntityBaseField(caseAction, caseActionDTO);
		return caseAction;
	}

}
