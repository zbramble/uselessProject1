package org.mega.pmt.caseaction;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class CaseActionFacade extends BaseFacade {
	private static CaseActionCopier copier = new CaseActionCopier();
	private static CaseActionFacade facade = new CaseActionFacade();

	@Override
	public BaseCopier getCopier() {
		// TODO Auto-generated method stub
		return copier;
	}
	
	public static CaseActionFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
	
		CaseActionDTO caseActionDTO = (CaseActionDTO) baseDTO;
		if(caseActionDTO.getRowId() == 0)
			caseActionDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}

}
