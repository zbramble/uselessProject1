package org.mega.pmt.teamchannel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.pmt.marketingteam.MarketingTeam;
import org.mega.product.channelsku.ProductChannelSKU;

@Entity
@Table(name = "PMT_TEAM_CHANNEL ", uniqueConstraints = @UniqueConstraint(name = "PK_PMT_TEAM_CHANNEL", columnNames = "PMT_TEAM_CHANNEL_ID"))
public class TeamChannel extends BaseEntity{
	
	@Id
    @Column(name = "PMT_TEAM_CHANNEL_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TEAM_ID", foreignKey = @ForeignKey(name = "FK_PMT_MARK_REFERENCE_CO_USER") , nullable = false)
	private MarketingTeam team;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_CHANNEL_SKU", foreignKey = @ForeignKey(name = "FK_PRODUCT_CHANNEL_SKU") , nullable = false)
	private ProductChannelSKU channelSKU;

	@Column(name = "DESCRIPTION", length = 500)
	private String description;
	
	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public MarketingTeam getTeam() {
		return team;
	}

	public void setTeam(MarketingTeam team) {
		this.team = team;
	}

	public ProductChannelSKU getChannelSKU() {
		return channelSKU;
	}

	public void setChannelSKU(ProductChannelSKU channelSKU) {
		this.channelSKU = channelSKU;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	@PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = team.getTeamTitle();
    }
	
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = team.getTeamTitle();
    }
	

}
