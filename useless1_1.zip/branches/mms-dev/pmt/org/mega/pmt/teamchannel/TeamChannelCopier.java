package org.mega.pmt.teamchannel;

import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.pmt.marketingteam.MarketingTeam;
import org.mega.pmt.marketingteam.MarketingTeamDTO;
import org.mega.product.ProductDTO;
import org.mega.product.channelsku.ProductChannelSKU;
import org.mega.product.channelsku.ProductChannelSKUDTO;

public class TeamChannelCopier extends BaseCopier<TeamChannel, TeamChannelDTO>{

	@Override
	public TeamChannelDTO copyFromEntity(TeamChannel teamChannel) {
		TeamChannelDTO teamChannelDTO = new TeamChannelDTO();
		teamChannelDTO.setRowId(teamChannel.getRowId());
		teamChannelDTO.setDescription(teamChannel.getDescription());
		if(teamChannel.getTeam() != null){
			MarketingTeamDTO mDTO = new MarketingTeamDTO();
			mDTO.setRowId(teamChannel.getTeam().getRowId());
			mDTO.setTeamTitle(teamChannel.getTeam().getTeamTitle());
			teamChannelDTO.setTeamDTO(mDTO);
		}
		if(teamChannel.getChannelSKU() != null){
			ProductChannelSKUDTO pcChannelSKUDTO = new ProductChannelSKUDTO();
			pcChannelSKUDTO.setRowId(teamChannel.getChannelSKU().getRowId());
			pcChannelSKUDTO.setSKU(teamChannel.getChannelSKU().getSKU());
			pcChannelSKUDTO.setAllReviewCount(teamChannel.getChannelSKU().getAllReviewCount());
			pcChannelSKUDTO.setReviewRate(teamChannel.getChannelSKU().getReviewRate());
			if(teamChannel.getChannelSKU().getSite()!= null){
				SiteDTO sDTO = new SiteDTO();
				sDTO.setRowId(teamChannel.getChannelSKU().getSite().getRowId());
				sDTO.setSiteName(teamChannel.getChannelSKU().getSite().getSiteName());
				pcChannelSKUDTO.setSiteDTO(sDTO);
			}
			if(teamChannel.getChannelSKU().getProduct() != null){
				ProductDTO pDTO = new ProductDTO();
				pDTO.setRowId(teamChannel.getChannelSKU().getProduct().getRowId());
				pDTO.setProductTitle(teamChannel.getChannelSKU().getProduct().getProductTitle());
				pcChannelSKUDTO.setProductDTO(pDTO);
			}
			
			teamChannelDTO.setChannelSKU(pcChannelSKUDTO);
		}
		copyFromEntityBaseField(teamChannel, teamChannelDTO);
		return teamChannelDTO;
	}

	@Override
	public TeamChannel copyToEntity(TeamChannelDTO teamChannelDTO) throws Exception {
		TeamChannel teamChannel = new TeamChannel();
		teamChannel.setRowId(teamChannelDTO.getRowId());
		teamChannel.setDescription(teamChannelDTO.getDescription());
		if(teamChannelDTO.getTeamDTO() != null){
			MarketingTeam marketingTeam = new MarketingTeam();
			marketingTeam.setRowId(teamChannelDTO.getTeamDTO().getRowId());
			marketingTeam.setTeamTitle(teamChannelDTO.getTeamDTO().getTeamTitle());
			teamChannel.setTeam(marketingTeam);
		}
		if(teamChannelDTO.getChannelSKU() != null){
			ProductChannelSKU channelSKU = new ProductChannelSKU();
			channelSKU.setRowId(teamChannelDTO.getChannelSKU().getRowId());
			channelSKU.setSKU(teamChannelDTO.getChannelSKU().getSKU());
			//Site site = new Site();
			//site.setRowId(teamChannelDTO.getChannelSKU().getSiteDTO().getRowId());
			//site.setSiteName(teamChannelDTO.getChannelSKU().getSiteDTO().getSiteName());
			//channelSKU.setSite(site);
			teamChannel.setChannelSKU(channelSKU);
		}
		copyToEntityBaseField(teamChannel,teamChannelDTO);
		return teamChannel;
	}

}
