package org.mega.pmt.teamchannel;

import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.pmt.marketingteam.MarketingTeamDTO;
import org.mega.product.channelsku.ProductChannelSKUDTO;

public class TeamChannelFacade extends BaseFacade{
	private static TeamChannelCopier copier = new TeamChannelCopier();
	private static TeamChannelFacade facade = new TeamChannelFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static TeamChannelFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		TeamChannelDTO channelDTO = (TeamChannelDTO) baseDTO;
		if(channelDTO.getRowId() == 0)
			channelDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		try {
			BaseDB db = businessParam.getDB();
			 Query query = db.createNativeQuery("select e.PMT_TEAM_CHANNEL_ID from PMT_TEAM_CHANNEL e where e.IS_DELETED = 0 and e.PRODUCT_CHANNEL_SKU =  "+channelDTO.getChannelSKU().getRowId()+" and e.TEAM_ID = "+channelDTO.getTeamDTO().getRowId());
			 if(query.getResultList().size() > 0){
				 businessParam.releaseDB();
				 return new ServiceResult(ServiceResult.ERROR_CODE.DUPLICATE,"Product Channel SKU already in Saved","Product Channel SKU already in Saved");
			 }else{
				 businessParam.releaseDB();
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.save(baseDTO, businessParam);
	}
	
	public ServiceResult manyToManySave(MarketingTeamDTO marketingTeamDTO,List<String> channelsku,BusinessParam businessParam){
		ServiceResult resultSave = null;
		for (int i = 0; i < channelsku.size(); i++) {
			TeamChannelDTO teamChannelDTO = new TeamChannelDTO();
			teamChannelDTO.setTeamDTO(marketingTeamDTO);
			//System.out.println(channelsku.get(i));
			ProductChannelSKUDTO channelSKUDTO = new ProductChannelSKUDTO();
			channelSKUDTO.setRowId(Long.parseLong(channelsku.get(i).toString().replace("[", " ").replace("]", " ")));
			teamChannelDTO.setChannelSKU(channelSKUDTO);
			resultSave = save(teamChannelDTO, businessParam);
		}
		return resultSave;
		
	}
}
