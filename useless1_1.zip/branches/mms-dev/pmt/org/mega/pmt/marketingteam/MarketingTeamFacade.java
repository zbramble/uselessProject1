package org.mega.pmt.marketingteam;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class MarketingTeamFacade extends BaseFacade {

	private static MarketingTeamCopier copier = new MarketingTeamCopier();
	private static MarketingTeamFacade facade = new MarketingTeamFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static MarketingTeamFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		MarketingTeamDTO marketingTeamDTO = (MarketingTeamDTO) baseDTO;
		if(marketingTeamDTO.getRowId() == 0)
			marketingTeamDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}
	
}
