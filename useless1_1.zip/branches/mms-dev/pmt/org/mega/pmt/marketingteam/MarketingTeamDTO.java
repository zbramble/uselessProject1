package org.mega.pmt.marketingteam;

import org.mega.core.base.BaseDTO;
import org.mega.core.user.UserDTO;

public class MarketingTeamDTO extends BaseDTO{

    private long rowId;
	private String teamTitle;
	private UserDTO userDTO;
	private String description;
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getTeamTitle() {
		return teamTitle;
	}
	public void setTeamTitle(String teamTitle) {
		this.teamTitle = teamTitle;
	}
	
	public UserDTO getUserDTO() {
		return userDTO;
	}
	
	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
