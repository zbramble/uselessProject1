package org.mega.pmt.caseproblem;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class CaseProblemFacade extends BaseFacade{

	private static CaseProblemCopier copier = new CaseProblemCopier();
	private static CaseProblemFacade facade = new CaseProblemFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static CaseProblemFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		CaseProblemDTO caseProblemDTO =(CaseProblemDTO) baseDTO;
		if(caseProblemDTO.getRowId() == 0)
			caseProblemDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		
		return super.save(baseDTO, businessParam);
	}
}
