package org.mega.pmt.caseproblem;

import org.mega.core.base.BaseCopier;
import org.mega.product.ProductDTO;
import org.mega.product.customerservicecase.CustomerServiceCase;
import org.mega.product.customerservicecase.CustomerServiceCaseDTO;
import org.mega.product.problem.ProductProblem;
import org.mega.product.problem.ProductProblemDTO;

public class CaseProblemCopier extends BaseCopier<CaseProblem, CaseProblemDTO>{

	@Override
	public CaseProblemDTO copyFromEntity(CaseProblem caseProblem) {
		CaseProblemDTO caseProblemDTO = new CaseProblemDTO();
		caseProblemDTO.setRowId(caseProblem.getRowId());
		if(caseProblem.getCustomerServiceCase() != null){
			CustomerServiceCaseDTO caseDTO = new CustomerServiceCaseDTO();
			caseDTO.setRowId(caseProblem.getCustomerServiceCase().getRowId());
			caseDTO.setCustomerName(caseProblem.getCustomerServiceCase().getCustomerName());
			caseProblemDTO.setCustomerServiceCaseDTO(caseDTO);
		}
		if(caseProblem.getProductProblem() != null){
			ProductProblemDTO productProblemDTO = new ProductProblemDTO();
			productProblemDTO.setRowId(caseProblem.getProductProblem().getRowId());
			ProductDTO productDTO = new ProductDTO();
			productDTO.setRowId(caseProblem.getProductProblem().getProduct().getRowId());
			productDTO.setProductTitle(caseProblem.getProductProblem().getProduct().getProductTitle());
			productProblemDTO.setProductDTO(productDTO);
			caseProblemDTO.setProductProblemDTO(productProblemDTO);
		}
		caseProblemDTO.setProblemDescription(caseProblem.getProblemDescription());
		copyFromEntityBaseField(caseProblem, caseProblemDTO);
		return caseProblemDTO;
	}

	@Override
	public CaseProblem copyToEntity(CaseProblemDTO caseProblemDTO) throws Exception {
		CaseProblem caseProblem = new CaseProblem();
		caseProblem.setRowId(caseProblemDTO.getRowId());
		caseProblem.setProblemDescription(caseProblemDTO.getProblemDescription());
		if(caseProblemDTO.getCustomerServiceCaseDTO() != null){
			CustomerServiceCase customerServiceCase = new CustomerServiceCase();
			customerServiceCase.setRowId(caseProblemDTO.getCustomerServiceCaseDTO().getRowId());
			customerServiceCase.setCustomerName(caseProblemDTO.getCustomerServiceCaseDTO().getCustomerName());
			caseProblem.setCustomerServiceCase(customerServiceCase);
		}
		if(caseProblemDTO.getProductProblemDTO() != null){
			ProductProblem productProblem = new ProductProblem();
			productProblem.setRowId(caseProblemDTO.getProductProblemDTO().getRowId());
			/*Product product = new Product();
			product.setRowId(caseProblemDTO.getProductProblemDTO().getProduct().getRowId());
			product.setProductTitle(caseProblemDTO.getProductProblemDTO().getProduct().getProductTitle());
			productProblem.setProduct(product);*/
			caseProblem.setProductProblem(productProblem);
		}
		copyToEntityBaseField(caseProblem, caseProblemDTO);
		return caseProblem;
	}
}
