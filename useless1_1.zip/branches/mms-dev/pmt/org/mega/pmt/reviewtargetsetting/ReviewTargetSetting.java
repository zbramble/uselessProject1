package org.mega.pmt.reviewtargetsetting;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.product.channelsku.ProductChannelSKU;

@Entity
@Table(name = "PMT_REVIEW_TARGET_SETTING ", uniqueConstraints = @UniqueConstraint(name = "PK_PMT_REVIEW_TARGET_RULE_SETT", columnNames = "REVIEW_RULE_SETTING_ID"))
public class ReviewTargetSetting extends BaseEntity {

	@Id
	@Column(name = "REVIEW_RULE_SETTING_ID")
	private long rowId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_CHANNEL_SKU_ID", foreignKey = @ForeignKey(name = "FK_PMT_REVI_REFERENCE_PRODUCT_"), nullable = false)
	private ProductChannelSKU channelSKU;

	@Column(name = "REVIEW_TARGET", length = 5, nullable = true)
	private double reviewTarget;

	@Column(name = "DAILY_NEGATIVE_THRESHOULD", length = 3, nullable = true)
	private int dailyThreshould;

	@Column(name = "WEEKLY_NEGATIVE_THRESHOULD", length = 3, nullable = true)
	private int weeklyThreshould;

	@Column(name = "MONTHLY_NEGATIVE_THRESHOULD", length = 3, nullable = true)
	private int monthlyThreshould;

	@Column(name = "DAILY_COUNT", length = 5, nullable = true)
	private int dailyCount;

	@Column(name = "WEEKLY_COUNT", length = 5, nullable = true)
	private int weeklyCount;

	@Column(name = "MONTHLY_COUNT", length = 5, nullable = true)
	private int monthlyCount;
	
	@Column(name = "NEGATIVE_RISK_COUNT", length = 5, nullable = false)
	private int negativeRiskCount;

	/*
	 * @Column(name = "DAILY_NEGATIVE_REVIEW_COUNT",length=5,nullable =true)
	 * private int dailyReviewCount;
	 * 
	 * @Column(name = "WEEKLY_NEGATIVE_REVIEW_COUNT",length=5,nullable =true)
	 * private int weeklyReviewCount;
	 * 
	 * @Column(name = "MONTHLY_NEGATIVE_REVIEW_COUNT",length=5,nullable =true)
	 * private int monthlyReviewCount;
	 */
	@Temporal(TemporalType.DATE)
	@Column(name = "NEGATIVE_REVIEW_COLLECT_START")
	private Date negativeCollectStart;

	@Column(name = "REALTTIME_NEGATIVE_REVIEW_NOTI", length = 1000, nullable = true)
	private String realTimeNotification;

	@Column(name = "DAILY_NEGATIVE_REVIEW_NOTIFICA", length = 1000, nullable = true)
	private String dailyNotification;

	@Column(name = "WEEKLY_NEGATIVE_REVIEW_NOTIF", length = 1000, nullable = true)
	private String weeklyNotification;

	@Column(name = "MONTHLY_NEGATIVE_REVIEW_NOTIF_", length = 1000, nullable = true)
	private String monthlyNotification;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public ProductChannelSKU getChannelSKU() {
		return channelSKU;
	}

	public void setChannelSKU(ProductChannelSKU channelSKU) {
		this.channelSKU = channelSKU;
	}

	public double getReviewTarget() {
		return reviewTarget;
	}

	public void setReviewTarget(double reviewTarget) {
		this.reviewTarget = reviewTarget;
	}

	public int getDailyThreshould() {
		return dailyThreshould;
	}

	public void setDailyThreshould(int dailyThreshould) {
		this.dailyThreshould = dailyThreshould;
	}

	public int getWeeklyThreshould() {
		return weeklyThreshould;
	}

	public void setWeeklyThreshould(int weeklyThreshould) {
		this.weeklyThreshould = weeklyThreshould;
	}

	public int getMonthlyThreshould() {
		return monthlyThreshould;
	}

	public void setMonthlyThreshould(int monthlyThreshould) {
		this.monthlyThreshould = monthlyThreshould;
	}

	public int getDailyCount() {
		return dailyCount;
	}

	public void setDailyCount(int dailyCount) {
		this.dailyCount = dailyCount;
	}

	public int getWeeklyCount() {
		return weeklyCount;
	}

	public void setWeeklyCount(int weeklyCount) {
		this.weeklyCount = weeklyCount;
	}

	public int getMonthlyCount() {
		return monthlyCount;
	}

	public void setMonthlyCount(int monthlyCount) {
		this.monthlyCount = monthlyCount;
	}

	public Date getNegativeCollectStart() {
		return negativeCollectStart;
	}

	public void setNegativeCollectStart(Date negativeCollectStart) {
		this.negativeCollectStart = negativeCollectStart;
	}

	public String getRealTimeNotification() {
		return realTimeNotification;
	}

	public void setRealTimeNotification(String realTimeNotification) {
		this.realTimeNotification = realTimeNotification;
	}

	/*
	 * public int getDailyReviewCount() { return dailyReviewCount; }
	 * 
	 * public void setDailyReviewCount(int dailyReviewCount) {
	 * this.dailyReviewCount = dailyReviewCount; }
	 * 
	 * public int getWeeklyReviewCount() { return weeklyReviewCount; }
	 * 
	 * public void setWeeklyReviewCount(int weeklyReviewCount) {
	 * this.weeklyReviewCount = weeklyReviewCount; }
	 * 
	 * public int getMonthlyReviewCount() { return monthlyReviewCount; }
	 * 
	 * public void setMonthlyReviewCount(int monthlyReviewCount) {
	 * this.monthlyReviewCount = monthlyReviewCount; }
	 */

	public String getWeeklyNotification() {
		return weeklyNotification;
	}

	public String getDailyNotification() {
		return dailyNotification;
	}

	public void setDailyNotification(String dailyNotification) {
		this.dailyNotification = dailyNotification;
	}

	public void setWeeklyNotification(String weeklyNotification) {
		this.weeklyNotification = weeklyNotification;
	}

	public String getMonthlyNotification() {
		return monthlyNotification;
	}

	public void setMonthlyNotification(String monthlyNotification) {
		this.monthlyNotification = monthlyNotification;
	}
	
	public int getNegativeRiskCount() {
		return negativeRiskCount;
	}

	public void setNegativeRiskCount(int negativeRiskCount) {
		this.negativeRiskCount = negativeRiskCount;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = channelSKU.getFullTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		fullTitle = channelSKU.getFullTitle();
	}
}
