package org.mega.pmt.reviewtargetsetting;

import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.product.ProductDTO;
import org.mega.product.channelsku.ProductChannelSKU;
import org.mega.product.channelsku.ProductChannelSKUDTO;
import org.mega.util.DateUtil;

public class ReviewTargetSettingCopier extends BaseCopier<ReviewTargetSetting, ReviewTargetSettingDTO>{

	@Override
	public ReviewTargetSettingDTO copyFromEntity(ReviewTargetSetting reviewTargetRuleSetting) {
		ReviewTargetSettingDTO reviewTargetRuleSettingDTO = new ReviewTargetSettingDTO();
		reviewTargetRuleSettingDTO.setRowId(reviewTargetRuleSetting.getRowId());
		if(reviewTargetRuleSetting.getChannelSKU() != null){
			ProductChannelSKUDTO pcChannelSKUDTO = new ProductChannelSKUDTO();
			pcChannelSKUDTO.setRowId(reviewTargetRuleSetting.getChannelSKU().getRowId());
			pcChannelSKUDTO.setSKU(reviewTargetRuleSetting.getChannelSKU().getSKU());
			ProductDTO pDTO = new ProductDTO();
			pDTO.setRowId(reviewTargetRuleSetting.getChannelSKU().getProduct().getRowId());
			pDTO.setProductTitle(reviewTargetRuleSetting.getChannelSKU().getProduct().getProductTitle());
			pcChannelSKUDTO.setProductDTO(pDTO);
			SiteDTO sDTO = new SiteDTO();
			sDTO.setRowId(reviewTargetRuleSetting.getChannelSKU().getSite().getRowId());
			sDTO.setSiteName(reviewTargetRuleSetting.getChannelSKU().getSite().getSiteName());
			pcChannelSKUDTO.setSiteDTO(sDTO);
			reviewTargetRuleSettingDTO.setChannelSKU(pcChannelSKUDTO);
		}
		reviewTargetRuleSettingDTO.setDailyCount(reviewTargetRuleSetting.getDailyCount());
		reviewTargetRuleSettingDTO.setDailyNotification(reviewTargetRuleSetting.getDailyNotification());
		reviewTargetRuleSettingDTO.setWeeklyNotification(reviewTargetRuleSetting.getWeeklyNotification());
		reviewTargetRuleSettingDTO.setDailyThreshould(reviewTargetRuleSetting.getDailyThreshould());
		reviewTargetRuleSettingDTO.setMonthlyCount(reviewTargetRuleSetting.getMonthlyCount());
		reviewTargetRuleSettingDTO.setMonthlyNotification(reviewTargetRuleSetting.getMonthlyNotification());
		reviewTargetRuleSettingDTO.setMonthlyThreshould(reviewTargetRuleSetting.getMonthlyThreshould());
		reviewTargetRuleSettingDTO.setNegativeCollectStart(DateUtil.getDateString(reviewTargetRuleSetting.getNegativeCollectStart(), "en"));
		reviewTargetRuleSettingDTO.setRealTimeNotification(reviewTargetRuleSetting.getRealTimeNotification());
		reviewTargetRuleSettingDTO.setReviewTarget(reviewTargetRuleSetting.getReviewTarget());
		reviewTargetRuleSettingDTO.setWeeklyCount(reviewTargetRuleSetting.getWeeklyCount());
		reviewTargetRuleSettingDTO.setWeeklyThreshould(reviewTargetRuleSetting.getWeeklyThreshould());
		reviewTargetRuleSettingDTO.setNegativeRiskCount(reviewTargetRuleSetting.getNegativeRiskCount());
		copyFromEntityBaseField(reviewTargetRuleSetting, reviewTargetRuleSettingDTO);
		return reviewTargetRuleSettingDTO;
	}

	@Override
	public ReviewTargetSetting copyToEntity(ReviewTargetSettingDTO reviewTargetRuleSettingDTO) throws Exception {
		ReviewTargetSetting reviewTargetRuleSetting = new ReviewTargetSetting();
		reviewTargetRuleSetting.setRowId(reviewTargetRuleSettingDTO.getRowId());
		if(reviewTargetRuleSettingDTO.getChannelSKU() != null){
			ProductChannelSKU pcChannelSKU = new ProductChannelSKU();
			pcChannelSKU.setRowId(reviewTargetRuleSettingDTO.getChannelSKU().getRowId());
			pcChannelSKU.setSKU(reviewTargetRuleSettingDTO.getChannelSKU().getSKU());
			//Site s = new Site();
			//s.setRowId(reviewTargetRuleSettingDTO.getChannelSKU().getSiteDTO().getRowId());
			//s.setSiteName(reviewTargetRuleSettingDTO.getChannelSKU().getSiteDTO().getSiteName());
			//pcChannelSKU.setSite(s);
			reviewTargetRuleSetting.setChannelSKU(pcChannelSKU);
		}
		reviewTargetRuleSetting.setDailyCount(reviewTargetRuleSettingDTO.getDailyCount());
		reviewTargetRuleSetting.setDailyNotification(reviewTargetRuleSettingDTO.getDailyNotification());
		reviewTargetRuleSetting.setWeeklyNotification(reviewTargetRuleSettingDTO.getWeeklyNotification());
		reviewTargetRuleSetting.setDailyThreshould(reviewTargetRuleSettingDTO.getDailyThreshould());
		reviewTargetRuleSetting.setMonthlyCount(reviewTargetRuleSettingDTO.getMonthlyCount());
		//System.out.println(reviewTargetRuleSettingDTO.getMonthlyNotification());
		reviewTargetRuleSetting.setMonthlyNotification(reviewTargetRuleSettingDTO.getMonthlyNotification());
		reviewTargetRuleSetting.setMonthlyThreshould(reviewTargetRuleSettingDTO.getMonthlyThreshould());
		if(reviewTargetRuleSettingDTO.getNegativeCollectStart() != ""){
			String day = reviewTargetRuleSettingDTO.getNegativeCollectStart().substring(0, 2);
			String year = reviewTargetRuleSettingDTO.getNegativeCollectStart().substring(6, reviewTargetRuleSettingDTO.getNegativeCollectStart().length());
			if(year.indexOf('/') < 0)
				reviewTargetRuleSettingDTO.setNegativeCollectStart(year+"/"+reviewTargetRuleSettingDTO.getNegativeCollectStart().substring(4,6)+day);
			//System.out.println(reviewTargetRuleSettingDTO.getNegativeCollectStart());
			//System.out.println(DateUtil.getDate(reviewTargetRuleSettingDTO.getNegativeCollectStart(), "en"));
			reviewTargetRuleSetting.setNegativeCollectStart(DateUtil.getDate(reviewTargetRuleSettingDTO.getNegativeCollectStart(), "en"));
		}
		reviewTargetRuleSetting.setRealTimeNotification(reviewTargetRuleSettingDTO.getRealTimeNotification());
		reviewTargetRuleSetting.setReviewTarget(reviewTargetRuleSettingDTO.getReviewTarget());
		reviewTargetRuleSetting.setWeeklyCount(reviewTargetRuleSettingDTO.getWeeklyCount());
		reviewTargetRuleSetting.setWeeklyThreshould(reviewTargetRuleSettingDTO.getWeeklyThreshould());
		reviewTargetRuleSetting.setNegativeRiskCount(reviewTargetRuleSettingDTO.getNegativeRiskCount());
		copyToEntityBaseField(reviewTargetRuleSetting, reviewTargetRuleSettingDTO);
		return reviewTargetRuleSetting;
	}

}
