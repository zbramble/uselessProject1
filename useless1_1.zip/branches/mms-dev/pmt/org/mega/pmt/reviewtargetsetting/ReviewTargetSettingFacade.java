package org.mega.pmt.reviewtargetsetting;

import java.util.List;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class ReviewTargetSettingFacade extends BaseFacade{

	private static ReviewTargetSettingCopier copier = new ReviewTargetSettingCopier();
	private static ReviewTargetSettingFacade facade = new ReviewTargetSettingFacade();

	@Override
	public BaseCopier getCopier() {
		// TODO Auto-generated method stub
		return copier;
	}
	
	public static ReviewTargetSettingFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		ReviewTargetSettingDTO reviewTargetRuleSettingDTO = (ReviewTargetSettingDTO) baseDTO;
		//System.out.println(reviewTargetRuleSettingDTO.getNegativeCollectStart());
		if(reviewTargetRuleSettingDTO.getRowId() == 0)
			reviewTargetRuleSettingDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}
	
	public ServiceResult saveSelected(List<ReviewTargetSettingDTO> listReview,BusinessParam businessParam){
		ServiceResult resultSave = null;
		for (int i = 0; i < listReview.size(); i++) {
			//System.out.println(listReview.get(i).getRowId());
			ReviewTargetSettingDTO review = listReview.get(i);
			review.setRowId(listReview.get(i).getRowId());
			review.setDailyThreshould(listReview.get(i).getDailyThreshould());
			review.setWeeklyThreshould(listReview.get(i).getWeeklyThreshould());
			review.setMonthlyThreshould(listReview.get(i).getMonthlyThreshould());
			review.setDailyCount(listReview.get(i).getDailyCount());
			review.setWeeklyCount(listReview.get(i).getWeeklyCount());
			review.setMonthlyCount(listReview.get(i).getMonthlyCount());
			review.setDailyNotification(listReview.get(i).getDailyNotification());
			review.setWeeklyNotification(listReview.get(i).getWeeklyNotification());
			review.setMonthlyNotification(listReview.get(i).getMonthlyNotification());
			review.setRealTimeNotification(listReview.get(i).getRealTimeNotification());
			review.setReviewTarget(listReview.get(i).getReviewTarget());
			//review.setNegativeCollectStart(listReview.get(i).getNegativeCollectStart());
			resultSave = save(review, businessParam);
		}
		return resultSave;
	}

}
