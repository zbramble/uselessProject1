package org.mega.pmt.teammember;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.pmt.marketingteam.MarketingTeamDTO;

public class MasterTeamMemberDTO extends BaseDTO{
	
	private MarketingTeamDTO marketingTeamDTO;
	private List<String> listUsers;
	public MarketingTeamDTO getMarketingTeamDTO() {
		return marketingTeamDTO;
	}
	public void setMarketingTeamDTO(MarketingTeamDTO marketingTeamDTO) {
		this.marketingTeamDTO = marketingTeamDTO;
	}
	
	public List<String> getListUsers() {
		return listUsers;
	}
	public void setListUsers(List<String> listUsers) {
		this.listUsers = listUsers;
	}
	@Override
	public Long getRowId() {
		// TODO Auto-generated method stub
		return marketingTeamDTO.getRowId();
	}
	
	

}
