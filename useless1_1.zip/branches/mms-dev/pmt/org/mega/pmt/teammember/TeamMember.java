package org.mega.pmt.teammember;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.user.User;
import org.mega.pmt.marketingteam.MarketingTeam;

@Entity
@Table(name = "PMT_TEAM_MEMBER ", uniqueConstraints = @UniqueConstraint(name = "PK_TEAM_MEMBER", columnNames = "PMT_TEAM_MEMBER_ID"))
public class TeamMember extends BaseEntity{

	@Id
    @Column(name = "PMT_TEAM_MEMBER_ID")
    private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "USER_ID", foreignKey = @ForeignKey(name = "FK_TEAM_MEM_REFERENCE_CO_USER") , nullable = false)
	private User user;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TEAM_ID", foreignKey = @ForeignKey(name = "FK_TEAM_MEM_REFERENCE_PMT_MARK") , nullable = false)
	private MarketingTeam team;
	
	@Column(name = "DESCRIPTION", length = 500)
	private String description;
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}	
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public MarketingTeam getTeam() {
		return team;
	}

	public void setTeam(MarketingTeam team) {
		this.team = team;
	}

	public Long getRowId() {
		return rowId;
	}
	
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	@PrePersist
	@Override
	public void prePersist() throws Exception {
		rowId = IDGenerator.genId(this);
		fullTitle = team.getTeamTitle();
	}

	@PreUpdate
	@Override
	public void preUpdate() throws Exception {
		// TODO Auto-generated method stub
		fullTitle = team.getTeamTitle();
	}

}
