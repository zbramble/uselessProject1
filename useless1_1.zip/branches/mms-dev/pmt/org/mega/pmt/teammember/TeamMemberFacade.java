package org.mega.pmt.teammember;

import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.user.UserDTO;
import org.mega.pmt.marketingteam.MarketingTeamDTO;

public class TeamMemberFacade extends BaseFacade{
	private static TeamMemberCopier copier = new TeamMemberCopier();
	private static TeamMemberFacade facade = new TeamMemberFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static TeamMemberFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		TeamMemberDTO teamMemberDTO = (TeamMemberDTO) baseDTO;
		if(teamMemberDTO.getRowId() == 0)
			teamMemberDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		
		try {
			BaseDB db = businessParam.getDB();
			//System.out.println("select e.PMT_TEAM_MEMBER_ID from PMT_TEAM_MEMBER e where e.IS_DELETED = 0 and e.USER_ID =  "+teamMemberDTO.getUserDTO().getRowId()+" and e.TEAM_ID = "+teamMemberDTO.getTeamDTO().getRowId());
			 Query query = db.createNativeQuery("select e.PMT_TEAM_MEMBER_ID from PMT_TEAM_MEMBER e where e.IS_DELETED = 0 and e.USER_ID =  "+teamMemberDTO.getUserDTO().getRowId()+" and e.TEAM_ID = "+teamMemberDTO.getTeamDTO().getRowId());
			 if(query.getResultList().size() > 0){
				 businessParam.releaseDB();
				 return new ServiceResult(ServiceResult.ERROR_CODE.DUPLICATE,"User already in Saved","User already in Saved");
			 }else{
				 businessParam.releaseDB();
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.save(baseDTO, businessParam);
		
	}
	public ServiceResult manyToManySave(MarketingTeamDTO marketingTeamDTO,List<String> listUsers,BusinessParam businessParam){
		ServiceResult resultSave = null;
		for (int i = 0; i < listUsers.size(); i++) {
			TeamMemberDTO teamMemberDTO = new TeamMemberDTO();
			teamMemberDTO.setTeamDTO(marketingTeamDTO);
			//System.out.println(listUsers.get(i));
			UserDTO userDTO = new UserDTO();
			userDTO.setRowId(Long.parseLong(listUsers.get(i).toString().replace("[", " ").replace("]", " ")));
			//channelSKUDTO.setAccessKey((businessParam.getUserSession().getUserInfo().getAccessKey()));
			teamMemberDTO.setUserDTO(userDTO);
			//teamChannelDTO.setAccessKey((businessParam.getUserSession().getUserInfo().getAccessKey()));
			resultSave = save(teamMemberDTO, businessParam);
		}
		return resultSave;
		
	}

}
