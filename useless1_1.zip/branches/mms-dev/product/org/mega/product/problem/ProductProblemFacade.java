package org.mega.product.problem;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class ProductProblemFacade extends BaseFacade {

	private static ProductProblemCopier copier = new ProductProblemCopier();
	private static ProductProblemFacade facade = new ProductProblemFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductProblemFacade getInstace() {
		return facade;
	}

}
