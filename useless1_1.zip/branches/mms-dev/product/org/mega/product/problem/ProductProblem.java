package org.mega.product.problem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.product.Product;

@Entity
@Table(name = "BSE_PRODUCT_PROBLEM", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_PRODUCT_PROBLEM", columnNames = "PRODUCT_PROBLEM_ID") )
public class ProductProblem extends BaseEntity {

	@Id
	@Column(name = " PRODUCT_PROBLEM_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_BSE_PROD_REFERENCE_PRODUCT") , nullable = true)
	private Product product;
	
	@Column(name = "DESCRIPTION", length = 500)
	private String description;
	
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = product.getProductTitle();
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = product.getProductTitle();
    }

}
