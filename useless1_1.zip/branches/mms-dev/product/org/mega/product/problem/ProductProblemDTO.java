package org.mega.product.problem;

import org.mega.core.base.BaseDTO;
import org.mega.product.ProductDTO;

public class ProductProblemDTO extends BaseDTO {

	
	
	private long rowId;
	private ProductDTO productDTO;
	private String description;
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
}
