package org.mega.product.problem;

import org.mega.core.base.BaseCopier;
import org.mega.product.Product;
import org.mega.product.ProductDTO;

public class ProductProblemCopier extends BaseCopier<ProductProblem, ProductProblemDTO>{

	@Override
	public ProductProblemDTO copyFromEntity(ProductProblem productProblem) {
		ProductProblemDTO productProblemDTO = new ProductProblemDTO();
		productProblemDTO.setRowId(productProblem.getRowId());
		if(productProblem.getProduct() != null){
			ProductDTO productDTO = new ProductDTO();
			productDTO.setRowId(productProblem.getProduct().getRowId());
			productDTO.setProductTitle(productProblem.getProduct().getProductTitle());
			productProblemDTO.setProductDTO(productDTO);
		}
		productProblemDTO.setDescription(productProblem.getDescription());
		copyFromEntityBaseField(productProblem, productProblemDTO);
		return productProblemDTO;
	}

	@Override
	public ProductProblem copyToEntity(ProductProblemDTO productProblemDTO) throws Exception {
		ProductProblem productProblem = new ProductProblem();
		productProblem.setRowId(productProblemDTO.getRowId());
		productProblem.setDescription(productProblemDTO.getDescription());
		if(productProblemDTO.getProductDTO() != null){
			Product product = new Product();
			product.setRowId(productProblemDTO.getProductDTO().getRowId());
			product.setProductTitle(productProblemDTO.getProductDTO().getProductTitle());
			productProblem.setProduct(product);
		}
		copyToEntityBaseField(productProblem, productProblemDTO);
		return productProblem;
	}

}
