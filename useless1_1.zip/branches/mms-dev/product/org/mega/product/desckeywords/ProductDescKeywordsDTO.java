package org.mega.product.desckeywords;

import org.mega.core.base.BaseDTO;
import org.mega.product.ProductDTO;

public class ProductDescKeywordsDTO extends BaseDTO{

	private long rowId;
	private ProductDTO productDTO;
	private String description;
	private String defaultShortDescription;
	private String defaultFullDescription;
	private String defaultTagline;
	private String defaultSlogan;
	private String feature1;
	private String feature2;
	private String feature3;
	private String feature4;
	private String feature5;
	private String majorKeyword;
	private String 	keyword1;
	private String 	keyword2;
	private String 	keyword3;
	private String 	keyword4;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDefaultShortDescription() {
		return defaultShortDescription;
	}
	public void setDefaultShortDescription(String defaultShortDescription) {
		this.defaultShortDescription = defaultShortDescription;
	}
	public String getDefaultFullDescription() {
		return defaultFullDescription;
	}
	public void setDefaultFullDescription(String defaultFullDescription) {
		this.defaultFullDescription = defaultFullDescription;
	}
	public String getDefaultTagline() {
		return defaultTagline;
	}
	public void setDefaultTagline(String defaultTagline) {
		this.defaultTagline = defaultTagline;
	}
	public String getDefaultSlogan() {
		return defaultSlogan;
	}
	public void setDefaultSlogan(String defaultSlogan) {
		this.defaultSlogan = defaultSlogan;
	}
	public String getFeature1() {
		return feature1;
	}
	public void setFeature1(String feature1) {
		this.feature1 = feature1;
	}
	public String getFeature2() {
		return feature2;
	}
	public void setFeature2(String feature2) {
		this.feature2 = feature2;
	}
	public String getFeature3() {
		return feature3;
	}
	public void setFeature3(String feature3) {
		this.feature3 = feature3;
	}
	public String getFeature4() {
		return feature4;
	}
	public void setFeature4(String feature4) {
		this.feature4 = feature4;
	}
	public String getFeature5() {
		return feature5;
	}
	public void setFeature5(String feature5) {
		this.feature5 = feature5;
	}
	public String getMajorKeyword() {
		return majorKeyword;
	}
	public void setMajorKeyword(String majorKeyword) {
		this.majorKeyword = majorKeyword;
	}
	public String getKeyword1() {
		return keyword1;
	}
	public void setKeyword1(String keyword1) {
		this.keyword1 = keyword1;
	}
	public String getKeyword2() {
		return keyword2;
	}
	public void setKeyword2(String keyword2) {
		this.keyword2 = keyword2;
	}
	public String getKeyword3() {
		return keyword3;
	}
	public void setKeyword3(String keyword3) {
		this.keyword3 = keyword3;
	}
	public String getKeyword4() {
		return keyword4;
	}
	public void setKeyword4(String keyword4) {
		this.keyword4 = keyword4;
	}
	
	
	
}
