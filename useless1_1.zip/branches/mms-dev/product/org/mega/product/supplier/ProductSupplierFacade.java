package org.mega.product.supplier;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class ProductSupplierFacade extends BaseFacade{
	private static ProductSupplierCopier copier = new ProductSupplierCopier();
	private static ProductSupplierFacade facade = new ProductSupplierFacade();

	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductSupplierDTO supplierDTO = (ProductSupplierDTO) baseDTO;
		if(supplierDTO.getRowId() == 0)
			supplierDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductSupplierFacade getInstace() {
		return facade;
	}
}
