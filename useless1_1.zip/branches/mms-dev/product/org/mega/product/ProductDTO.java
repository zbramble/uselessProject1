package org.mega.product;

import org.mega.bse.brand.BrandDTO;
import org.mega.bse.category.CategoryDTO;
import org.mega.bse.currency.CurrencyDTO;
import org.mega.bse.tax.TaxDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;

public class ProductDTO extends BaseDTO {

	private long rowId;
	private ProductDTO relatedProductDTO;
	private CategoryDTO categoryDTO;
	private ComboValDTO relationShipTypeDTO;
	private TaxDTO taxClassDTO;
	private CurrencyDTO currencyTypeDTO;
	private BrandDTO brandDTO;
	private String sku;
	private String manufactureSku;
	private String barcode;
	private String productTitle;
	private double realPrice;
	private double salePrice;
	private double taxAmount;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public ProductDTO getRelatedProductDTO() {
		return relatedProductDTO;
	}

	public void setRelatedProductDTO(ProductDTO relatedProductDTO) {
		this.relatedProductDTO = relatedProductDTO;
	}


	public ComboValDTO getRelationShipTypeDTO() {
		return relationShipTypeDTO;
	}

	public void setRelationShipTypeDTO(ComboValDTO relationShipTypeDTO) {
		this.relationShipTypeDTO = relationShipTypeDTO;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getManufactureSku() {
		return manufactureSku;
	}

	public void setManufactureSku(String manufactureSku) {
		this.manufactureSku = manufactureSku;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public double getRealPrice() {
		return realPrice;
	}

	public void setRealPrice(double realPrice) {
		this.realPrice = realPrice;
	}

	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public CategoryDTO getCategoryDTO() {
		return categoryDTO;
	}

	public void setCategoryDTO(CategoryDTO categoryDTO) {
		this.categoryDTO = categoryDTO;
	}

	public TaxDTO getTaxClassDTO() {
		return taxClassDTO;
	}

	public void setTaxClassDTO(TaxDTO taxClassDTO) {
		this.taxClassDTO = taxClassDTO;
	}

	public CurrencyDTO getCurrencyTypeDTO() {
		return currencyTypeDTO;
	}

	public void setCurrencyTypeDTO(CurrencyDTO currencyTypeDTO) {
		this.currencyTypeDTO = currencyTypeDTO;
	}

	public BrandDTO getBrandDTO() {
		return brandDTO;
	}

	public void setBrandDTO(BrandDTO brandDTO) {
		this.brandDTO = brandDTO;
	}

}
