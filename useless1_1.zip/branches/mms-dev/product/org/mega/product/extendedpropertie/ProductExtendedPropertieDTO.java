package org.mega.product.extendedpropertie;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.product.ProductDTO;

public class ProductExtendedPropertieDTO extends BaseDTO{
private long rowId;
	private String description;
	private ProductDTO productDTO;
	private ComboValDTO dataTypeDTO;
	private FileDTO propertyFile;
	private String propertyName;
	private String propertyValue;
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public ComboValDTO getDataTypeDTO() {
		return dataTypeDTO;
	}
	public void setDataTypeDTO(ComboValDTO dataTypeDTO) {
		this.dataTypeDTO = dataTypeDTO;
	}
	
	public FileDTO getPropertyFile() {
		return propertyFile;
	}
	public void setPropertyFile(FileDTO propertyFile) {
		this.propertyFile = propertyFile;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	public String getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}
	
}
