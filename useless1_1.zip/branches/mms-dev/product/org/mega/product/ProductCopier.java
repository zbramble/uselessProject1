package org.mega.product;

import org.mega.bse.brand.Brand;
import org.mega.bse.brand.BrandDTO;
import org.mega.bse.category.Category;
import org.mega.bse.category.CategoryDTO;
import org.mega.bse.currency.Currency;
import org.mega.bse.currency.CurrencyDTO;
import org.mega.bse.tax.Tax;
import org.mega.bse.tax.TaxDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;

public class ProductCopier extends BaseCopier<Product, ProductDTO>{

	@Override
	public ProductDTO copyFromEntity(Product product) {
		ProductDTO productDTO = new ProductDTO();
		productDTO.setRowId(product.getRowId());
		
		productDTO.setBarcode(product.getBarcode());
		if(product.getBrand() != null){
			BrandDTO brandDTO = new BrandDTO();
			brandDTO.setRowId(product.getBrand().getRowId());
			brandDTO.setBrandTitle(product.getBrand().getBrandTitle());
			brandDTO.setAccessKey(product.getAccessKey());
			productDTO.setBrandDTO(brandDTO);
		}
		if(product.getCategory() != null){
			CategoryDTO categoryDTO = new CategoryDTO();
			categoryDTO.setRowId(product.getCategory().getRowId());
			categoryDTO.setCategoryDescription(product.getCategory().getCategoryDescription());
			categoryDTO.setAccessKey(product.getCategory().getAccessKey());
			productDTO.setCategoryDTO(categoryDTO);
		}
		if(product.getCurrencyType() != null){
			CurrencyDTO currencyDTO = new CurrencyDTO();
			currencyDTO.setRowId(product.getCurrencyType().getRowId());
			currencyDTO.setTitle(product.getCurrencyType().getTitle());
			productDTO.setCurrencyTypeDTO(currencyDTO);
		}
		if(product.getRelatedProduct() != null){
			ProductDTO p = new ProductDTO();
			p.setRowId(product.getRelatedProduct().getRowId());
			p.setAccessKey(product.getRelatedProduct().getAccessKey());
			p.setSku(product.getRelatedProduct().getSku());
			p.setProductTitle(product.getRelatedProduct().getProductTitle());
			productDTO.setRelatedProductDTO(p);
		}
		if(product.getTaxClass() != null){ 
			TaxDTO taxClassDTO = new TaxDTO();
			taxClassDTO.setRowId(product.getTaxClass().getRowId());
			taxClassDTO.setTaxClassTitle(product.getTaxClass().getTaxClassTitle());
			productDTO.setTaxClassDTO(taxClassDTO);
		}
		if(product.getRelationShipType() != null){
			ComboValDTO c = new ComboValDTO();
			c.setRowId(product.getRelationShipType().getRowId());
			c.setName(product.getRelationShipType().getName());
			productDTO.setRelationShipTypeDTO(c);
		}
		productDTO.setRealPrice(product.getRealPrice());
		productDTO.setSalePrice(product.getSalePrice());
		productDTO.setTaxAmount(product.getTaxAmount());

		productDTO.setSku(product.getSku());
		productDTO.setProductTitle(product.getProductTitle());
		productDTO.setManufactureSku(product.getManufactureSku());
		copyFromEntityBaseField(product, productDTO);
		return productDTO;
	}

	@Override
	public Product copyToEntity(ProductDTO productDTO) throws Exception {
		Product product = new Product();
		product.setRowId(productDTO.getRowId());
		
		product.setBarcode(productDTO.getBarcode());
		if(productDTO.getBrandDTO() != null){
			Brand brand = new Brand();
			brand.setRowId(productDTO.getBrandDTO().getRowId());
//			brand.setBrandTitle(productDTO.getBrand().getBrandTitle());
//			brand.setAccessKey(productDTO.getAccessKey());
			product.setBrand(brand);
		}
		if(productDTO.getCategoryDTO() != null){
			Category category = new Category();
			category.setRowId(productDTO.getCategoryDTO().getRowId());
//			category.setTopCategory(productDTO.getCategory().getTopCategory());
//			category.setCategoryDescription(productDTO.getCategory().getCategoryDescription());
//			category.setAccessKey(productDTO.getCategory().getAccessKey());
			product.setCategory(category);
		}
		
		if(productDTO.getCurrencyTypeDTO() != null){
			Currency currency = new Currency();
			currency.setRowId(productDTO.getCurrencyTypeDTO().getRowId());
			currency.setTitle(productDTO.getCurrencyTypeDTO().getTitle());
			product.setCurrencyType(currency);
		}
		
		if(productDTO.getRelatedProductDTO() != null){
			Product p = new Product();
			p.setRowId(productDTO.getRelatedProductDTO().getRowId());
//			p.setAccessKey(productDTO.getRelatedProduct().getAccessKey());
//			p.setSku(productDTO.getRelatedProduct().getSku());
			product.setRelatedProduct(p);
		}
		
				
		if(productDTO.getTaxClassDTO() != null){ 
			Tax taxClass = new Tax();
			taxClass.setRowId(productDTO.getTaxClassDTO().getRowId());
//			taxClass.setTaxClassTitle(productDTO.getTaxClassDTO().getTaxClassTitle());
			product.setTaxClass(taxClass);
		}
		if(productDTO.getRelationShipTypeDTO() != null){
			ComboVal c = new ComboVal();
			c.setRowId(productDTO.getRelationShipTypeDTO().getRowId());
			c.setName(productDTO.getRelationShipTypeDTO().getName());
			product.setRelationShipType(c);
		}
		product.setRealPrice(productDTO.getRealPrice());
		product.setSalePrice(productDTO.getSalePrice());
		product.setTaxAmount(productDTO.getTaxAmount());
		product.setManufactureSku(productDTO.getManufactureSku());
		product.setProductTitle(productDTO.getProductTitle());
		product.setSku(productDTO.getSku());
		copyToEntityBaseField(product, productDTO);
		return product;
	}

}
