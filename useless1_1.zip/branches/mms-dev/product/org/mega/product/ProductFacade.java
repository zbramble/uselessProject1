package org.mega.product;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.sec.UserSession;
import org.mega.product.problem.ProductProblemDTO;
import org.mega.product.problem.ProductProblemFacade;

public class ProductFacade extends BaseFacade {

	private static ProductCopier copier = new ProductCopier();
	private static ProductFacade facade = new ProductFacade();

	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		ProductDTO productDTO = (ProductDTO) baseDTO;
		if(productDTO.getRowId() == 0){
			productDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
			
			ServiceResult saveResult=super.save(baseDTO, businessParam);
			if(saveResult.isDone()){
				//به ازای هر پروداکت یک پرابلم پیش فرض هم ثبت شود
				productDTO.setRowId(Long.parseLong(saveResult.getResult().toString()));
				ProductProblemDTO problem = new ProductProblemDTO();
				problem.setProductDTO(productDTO);
				problem.setDescription("Not Categorized");
				try{
				    ProductProblemFacade.getInstace().save(problem, businessParam);
				}catch (Exception e) {
					System.out.println("***Error in registering default problem for product***");
					System.out.println(e.getMessage());
				}
				return saveResult;
			}
		}
		return super.save(baseDTO, businessParam);
	}

	
	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ProductFacade getInstance() {
		return facade;
	}
	
	@Override
	public String getConstraint(BusinessParam businessParam) {
		UserSession userSession = businessParam.getUserSession();
		if(userSession.dontCheckAccess())
			return null;
		return "e.accessKey like '" + userSession.getUserInfo().getAccessKey() +"%' ";
	}

}
