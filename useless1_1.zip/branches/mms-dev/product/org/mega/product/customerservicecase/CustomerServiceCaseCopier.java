package org.mega.product.customerservicecase;

import org.mega.bse.channel.Channel;
import org.mega.bse.channel.ChannelDTO;
import org.mega.bse.site.Site;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.product.Product;
import org.mega.product.ProductDTO;
import org.mega.product.problem.ProductProblem;
import org.mega.product.problem.ProductProblemDTO;
import org.mega.util.DateUtil;

public class CustomerServiceCaseCopier extends BaseCopier<CustomerServiceCase, CustomerServiceCaseDTO>{

	@Override
	public CustomerServiceCaseDTO copyFromEntity(CustomerServiceCase cusomerServiceCase) {
		CustomerServiceCaseDTO cusomerServiceCaseDTO = new CustomerServiceCaseDTO();
		cusomerServiceCaseDTO.setRowId(cusomerServiceCase.getRowId());
		if(cusomerServiceCase.getProduct() != null){
			ProductDTO productDTO = new ProductDTO();
			productDTO.setRowId(cusomerServiceCase.getProduct().getRowId());
			productDTO.setProductTitle(cusomerServiceCase.getProduct().getProductTitle());
			cusomerServiceCaseDTO.setProductDTO(productDTO);
		}
		if(cusomerServiceCase.getProductProblem() != null){
			ProductProblemDTO problemDTO = new ProductProblemDTO();
			problemDTO.setRowId(cusomerServiceCase.getProductProblem().getRowId());
			problemDTO.setFullTitle(cusomerServiceCase.getProductProblem().getFullTitle());
			problemDTO.setDescription(cusomerServiceCase.getProductProblem().getDescription());
			cusomerServiceCaseDTO.setProductProblemDTO(problemDTO);
		}
		if(cusomerServiceCase.getCaseType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(cusomerServiceCase.getCaseType().getRowId());
			comboValDTO.setName(cusomerServiceCase.getCaseType().getName());
			cusomerServiceCaseDTO.setCaseTypeDTO(comboValDTO);
		}
		if(cusomerServiceCase.getCaseSatusType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(cusomerServiceCase.getCaseSatusType().getRowId());
			comboValDTO.setName(cusomerServiceCase.getCaseSatusType().getName());
			cusomerServiceCaseDTO.setCaseSatusTypeDTO(comboValDTO);
		} 
		if(cusomerServiceCase.getCaseReasonType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(cusomerServiceCase.getCaseReasonType().getRowId());
			comboValDTO.setName(cusomerServiceCase.getCaseReasonType().getName());
			cusomerServiceCaseDTO.setCaseReasonTypeDTO(comboValDTO);
		}
		if(cusomerServiceCase.getChannel() != null){
			ChannelDTO channelDTO = new ChannelDTO();
			channelDTO.setRowId(cusomerServiceCase.getChannel().getRowId());
			channelDTO.setChannelName(cusomerServiceCase.getChannel().getChannelName());
			cusomerServiceCaseDTO.setChannelDTO(channelDTO);
		}
		
		if(cusomerServiceCase.getSite() != null){
			SiteDTO siteDTO = new SiteDTO();
			siteDTO.setRowId(cusomerServiceCase.getSite().getRowId());
			siteDTO.setSiteName(cusomerServiceCase.getSite().getSiteName());
			cusomerServiceCaseDTO.setSiteDTO(siteDTO);
		}
		if(cusomerServiceCase.getUser() != null){
			UserDTO userDTO = new UserDTO();
			userDTO.setRowId(cusomerServiceCase.getUser().getRowId());
			userDTO.setFullName(cusomerServiceCase.getUser().getFullName());
			cusomerServiceCaseDTO.setUserDTO(userDTO);
		}
		if(cusomerServiceCase.getCountry() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(cusomerServiceCase.getCountry().getRowId());
			locationDTO.setName(cusomerServiceCase.getCountry().getName());
			cusomerServiceCaseDTO.setCountryDTO(locationDTO);
		}
		if(cusomerServiceCase.getRequestedActionType() != null){
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(cusomerServiceCase.getRequestedActionType().getRowId());
			comboValDTO.setName(cusomerServiceCase.getRequestedActionType().getName());
			cusomerServiceCaseDTO.setRequestedActionTypeDTO(comboValDTO);
		}
		cusomerServiceCaseDTO.setCustomerName(cusomerServiceCase.getCustomerName());
		cusomerServiceCaseDTO.setCaseDate(DateUtil.getDateString(cusomerServiceCase.getCaseDate(), "en"));
		cusomerServiceCaseDTO.setOrderId(cusomerServiceCase.getOrderId());
		cusomerServiceCaseDTO.setCaseDescription(cusomerServiceCase.getCaseDescription());
		if(cusomerServiceCase.getState() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(cusomerServiceCase.getState().getRowId());
			locationDTO.setName(cusomerServiceCase.getState().getName());
			cusomerServiceCaseDTO.setStateDTO(locationDTO);
		}
		if(cusomerServiceCase.getCity() != null){
			LocationDTO locationDTO = new LocationDTO();
			locationDTO.setRowId(cusomerServiceCase.getCity().getRowId());
			locationDTO.setName(cusomerServiceCase.getCity().getName());
			cusomerServiceCaseDTO.setCityDTO(locationDTO);
		}
		copyFromEntityBaseField(cusomerServiceCase, cusomerServiceCaseDTO);
		return cusomerServiceCaseDTO;
	}

	@Override
	public CustomerServiceCase copyToEntity(CustomerServiceCaseDTO cusomerServiceCaseDTO) throws Exception {
		CustomerServiceCase cusomerServiceCase = new CustomerServiceCase();
		cusomerServiceCase.setRowId(cusomerServiceCaseDTO.getRowId());
		if(cusomerServiceCaseDTO.getProductDTO() != null){
			Product product = new Product();
			product.setRowId(cusomerServiceCaseDTO.getProductDTO().getRowId());
			cusomerServiceCase.setProduct(product);
		}
		if(cusomerServiceCaseDTO.getProductProblemDTO() != null){
			ProductProblem problem = new ProductProblem();
			problem.setRowId(cusomerServiceCaseDTO.getProductProblemDTO().getRowId());
			problem.setFullTitle(cusomerServiceCaseDTO.getProductProblemDTO().getFullTitle());
			cusomerServiceCase.setProductProblem(problem);
		}
		if(cusomerServiceCaseDTO.getCaseTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(cusomerServiceCaseDTO.getCaseTypeDTO().getRowId());
			cusomerServiceCase.setCaseType(comboVal);
		}
		if(cusomerServiceCaseDTO.getCaseSatusTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(cusomerServiceCaseDTO.getCaseSatusTypeDTO().getRowId());
			cusomerServiceCase.setCaseSatusType(comboVal);
		} 
		if(cusomerServiceCaseDTO.getCaseReasonTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(cusomerServiceCaseDTO.getCaseReasonTypeDTO().getRowId());
			cusomerServiceCase.setCaseReasonType(comboVal);
		}
		if(cusomerServiceCaseDTO.getChannelDTO() != null){
			Channel channel = new Channel();
			channel.setRowId(cusomerServiceCaseDTO.getChannelDTO().getRowId());
			cusomerServiceCase.setChannel(channel);
		}
		if(cusomerServiceCaseDTO.getSiteDTO() != null){
			Site site= new Site();
			site.setRowId(cusomerServiceCaseDTO.getSiteDTO().getRowId());
			cusomerServiceCase.setSite(site);
		}
		if(cusomerServiceCaseDTO.getUserDTO() != null){
			User user = new User();
			user.setRowId(cusomerServiceCaseDTO.getUserDTO().getRowId());
			cusomerServiceCase.setUser(user);
		}
		if(cusomerServiceCaseDTO.getCountryDTO() != null){
			Location location = new Location();
			location.setRowId(cusomerServiceCaseDTO.getCountryDTO().getRowId());
			cusomerServiceCase.setCountry(location);
		}
		if(cusomerServiceCaseDTO.getRequestedActionTypeDTO() != null){
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(cusomerServiceCaseDTO.getRequestedActionTypeDTO().getRowId());
			cusomerServiceCase.setRequestedActionType(comboVal);
		}
		cusomerServiceCase.setCustomerName(cusomerServiceCaseDTO.getCustomerName());
		cusomerServiceCase.setCaseDate(DateUtil.getDate(cusomerServiceCaseDTO.getCaseDate(), "en"));
		cusomerServiceCase.setOrderId(cusomerServiceCaseDTO.getOrderId());
		cusomerServiceCase.setCaseDescription(cusomerServiceCaseDTO.getCaseDescription());
		if(cusomerServiceCaseDTO.getStateDTO() != null){
			Location location = new Location();
			location.setRowId(cusomerServiceCaseDTO.getStateDTO().getRowId());
			cusomerServiceCase.setState(location);
		}
		if(cusomerServiceCaseDTO.getCityDTO() != null){
			Location location = new Location();
			location.setRowId(cusomerServiceCaseDTO.getCityDTO().getRowId());
			cusomerServiceCase.setCity(location);
		}
		
		copyToEntityBaseField(cusomerServiceCase, cusomerServiceCaseDTO);
		return cusomerServiceCase;
	}

}
