package org.mega.product.customerservicecase;




import org.mega.bse.channel.ChannelDTO;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.LocationDTO;
import org.mega.core.user.UserDTO;
import org.mega.product.ProductDTO;
import org.mega.product.problem.ProductProblemDTO;


public class CustomerServiceCaseDTO extends BaseDTO {
	private long rowId;
	private ProductDTO productDTO;
	private ProductProblemDTO  productProblemDTO;
	private ComboValDTO caseTypeDTO;
	private ComboValDTO caseSatusTypeDTO;
	private ComboValDTO caseReasonTypeDTO;
	private ChannelDTO channelDTO;
	private SiteDTO siteDTO;
	private UserDTO userDTO;
	private LocationDTO countryDTO;
	private ComboValDTO requestedActionTypeDTO;
	private String customerName;
	private String caseDate;
	private String orderId;
	private String caseDescription;
	private LocationDTO stateDTO;
	private LocationDTO cityDTO;
	
	public ProductProblemDTO getProductProblemDTO() {
		return productProblemDTO;
	}
	
	public void setProductProblemDTO(ProductProblemDTO productProblemDTO) {
		this.productProblemDTO = productProblemDTO;
	}
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public ProductDTO getProductDTO() {
		return productDTO;
	}
	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}
	public ComboValDTO getCaseTypeDTO() {
		return caseTypeDTO;
	}
	public void setCaseTypeDTO(ComboValDTO caseTypeDTO) {
		this.caseTypeDTO = caseTypeDTO;
	}
	public ComboValDTO getCaseSatusTypeDTO() {
		return caseSatusTypeDTO;
	}
	public void setCaseSatusTypeDTO(ComboValDTO caseSatusTypeDTO) {
		this.caseSatusTypeDTO = caseSatusTypeDTO;
	}
	public ComboValDTO getCaseReasonTypeDTO() {
		return caseReasonTypeDTO;
	}
	public void setCaseReasonTypeDTO(ComboValDTO caseReasonTypeDTO) {
		this.caseReasonTypeDTO = caseReasonTypeDTO;
	}
	public ChannelDTO getChannelDTO() {
		return channelDTO;
	}
	public void setChannelDTO(ChannelDTO channelDTO) {
		this.channelDTO = channelDTO;
	}
	public SiteDTO getSiteDTO() {
		return siteDTO;
	}
	public void setSiteDTO(SiteDTO siteDTO) {
		this.siteDTO = siteDTO;
	}
	public UserDTO getUserDTO() {
		return userDTO;
	}
	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}
	public LocationDTO getCountryDTO() {
		return countryDTO;
	}
	public void setCountryDTO(LocationDTO countryDTO) {
		this.countryDTO = countryDTO;
	}
	public ComboValDTO getRequestedActionTypeDTO() {
		return requestedActionTypeDTO;
	}
	public void setRequestedActionTypeDTO(ComboValDTO requestedActionTypeDTO) {
		this.requestedActionTypeDTO = requestedActionTypeDTO;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCaseDate() {
		return caseDate;
	}
	public void setCaseDate(String caseDate) {
		this.caseDate = caseDate;
	}
	public String getOrderId() {
		return orderId;
	}
	
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	public String getCaseDescription() {
		return caseDescription;
	}
	public void setCaseDescription(String caseDescription) {
		this.caseDescription = caseDescription;
	}
	public LocationDTO getStateDTO() {
		return stateDTO;
	}
	public void setStateDTO(LocationDTO stateDTO) {
		this.stateDTO = stateDTO;
	}
	public LocationDTO getCityDTO() {
		return cityDTO;
	}
	public void setCityDTO(LocationDTO cityDTO) {
		this.cityDTO = cityDTO;
	}
	
}
