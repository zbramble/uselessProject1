package org.mega.product.customerservicecase;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class CustomerServiceCaseFacade extends BaseFacade {

	private static CustomerServiceCaseCopier copier = new CustomerServiceCaseCopier();
	private static CustomerServiceCaseFacade facade = new CustomerServiceCaseFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static CustomerServiceCaseFacade getInstance() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		CustomerServiceCaseDTO customerServiceCaseDTO = (CustomerServiceCaseDTO) baseDTO;
		if(customerServiceCaseDTO.getRowId() == 0)
			customerServiceCaseDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}

}
