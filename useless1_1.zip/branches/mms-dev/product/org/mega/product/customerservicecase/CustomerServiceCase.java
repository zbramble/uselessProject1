package org.mega.product.customerservicecase;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.mega.bse.channel.Channel;
import org.mega.bse.site.Site;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.location.Location;
import org.mega.core.user.User;
import org.mega.product.Product;
import org.mega.product.problem.ProductProblem;



@Entity
@Table(name = "PMT_CUSTOMER_SERVICE_CASE", uniqueConstraints = @UniqueConstraint(name = "PK_PMT_CUSTOMER_SERVICE_CASE", columnNames = "PMT_CUSTOMER_SERVICE_CASE_ID") )
public class CustomerServiceCase extends BaseEntity {

	@Id
	@Column(name = "PMT_CUSTOMER_SERVICE_CASE_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REFERENCE_PRODUCT") , nullable = true)
	private Product product;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_PROBLEM_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_PRODUCT_PROBLEM") , nullable = true)
	private ProductProblem  productProblem;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CASE_TYPE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REFERENCE_CO_COMBO") , nullable = true)
	private ComboVal caseType;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CASE_STATUS_TYPE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CASE_STATUS_TYPE_COMBO") , nullable = true)
	private ComboVal caseSatusType;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CASE_REASON_TYPE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CASE_REASON_COMBO") , nullable = true)
	private ComboVal caseReasonType;
	
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BSE_CHANNEL_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REFERENCE_BSE_CHAN") , nullable = true)
	private Channel channel;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "BSE_SITE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REFERENCE_BSE_SITE") , nullable = true)
	private Site site;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CS_USER_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REFERENCE_CO_USER") , nullable = true)
	private User user;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "COUNTRY_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REFERENCE_CO_LOCAT") , nullable = true)
	private Location country;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CUSTOMER_REQUESTED_ACTION_TYPE", foreignKey = @ForeignKey(name = "FK_PMT_CUST_REQUESTED_COMBO") , nullable = true)
	private ComboVal requestedActionType;
	
	@Column(name = "CUSTOMER_NAME", length = 500)
	private String customerName;
	
	@Temporal(TemporalType.DATE)
    @Column(name = "CASE_DATE")
    private Date caseDate;
	
	@Column(name = "ORDER_ID", nullable = true,length=20)
	private String orderId;
	
	@Column(name = "CASE_DESCRIPTION", length = 2000)
	private String caseDescription;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "STATE_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_STATE_ID") , nullable = true)
	private Location state;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CITY_ID", foreignKey = @ForeignKey(name = "FK_PMT_CUST_CITY_ID") , nullable = true)
	private Location city;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ComboVal getCaseType() {
		return caseType;
	}

	public void setCaseType(ComboVal caseType) {
		this.caseType = caseType;
	}

	public ComboVal getCaseSatusType() {
		return caseSatusType;
	}

	public void setCaseSatusType(ComboVal caseSatusType) {
		this.caseSatusType = caseSatusType;
	}

	public ComboVal getCaseReasonType() {
		return caseReasonType;
	}

	public void setCaseReasonType(ComboVal caseReasonType) {
		this.caseReasonType = caseReasonType;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Location getCountry() {
		return country;
	}

	public void setCountry(Location country) {
		this.country = country;
	}

	public ComboVal getRequestedActionType() {
		return requestedActionType;
	}

	public void setRequestedActionType(ComboVal requestedActionType) {
		this.requestedActionType = requestedActionType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getCaseDate() {
		return caseDate;
	}

	public void setCaseDate(Date caseDate) {
		this.caseDate = caseDate;
	}

	public String getOrderId() {
		return orderId;
	}
	
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCaseDescription() {
		return caseDescription;
	}

	public void setCaseDescription(String caseDescription) {
		this.caseDescription = caseDescription;
	}

	public Location getState() {
		return state;
	}

	public void setState(Location state) {
		this.state = state;
	}

	public Location getCity() {
		return city;
	}

	public void setCity(Location city) {
		this.city = city;
	}

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	public ProductProblem getProductProblem() {
		return productProblem;
	}
	
	public void setProductProblem(ProductProblem productProblem) {
		this.productProblem = productProblem;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = customerName;
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = customerName;
    }

}
