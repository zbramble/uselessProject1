package org.mega.msg.conversationroom;

import java.util.List;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.msg.conversation.ConversationDTO;
import org.mega.msg.conversationuser.ConversationUserDTO;

import java.util.List;

public class ConversationRoomDTO extends BaseDTO {
    private long rowId;
    private String name;
    private ComboValDTO category;
    private ComboValDTO type;
    private ComboValDTO priority;
    private List<ConversationUserDTO> conversationUsersLists;
    private List<ConversationDTO> conversations;
    private ConversationRoomStatus lastStatus;
    private String lastConversation;
    private int unseen = 0;

    public ConversationRoomDTO() {
    }

    public ConversationRoomDTO(long rowId) {
        this.rowId = rowId;
    }

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ComboValDTO getCategory() {
        return category;
    }

    public void setCategory(ComboValDTO category) {
        this.category = category;
    }

    public ComboValDTO getType() {
        return type;
    }

    public void setType(ComboValDTO type) {
        this.type = type;
    }

    public ComboValDTO getPriority() {
        return priority;
    }

    public void setPriority(ComboValDTO priority) {
        this.priority = priority;
    }

    public List<ConversationUserDTO> getConversationUsersLists() {
        return conversationUsersLists;
    }

    public void setConversationUsersLists(List<ConversationUserDTO> conversationUsersLists) {
        this.conversationUsersLists = conversationUsersLists;
    }

    public List<ConversationDTO> getConversations() {
        return conversations;
    }

    public void setConversations(List<ConversationDTO> conversations) {
        this.conversations = conversations;
    }

    public ConversationRoomStatus getLastStatus() {
        return lastStatus;
    }

    public void setLastStatus(ConversationRoomStatus lastStatus) {
        this.lastStatus = lastStatus;
    }

    public String getLastConversation() {
        return lastConversation;
    }

    public void setLastConversation(String lastConversation) {
        this.lastConversation = lastConversation;
    }

    public int getUnseen() {
        return unseen;
    }

    public void setUnseen(int unseen) {
        this.unseen = unseen;
    }
}