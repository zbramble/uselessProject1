package org.mega.msg.conversationroom;

public enum ConversationRoomStatus {
    NEW_MESSAGE("New message"),
    SEE("See"),
    ANSWERED("Answered");

    private String value;

    ConversationRoomStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}