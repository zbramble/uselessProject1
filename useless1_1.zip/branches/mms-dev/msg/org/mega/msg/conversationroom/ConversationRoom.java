package org.mega.msg.conversationroom;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.msg.conversation.Conversation;
import org.mega.msg.conversationuser.ConversationUser;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "MSG_CONVERSATION_ROOM",
        uniqueConstraints = @UniqueConstraint(name = "PK_MSG_CONVERSATION_ROOM", columnNames = "ID"))
public class ConversationRoom extends BaseEntity {

    @Id
    @Column(name = "ID", nullable = false)
    private long rowId;

    @Column(name = "NAME", length = 4000)
    private String name;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "CATEGORY", foreignKey = @ForeignKey(name = "FK_CNRM_CATEGORY_2_CMVL"))
    private ComboVal category;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "TYPE", foreignKey = @ForeignKey(name = "FK_CNRM_TYPE_2_CMVL"))
    private ComboVal type;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "PRIORITY", foreignKey = @ForeignKey(name = "FK_CNRM_PRIORITY_2_CMVL"))
    private ComboVal priority;

    @OneToMany(mappedBy = "conversationRoom")
    private List<ConversationUser> conversationUsersLists;

    @OneToMany(mappedBy = "conversationRoom")
    private List<Conversation> conversations;

    @Column(name = "LAST_STATUS")
    @Enumerated(EnumType.STRING)
    private ConversationRoomStatus lastStatus;

    @Column(name = "LAST_CONVERSATION", length = 4000)
    private String lastConversation;

    public ConversationRoom() {
    }

    public ConversationRoom(Long rowId) {
        this.rowId = rowId;
    }

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ComboVal getCategory() {
        return category;
    }

    public void setCategory(ComboVal category) {
        this.category = category;
    }

    public ComboVal getType() {
        return type;
    }

    public void setType(ComboVal type) {
        this.type = type;
    }

    public ComboVal getPriority() {
        return priority;
    }

    public void setPriority(ComboVal priority) {
        this.priority = priority;
    }

    public List<ConversationUser> getConversationUsersLists() {
        return conversationUsersLists;
    }

    public void setConversationUsersLists(List<ConversationUser> conversationUsersLists) {
        this.conversationUsersLists = conversationUsersLists;
    }

    public List<Conversation> getConversations() {
        return conversations;
    }

    public void setConversations(List<Conversation> conversations) {
        this.conversations = conversations;
    }

    public ConversationRoomStatus getLastStatus() {
        return lastStatus;
    }

    public void setLastStatus(ConversationRoomStatus lastStatus) {
        this.lastStatus = lastStatus;
    }

    public String getLastConversation() {
        return lastConversation;
    }

    public void setLastConversation(String lastConversation) {
        this.lastConversation = lastConversation;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    }
}