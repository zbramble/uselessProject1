package org.mega.msg.conversationroom;

import org.mega.core.base.*;
import org.mega.core.sec.OnlineUserManager;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;
import org.mega.core.user.UserFacade;
import org.mega.msg.conversationuser.ConversationUser;
import org.mega.msg.conversationuser.ConversationUserDTO;
import org.mega.msg.conversationuser.ConversationUserFacade;
import org.mega.util.QueryUtil;
import org.mega.util.WebUtil;

import javax.persistence.Query;
import java.util.Arrays;
import java.util.List;

public class ConversationRoomFacade extends BaseFacade {
    private static ConversationRoomCopier copier = new ConversationRoomCopier();
    private static ConversationRoomFacade facade = new ConversationRoomFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static ConversationRoomFacade getInstance() {
        return facade;
    }

    public ServiceResult list(BusinessParam businessParam) {
        long userId = businessParam.getUserSession().getUserInfo().getUserId();

        try {
            String constraint = getConstraint(businessParam);
            Query query = businessParam.getDB().createQuery(
                    "SELECT distinct e " +
                            "FROM ConversationRoom e " +
                            "LEFT JOIN ConversationUser T2 " +
                            "ON e.rowId = T2.conversationRoom.rowId AND T2.active = TRUE AND T2.deleted = 0 " +
                            "LEFT JOIN Supporter T3 " +
                            "ON e.type.rowId = T3.type.rowId AND T3.active = TRUE AND T3.deleted = 0 " +
                            QueryUtil.getWhereClause(businessParam.getFilter()
                                    , " e.active = TRUE AND e.deleted = 0 AND (T2.user.rowId = :userId OR T3.user.rowId = :userId) " +
                                            (constraint != null ? "AND (" + constraint + ")" : "")) +
                            QueryUtil.getOrderByClause(businessParam.getFilter()));

            query.setParameter("userId", userId);
            query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
            query.setMaxResults(businessParam.getFilter().getPageSize());

            List<ConversationRoom> conversationRooms = query.getResultList();
            ServiceResult serviceResult = new ServiceResult(copier.copyFromEntity(conversationRooms), conversationRooms.size());
            businessParam.releaseDB();
            return serviceResult;
        } catch (Exception e) {
            businessParam.rolback();
            return new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, "Error.", e);
        }
    }

    public ServiceResult save(ConversationRoomDTO conversationRoom, BusinessParam businessParam) {
        conversationRoom.setLastStatus(ConversationRoomStatus.NEW_MESSAGE);
        ServiceResult serviceResult = super.save(conversationRoom, businessParam);
        if (!serviceResult.isDone()) {
            return serviceResult;
        }
        try {
            // Add current user to conversation user list.
            if (conversationRoom.getRowId() == 0) {
                addUserToRoom((Long) serviceResult.getResult()
                        , businessParam.getUserSession().getUserInfo().getUserId()
                        , businessParam);

                //Add a online supporter to ConversationRoom
                if (conversationRoom.getType() != null && conversationRoom.getType().getRowId() == 100077) { //ONLINE
                    long supportUserId = OnlineUserManager.getInstance().getSupporter();
                    if (supportUserId != 0) {
                        addUserToRoom((Long) serviceResult.getResult(), supportUserId, businessParam);
                    } else {
                        System.out.println("------Poshtiban online vojod nadarad");
                    }
                }

            }
        } catch (Exception e) {
            businessParam.rolback();
            long errorId = System.nanoTime();
            BaseLogger.getLogger().info("#Error Id:" + errorId + "\n " + Arrays.toString(e.getStackTrace()));
            return new ServiceResult(ServiceResult.ERROR_CODE.BUSINESS_MESSAGE, "Error save entity. error code:" + errorId, "");
        }
        return serviceResult;
    }

    public ServiceResult saveList(MasterConversationRoomDTO roomDTO, BusinessParam businessParam) {

        // Check: بررسی وجود اتاق گفتگو بین دو کاربر
        if (roomDTO.getConversationRoom().getCategory().getRowId() == 100079 //PRIVATE
                || roomDTO.getConversationRoom().getCategory().getRowId() == 100077) { //ONLINE_SUPPORTER

            ServiceResult result =
                    findOldRoom(roomDTO.getConversationUsers().get(0).getUser().getRowId(), businessParam);
            if (result.isDone() && result.getResult() != null) {
                return result;
            }
        }

        ServiceResult serviceResult = save(roomDTO.getConversationRoom(), businessParam);
        if (!serviceResult.isDone()) {
            return serviceResult;
        }
        ConversationRoomDTO conversationRoomDTO = new ConversationRoomDTO();
        conversationRoomDTO.setRowId((Long) serviceResult.getResult());
        for (ConversationUserDTO conversationUserDTO : roomDTO.getConversationUsers()) {

            conversationUserDTO.setConversationRoom(conversationRoomDTO);
            conversationUserDTO.setActive(true);
            conversationUserDTO.setTicket(roomDTO.getTicket());
            ConversationUserFacade.getInstance().save(conversationUserDTO, businessParam);
        }
        return serviceResult;
    }

    private void addUserToRoom(long conversationRoomId, long userId, BusinessParam businessParam) throws Exception {
        ConversationUserDTO conversationUser = new ConversationUserDTO();
        //Conversation Room
        ConversationRoomDTO conversationRoom = new ConversationRoomDTO();
        conversationRoom.setRowId(conversationRoomId);
        conversationUser.setConversationRoom(conversationRoom);
        //user
        UserDTO user = new UserDTO();
        user.setRowId(userId);
        conversationUser.setUser(user);
        //Other Attribute
        conversationUser.setActive(true);
        //Save Entity
        ConversationUserFacade.getInstance().save(conversationUser, businessParam);
    }

    public ServiceResult findOldRoom(long userId, BusinessParam businessParam) {
        long currentUserId = businessParam.getUserSession().getUserInfo().getUserId();
        ServiceResult serviceResult;
        try {
            Query query = businessParam.getDB().createQuery(
                    "SELECT distinct e" +
                            "  FROM ConversationUser e " +
                            "  JOIN ConversationUser e1 " +
                            "    ON e.conversationRoom.rowId = e1.conversationRoom.rowId " +
                            "    AND e.conversationRoom.category.rowId IN (100077, 100079)" +
                            "    AND e.conversationRoom.active = TRUE " +
                            "    AND e.conversationRoom.deleted = 0 " +
                            " WHERE e.active = TRUE " +
                            "   AND e.deleted = 0 " +
                            "   AND e1.active = TRUE " +
                            "   AND e1.deleted = 0" +
                            "   AND e.user.rowId = :currentUserId " +
                            "   AND e1.user.rowId = :userId" +
                            (getConstraint(businessParam) != null ? "   AND (" + getConstraint(businessParam) + " )" : ""));

            query.setParameter("currentUserId", currentUserId);
            query.setParameter("userId", userId);
            List<ConversationUser> conversationUsers = query.getResultList();
            if (conversationUsers.size() > 0) {
                serviceResult = new ServiceResult(conversationUsers.get(0).getConversationRoom().getRowId(), conversationUsers.size());
            } else {
                serviceResult = new ServiceResult(ServiceResult.ERROR_CODE.BUSINESS_MESSAGE, "There is no information to display.", "");
            }
            businessParam.releaseDB();
            return serviceResult;
        } catch (Exception e) {
            businessParam.rolback();
            long errorId = System.nanoTime();
            BaseLogger.getLogger().info("#Error Id:" + errorId + "\n " + Arrays.toString(e.getStackTrace()));
            return new ServiceResult(ServiceResult.ERROR_CODE.BUSINESS_MESSAGE, "Error fetching information. Error code:" + errorId, "");
        }
    }
}