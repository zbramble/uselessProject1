package org.mega.msg.conversation;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.comboval.ComboVal;
import org.mega.core.file.File;
import org.mega.msg.conversationroom.ConversationRoom;

import javax.persistence.*;

@Entity
@Table(name = "MSG_CONVERSATION",
        uniqueConstraints = @UniqueConstraint(name = "PK_MSG_CONVERSATION", columnNames = "ID"))
public class Conversation extends BaseEntity {

    @Id
    @Column(name = "ID", nullable = false)
    private long rowId;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "CONVERSATION_ROOM_ID", nullable = false, foreignKey = @ForeignKey(name = "FK_CONV_2_HDSK"))
    private ConversationRoom conversationRoom;

    @Column(name = "TEXT", length = 4000)
    private String text;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "ATTACHE", foreignKey = @ForeignKey(name = "FK_CONV_2_FILE"))
    private File attache;

    @Column(name = "AMOUNT_LIKES")
    private int amountLikes;

    @Column(name = "OPINION", length = 1000)
    private String opinion;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "STATUS", foreignKey = @ForeignKey(name = "FK_CONV_2_CMVL"))
    private ComboVal status;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "PARENT", foreignKey = @ForeignKey(name = "FK_CONV_2_CONV"))
    private Conversation parent;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public ConversationRoom getConversationRoom() {
        return conversationRoom;
    }

    public void setConversationRoom(ConversationRoom conversationRoom) {
        this.conversationRoom = conversationRoom;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public File getAttache() {
        return attache;
    }

    public void setAttache(File attache) {
        this.attache = attache;
    }

    public int getAmountLikes() {
        return amountLikes;
    }

    public void setAmountLikes(int amountLikes) {
        this.amountLikes = amountLikes;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    public ComboVal getStatus() {
        return status;
    }

    public void setStatus(ComboVal status) {
        this.status = status;
    }

    public Conversation getParent() {
        return parent;
    }

    public void setParent(Conversation parent) {
        this.parent = parent;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = getCreatedBy().getUsername() + ":" + (getText().length() > 10 ? getText().substring(0, 10) : getText());    }

    @PreUpdate
    public void preUpdate() throws Exception {
    	fullTitle = getCreatedBy().getUsername() + ":" + (getText().length() > 10 ? getText().substring(0, 10) : getText());    }
}