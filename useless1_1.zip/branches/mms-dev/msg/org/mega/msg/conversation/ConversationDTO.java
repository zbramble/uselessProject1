package org.mega.msg.conversation;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.file.FileDTO;
import org.mega.msg.conversationroom.ConversationRoomDTO;

public class ConversationDTO extends BaseDTO {
    private long rowId;
    private ConversationRoomDTO conversationRoom;
    private String text;
    private FileDTO attache;
    private int amountLikes;
    private String opinion;
    private ComboValDTO status;
    private ConversationDTO parent;

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public ConversationRoomDTO getConversationRoom() {
        return conversationRoom;
    }

    public void setConversationRoom(ConversationRoomDTO conversationRoom) {
        this.conversationRoom = conversationRoom;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public FileDTO getAttache() {
        return attache;
    }

    public void setAttache(FileDTO attache) {
        this.attache = attache;
    }

    public int getAmountLikes() {
        return amountLikes;
    }

    public void setAmountLikes(int amountLikes) {
        this.amountLikes = amountLikes;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    public ComboValDTO getStatus() {
        return status;
    }

    public void setStatus(ComboValDTO status) {
        this.status = status;
    }

    public ConversationDTO getParent() {
        return parent;
    }

    public void setParent(ConversationDTO parent) {
        this.parent = parent;
    }
}