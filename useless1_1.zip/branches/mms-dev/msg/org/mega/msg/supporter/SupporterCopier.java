package org.mega.msg.supporter;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;

public class SupporterCopier extends BaseCopier<Supporter, SupporterDTO> {
    @Override
    public SupporterDTO copyFromEntity(Supporter supporter) {
        SupporterDTO supporterDTO = new SupporterDTO();

        supporterDTO.setRowId(supporter.getRowId());
        if (supporter.getUser() != null) {
            UserDTO user = new UserDTO();
            user.setRowId(supporter.getUser().getRowId());
            user.setFullTitle(supporter.getUser().getFullTitle());
            supporterDTO.setUser(user);
        }
        if (supporter.getType() != null) {
            ComboValDTO type = new ComboValDTO();
            type.setRowId(supporter.getType().getRowId());
            type.setName(supporter.getType().getName());
            supporterDTO.setType(type);
        }
        copyFromEntityBaseField(supporter, supporterDTO);

        return supporterDTO;
    }

    @Override
    public Supporter copyToEntity(SupporterDTO supporterDTO) throws Exception {
        Supporter supporter = new Supporter();

        supporter.setRowId(supporterDTO.getRowId());
        if (supporterDTO.getUser() != null) {
            User user = new User();
            user.setRowId(supporterDTO.getUser().getRowId());
            supporter.setUser(user);
        }
        if (supporterDTO.getType() != null) {
            ComboVal type = new ComboVal();
            type.setRowId(supporterDTO.getType().getRowId());
            supporter.setType(type);
        }
        copyToEntityBaseField(supporter, supporterDTO);

        return supporter;
    }
}