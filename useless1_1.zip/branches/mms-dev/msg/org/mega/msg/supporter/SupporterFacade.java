package org.mega.msg.supporter;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class SupporterFacade extends BaseFacade {
    private static SupporterCopier copier = new SupporterCopier();
    private static SupporterFacade facade = new SupporterFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static SupporterFacade getInstance() {
        return facade;
    }
}