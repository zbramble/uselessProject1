/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicProductProblem(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/product/list",
        mapPattern: {
            label: "productTitle",
            value: "productTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};