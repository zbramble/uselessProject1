/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicChannelintegration(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/channelintegration/list",
        mapPattern: {
            label: "sellerUserName",
            value: "sellerUserName",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};

function AutocompleteDynamicSite(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/site/list",
        mapPattern: {
            label: "siteName",
            value: "siteName",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};

function AutocompleteDynamicOrganization(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/organization/list",
        mapPattern: {
            label: "name",
            value: "name",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};