/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicLocation(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/location/list",
        mapPattern: {
            label: "name",
            value: "name",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};