var entity;

$(document).ready(function () {
    setEditListeners();

    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
       // saveRow('edit-form', hSave, "/company/save");
    /*----------------------------------------------------------- Image ------*/
    var hImageSave = new Handler;
    hImageSave.success = function (result) {
        if (result.done) {
            fileRowId = result.result[0];
            $("#companyLogo").attr('entityId', result.result);
            saveRow('edit-form', hSave, "/company/save");
        }
        else {
            errorHandle(result);
        }
    }
    hImageSave.error = function (jqXHR, textStatus) {
        dialog('Save', textStatus + 'Error: ');
    }


    var formData = new FormData;
    formData.append('rowId', $("#companyLogo").attr("entityId"));
    formData.append('title', $("#companyName").val());
    formData.append('description', "Company Logo")
    formData.append('useTitle', "Company Form");
    formData.append('useEntity', "BseCompany");
    formData.append('path', $("#companyLogo").attr("path"));
    formData.append('active', $("#active").prop("checked"));

    var files = $('#companyLogo')[0].files;
    if ($("#companyLogo")[0].files.length > 0) {
        ServiceInvoker.upload(files, formData, hImageSave);
    } else {
    	saveRow('edit-form', hSave, "/company/save");
    }
});
/*--------------------------------------------------------------------------------------- Listener -------------------*/
$('#imageContent').on('click', function () {
    $("#companyLogo").click();
});

$('#companyLogo').on('change', function () {
    var input = $("#companyLogo")[0];

    if (input.files.length > 0) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#img').attr('src', e.target.result);
            $("#imageContent").attr("src", e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
});
	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var filterCountry = new Filter();
    filterCountry.addParameter("type.name", "'Country'", Condition.CONTAINS);
    filterCountry.addParameter("name", '$("#countryDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicLocation("countryDTO",filterCountry);
    
    var filterCity = new Filter();
    filterCity.addParameter("type.name", "'City'", Condition.CONTAINS);
    filterCity.addParameter("name", '$("#cityDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicLocation("cityDTO",filterCity);
    
    var filterProvince = new Filter();
    filterProvince.addParameter("type.name", "'Province'", Condition.CONTAINS);
    filterProvince.addParameter("name", '$("#provinceDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicLocation("provinceDTO",filterProvince);
    
});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/company/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    $("#companyName").val(dto.companyName);
	$("#description").val(dto.description);
	if(dto.cityDTO){
		$("#cityDTO").val(dto.cityDTO.name);
        $("#cityDTO").attr("entityId", dto.cityDTO.rowId);
	}
	if(dto.countryDTO){
		$("#countryDTO").val(dto.countryDTO.name);
        $("#countryDTO").attr("entityId", dto.countryDTO.rowId);
	}
	if(dto.provinceDTO){
		$("#provinceDTO").val(dto.provinceDTO.name);
        $("#provinceDTO").attr("entityId", dto.provinceDTO.rowId);
	}
	$("#companyPersonName").val(dto.companyPersonName);
	$("#companyWebsite").val(dto.companyWebsite);
	$("#companyPhone").val(dto.companyPhone);
	$("#companyEmail").val(dto.companyEmail);
	$("#personRole").val(dto.personRole);
	$("#address1").val(dto.address1);
	$("#address2").val(dto.address2);
	$("#zipcode").val(dto.zipcode);
	$("#accessKey").val(dto.accessKey);
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/company/list");
    pageNo = oldPageNo;
}

/*--------------------------------------------------------------------------------------- End ------------------------*/

