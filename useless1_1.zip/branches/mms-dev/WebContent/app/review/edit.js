var entity;

$(document).ready(function () {
    setEditListeners();
	 
});

//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    if(dto.buyerInfoMatched){
    	$("#buyerInfoMatched").text('Matched Buyer');
    	$("#buyerInfoMatched").removeClass("mega-nok");
    	$("#buyerInfoMatched").addClass("mega-ok");
    }else{
    	$("#buyerInfoMatched").text('Unmatched Buyer');
    	$("#buyerInfoMatched").removeClass("mega-ok");
    	$("#buyerInfoMatched").addClass("mega-nok");
    }
    
    if(dto.verifiedPurchase){
    	$("#verifiedPurchase").text('Verified Purchase');
    	$("#verifiedPurchase").removeClass("mega-nok");
    	$("#verifiedPurchase").addClass("mega-ok");
    }else{
    	$("#verifiedPurchase").text('Unverified Purchase');
    	$("#verifiedPurchase").removeClass("mega-ok");
    	$("#verifiedPurchase").addClass("mega-nok");
    }
    
    for(c = 1; c<6;c++)//remove prev style
    	$("#rating").removeClass('star' + c);
	$("#rating").addClass('star' + dto.rating);

	$("#product").text(dto.channelSkuId.fullTitle);
    $("#content").text(dto.content);
	$("#linkOnSite").attr('href' , dto.linkOnSite);
  
    if(dto.buyerInfoMatched){
    	$("#OrderLink").hide();
    	$("#OrderOnSiteLink").show();
    	$("#OrderLink").attr('rowId' , dto.orderDto.rowId);
    	$("#OrderOnSiteLink").attr('href' , 'https://sellercentral.amazon.com/hz/orders/details?_encoding=UTF8&orderId=' + dto.orderDto.channelOrderIdDTO);
    	$("#email-div").show();
    	$("#sendEmailBtn").show();

    	$("#customerEmail").text(dto.orderDto.buyerEmailDTO);
    	$("#emailText").val('Dear Customer,\nI would like to take a moment to say thank you.  I am deeply humbled to hear such incredible reviews from you.\n'
    			+ 'Your incredible reviews and testimonials inspire me and tell us all that we are doing the right thing at Aspectek.\n'
    			+'Thank You Again!\nAnthony Liu\n   CEO');
    }else{
    	$("#OrderLink").hide();
    	$("#OrderOnSiteLink").hide();
    	$("#email-div").hide();
    	$("#sendEmailBtn").hide();
    }

    
    $("#customerId").val(dto.customerId);
    $("#customerName").text(dto.customerName);
	$("#reviewDate").text(dto.reviewDate);
	$("#title").text(dto.title);

    $("#fullRating").val(dto.fullRating);
	$("#helpfulVotes").val(dto.helpfulVotes);
	$("#itemId").val(dto.itemId);
	if(dto.productId){
		$("#productId").val(dto.productId.productTitle);
        $("#productId").attr("entityId", dto.productId.rowId);
	}
	$("#realName").val(dto.realName);
	$("#responded").val(dto.responded);
	$("#reviewId").val(dto.reviewId);
	$("#specificNote").val(dto.specificNote);
	$("#status").val(dto.status);
	$("#totalVotes").val(dto.totalVotes);
	if(dto.createdBy){
    	$("#createdBy").val(dto.createdBy.fullTitle);
		$("#createdBy").attr("entityId", dto.createdBy.rowId);
	}
    if(dto.updatedBy){
    	$("#updatedBy").val(dto.updatedBy.fullTitle);
		$("#updatedBy").attr("entityId", dto.updatedBy.rowId);
	}
    $("#created").val(dto.created);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/review/list");
    pageNo = oldPageNo;
}

var sendEmailHandler = new Handler();
sendEmailHandler.beforeSend = function beforeSend() {
	parent.lockPage();
}
sendEmailHandler.success = function success(result) {
	parent.unlockPage();
    if (result.done) {
        setTimeout(function () {
            dialog('Message', 'Email successfully sent');
        }, 300);
    } else {
        setTimeout(function () {
            dialog('Error', 'Send email failed');
        }, 300);
    }
}
sendEmailHandler.error = function error(jqXHR, textStatus) {
	parent.unlockPage();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
sendEmailHandler.complete = function complete() {
	parent. unlockPage();
}
function sendEmail(){
	var mailDTO = {reviewId: $("#rowId").val(), content: $("#emailText").val(), ticket:user.ticket};
    ServiceInvoker.call(JSON.stringify(mailDTO), sendEmailHandler, "/review/mailToAmazonCustomer");
}

/*--------------------------------------------------------------------------------------- End ------------------------*/

