/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicReview(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/review/list",
        mapPattern: {
            label: "content",
            value: "content",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicProductChannelSKU(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/channelSKU/list",
        mapPattern: {
            label: "fullTitle",
            value: "fullTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicProduct(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/product/list",
        mapPattern: {
            label: "productTitle",
            value: "productTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
function AutocompleteDynamicComboVal(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/combo/list",
        mapPattern: {
            label: "name",
            value: "name",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};

