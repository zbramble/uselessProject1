/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var id,title;
var searchFields = [
                 
                    { key: 'rowId', propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'Identity', maxlength: 7 },
					{
						key: 'dataType',
						propName: 'e.dataType.rowId',
					    autocompleteInstance: 'AutocompleteDynamicComboVal',
					    type: SearchPropertyType.AUTOCOMPLETE,
					    title: 'Data Type',
					    maxlength: 50,
					    autocompleteProp: 'name',
					    autocompleteCondition: Condition.CONTAINS,
					    initialFilter: {key: 'val', value: 'EXT_PRO_DATA_TYPE', condition: Condition.EQUAL}
					},
                   
                    { key: 'propertyName',propName: 'e.propertyName', type: SearchPropertyType.TEXT, title: 'Property Name', maxlength: 20 },
                    { key: 'propertyValue',propName: 'e.propertyValue', type: SearchPropertyType.TEXT, title: 'Property Value', maxlength: 20 },
                    {
                    	key: 'createdBy',
                    	propName: 'e.createdBy.rowId',
                        autocompleteInstance: 'AutocompleteDynamicUser',
                        type: SearchPropertyType.AUTOCOMPLETE,
                        title: 'Created By',
                        maxlength: 50,
                        autocompleteProp: 'lastName',
                        autocompleteCondition: Condition.CONTAINS
                    },
                    {
                    	key: 'updatedBy',
                    	propName: 'e.updatedBy.rowId',
                        autocompleteInstance: 'AutocompleteDynamicUser',
                        type: SearchPropertyType.AUTOCOMPLETE,
                        title: 'Updated By',
                        maxlength: 50,
                        autocompleteProp: 'lastName',
                        autocompleteCondition: Condition.CONTAINS
                    },
                    { key: 'created',propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created', maxlength: 8 },
                    { key: 'updated',propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated', maxlength: 8 },
                    { key: 'active',propName: 'e.active', type: SearchPropertyType.BOOLEAN, title: 'Active', maxlength: -1}
]

/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#dataTypeDTO").attr("id", 'dataTypeDTO-' + id).find('span').html(item.dataTypeDTO);
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#productDTO").attr("id", 'productDTO-' + id).find('span').html(item.productDTO ? item.productDTO.productTitle : '');
        patternRow.find("#dataTypeDTO").attr("id", 'dataTypeDTO-' + id).find('span').html(item.dataTypeDTO ? item.dataTypeDTO.name : '');
        patternRow.find('#propertyName').attr("id", 'propertyName-' + id).find('span').html(item.propertyName);
        patternRow.find('#propertyValue').attr("id", 'propertyValue-' + id).find('span').html(item.propertyValue);

        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
        if (result.result) {
            fillGrid(result.result);
        } else {
            hideLoading();
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("propertyName", '$("#propertyName_Searcher").val()', Condition.CONTAINS);

var pageOrderField="rowId desc"
function search(orderField){
	pageOrderField = orderField;
    ServiceInvoker.call(fSearch.getFilters(orderField), hSearch, "/extendedPropertie/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
    window.frames['editFrame'].showRow(id)
}


$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    /*$('#search').on('click', function () {
        search();
    })*/

    var tabID = window.location.href.urlParameter('tabID');
    if(tabID != null && tabID != 0) { // is opened as tab
 	   var filterArray = top.tabFilter[tabID];
 	  fSearch.addParameter(filterArray[0].key, filterArray[0].value, filterArray[0].condition,filterArray[0].productTitle);
	 	 /*  filterArray.forEach(function (item) {
	 		   fSearch.addParameter(item.key, item.value, item.condition);
	 	   });*/
 	  title = filterArray[0].productTitle;
 	  id = filterArray[0].value;
    }

    $('#search').on('click', function () {
        if(AdvanceSearch.initializeFilter().length > 0) {
            fSearch.removeParameter(Condition.WHERE);
            fSearch.addParameter(Condition.WHERE, AdvanceSearch.initializeFilter(), Condition.WHERE);
            $('.win-content-header').removeClass('full-search compact')
            $('#clear-filter').removeClass('hide');
        } else if($('.simple-search input').val().trim().length > 0) {
            $('#clear-filter').removeClass('hide');
        }
        search(pageOrderField);
        $('.win-content-header').removeClass('compact full-search')

    })

    $('#clear-filter').on('click', function () {
        // Remove Advance Filter Key From Filter Object & Clear Advanced Form & Clear Simple Search From
        $('#filter-item-container').empty();
        $('.simple-search input').val('');
        fSearch.removeParameter(Condition.WHERE);
        this.classList.add('hide');
        search(pageOrderField)
    })
    
    /*----------------------------------------------------------------------------------- Initialization -------------*/
	AdvanceSearch.init();
    setIndexListeners();
    search(pageOrderField);

});

/*--------------------------------------------------------------------------------------- End ------------------------*/