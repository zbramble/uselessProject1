var searchFields = "name,isActive,parent";

$(document).ready(function () {

	$(window).on('click', function () {
		hideRowAction();
	});
	
	$("#view").on('click', function () {
		hideRowAction();
		showRow(lastResult[lastIndex][3]);
	});

	$("#copyToLocal").on('click', function () {
		hideRowAction();
		showRow(lastResult[lastIndex][3]);
	});
	
	
});

var lastIndex;
function lastId(i){
	lastIndex = i ;
}
 
	function search() {
		try {
			lockPage();
			$.ajax({
				url : servicePath + "/service/AmazonProducts/list",
				type : "POST",
				data : getFilter(),
				contentType : "application/json",
				cache : false,
				dataType : "json",
			}).done(function(result) {
				if (result.done) {
					fillGrid(result);
					$("#gridDiv").show('slow');

				}else{
					errorHandle(result);
				}
				
			}).fail(function(jqXHR, textStatus) {
				alert("Error: " + textStatus + ' ' + jqXHR.status);
			}).always(function() {
				unlockPage();
			});
		} catch (e) {
			alert(e);
			unlockPage();
		}
	}
	function importData() {
		try {
			lockPage();
			$.ajax({
				url : servicePath + "/service/AmazonProducts/import",
				type : "POST",
				data : getFilter(),
				contentType : "application/json",
				cache : false,
				dataType : "json",
			}).done(function(result) {
				if (result.done) {
					search();
					dialog('Message', result.resultCountAll + ' items imported successfully');
				}else{
					errorHandle(result);
				}
				
			}).fail(function(jqXHR, textStatus) {
				alert("Error: " + textStatus + ' ' + jqXHR.status);
			}).always(function() {
				unlockPage();
			});
		} catch (e) {
			alert(e);
			unlockPage();
		}
	}
	function copyAllData() {
		try {
			lockPage();
			$.ajax({
				url : servicePath + "/service/AmazonProducts/copyAllToLocal",
				type : "POST",
				data : '{"ticket":"' + user.ticket + '"}',
				contentType : "application/json",
				cache : false,
				dataType : "json",
			}).done(function(result) {
				if (result.done) {
					dialog('Message', result.resultCountAll + ' items copied successfully');
				}else{
					errorHandle(result);
				}
				
			}).fail(function(jqXHR, textStatus) {
				alert("Error: " + textStatus + ' ' + jqXHR.status);
			}).always(function() {
				unlockPage();
			});
		} catch (e) {
			alert(e);
			unlockPage();
		}
	}


	function downloadExcel() {
		$.ajax({
			url : servicePath + "/service/ReportService/downloadExcel",
			type : "POST",
			data : getFilter(),
			contentType : "application/json",
			xhrFields : {
				responseType : 'blob'
			},
			success : function(data) {
				if(data){
				var blob = new Blob([ data ]);
				var link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);
				link.download = "report_reward_" + new Date().getTime() + ".xls";
				link.click();
				}else{
					alert(' Error!');
				}
			},
			fail: function(data){
				alert(data);
			}
		});
	}


	function getFilter(){
		var f=  '{"params": [' + 
					'{"key": "asin1",	"value": "'+ $("#asin1").val() +'","condition": "EQUAL"},' +
		 			'{"key": "seller_sku","value": "'+  $("#seller_sku").val() +'","condition": "EQUAL"}' +
		 		'], "ticket":"' + user.ticket + '" , "pageNo":"'+pageNo+'", "pageSize":"'+pageSize+'"}';
		 console.log(f);
		 return f;
	}
	
	var lastResult;
	function fillGrid(result){
		lastResult = result.result;
		$("#grid").empty();
		if(!result.result){
			$("#dataGrid").css({"display":"none"});
			//alert('No things found');
			return;
		}else{
			$("#dataGrid").css({"display":""});
		}
		var grid = '<thead><tr>';
		
		for(var i = 0 ; result.result[0] && i < result.result[0].length; i++){
			grid+= '<th>' + result.result[0][i] + '</th>';
		}
		grid+='<th></th></tr></thead><tbody id="grid">';
		for(var i = 1 ; result.result && i < result.result.length; i++){
			grid+='<tr>';
			for(var j = 0 ; result.result[i] && j < result.result[0].length; j++){
				if(j == 1)//item name
					grid+='<td style="width:400px;text-align:left" id="'+ i +'">';
				else if(j == 3)//SKU
					grid+='<td nowrap="nowrap">';
				else
					grid+='<td>';
				
				if(j==1)
					grid +='<a href="javascript:{}" onclick="showRow(\''+ result.result[i][3] +'\')">' + result.result[i][j] +'</a>' ;
				else if(j == 2)//asin
					grid += '<a target="_blank" href="http://www.amazon.com/dp/' + result.result[i][j] + '">'+result.result[i][j]+'</a>' ;
				else if(j == 7)//product_id
					grid+=result.result[i][j];
				else
					grid+= ($.isNumeric(result.result[i][j]) ? numberWithCommas(result.result[i][j]) : (result.result[i][j] == null ? '' :result.result[i][j])) + '</td>';
			}
			grid+='<td id="entityId">' +
                '<a class="more-action ripple" href="#" onclick="lastId('+i+');showRowAction(this);"> <div class="ion-more action-link"></div></a></td></tr>';			
		}
		grid+='</tbody>';				
		$("#dataGrid").html(grid);
		$("#gridDiv").show('slow');
	}
	
	function showRow(sellerSKU) {
		addTab({
            window: window,
            src: '/app/amazon/product/edit.html',
            title: 'SKU: ' + sellerSKU,
            filter: [
                {
                    filterTitle: 'Product sku:' + sellerSKU,
                    key: 'SELLER_SKU',
                    value: '\'' + sellerSKU + '\'',//Must be string for avoid eval function error
                    condition: Condition.EQUAL
                }
            ]
        })
	}
	
