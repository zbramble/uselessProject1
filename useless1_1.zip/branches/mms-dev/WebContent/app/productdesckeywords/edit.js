var entity;

$(document).ready(function () {
    setEditListeners();

    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/productKeywords/save");
    });
   
	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
var fProduct = new Filter();
    fProduct.addParameter("productTitle", '$("#productDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicProduct("productDTO", fProduct);

	
});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/productKeywords/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
   // entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    $("#defaultShortDescription").val(dto.defaultShortDescription);
    $("#defaultFullDescription").val(dto.defaultFullDescription);
	$("#defaultSlogan").val(dto.defaultSlogan);
	$("#feature1").val(dto.feature1);
	if(dto.feature2)
		$('#div-feature2').css('display',"block");
	$("#feature2").val(dto.feature2);
	if(dto.feature3)
		$('#div-feature3').css('display',"block");
	$("#feature3").val(dto.feature3);
	if(dto.feature4)
		$('#div-feature4').css('display',"block");
	$("#feature4").val(dto.feature4);
	if(dto.feature5)
		$('#div-feature5').css('display',"block");
	$("#feature5").val(dto.feature5);
    $("#defaultTagline").val(dto.defaultTagline);
    if(dto.productDTO){
		$("#productDTO").val(dto.productDTO.productTitle);
		$("#productDTO").attr("entityId", dto.productDTO.rowId);
	}
	 $("#majorKeyword").val(dto.majorKeyword);
	 if(dto.keyword1)
			$('#div-keyword1').css('display',"block");
	 $("#keyword1").val(dto.keyword1);
	 if(dto.keyword2)
			$('#div-keyword2').css('display',"block");
	 $("#keyword2").val(dto.keyword2);
	 if(dto.keyword3)
			$('#div-keyword3').css('display',"block");
	 $("#keyword3").val(dto.keyword3);
	 if(dto.keyword4)
			$('#div-keyword4').css('display',"block");
	 $("#keyword4").val(dto.keyword4);
	$("#description").val(dto.description);
	$("#accessKey").val(dto.accessKey);
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $("#productDTO").val(parent.title);
	$("#productDTO").attr("entityId", parent.id);
	$('#div-feature2').css('display',"none");
	$('#div-feature3').css('display',"none");
	$('#div-feature4').css('display',"none");
	$('#div-feature5').css('display',"none");
	$('#div-keyword1').css('display',"none");
	$('#div-keyword2').css('display',"none");
	$('#div-keyword3').css('display',"none");
	$('#div-keyword4').css('display',"none");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/productKeywords/list");
    pageNo = oldPageNo;
}

/*--------------------------------------------------------------------------------------- End ------------------------*/
function addFeature(){
	if($('#div-feature2').css('display') == "none")
		$('#div-feature2').css('display',"block");
	else if($('#div-feature3').css('display') == "none")
		$('#div-feature3').css('display',"block");
	else if($('#div-feature4').css('display') == "none")
		$('#div-feature4').css('display',"block");
	else if($('#div-feature5').css('display') == "none")
		$('#div-feature5').css('display',"block");
}
function lowFeature(){
	if($('#div-feature5').css('display') == "block" && $('#feature5').val() == "")
		$('#div-feature5').css('display',"none");
	else if($('#div-feature4').css('display') == "block" && $('#feature4').val() == "")
		$('#div-feature4').css('display',"none");
	else if($('#div-feature3').css('display') == "block" && $('#feature3').val() == "")
		$('#div-feature3').css('display',"none");
	else if($('#div-feature2').css('display') == "block" && $('#feature2').val() == "")
		$('#div-feature2').css('display',"none");
	
}
function addKeyword(){
	if($('#div-keyword1').css('display') == "none")
		$('#div-keyword1').css('display',"block");
	else if($('#div-keyword2').css('display') == "none")
		$('#div-keyword2').css('display',"block");
	else if($('#div-keyword3').css('display') == "none")
		$('#div-keyword3').css('display',"block");
	else if($('#div-keyword4').css('display') == "none")
		$('#div-keyword4').css('display',"block");
}
function lowKeyWord(){
	if($('#div-keyword4').css('display') == "block" && $('#keyword4').val() == "")
		$('#div-keyword4').css('display',"none");
	else if($('#div-keyword3').css('display') == "block" && $('#keyword3').val() == "")
		$('#div-keyword3').css('display',"none");
	else if($('#div-keyword2').css('display') == "block" && $('#keyword2').val() == "")
		$('#div-keyword2').css('display',"none");
	else if($('#div-keyword1').css('display') == "block" && $('#keyword1').val() == "")
		$('#div-keyword1').css('display',"none");
}