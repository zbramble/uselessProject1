/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;
var entity;

$(document).ready(function () {
    var fileTypes = ['jpg', 'jpeg', 'png'];

    setEditListeners();
    /*----------------------------------------------------------------------------------- Listener -------------------*/
    $('#imageContent').on('click', function () {
        $("#file").click();
    });

    $('#file').on('change', function () {
        var input = $("#file")[0];

        if (input.files.length > 0) {
            var extension = input.files[0].name.split('.').pop().toLowerCase();
            var isSuccess = fileTypes.indexOf(extension) > -1;

            if (isSuccess) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $("#imageContent").attr("src", e.target.result);
                }
            } else {
                $("#imageContent").attr("src", '../../../core/img/attach-image.png');
            }
            reader.readAsDataURL(input.files[0]);
        }
    });

    $('#imageContentMaster').on('click', function () {
        $("#fileMaster").click();
    });

    $('#fileMaster').on('change', function () {
        var input = $("#fileMaster")[0];

        if (input.files.length > 0) {
            var extension = input.files[0].name.split('.').pop().toLowerCase();
            var isSuccess = fileTypes.indexOf(extension) > -1;

            if (isSuccess) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $("#imageContentMaster").attr("src", e.target.result);
                }
            } else {
                $("#imageContentMaster").attr("src", '../../../core/img/attach-image.png');
            }
            reader.readAsDataURL(input.files[0]);
        }
    });

    $('#save-btn').on('click', function () {
        if ($('.conversation-form').get(0).style.display == 'none') {
            checkMandatories('edit-form');
            saveConversationRoom();
        } else {
            if ($("#file")[0].files.length > 0) {
                saveFile();
            } else {
                saveConversation(false);
            }
        }
    });

    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var fType = new Filter();
    fType.addParameter("parent.val", "'SUPPORT_PROBLEM_TYPE'", Condition.EQUAL);
    AutocompleteStaticComboVal("type", fType, "SUPPORT_PROBLEM_TYPE");

    var fPriority = new Filter();
    fPriority.addParameter("parent.val", "'PRIORITY'", Condition.EQUAL);
    AutocompleteStaticComboVal("priority", fPriority, "PRIORITY");
});

/*--------------------------------------------------------------------------------------- Save -----------------------*/
var fileRowId;

function saveFile(isFirstMessage) {
    var hImageSave = new Handler;
    hImageSave.success = function (result) {
        if (result.done) {
            fileRowId = result.result[0];
            if (isFirstMessage == true) {
                $("#fileMaster").attr('entityId', result.result);
            } else {
                $("#file").attr('entityId', result.result);
            }
            saveConversation(isFirstMessage);
        }
        else {
            errorHandle(result);
        }
    }
    hImageSave.error = function (jqXHR, textStatus) {
        dialog('Save', textStatus + 'Error: ');
    }

    var files = isFirstMessage ? $('#fileMaster')[0].files : $('#file')[0].files;

    var formData = new FormData;
    formData.append('rowId', isFirstMessage ? $("#fileMaster").attr("entityId") : $("#file").attr("entityId"));
    formData.append('title', $("#type").val());
    formData.append('description', "Send ticket form");
    formData.append('useTitle', "Send ticket form");
    formData.append('useEntity', "ConversationRoom");
    formData.append('path', isFirstMessage ? $("#fileMaster").attr("path") : $("#file").attr("path"));
    formData.append('active', $("#active").prop("checked"));

    ServiceInvoker.upload(files, formData, hImageSave);
}

function saveConversation(isFirstMessage) {   
    checkMandatories('conversation-form');

    var hSaveConversation = new Handler();
    hSaveConversation.success = function success(result) {
        if (result.done) {
            dialog('Save', result.resultCountAll + ' Item saved');
            $(".conversation-new").find("#text").val('');

            if (isFirstMessage == true) {
                $(".ticket-master").css({display: 'none'});
            } else {
                $("#file").attr("path", "");
                $("#file").attr("entityId", "");
                $("#imageContent").attr("src", "../../../core/img/attach-image.png");
            }

            searchConversation($("#rowId").val())
        } else {
            errorHandle(result);
        }
    }
    hSaveConversation.error = function error(jqXHR, textStatus) {
        dialog('Save', textStatus + 'Error: ')
    }

    if (isFirstMessage == true) {
        var text = $("#textMaster").val();
        text = text ? text.replaceAll("\n", "|^|") : '';

        var formData = '{"text":"' + text + '"' +
            ',"active":"true"' +
            ',"ticket":"' + user.ticket + '"' +

            ( $("#fileMaster").attr("entityId") != "" ?
                ',"attache": { "rowId" : ' + fileRowId + ' }' : "") +

            ',"conversationRoom": {"rowId":"' + $("#rowId").val() + '"}}';
    } else {
        var text = $("#text").val().replaceAll("\n", "|^|");

        var formData = '{"text":"' + text + '"' +
            ',"active":"true"' +
            ',"ticket":"' + user.ticket + '"' +

            ( $("#file").attr("entityId") != "" ?
                ',"attache": { "rowId" : ' + fileRowId + ' }' : "") +

            ',"conversationRoom": {"rowId":"' + $("#rowId").val() + '"}}';
    }

    ServiceInvoker.call(formData, hSaveConversation, "/conversation/save");
}

function saveConversationRoom() {
    var hSaveConversationRoom = new Handler();
    hSaveConversationRoom.success = function success(result) {
        if (result.done) {
            dialog('Save', result.resultCountAll + ' Item saved');
            $(".edit-form").find("#rowId").val(result.result);

            $('.conversation-form').css({display: 'block'});
            $(".edit-form :input").not("#rowId").attr("disabled", true);

            var conversationView = $('.conversation-view');
            conversationView.find('div').not('div#row').remove();
            conversationView.find('.row-br').remove();

            if ($("#fileMaster")[0].files.length > 0) {
                saveFile(true);
            } else {
                saveConversation(true);
            }
        } else {
            errorHandle(result);
        }
    }
    hSaveConversationRoom.error = function error(jqXHR, textStatus) {
        dialog('Save', textStatus + 'Error: ')
    }

    var formData = '{"rowId":"' + $("#rowId").val() + '"' +
        ',"name":"' + $("#textMaster").val() + '"' +
        ',"type":{"rowId": ' + $("#type").attr("entityId") + '}' +
        ',"priority":{"rowId": ' + $("#priority").attr("entityId") + '}' +
        ',"category":{ "rowId": 100075 }' + //Combo row id for ticket
        ',"active":"true"' +
        ',"ticket":"' + user.ticket + '"}';

    checkMandatories('edit-form');
    ServiceInvoker.call(formData, hSaveConversationRoom, "/conversationroom/save");
}

/*--------------------------------------------------------------------------------------- Delete ---------------------*/
var hDelete = new Handler();
hDelete.error = function error(jqXHR, textStatus) {
    alert("Error: " + textStatus);
}

function deleteRow(id) {
    hDelete.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' Item deleted');
            if (id == undefined) {
            } else {
                parent.$('tr#row-' + id).remove();
            }
        } else {
            errorHandle(result)
        }
    }

    var dFilter = new Filter();
    if (id == undefined) {
        dFilter.addParameter("rowId", '$("#rowId").val()', Condition.EQUAL);
    } else {
        dFilter.addParameter("rowId", id, Condition.EQUAL);
    }
    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/conversationroom/delete");
}

/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();

    $('.conversation-form').css({display: 'block'});
    $(".edit-form :input").not("#rowId").attr("disabled", true);

    $("#rowId").val(dto.rowId);
    $("#name").val(dto.name.replaceAll("|^|", "\n"));

    if (dto.type) {
        $("#type").val(dto.type.name);
        $("#type").attr("entityId", dto.type.rowId);
    }
    if (dto.priority) {
        $("#priority").val(dto.priority.name);
        $("#priority").attr("entityId", dto.priority.rowId);
    }
    if (dto.category) {
        $("#category").val(dto.category.name);
        $("#category").attr("entityId", dto.category.rowId);
    }
    $('.ticket-master').css({'display': 'none'});

    $("#active").attr("checked", dto.active);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
            searchConversation(result.result[0].rowId);
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}

var fShrSearch = new Filter();

function showRow(id) {
    fShrSearch.clearParams();
    fShrSearch.addParameter("category.rowId", "'100065'", Condition.EQUAL);//Ticket
    fShrSearch.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearch.getFilters(), hShowRow, "/conversationroom/list");
    pageNo = oldPageNo;

}

/*--------------------------------------------------------------------------------------- Clear Form -----------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);

    $("#file").attr("path", "");
    $("#file").attr("entityId", "");
    $("#imageContent").attr("src", "../../../core/img/attach-image.png");

    $("#fileMaster").attr("path", "");
    $("#fileMaster").attr("entityId", "");
    $("#imageContentMaster").attr("src", "../../../core/img/attach-image.png");
    $('.ticket-master').css({'display': ''});

    $(".edit-form :input").not("#rowId").attr("disabled", false);
    $('.conversation-form').css({display: 'none'});
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTableConversation(entities) {

    $('#conversationsList').empty();
    $.each(entities, function (index, value) {
        createConversation(value);
    });
}

/*--------------------------------------------------------------------------------------- Create Conversation --------*/
function createConversation(value) {

    <!--Conversation Items-->
    var liItem = document.createElement('li');
    liItem.setAttribute('class', 'msg-s-message-list__date-group');
    liItem.setAttribute('id', "conversation-" + value.rowId);

    <!-- --Top-->
    var ulTop = document.createElement('ul');
    ulTop.setAttribute('class', 'clearfix msg-s-message-group');
    liItem.append(ulTop);

    <!-- -- --li-->
    var li = document.createElement('li');
    li.setAttribute('class', 'msg-s-message-listitem msg-s-ticket-list-item-other ember-view');
    ulTop.append(li);

    <!-- -- -- --div-->
    var div = document.createElement('div');
    div.setAttribute('class', 'msg-s-message-listitem__message-bubble');
    li.append(div);

    <!-- -- -- -- --p-->
    var p = document.createElement('p');
    p.setAttribute('class', 'msg-s-message-listitem__body Sans-15px-black-70%');
    p.innerHTML = value.text.replaceAll("|^|", "\n");
    div.append(p);

    <!-- -- -- --a-->
    if (value.attache) {

        var a = document.createElement('a');
        a.setAttribute('class', 'msg-s-message-listitem__profile-picture EntityPhoto-circle-1');
        a.innerHTML = 'Attachment';
        div.append(a);

        $(a).on('dblclick', function () {
            var fDownloadAttached = new Filter();
            fDownloadAttached.addParameter("id", value.attache.rowId, Condition.EQUAL);
            ServiceInvoker.download(fDownloadAttached.getFilters(), '/conversation/download');
        });
    }
    <!-- --Bottom-->
    var divBottom = document.createElement('div');
    divBottom.setAttribute('class', 'Sans-13px-black-55% clearfix msg-s-message-group__meta msg-s-ticket-group__meta--other');
    divBottom.setAttribute('aria-hidden', 'true');
    liItem.append(divBottom);

    <!-- -- --span-->
    var span = document.createElement('span');
    span.setAttribute('class', 'msg-s-message-group__user-name');
    span.innerHTML = value.createdBy.fullName;
    divBottom.append(span);

    <!-- -- --time-->
    var time = document.createElement('time');
    time.setAttribute('class', 'msg-s-message-group__timestamp');
    time.innerHTML = value.created;
    divBottom.append(time);

    var ulConversationsList = $('#conversationsList');
    ulConversationsList.append(liItem);
}

/*--------------------------------------------------------------------------------------- Search Conversation --------*/
var hSearchConversation = new Handler();
hSearchConversation.success = function (data) {
    if (data.done) {
        if (data.result) {
            fillTableConversation(data.result);
        } else {
            var conversationView = $('.conversation-view');
            conversationView.find('div').not('div#row').remove();
            conversationView.find('.row-br').remove();

            hideLoading();
            setTimeout(function () {
                switch (pageState) {
                    case PageState.READY:
                        $('.error-container').off('click');
                        $('.error-container').find('.close-error-container').off('click');
                        break
                    case PageState.NEXT:
                        break
                    case PageState.PREV:
                        break
                    case PageState.REFRESH:
                        break
                }
                showError("No things for show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(data);
        }, 300)
    }
}

function searchConversation(conversationRoomId) {
    var fSearchConversation = new Filter();
    fSearchConversation.addParameter("conversationRoom.rowId", conversationRoomId, Condition.EQUAL);
    ServiceInvoker.call(fSearchConversation.getFilters(), hSearchConversation, "/conversation/list");
}

/*--------------------------------------------------------------------------------------- End ------------------------*/