$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    var hSave = new Handler();
    hSave.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد ذخیره گردید');
            $("#studentId").val(result.result);
        } else {
            errorHandle(result)
        }
    }
    hSave.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus);
    }

    function saveRow() {
        var formData = '{"studentId": "' + $("#studentId").val() + '"' +
            ( $("#person").attr("entityId") != "" ?
            ', "person": { "personId" : ' + $("#person").attr("entityId") + ' }' : "") +

            ( $("#studentType").attr("entityId") != "" ?
            ', "studentType": { "comboValId" : ' + $("#studentType").attr("entityId") + ' }' : "") +

            ( $("#studentStatusType").attr("entityId") != "" ?
            ', "studentStatusType": { "comboValId" : ' + $("#studentStatusType").attr("entityId") + ' }' : "") +

            ( $("#educationalOrganization").attr("entityId") != "" ?
            ', "educationalOrganization": { "organizationId" : ' + $("#educationalOrganization").attr("entityId") + ' }' : "") +

            ( $("#eduDuration").attr("entityId") != "" ?
            ', "eduDuration": { "eduDurationId" : ' + $("#eduDuration").attr("entityId") + ' }' : "") +

            ( $("#educationalGrade").attr("entityId") != "" ?
            ', "educationalGrade": { "educationalGradeId" : ' + $("#educationalGrade").attr("entityId") + ' }' : "") +

            ( $("#field").attr("entityId") != "" ?
            ', "field": { "fieldId" : ' + $("#field").attr("entityId") + ' }' : "") +

            ( $("#orientation").attr("entityId") != "" ?
            ', "orientation": { "orientationId" : ' + $("#orientation").attr("entityId") + ' }' : "") +

            ', "isActive" : "' + $("#isActive").prop('checked') + '"' +
            ', "ticket":"' + user.ticket + '"}';

        ServiceInvoker.call(formData, hSave, "/student/save");
    }

    /*----------------------------------------------------------------------------------- Delete ---------------------*/
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد حذف گردید');
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        alert("خطا: " + textStatus);
    }

    var dFilter = new Filter();
    dFilter.addParameter("studentId", '$("#studentId").val()', Condition.EQUAL);

    function deleteRow() {
        ServiceInvoker.call(dFilter.getFilters(), hDelete, "/student/delete");
    }

    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var fPerson = new Filter();
    fPerson.addParameter("nationalId", '$("#person").val()', Condition.CONTAINS);
    AutocompleteDynamicPerson("person", fPerson);

    var fStudentType = new Filter();
    fStudentType.addParameter("parent.name", '"نوع دانشجو"', Condition.CONTAINS);
    fStudentType.addParameter("name", '$("#studentType").val()', Condition.CONTAINS);
    AutocompleteDynamicComboVal("studentType", fStudentType);

    var fStudentStatusType = new Filter();
    fStudentStatusType.addParameter("parent.name", '"وضعیت دانشجو"', Condition.CONTAINS);
    fStudentStatusType.addParameter("name", '$("#studentStatusType").val()', Condition.CONTAINS);
    AutocompleteDynamicComboVal("studentStatusType", fStudentStatusType);

    var fEducationalOrganization = new Filter();
    fEducationalOrganization.addParameter("name", '$("#educationalOrganization").val()', Condition.CONTAINS);
    AutocompleteDynamicOrganization("educationalOrganization", fEducationalOrganization);

    var fEduDuration = new Filter();
    fEduDuration.addParameter("durationTitle", '$("#eduDuration").val()', Condition.CONTAINS);
    AutocompleteDynamicEduDuration("eduDuration", fEduDuration);

    var fEducationalGrade = new Filter();
    fEducationalGrade.addParameter("educationalGradeTitle", '$("#educationalGrade").val()', Condition.CONTAINS);
    AutocompleteDynamicEducationalGrade("educationalGrade", fEducationalGrade);

    var fField = new Filter();
    fField.addParameter("fieldTitle", '$("#field").val()', Condition.CONTAINS);
    AutocompleteDynamicField("field", fField);

    var fOrientation = new Filter();
    fOrientation.addParameter("orientationTitle", '$("#orientation").val()', Condition.CONTAINS);
    AutocompleteDynamicOrientation("orientation", fOrientation);

    /*----------------------------------------------------------------------------------- Listener -------------------*/
    $('#sendDeleteBTN').click(function () {
        deleteRow();
    });

    $('#sendSaveBTN').click(function () {
        saveRow();
    });

    $('#sendBackBTN').click(function () {
        parent.hideEdit();
    });
});

/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    addNew();
    $("#studentId").val(dto.studentId);
    if (dto.person !== undefined) {
        $("#person").val(dto.person.nationalId);
        $("#person").attr("entityId", dto.person.personId);
    }
    if (dto.studentType !== undefined) {
        $("#studentType").val(dto.studentType.name);
        $("#studentType").attr("entityId", dto.studentType.comboValId);
    }
    if (dto.studentStatusType !== undefined) {
        $("#studentStatusType").val(dto.studentStatusType.name);
        $("#studentStatusType").attr("entityId", dto.studentStatusType.comboValId);
    }
    if (dto.educationalOrganization !== undefined) {
        $("#educationalOrganization").val(dto.educationalOrganization.name);
        $("#educationalOrganization").attr("entityId", dto.educationalOrganization.organizationId);
    }
    if (dto.eduDuration !== undefined) {
        $("#eduDuration").val(dto.eduDuration.durationTitle);
        $("#eduDuration").attr("entityId", dto.eduDuration.eduDurationId);
    }
    if (dto.educationalGrade !== undefined) {
        $("#educationalGrade").val(dto.educationalGrade.educationalGradeTitle);
        $("#educationalGrade").attr("entityId", dto.educationalGrade.educationalGradeId);
    }
    if (dto.field !== undefined) {
        $("#field").val(dto.field.fieldTitle);
        $("#field").attr("entityId", dto.field.fieldId);
    }
    if (dto.orientation !== undefined) {
        $("#orientation").val(dto.orientation.name);
        $("#orientation").attr("entityId", dto.orientation.orientationId);
    }
    $("#isActive").attr("checked", dto.isActive);
}

/*--------------------------------------------------------------------------------------- Add New --------------------*/
function addNew() {
    $("#studentId").val("");
    $("#person").val("");
    $("#person").attr("entityId", "");
    $("#studentType").val("");
    $("#studentType").attr("entityId", "");
    $("#studentStatusType").val("");
    $("#studentStatusType").attr("entityId", "");
    $("#educationalOrganization").val("");
    $("#educationalOrganization").attr("entityId", "");
    $("#eduDuration").val("");
    $("#eduDuration").attr("entityId", "");
    $("#educationalGrade").val("");
    $("#educationalGrade").attr("entityId", "");
    $("#field").val("");
    $("#field").attr("entityId", "");
    $("#orientation").val("");
    $("#orientation").attr("entityId", "");
    $("#isActive").attr("checked", true);
}

/*--------------------------------------------------------------------------------------- End ------------------------*/