$(document).ready(function () {
        /*----------------------------------------------------------------------------------- Search -----------------*/
        var hSearch = new Handler();
        hSearch.beforeSend = function beforeSend() {
            lockPage();
        }
        hSearch.success = function success(result) {
            if (result.done) {
                $("#studentGrid").empty();
                if (!result.result) {
                    $("#dataGrid").css({"display": "none"});
                    //alert('موردی یافت نشد');
                    return;
                } else {
                    $("#dataGrid").css({"display": ""});
                }
                for (var i = 0; result.result && i < result.result.length; i++) {
                    var entityId = result.result[i].studentId;
                    var clone = $("#row").clone();
                    clone.find("[id]").add(clone).each(function () {
                        this.id = this.id + '-' + entityId;
                    });
                    clone.find("#id-" + entityId).html(i + 1 + (pageNo - 1) * pageSize);
                    clone.find("#studentId-" + entityId).html(result.result[i].studentId);
                    if (result.result[i].person !== undefined) {
                        clone.find("#person-" + entityId).html(result.result[i].person.firstName
                            + " " + result.result[i].person.lastName);
                    }
                    if (result.result[i].studentType !== undefined) {
                        clone.find("#studentType-" + entityId).html(result.result[i].studentType.name);
                    }
                    if (result.result[i].studentStatusType !== undefined) {
                        clone.find("#studentStatusType-" + entityId).html(result.result[i].studentStatusType.name);
                    }
                    if (result.result[i].educationalOrganization !== undefined) {
                        clone.find("#educationalOrganization-" + entityId).html(result.result[i].educationalOrganization.name);
                    }
                    if (result.result[i].eduDuration !== undefined) {
                        clone.find("#eduDuration-" + entityId).html(result.result[i].eduDuration.durationTitle);
                    }
                    if (result.result[i].educationalGrade !== undefined) {
                        clone.find("#educationalGrade-" + entityId).html(result.result[i].educationalGrade.educationalGradeTitle);
                    }
                    if (result.result[i].field !== undefined) {
                        clone.find("#field-" + entityId).html(result.result[i].field.fieldTitle);
                    }
                    if (result.result[i].orientation !== undefined) {
                        clone.find("#orientation-" + entityId).html(result.result[i].orientation.name);
                    }
                    clone.find("#isActive-" + entityId).html(result.result[i].isActive ? "فعال" : "غیرفعال");

                    clone.appendTo("#studentGrid");
                }
                $("#gridDiv").show('slow');

                $('tr[id^="row-"]').dblclick(function () {
                    showRow(this.id.split('-')[1]);
                });
            } else {
                errorHandle(result);
            }
        }
        hSearch.error = function error(jqXHR, textStatus) {
            alert("خطا: " + textStatus + ' ' + jqXHR.status);
        }
        hSearch.complete = function complete() {
            unlockPage();
        }

        var fSearche = new Filter();
        fSearche.addParameter("studentId", '$("#studentId_Searcher").val()', Condition.EQUAL);

        function search() {
            ServiceInvoker.call(fSearche.getFilters(), hSearch, "/student/list");
            $("#gridDiv").show('slow');
        }

        /*----------------------------------------------------------------------------------- Show Row ---------------*/
        var hShowRow = new Handler();
        hShowRow.beforeSend = function beforeSend() {
            lockPage();
        }
        hShowRow.success = function success(result) {
            if (result.done) {
                $('#editDiv').show('slow');
                $('#editDiv').css({"height": "100%"});
                window.frames['editFrame'].fillEdit(result.result[0]);
            } else {
                errorHandle(result);
            }
        }
        hShowRow.error = function error(jqXHR, textStatus) {
            alert("خطا: " + textStatus + ' ' + jqXHR.status);
        }
        hShowRow.complete = function complete() {
            unlockPage();
        }

        var fShrSearche = new Filter();

        function showRow(id) {
            fShrSearche.clearParams();
            fShrSearche.addParameter("studentId", id, Condition.EQUAL)
            var oldPageNo = pageNo;
            pageNo = 1;
            ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/student/list");
            pageNo = oldPageNo;
        }

        /*----------------------------------------------------------------------------------- Add New  ---------------*/
        function addNew() {
            $('#editDiv').show('slow');
            $('#editDiv').css({"height": "100%"});
            window.frames['editFrame'].addNew();
        }

        /*----------------------------------------------------------------------------------- Listener ---------------*/
        $('#sendBTN').click(function () {
            pageNo = 1;
            $('#pageNo').val('1');
            search();
        });

        $('#sendNewBTN').click(function () {
            addNew();
        });

        $('#next').click(function () {
            if ($("#pageNo").length > 0) {
                pageNo = $("#pageNo").val();
                $("#pageNo").val(++pageNo)
            } else
                pageNo++;
            search();
        });

        $('#prev').click(function () {
            if ($("#pageNo").length > 0) {
                pageNo = $("#pageNo").val();
                if (pageNo == 1)
                    return;
                $("#pageNo").val(--pageNo)
            } else {
                if (pageNo == 1)
                    return;
                pageNo--;
            }
            search();
        });
    }
);

/*--------------------------------------------------------------------------------------- Hide Edit ------------------*/
function hideEdit() {
    $('#editDiv').hide('slow');
}

/*--------------------------------------------------------------------------------------- End ------------------------*/
