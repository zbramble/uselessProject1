/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicStudent(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/student/list",
        mapPattern: {
            label: "studentId",
            value: "studentId",
            entityId: "studentId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};