$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Save -----------------------*/
    var hSave = new Handler();
    hSave.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' Item saved');
            $("#employeeId").val(result.result);
        } else {
            errorHandle(result)
        }
    }
    hSave.error = function error(jqXHR, textStatus) {
        alert("Error: " + textStatus);
    }

    function saveRow() {
        var formData = '{"employeeId": "' + $("#employeeId").val() + '"' +

            ( $("#eduDuration").attr("entityId") != "" ?
            ', "eduDuration": { "eduDurationId" : ' + $("#eduDuration").attr("entityId") + ' }' : '') +

            ( $("#organization").attr("entityId") != "" ?
            ', "organization": { "organizationId" : ' + $("#organization").attr("entityId") + ' }' : '') +

            ( $("#person").attr("entityId") != "" ?
            ', "person": { "personId" : ' + $("#person").attr("entityId") + ' }' : '') +

            ( $("#employeeType").attr("entityId") != "" ?
            ', "employeeType": { "comboValId" : ' + $("#employeeType").attr("entityId") + ' }' : '') +

            ( $("#employeeStatusType").attr("entityId") != "" ?
            ', "employeeStatusType": { "comboValId" : ' + $("#employeeStatusType").attr("entityId") + ' }' : '') +

            ', "isActive" : "' + $("#isActive").prop('checked') + '"' +
            ', "ticket" : "' + user.ticket + '"}';

        ServiceInvoker.call(formData, hSave, "/employee/save");
    }

    /*----------------------------------------------------------------------------------- Delete ---------------------*/
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            alert(result.resultCountAll + ' مورد Delete گردید');
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        alert("Error: " + textStatus);
    }

    var dFilter = new Filter();
    dFilter.addParameter("employeeId", '$("#employeeId").val()', Condition.EQUAL);

    function deleteRow() {
        ServiceInvoker.call(dFilter.getFilters(), hDelete, "/employee/delete");
    }

    /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
    var fEduDuration = new Filter();
    fEduDuration.addParameter("durationTitle", '$("#eduDuration").val()', Condition.CONTAINS);
    AutocompleteDynamicEduDuration("eduDuration", fEduDuration);

    var fOrganization = new Filter();
    fOrganization.addParameter("name", '$("#organization").val()', Condition.CONTAINS);
    AutocompleteDynamicOrganization("organization", fOrganization);

    var fPerson = new Filter();
    fPerson.addParameter("name", '$("#person").val()', Condition.CONTAINS);
    AutocompleteDynamicPerson("person", fPerson);

    var fEmployeeType = new Filter();
    fEmployeeType.addParameter("parent.name", "'نوع کارمندی'", Condition.EQUAL);
    fEmployeeType.addParameter("name", '$("#employeeType").val()', Condition.CONTAINS);
    AutocompleteDynamicComboVal("employeeType", fEmployeeType);

    var fEmployeeStatusType = new Filter();
    fEmployeeStatusType.addParameter("parent.name", "'نوع وضعیت کارمند'", Condition.EQUAL);
    fEmployeeStatusType.addParameter("name", '$("#employeeStatusType").val()', Condition.CONTAINS);
    AutocompleteDynamicComboVal("employeeStatusType", fEmployeeStatusType);
    /*----------------------------------------------------------------------------------- Listener -------------------*/
    $('#sendDeleteBTN').click(function () {
        deleteRow();
    });

    $('#sendSaveBTN').click(function () {
        saveRow();
    });

    $('#sendBackBTN').click(function () {
        parent.hideEdit();
    });
});

/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    addNew();
    $("#employeeId").val(dto.employeeId);
    if (dto.eduDuration != undefined) {
        $("#eduDuration").val(dto.eduDuration.durationTitle);
        $("#eduDuration").attr("entityId", dto.eduDuration.eduDurationId);
    }
    if (dto.organization != undefined) {
        $("#organization").val(dto.organization.name);
        $("#organization").attr("entityId", dto.organization.organizationId);
    }
    if (dto.person != undefined) {
        $("#person").val(dto.person.nationalId);
        $("#person").attr("entityId", dto.person.personId);
    }
    if (dto.employeeType != undefined) {
        $("#employeeType").val(dto.employeeType.name);
        $("#employeeType").attr("entityId", dto.employeeType.comboValId);
    }
    if (dto.employeeStatusType != undefined) {
        $("#employeeStatusType").val(dto.employeeStatusType.name);
        $("#employeeStatusType").attr("entityId", dto.employeeStatusType.comboValId);
    }
    $("#isActive").attr("checked", dto.isActive);
}

/*--------------------------------------------------------------------------------------- Add New --------------------*/
function addNew() {
    $("#employeeId").val("");
    $("#eduDuration").val("");
    $("#eduDuration").attr("entityId", "");
    $("#organization").val("");
    $("#organization").attr("entityId", "");
    $("#person").val("");
    $("#person").attr("entityId", "");
    $("#employeeType").val("");
    $("#employeeType").attr("entityId", "");
    $("#employeeStatusType").val("");
    $("#employeeStatusType").attr("entityId", "");
    $("#isActive").attr("checked", true);
}
/*--------------------------------------------------------------------------------------- End ------------------------*/