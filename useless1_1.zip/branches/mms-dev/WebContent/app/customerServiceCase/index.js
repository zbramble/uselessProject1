/*--------------------------------------------------------------------------------------- Variable -------------------*/
var pageState = PageState.READY;

var searchFields = [
	{  key: 'rowId', propName: 'e.rowId', type: SearchPropertyType.NUMBER, title: 'ID', maxlength: 20 },
    {
		key: 'product',
		propName: 'e.product.rowId',
	    autocompleteInstance: 'AutocompleteDynamicProduct',
	    type: SearchPropertyType.AUTOCOMPLETE,
	    title: 'Product',
	    maxlength: 50,
	    autocompleteProp: 'productTitle',
	    autocompleteCondition: Condition.CONTAINS
	},
    {
		key: 'productProblem',
		propName: 'e.productProblem.rowId',
	    autocompleteInstance: 'AutocompleteDynamicProductProblem',
	    type: SearchPropertyType.AUTOCOMPLETE,
	    title: 'Product Problem',
	    maxlength: 50,
	    autocompleteProp: 'description',
	    autocompleteCondition: Condition.CONTAINS
	},
	{
		key: 'caseType',
		propName: 'e.caseType.rowId',
	    autocompleteInstance: 'AutocompleteDynamicComboVal',
	    type: SearchPropertyType.AUTOCOMPLETE,
	    title: 'Case Type',
	    maxlength: 50,
	    autocompleteProp: 'name',
	    autocompleteCondition: Condition.CONTAINS,
	    initialFilter: {key: 'val', value: 'CASE_TYPE', condition: Condition.EQUAL}
	},
	{
		key: 'channel',
		propName: 'e.channel.rowId',
	    autocompleteInstance: 'AutocompleteDynamicChannel',
	    type: SearchPropertyType.AUTOCOMPLETE,
	    title: 'Channel',
	    maxlength: 50,
	    autocompleteProp: 'channelName',
	    autocompleteCondition: Condition.CONTAINS
	},
	{
		key: 'site',
		propName: 'e.site.rowId',
	    autocompleteInstance: 'AutocompleteDynamicSite',
	    type: SearchPropertyType.AUTOCOMPLETE,
	    title: 'Site',
	    maxlength: 50,
	    autocompleteProp: 'siteName',
	    autocompleteCondition: Condition.CONTAINS
	},
	{ key: 'caseDate',propName: 'e.caseDate', type: SearchPropertyType.DATE, title: 'Case Date', maxlength: 8 },
    {  key: 'orderId', propName: 'e.orderId', type: SearchPropertyType.TEXT, title: 'Order Id', maxlength: 100 },
    {  key: 'caseDescription', propName: 'e.caseDescription', type: SearchPropertyType.TEXT, title: 'Case Description', maxlength: 100 },
    {  key: 'customerName', propName: 'e.customerName', type: SearchPropertyType.TEXT, title: 'Customer Name', maxlength: 100 },
    {
    	key: 'createdBy',
    	propName: 'e.createdBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Created By',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    {
    	key: 'updatedBy',
    	propName: 'e.updatedBy.rowId',
        autocompleteInstance: 'AutocompleteDynamicUser',
        type: SearchPropertyType.AUTOCOMPLETE,
        title: 'Updated By',
        maxlength: 50,
        autocompleteProp: 'lastName',
        autocompleteCondition: Condition.CONTAINS
    },
    { key: 'created',propName: 'e.created', type: SearchPropertyType.DATE, title: 'Created', maxlength: 8 },
    { key: 'updated',propName: 'e.updated', type: SearchPropertyType.DATE, title: 'Updated', maxlength: 8 },
    { key: 'active',propName: 'e.active', type: SearchPropertyType.BOOLEAN, title: 'Active', maxlength: -1}
]


/*--------------------------------------------------------------------------------------- Fill Card ------------------*/
function fillCard(entities) {
    var cardContainer = $('.card-container');
    var patternRow = cardContainer.find('section#row');
    cardContainer.css({"display": "block"});
    cardContainer.find('section').not(patternRow).remove();

    entities.forEach(function (item, index) {
        var newRow = patternRow.clone();
        var id = item.rowId;
        newRow.attr('id', 'row-' + id);
        newRow.find('.row-number').html(index + 1 + (pageNo - 1) * pageSize);
        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#userDTO").attr("id", 'userDTO-' + id).find('span').html(item.userDTO ? item.userDTO.fullTitle : '');
        patternRow.find('#createdBy').attr("id", 'createdBy-' + id).find('span').html(item.createdBy.fullTitle);
        patternRow.find('#created').attr("id", 'created-' + id).find('span').html(item.created);
        patternRow.find('#updatedBy').attr("id", 'updatedBy-' + id).find('span').html(item.updatedBy.fullTitle);
        patternRow.find('#updated').attr("id", 'updated-' + id).find('span').html(item.updated);
        patternRow.find("#active").attr("id", 'active-' + id).find('span').html(item.active ? "Active" : "Inactive");
        patternRow.find('#entityId').attr("id", 'entityId-' + id);

        newRow.appendTo(cardContainer);
    })

    // Listener(s)
    $('.row-action').on('click', function (e) {
        e.stopPropagation()
        $('.row-action-item').not($(this).find('.row-action-item')).removeClass('show');
        $(this).find('.row-action-item').toggleClass('show');
    })
    cardContainer.on('click', function () {
        $('.row-action-item').removeClass('show');
    })
    $('.row-action-item.remove').on('click', function () {
        alert('Remove');
    })
    $('.row-action-item.edit').on('click', function () {
        showRow($(this).parent().attr('id').split('-')[1]);
    })

    patternRow.css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Fill Table -----------------*/
function fillTable(entities) {
    $('.win-content-body > table').css({"display": "table"});
    var tableBody = $('.win-content-body > table > tbody');
    tableBody.find('tr').not('tr#row').remove();
    tableBody.find('tr#row').removeAttr('style');
    entities.forEach(function (item, index) {
        var patternRow = tableBody.find('#row').clone();
        var id = item.rowId;
        patternRow.attr('id', 'row-' + id);
        patternRow.find('#id').attr("id", id).find('span').html(index + 1 + (pageNo - 1) * pageSize);

        patternRow.find("#rowId").attr("id", 'rowId-' + id).find('span').html(item.rowId);
        patternRow.find("#userDTO").attr("id", 'userDTO-' + id).find('span').html(item.userDTO ? item.userDTO.fullTitl : '');
        patternRow.find("#channelDTO").attr("id", 'channelDTO-' + id).find('span').html(item.channelDTO ? item.channelDTO.channelName : '');
        patternRow.find('#productDTO').attr("id", 'productDTO-' + id).find('span').html(item.productDTO ? formatLongStr(item.productDTO.productTitle, true, 50) : '');
        patternRow.find('#caseTypeDTO').attr("id", 'caseTypeDTO-' + id).find('span').html(item.caseTypeDTO ? item.caseTypeDTO.name : '');
        patternRow.find('#entityId').attr("id", 'entityId-' + id);
        patternRow.appendTo(tableBody);
        $(patternRow).on('dblclick', function () {
            showRow(id)
        });
    });
    tableBody.find('tr#row').css({'display': 'none'});
    hideLoading();
    setTimeout(function () {
        showGrid();
    }, 300)
}

/*--------------------------------------------------------------------------------------- Search ---------------------*/
var hSearch = new Handler();
var gridEntities;
hSearch.beforeSend = function beforeSend() {
    showLoading();
}
hSearch.success = function success(result) {
    if (result.done) {
    	searchResultEntities = result.result;
        if (result.result) {
            fillGrid(result.result);
        } else {
            hideLoading();
            $('.win-content-body').removeClass('animated').css({'display': 'none'});;
            setTimeout(function () {
                showError("No things to show");
            }, 300)
        }
    } else {
        hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hSearch.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + ResponseCode[jqXHR.status]);
    }, 300)
}
hSearch.complete = function complete() {
    unlockPage();
}

var fSearch = new Filter();
fSearch.addParameter("customerName", '$("#customerName_Searcher").val()', Condition.CONTAINS);
fSearch.addParameter("product.sku", '$("#productSKU_Searcher").val()', Condition.CONTAINS);

var pageOrderField="rowId desc";
function search(orderField){
	pageOrderField = orderField;
	//alert(fSearch.getFilters(orderField))
    ServiceInvoker.call(fSearch.getFilters(orderField), hSearch, "/customerServiceCase/list");
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/

function showRow(id) {
    window.frames['editFrame'].showRow(id);
}


$(document).ready(function () {
    /*----------------------------------------------------------------------------------- Set Mask -------------------*/
    /*$('#search').on('click', function () {
        search();
    })*/
	$('#caseProblem').on('click', function () {
		var id = $(this).closest('ul').parent().attr('data-id');

		addTab({
            window: window,
			src: '/pmt/caseproblem',
			title: 'Case Problem',
            filter: [
                {
                    filterTitle: 'Case Problem',
                    key: 'customerServiceCase.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    customerTitle:getSearchResultValue(id, 'customerName')
                }
            ]
        })
	})
	$('#caseAction').on('click', function () {
		var id = $(this).closest('ul').parent().attr('data-id');

		addTab({
            window: window,
			src: '/pmt/caseaction',
			title: 'Case Action',
            filter: [
                {
                    filterTitle: 'Case Action',
                    key: 'customerServiceCase.rowId',
                    value: id,
                    condition: Condition.EQUAL,
                    customerTitle:getSearchResultValue(id, 'customerName')
                }
            ]
        })
	})
    $('#search').on('click', function () {
        if(AdvanceSearch.initializeFilter().length > 0) {
            fSearch.removeParameter(Condition.WHERE);
            fSearch.addParameter(Condition.WHERE, AdvanceSearch.initializeFilter(), Condition.WHERE);
            $('.win-content-header').removeClass('full-search compact')
            $('#clear-filter').removeClass('hide');
        } else if($('.simple-search input').val().trim().length > 0 || $("#productSKU_Searcher").val() != "" || $("#product_Searcher").val() != "") {
            $('#clear-filter').removeClass('hide');
        }
        search(pageOrderField);
        $('.win-content-header').removeClass('compact full-search')

    })

    $('#clear-filter').on('click', function () {
        // Remove Advance Filter Key From Filter Object & Clear Advanced Form & Clear Simple Search From
        $('#filter-item-container').empty();
        $('.simple-search input').val('');
        $("#product_Searcher").attr("entityId","");
        $("#productSKU_Searcher").val("");
        fSearch.removeParameter(Condition.WHERE);
        this.classList.add('hide');
        search(pageOrderField)
    })
    $('#product_Searcher').on('click',function(){
	 	var fproduct = new Filter();
	 	fproduct.addParameter("productTitle", '$("#product_Searcher").val()', Condition.CONTAINS);
	 	AutocompleteDynamicProduct("product_Searcher", fproduct);
	 	fSearch.addParameter("product", '$("#product_Searcher").attr("entityId")', Condition.CONTAINS);
   })
    
    /*----------------------------------------------------------------------------------- Initialization -------------*/
	AdvanceSearch.init();
    setIndexListeners();
    search(pageOrderField);

});
/*---------------------------------------------------------------------------------------- override ------------------*/
function showLoading() {
    if ($('.win-content-body').hasClass('animated')) {
        showGrid();
        setTimeout(function () {
            $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
        }, 300)
        return;
    }
    if ($('.edit-container').hasClass('animated')) {
        hideEdit();
        setTimeout(function () {
            $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
        }, 300)
        return;
    }
    if ($('.error-container').hasClass('animated')) {
        hideError();
        setTimeout(function () {
            $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
        }, 300)
        return;
    }
    $('.loading-container').addClass('animated fadeIn').css({'display': 'block'});
}
function newForm(){
	showLoading();
    hideLoading();
    setTimeout(function () {
    	$('.edit-container').addClass('animated fadeIn').css({'display': 'block'});
    	window.frames['editFrame'].clearForm();
    }, 300);
}
/*--------------------------------------------------------------------------------------- End ------------------------*/