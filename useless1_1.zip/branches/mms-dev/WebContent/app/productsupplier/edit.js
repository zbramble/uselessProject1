var entity;

$(document).ready(function () {
    setEditListeners();

    /*----------------------------------------------------------------------------------- Save -----------------------*/
    $('#save-btn').on('click', function () {
        var hSave = new Handler();
        hSave.success = function success(result) {
            if (result.done) {
                dialog('Save', result.resultCountAll + ' Item saved');
                $("#rowId").val(result.result);
            }
            else {
                errorHandle(result);
            }
        }
        hSave.error = function error(jqXHR, textStatus) {
            dialog('Save', textStatus + 'Error: ')
        }
        saveRow('edit-form', hSave, "/productSupplier/save");
    });

/*-----------------------------------------------------------------------------------Mask-----------------------*/
	$('#price').number( true, 2, '.', ',');
	$('#minOrderQty').number( true);
	$('#leadTimeDays').number( true);
	
	 /*----------------------------------------------------------------------------------- Autocomplete ---------------*/
var fProduct = new Filter();
    fProduct.addParameter("productTitle", '$("#productDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicProduct("productDTO", fProduct);

	var fcompany = new Filter();
	fcompany.addParameter("companyName", '$("#companyDTO").val()', Condition.CONTAINS);
    AutocompleteDynamicCompany("companyDTO", fcompany);

});
/*----------------------------------------------------------------------------------- Delete ---------------------*/
function deleteRow(id) {
    var hDelete = new Handler();
    hDelete.success = function success(result) {
        if (result.done) {
            parent.search()
        } else {
            errorHandle(result)
        }
    }
    hDelete.error = function error(jqXHR, textStatus) {
        dialog('Delete', textStatus + 'Error: ')
    }

    var dFilter = new Filter();
    dFilter.addParameter("rowId", id, Condition.EQUAL);

    ServiceInvoker.call(dFilter.getFilters(), hDelete, "/productSupplier/delete");
}
//does not have
/*--------------------------------------------------------------------------------------- Fill Edit ------------------*/
function fillEdit(dto) {
    entity = dto;
    clearForm();
    $("#rowId").val(dto.rowId);
    $("#leadTimeDays").val(dto.leadTimeDays);
    $("#minOrderQty").val(dto.minOrderQty);
    $("#note").val(dto.note);
	$("#price").val(dto.price);
	$("#description").val(dto.description);
	$("#accessKey").val(dto.accessKey);
	if(dto.productDTO){
		$("#productDTO").val(dto.productDTO.productTitle);
        $("#productDTO").attr("entityId", dto.productDTO.rowId);
	}
	
	if(dto.companyDTO){
		$("#companyDTO").val(dto.companyDTO.companyName);
		$("#companyDTO").attr("entityId", dto.companyDTO.rowId);
	}
	$("#defaultSupplier").prop("checked",dto.defaultSupplier);
	
	$("#createdBy").val(dto.createdBy.fullTitle);
    $("#created").val(dto.created);
    $("#updatedBy").val(dto.updatedBy.fullTitle);
    $("#updated").val(dto.updated);
    $("#active").prop("checked", dto.active);
    Log(dto.active)

}

/*--------------------------------------------------------------------------------------- Clear Form --------------------*/
function clearForm() {
    $('#edit-form').find('input:text').val('');
    $('#edit-form').find('textarea').val('');
    $('#edit-form').find('input:checkbox').not('#active').prop("checked", false);
    $('#edit-form').find('input:checkbox#active').prop("checked", true);
    $('#edit-form').find('input:radio').prop("checked", false);
    $('#edit-form').find("select option:first-child").prop("selected", true);
    $('#edit-form').find("[entityId]").removeAttr('entityId');
    $('.btn-container').find("#remove-btn").attr("disabled", true);
    $("#productDTO").val(parent.title);
	$("#productDTO").attr("entityId", parent.id);
}

/*--------------------------------------------------------------------------------------- Show Row -------------------*/
var hShowRow = new Handler();
hShowRow.beforeSend = function beforeSend() {
    parent.showLoading();
}
hShowRow.success = function success(result) {
    if (result.done) {
        parent.hideLoading();
        setTimeout(function () {
            parent.showEdit(result.result[0])
        }, 300);
    } else {
        parent.hideLoading();
        setTimeout(function () {
            errorHandle(result);
        }, 300)
    }
}
hShowRow.error = function error(jqXHR, textStatus) {
    hideLoading();
    setTimeout(function () {
        showError("Error: " + textStatus + ' ' + jqXHR.status);
    }, 300);
}
hShowRow.complete = function complete() {
    unlockPage();
}

var fShrSearche = new Filter();

function showRow(id) {
    fShrSearche.clearParams();
    fShrSearche.addParameter("rowId", id, Condition.EQUAL);
    var oldPageNo = pageNo;
    pageNo = 1;
    ServiceInvoker.call(fShrSearche.getFilters(), hShowRow, "/productSupplier/list");
    pageNo = oldPageNo;
}

/*--------------------------------------------------------------------------------------- End ------------------------*/

