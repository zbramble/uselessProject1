/**
 * @param  {String}   targetElement
 * @param  {Filter}   filter
 */
function AutocompleteDynamicProductChannelSKU(targetElement, filter) {

    var customAutocomplete = new CustomAutocomplete();
    var params = {
        filter: filter,
        targetElementId: targetElement,
        serviceUrl: "/channelSKU/list",
        mapPattern: {
            label: "fullTitle",
            value: "fullTitle",
            entityId: "rowId"
        }
    }
    customAutocomplete.dynamicConfig(params);
};
