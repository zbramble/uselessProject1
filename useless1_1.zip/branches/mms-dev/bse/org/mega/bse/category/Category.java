package org.mega.bse.category;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "BSE_PRODUCT_CATEGORY", uniqueConstraints = @UniqueConstraint(name = "PK_BSE_PRODUCT_CATEGORY", columnNames = "CATEGORY_ID") )
public class Category extends BaseEntity {

	@Id
	@Column(name = "CATEGORY_ID")
	private long rowId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TOP_CATEGORY_ID", foreignKey = @ForeignKey(name = "FK_BSE_PROD_REFERENCE_BSE_PROD") , nullable = false)
	private Category topCategory;

	@Column(name = "CATEGOTY_DESCRIPTION", length = 300)
	private String categoryDescription;

	@Column(name = "DESCRIPTION", length = 500)
	private String description;

	@Column(name = "IS_ENABLE")
	private boolean enable;

	public Long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public Category getTopCategory() {
		return topCategory;
	}

	public void setTopCategory(Category topCategory) {
		this.topCategory = topCategory;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = categoryDescription;
    }
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
    	fullTitle = categoryDescription;
    }
}
