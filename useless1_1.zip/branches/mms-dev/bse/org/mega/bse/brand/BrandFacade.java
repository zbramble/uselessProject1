package org.mega.bse.brand;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class BrandFacade extends BaseFacade {

	private static BrandCopier copier = new BrandCopier();
	private static BrandFacade facade = new BrandFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static BrandFacade getInstace() {
		return facade;
	}

}
