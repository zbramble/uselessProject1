package org.mega.bse.site;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDTO;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;

public class SiteFacade extends BaseFacade{
	private static SiteCopier copier = new SiteCopier();
	private static SiteFacade facade = new SiteFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static SiteFacade getInstace() {
		return facade;
	}
	
	@Override
	public ServiceResult save(BaseDTO baseDTO, BusinessParam businessParam) {
		// TODO Auto-generated method stub
		SiteDTO siteDTO = (SiteDTO) baseDTO;
		if(siteDTO.getRowId() == 0)
			siteDTO.setAccessKey(businessParam.getUserSession().getUserInfo().getAccessKey());
		return super.save(baseDTO, businessParam);
	}

}
