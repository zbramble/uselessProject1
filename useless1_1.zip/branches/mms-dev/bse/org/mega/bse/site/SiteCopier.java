package org.mega.bse.site;

import org.mega.bse.channel.Channel;
import org.mega.bse.channel.ChannelDTO;
import org.mega.core.base.BaseCopier;

public class SiteCopier extends BaseCopier<Site, SiteDTO>{

	@Override
	public SiteDTO copyFromEntity(Site site) {
		SiteDTO sDTO = new SiteDTO();
		sDTO.setRowId(site.getRowId());
		if(site.getChannel() != null){
			ChannelDTO cDTO = new ChannelDTO();
			cDTO.setRowId(site.getChannel().getRowId());
			cDTO.setChannelName(site.getChannel().getChannelName());
			sDTO.setChannelDTO(cDTO);
		}
		sDTO.setDescription(site.getDescription());
		sDTO.setSiteName(site.getSiteName());
		copyFromEntityBaseField(site, sDTO);
		return sDTO;
	}

	@Override
	public Site copyToEntity(SiteDTO siteDTO) throws Exception {
		Site s = new Site();
		s.setRowId(siteDTO.getRowId());
		if(siteDTO.getChannelDTO() != null){
			Channel c = new Channel();
			c.setRowId(siteDTO.getChannelDTO().getRowId());
			c.setChannelName(siteDTO.getChannelDTO().getChannelName());
			s.setChannel(c);
		}
		s.setDescription(siteDTO.getDescription());
		s.setSiteName(siteDTO.getSiteName());
		copyToEntityBaseField(s, siteDTO);
		return s;
	}

}
