package org.mega.bse.channel;

import org.mega.core.base.BaseCopier;

public class ChannelCopier extends BaseCopier<Channel, ChannelDTO>{

	@Override
	public ChannelDTO copyFromEntity(Channel channel) {
		ChannelDTO channelDTO = new ChannelDTO();
		channelDTO.setRowId(channel.getRowId());
		channelDTO.setChannelName(channel.getChannelName());
		channelDTO.setDescription(channel.getDescription());
		copyFromEntityBaseField(channel, channelDTO);
		return channelDTO;
	}

	@Override
	public Channel copyToEntity(ChannelDTO channelDTO) throws Exception {
		Channel channel = new Channel();
		channel.setRowId(channelDTO.getRowId());
		channel.setChannelName(channelDTO.getChannelName());
		channel.setDescription(channelDTO.getDescription());
		copyToEntityBaseField(channel, channelDTO);
		return channel;
	}

}
