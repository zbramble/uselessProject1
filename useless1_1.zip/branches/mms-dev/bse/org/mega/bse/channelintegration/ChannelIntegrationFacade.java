package org.mega.bse.channelintegration;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class ChannelIntegrationFacade extends BaseFacade {

	private static ChannelIntegrationCopier copier = new ChannelIntegrationCopier();
	private static ChannelIntegrationFacade facade = new ChannelIntegrationFacade();

	@Override
	public BaseCopier getCopier() {
		return copier;
	}

	public static ChannelIntegrationFacade getInstace() {
		return facade;
	}

}
