package org.mega.bse.channelintegration;

import org.mega.bse.site.Site;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.organization.Organization;
import org.mega.core.organization.OrganizationDTO;

public class ChannelIntegrationCopier extends BaseCopier<ChannelIntegration, ChannelIntegrationDTO>{

	@Override
	public ChannelIntegrationDTO copyFromEntity(ChannelIntegration channelIntegration) {
		ChannelIntegrationDTO channelIntegrationDTO = new ChannelIntegrationDTO();
		channelIntegrationDTO.setRowId(channelIntegration.getRowId());
		if(channelIntegration.getSite() != null){
			SiteDTO siteDto  = new SiteDTO();
			siteDto.setRowId(channelIntegration.getSite().getRowId());
			siteDto.setSiteName(channelIntegration.getSite().getSiteName());
			siteDto.setAccessKey(channelIntegration.getSite().getAccessKey());
			channelIntegrationDTO.setSiteDTO(siteDto);
		}
		if(channelIntegration.getOrg() != null){
			OrganizationDTO organizationDto  = new OrganizationDTO();
			organizationDto.setRowId(channelIntegration.getOrg().getRowId());
			organizationDto.setName(channelIntegration.getOrg().getName());
			organizationDto.setAccessKey(channelIntegration.getOrg().getAccessKey());
			channelIntegrationDTO.setOrgDTO(organizationDto);
		}
		channelIntegrationDTO.setAmazonAccessKeyDTO(channelIntegration.getAmazonAccessKey());
		channelIntegrationDTO.setSecretKeyDTO(channelIntegration.getSecretKey());
		channelIntegrationDTO.setSellerIdDTO(channelIntegration.getSellerId());
		channelIntegrationDTO.setMarketplaceIdDTO(channelIntegration.getMarketplaceId());
		channelIntegrationDTO.setSellerUserNameDTO(channelIntegration.getSellerUserName());
		channelIntegrationDTO.setSellerUserPassDTO(channelIntegration.getSellerUserPass());
		copyFromEntityBaseField(channelIntegration,channelIntegrationDTO);
		return channelIntegrationDTO;
	}

	@Override
	public ChannelIntegration copyToEntity(ChannelIntegrationDTO channelIntegrationDTO) throws Exception {
		ChannelIntegration channelIntegration = new ChannelIntegration();
		channelIntegration.setRowId(channelIntegrationDTO.getRowId());
		if(channelIntegrationDTO.getSiteDTO() != null){
			Site site  = new Site();
			site.setRowId(channelIntegrationDTO.getSiteDTO().getRowId());
			channelIntegration.setSite(site);
		}
		if(channelIntegrationDTO.getOrgDTO() != null){
			Organization organization  = new Organization();
			organization.setRowId(channelIntegrationDTO.getOrgDTO().getRowId());
			channelIntegration.setOrg(organization);
		}
		channelIntegration.setAmazonAccessKey(channelIntegrationDTO.getAmazonAccessKeyDTO());
		channelIntegration.setSecretKey(channelIntegrationDTO.getSecretKeyDTO());
		channelIntegration.setSellerId(channelIntegrationDTO.getSellerIdDTO());
		channelIntegration.setMarketplaceId(channelIntegrationDTO.getMarketplaceIdDTO());
		channelIntegration.setSellerUserName(channelIntegrationDTO.getSellerUserNameDTO());
		channelIntegration.setSellerUserPass(channelIntegrationDTO.getSellerUserPassDTO());
		
		copyToEntityBaseField(channelIntegration, channelIntegrationDTO);
		return channelIntegration;
	}

}
