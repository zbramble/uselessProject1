package org.mega.amazon.MerchantPlace;


import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseDTO;
import org.mega.core.organization.OrganizationDTO;

public class AmazonMarketPlaceDTO extends BaseDTO{


	private long rowId;
	private SiteDTO site;
	private OrganizationDTO org;
	private String secrectKey;
	private String sellerId;
	private String amazonMarketPlaceId;
	private String serviceUrl;
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public SiteDTO getSite() {
		return site;
	}
	public void setSite(SiteDTO site) {
		this.site = site;
	}
	public OrganizationDTO getOrg() {
		return org;
	}
	public void setOrg(OrganizationDTO org) {
		this.org = org;
	}
	public String getSecrectKey() {
		return secrectKey;
	}
	public void setSecrectKey(String secrectKey) {
		this.secrectKey = secrectKey;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public String getAmazonMarketPlaceId() {
		return amazonMarketPlaceId;
	}
	public void setAmazonMarketPlaceId(String amazonMarketPlaceId) {
		this.amazonMarketPlaceId = amazonMarketPlaceId;
	}
	public String getServiceUrl() {
		return serviceUrl;
	}
	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}
	
	
	
}
