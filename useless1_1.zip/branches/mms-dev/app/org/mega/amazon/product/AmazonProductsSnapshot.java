package org.mega.amazon.product;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

import org.mega.core.base.BaseEntity;

/**
 * The persistent class for the AMAZON_PRODUCTS_SNAPSHOT database table.
 * 
 */
//@Entity
//@Table(name="AMAZON_PRODUCTS_SNAPSHOT")
//@NamedQuery(name="AmazonProductsSnapshot.findAll", query="SELECT a FROM AmazonProductsSnapshot a")
public class AmazonProductsSnapshot extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "ID")
    private long rowId;
    
	@Column(name="ADD_DELETE")
	private String addDelete;

	private String asin1;

	private String asin2;

	private String asin3;

	@Column(name="BID_FOR_FEATURED_PLACEMENT")
	private String bidForFeaturedPlacement;

	@Column(name="BUSINESS_PRICE")
	private String businessPrice;

	@Column(name="EXPEDITED_SHIPPING")
	private String expeditedShipping;

	@Column(name="FULFILLMENT_CHANNEL")
	private String fulfillmentChannel;

	@Column(name="IMAGE_URL")
	private String imageUrl;

	@Column(name="ITEM_CONDITION")
	private String itemCondition;

	@Column(name="ITEM_DESCRIPTION")
	private String itemDescription;

	@Column(name="ITEM_IS_MARKETPLACE")
	private String itemIsMarketplace;

	@Column(name="ITEM_NAME")
	private String itemName;

	@Column(name="ITEM_NOTE")
	private String itemNote;

	@Column(name="LISTING_ID")
	private String listingId;

	@Column(name="MERCHANT_ID")
	private String merchantId;

	@Column(name="MERCHANT_SHIPPING_GROUP")
	private String merchantShippingGroup;

	@Column(name="OPEN_DATE")
	private String openDate;

	@Column(name="PENDING_QUANTITY")
	private String pendingQuantity;

	private String price;

	@Column(name="PRODUCT_ID")
	private String productId;

	@Column(name="PRODUCT_ID_TYPE")
	private String productIdType;

	private String quantity;

	@Column(name="QUANTITY_LOWER_BOUND_1")
	private String quantityLowerBound1;

	@Column(name="QUANTITY_LOWER_BOUND_2")
	private String quantityLowerBound2;

	@Column(name="QUANTITY_LOWER_BOUND_3")
	private String quantityLowerBound3;

	@Column(name="QUANTITY_LOWER_BOUND_4")
	private String quantityLowerBound4;

	@Column(name="QUANTITY_LOWER_BOUND_5")
	private String quantityLowerBound5;

	@Column(name="QUANTITY_PRICE_1")
	private String quantityPrice1;

	@Column(name="QUANTITY_PRICE_2")
	private String quantityPrice2;

	@Column(name="QUANTITY_PRICE_3")
	private String quantityPrice3;

	@Column(name="QUANTITY_PRICE_4")
	private String quantityPrice4;

	@Column(name="QUANTITY_PRICE_5")
	private String quantityPrice5;

	@Column(name="QUANTITY_PRICE_TYPE")
	private String quantityPriceType;

	@Column(name="SELLER_SKU")
	private String sellerSku;

	@Column(name="WILL_SHIP_INTERNATIONALLY")
	private String willShipInternationally;

	@Column(name="ZSHOP_BOLDFACE")
	private String zshopBoldface;

	@Column(name="ZSHOP_BROWSE_PATH")
	private String zshopBrowsePath;

	@Column(name="ZSHOP_CATEGORY1")
	private String zshopCategory1;

	@Column(name="ZSHOP_SHIPPING_FEE")
	private String zshopShippingFee;

	@Column(name="ZSHOP_STOREFRONT_FEATURE")
	private String zshopStorefrontFeature;

	public AmazonProductsSnapshot() {
	}

	public String getAddDelete() {
		return this.addDelete;
	}

	public void setAddDelete(String addDelete) {
		this.addDelete = addDelete;
	}

	public String getAsin1() {
		return this.asin1;
	}

	public void setAsin1(String asin1) {
		this.asin1 = asin1;
	}

	public String getAsin2() {
		return this.asin2;
	}

	public void setAsin2(String asin2) {
		this.asin2 = asin2;
	}

	public String getAsin3() {
		return this.asin3;
	}

	public void setAsin3(String asin3) {
		this.asin3 = asin3;
	}

	public String getBidForFeaturedPlacement() {
		return this.bidForFeaturedPlacement;
	}

	public void setBidForFeaturedPlacement(String bidForFeaturedPlacement) {
		this.bidForFeaturedPlacement = bidForFeaturedPlacement;
	}

	public String getBusinessPrice() {
		return this.businessPrice;
	}

	public void setBusinessPrice(String businessPrice) {
		this.businessPrice = businessPrice;
	}

	public String getExpeditedShipping() {
		return this.expeditedShipping;
	}

	public void setExpeditedShipping(String expeditedShipping) {
		this.expeditedShipping = expeditedShipping;
	}

	public String getFulfillmentChannel() {
		return this.fulfillmentChannel;
	}

	public void setFulfillmentChannel(String fulfillmentChannel) {
		this.fulfillmentChannel = fulfillmentChannel;
	}

	public String getImageUrl() {
		return this.imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getItemCondition() {
		return this.itemCondition;
	}

	public void setItemCondition(String itemCondition) {
		this.itemCondition = itemCondition;
	}

	public String getItemDescription() {
		return this.itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemIsMarketplace() {
		return this.itemIsMarketplace;
	}

	public void setItemIsMarketplace(String itemIsMarketplace) {
		this.itemIsMarketplace = itemIsMarketplace;
	}

	public String getItemName() {
		return this.itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemNote() {
		return this.itemNote;
	}

	public void setItemNote(String itemNote) {
		this.itemNote = itemNote;
	}

	public String getListingId() {
		return this.listingId;
	}

	public void setListingId(String listingId) {
		this.listingId = listingId;
	}

	public String getMerchantId() {
		return this.merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantShippingGroup() {
		return this.merchantShippingGroup;
	}

	public void setMerchantShippingGroup(String merchantShippingGroup) {
		this.merchantShippingGroup = merchantShippingGroup;
	}

	public String getOpenDate() {
		return this.openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	public String getPendingQuantity() {
		return this.pendingQuantity;
	}

	public void setPendingQuantity(String pendingQuantity) {
		this.pendingQuantity = pendingQuantity;
	}

	public String getPrice() {
		return this.price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getProductId() {
		return this.productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductIdType() {
		return this.productIdType;
	}

	public void setProductIdType(String productIdType) {
		this.productIdType = productIdType;
	}

	public String getQuantity() {
		return this.quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getQuantityLowerBound1() {
		return this.quantityLowerBound1;
	}

	public void setQuantityLowerBound1(String quantityLowerBound1) {
		this.quantityLowerBound1 = quantityLowerBound1;
	}

	public String getQuantityLowerBound2() {
		return this.quantityLowerBound2;
	}

	public void setQuantityLowerBound2(String quantityLowerBound2) {
		this.quantityLowerBound2 = quantityLowerBound2;
	}

	public String getQuantityLowerBound3() {
		return this.quantityLowerBound3;
	}

	public void setQuantityLowerBound3(String quantityLowerBound3) {
		this.quantityLowerBound3 = quantityLowerBound3;
	}

	public String getQuantityLowerBound4() {
		return this.quantityLowerBound4;
	}

	public void setQuantityLowerBound4(String quantityLowerBound4) {
		this.quantityLowerBound4 = quantityLowerBound4;
	}

	public String getQuantityLowerBound5() {
		return this.quantityLowerBound5;
	}

	public void setQuantityLowerBound5(String quantityLowerBound5) {
		this.quantityLowerBound5 = quantityLowerBound5;
	}

	public String getQuantityPrice1() {
		return this.quantityPrice1;
	}

	public void setQuantityPrice1(String quantityPrice1) {
		this.quantityPrice1 = quantityPrice1;
	}

	public String getQuantityPrice2() {
		return this.quantityPrice2;
	}

	public void setQuantityPrice2(String quantityPrice2) {
		this.quantityPrice2 = quantityPrice2;
	}

	public String getQuantityPrice3() {
		return this.quantityPrice3;
	}

	public void setQuantityPrice3(String quantityPrice3) {
		this.quantityPrice3 = quantityPrice3;
	}

	public String getQuantityPrice4() {
		return this.quantityPrice4;
	}

	public void setQuantityPrice4(String quantityPrice4) {
		this.quantityPrice4 = quantityPrice4;
	}

	public String getQuantityPrice5() {
		return this.quantityPrice5;
	}

	public void setQuantityPrice5(String quantityPrice5) {
		this.quantityPrice5 = quantityPrice5;
	}

	public String getQuantityPriceType() {
		return this.quantityPriceType;
	}

	public void setQuantityPriceType(String quantityPriceType) {
		this.quantityPriceType = quantityPriceType;
	}

	public String getSellerSku() {
		return this.sellerSku;
	}

	public void setSellerSku(String sellerSku) {
		this.sellerSku = sellerSku;
	}

	public String getWillShipInternationally() {
		return this.willShipInternationally;
	}

	public void setWillShipInternationally(String willShipInternationally) {
		this.willShipInternationally = willShipInternationally;
	}

	public String getZshopBoldface() {
		return this.zshopBoldface;
	}

	public void setZshopBoldface(String zshopBoldface) {
		this.zshopBoldface = zshopBoldface;
	}

	public String getZshopBrowsePath() {
		return this.zshopBrowsePath;
	}

	public void setZshopBrowsePath(String zshopBrowsePath) {
		this.zshopBrowsePath = zshopBrowsePath;
	}

	public String getZshopCategory1() {
		return this.zshopCategory1;
	}

	public void setZshopCategory1(String zshopCategory1) {
		this.zshopCategory1 = zshopCategory1;
	}

	public String getZshopShippingFee() {
		return this.zshopShippingFee;
	}

	public void setZshopShippingFee(String zshopShippingFee) {
		this.zshopShippingFee = zshopShippingFee;
	}

	public String getZshopStorefrontFeature() {
		return this.zshopStorefrontFeature;
	}

	public void setZshopStorefrontFeature(String zshopStorefrontFeature) {
		this.zshopStorefrontFeature = zshopStorefrontFeature;
	}

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

	@Override
	public void prePersist() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void preUpdate() throws Exception {
		// TODO Auto-generated method stub
	}

}