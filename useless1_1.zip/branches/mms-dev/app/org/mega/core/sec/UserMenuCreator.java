package org.mega.core.sec;

import java.util.HashMap;
import java.util.Map;

import org.mega.core.SystemConfig;
import org.mega.core.action.ActionDTO;

public class UserMenuCreator implements UserMenuCreatorI{

	private static Map<Long,String> menuTreeCache = new HashMap<Long, String>();
	private static Map<Long,String> menuDataCache = new HashMap<Long, String>();

	UserInfo userInfo;
	Map<String, Integer> access;
	StringBuilder menuTree = new StringBuilder();
	StringBuilder menuData = new StringBuilder();

	@Override
	public UserMenuCreatorI init(UserInfo userInfo) {
		UserMenuCreator creator = new UserMenuCreator();
		creator.userInfo = userInfo;
		creator.access = userInfo.getAccess();
		creator.createMenu();
		return creator;
	}

	public void createMenu() {
		int showInMenuAct = ActionDTO.ACTION.showInMenu.ordinal();

		menuData.append("{");
		menuTree.append("[");
	
		
		addItem("Dashboard"				                   , "#"		  	       , "Dashboard"				                ,null		        	,"ion-android-globe"	, -1, -1, false, showInMenuAct);
		addItem("ReviewAndReport"		                   , "Dashboard"		   , "Review And Order"			                ,"app/report/review_order.html"	,null			, -1, -1, false, showInMenuAct);
		
		addItem("Product"				                   , "#"		  	       , "Product"				                    ,"app/product"		    ,"ion-ios-barcode"	, -1, -1, false, showInMenuAct);
		addItem("Order"				                       , "#"		  	       , "Order"				                    ,"app/orderitem"		,"ion-ios-cart"	, -1, -1, false, showInMenuAct);
		addItem("Local"					                   , "Product"		       , "My Products"				                ,"app/product"		        ,null	, -1, -1, false, showInMenuAct);
		addItem("Amazon_products"		                   , "Product"		       , "Amazon-US Snapshot"			            ,"app/amazon/product"       ,null			, -1, -1, false, showInMenuAct);
		addItem("ProductChannelSKU"				           , "Product"		  	   , "Product Channel SKU"				        ,"app/channelsku"		, null	, -1, -1, false, showInMenuAct);
		addItem("ReviewTracker"			                   , "#"                   , "Review Tracker"				            ,null		                ,"ion-archive"	, -1, -1, false, showInMenuAct);
		addItem("Review"		                           , "ReviewTracker"       , "All Reviews"		                        , "app/review"	            ,null			, -1, -1, false, showInMenuAct);
		addItem("Review_Setting"		                   , "ReviewTracker"       , "Review Tracking Rules"	                , "bse/reviewtargetsetting" ,null			, -1, -1, false, showInMenuAct);
		addItem("Email_Template_Management"	               , "ReviewTracker"       , "Email Template Management"	            , null  		            ,null			, -1, -1, false, showInMenuAct);
		addItem("Automatic_Email_Sending_Configuration"	   , "ReviewTracker"       , "Automatic Email Sending Configuration"	, null  		            ,null			, -1, -1, false, showInMenuAct);
		
		addItem("Repricer"				                   , "#"                   , "Repricer"				                    ,null	                    ,"ion-ios-game-controller-b"	, -1, -1, false, showInMenuAct);
		addItem("Repricing_Rule_Setting"		           , "Repricer"            , "Repricing Rule Setting"		            , null	                    ,null			, -1, -1, false, showInMenuAct);
		
		addItem("PM_Toolkit"			                   , "#"		  	       , "Product Manager Toolkit"			        ,null			            ,"ion-settings"	, -1, -1, false, showInMenuAct);
		addItem("Team_management"		                   , "PM_Toolkit"          , "Manage Marketing Teams"			        ,"pmt/marketingteam"		,null	, -1, -1, false, showInMenuAct);
		addItem("Team_negative_reviews"		               , "PM_Toolkit"          , "Team negative reviews"			        ,"app/report/team_negative_reviews.html"       ,null	, -1, -1, false, showInMenuAct);
		addItem("PM_Performance_Report"		               , "PM_Toolkit"          , "PM Performance Report"			        ,"app/report/team_performance.html"       ,null	, -1, -1, false, showInMenuAct);
		addItem("review_drop_risk"		        	       , "PM_Toolkit"          , "Review drop risk report"			        ,"app/report/review_drop_risk.html"       ,null	, -1, -1, false, showInMenuAct);
		
		
		addItem("Customer_Service"		                   , "#"		  	       , "Customer Service"		                    ,null				        ,"ion-headphone"	, -1, -1, false, showInMenuAct);
		addItem("Case"					                   , "Customer_Service"    , "Cases"			                        , "app/customerServiceCase" ,null			, -1, -1, false, showInMenuAct);
		addItem("NegativReview"		                       , "Customer_Service"    , "Negative Reviews"		                    , "app/review/index.html?negative=1"	            ,null			, -1, -1, false, showInMenuAct);
		addItem("Channel_Configuration"		               , "#"		  	       , "Channel Configuration"		            ,null				        ,"ion-network"	, -1, -1, false, showInMenuAct);
		
		addItem("Messaging"					, "#"		   		 	, "Messaging"			   		, "app/msg/messaging/index.html"		,"ion-paper-airplane"	, 900, 550, false, showInMenuAct);
		addItem("Contact"				, "#"		   		 , "Contacts"			   		, "core/page/contact/index.html"		,"ion-android-contacts"	, -1, -1, false, showInMenuAct);
		addItem("UserManagment"			                   , "#"			       , "User Managment"			                , null				        ,"ion-person-stalker"			, -1, -1, false, showInMenuAct);
		if(userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID) {
			addItem("Action"			, "UserManagment"			, "Action"					, "core/page/action"				, null		, -1, -1, false, showInMenuAct);
			addItem("UseCase"			, "UserManagment"			, "Usecase"					, "core/page/usecase"				, null		, -1, -1, false, showInMenuAct);
			addItem("AccessGroup"		, "UserManagment"			, "Access group"			, "core/page/accessgrp"				, null		, -1, -1, false, showInMenuAct);
			addItem("Role"				, "UserManagment"			, "Role"					, "core/page/role"					, null		, -1, -1, false, showInMenuAct);
		}
		addItem("User"					, "UserManagment"			, "User"			  		, "core/masterdetail.html?urlPath=/core/page/user/index.html&isMaster=1"
				, null				, -1, -1 ,false, showInMenuAct);

		
		addItem("Settings"				, "#"		          , "Settings"				    , null				    ,"ion-settings"		, -1, -1, false, showInMenuAct);
		addItem("Location"				, "Settings"	      , "Location"				    , "core/page/location"	,null				, -1, -1, false, showInMenuAct);
		addItem("ComboVal"				, "Settings"	      , "Combo values"				, "core/page/comboval"	,null		    , -1, -1, false, showInMenuAct);
		addItem("ChangePassword"		, "Settings"          , "Change Password"		    , "ui/change_pass.html"	,null			, 400, 300, false, showInMenuAct);
		addItem("Brand"		            , "Settings"          , "Brand"		                , "bse/brand"	        ,null			, -1, -1, false, showInMenuAct);
		addItem("Currency"		        , "Settings"          , "Currency"		            , "bse/currency"	    ,null			, -1, -1, false, showInMenuAct);
		addItem("Tax"		            , "Settings"          , "Tax"		                , "bse/tax"	            ,null			, -1, -1, false, showInMenuAct);
		addItem("Category"		        , "Settings"          , "Category"		            , "bse/category"	    ,null			, -1, -1, false, showInMenuAct);
		addItem("Channelintegration"	, "Settings"          , "Channel Integration"		, "bse/channelintegration"	    ,null			, -1, -1, false, showInMenuAct);
		addItem("Site"			        , "Settings"          , "Site"		                , "bse/site"	        ,null			, -1, -1, false, showInMenuAct);
		addItem("Company"			    , "Settings"          , "Company"		            , "bse/company"	      ,null			, -1, -1, false, showInMenuAct);
		addItem("ProductProblem"	     , "Settings"          , "Product problem"		    , "bse/productProblem",null			, -1, -1, false, showInMenuAct);
		menuData.append("}");
		menuTree.append("]");

		menuTreeCache.put(userInfo.getRoleId(), menuTree.toString());
		menuDataCache.put(userInfo.getRoleId(), menuData.toString());
	}

	private void addItem(String usecase, String parentUC, String title, String path, String icon, int width, int height, boolean createNew, int actionToCheck) {
		if(!hasAccess(usecase, actionToCheck))
			return;
		if(menuTree.length() > 1){
			menuTree.append(",");
			menuData.append(",");
		}

		menuTree.append("{ \"id\" : \"").append(usecase).append("\", \"parent\" : \"")
			.append(parentUC).append("\", \"text\" : \"").append(title).append("\"")
			.append(",\"icon\": \"").append(icon != null ? icon : "none").append("\"");
		if (path != null)
			menuTree.append(",\"li_attr\": {\"data-name\": \"").append(usecase).append("\"}");

		menuTree.append(" }");

		//return such this:    "CUSTOMER": {"EN": "customer", "FA": "Ù�Ø±ÙˆØ´Ù†Ø¯Ú¯Ø§Ù†", "COUNT": "0", "PATH":"app/merchant", "WIDTH": "-1", "HEIGHT": "-1", "CREATE_NEW": "true"}
		menuData.append("\"").append(usecase).append("\": {\"EN\": \"").append(usecase).append("\", \"FA\": \"").append(title)
			.append("\", \"COUNT\": 0, \"PATH\":\"").append(path).append("\", \"WIDTH\": \"").append(width)
			.append("\", \"HEIGHT\": \"").append(height).append("\", \"CREATE_NEW\": ").append(createNew).append("}");
	}


	@Override
	public String getMenuData() {
		return menuData.toString();
	}

	@Override
	public String getMenuTree() {
		return menuTree.toString();
	}

	private boolean hasAccess(String userCase, int action){
		if(!SystemConfig.CHECK_ACCESSES || userInfo.getRoleId() == SystemConfig.SYS_ADMIN_ROLE_ID || userInfo.getRoleId() == SystemConfig.SYSTEM_ROLE_ID)
			return true;
		Integer acs = access.get(userCase);
		int p =(int) Math.pow(2, action);
		return acs != null && (acs.intValue() | p) == acs;
	}
	
}
