package org.mega.order.order;


import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseDTO;

public class OrderDTO extends BaseDTO{

	private long rowId;
	private String channelOrderIdDTO;
	private String sellerOrderIdDTO;
	private String purchaseDateDTO;
	private String lastUpdateDateDTO;
	private String orderStatusDTO;
	private SiteDTO siteDTO;
	private String buyerEmailDTO;
	private String buyerNameDTO;
	private String buyerIdDTO;
	private String orderTypeDTO;
	private String earliestDeliveryDateDTO;
	private String latestDeliveryDateDTO;
	
	public Long getRowId() {
		return rowId;
	}
	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	public String getChannelOrderIdDTO() {
		return channelOrderIdDTO;
	}
	public void setChannelOrderIdDTO(String channelOrderIdDTO) {
		this.channelOrderIdDTO = channelOrderIdDTO;
	}
	public String getSellerOrderIdDTO() {
		return sellerOrderIdDTO;
	}
	public void setSellerOrderIdDTO(String sellerOrderIdDTO) {
		this.sellerOrderIdDTO = sellerOrderIdDTO;
	}
	public String getPurchaseDateDTO() {
		return purchaseDateDTO;
	}
	public void setPurchaseDateDTO(String purchaseDateDTO) {
		this.purchaseDateDTO = purchaseDateDTO;
	}
	public String getLastUpdateDateDTO() {
		return lastUpdateDateDTO;
	}
	public void setLastUpdateDateDTO(String lastUpdateDateDTO) {
		this.lastUpdateDateDTO = lastUpdateDateDTO;
	}
	public String getOrderStatusDTO() {
		return orderStatusDTO;
	}
	public void setOrderStatusDTO(String orderStatusDTO) {
		this.orderStatusDTO = orderStatusDTO;
	}
	public SiteDTO getSiteDTO() {
		return siteDTO;
	}
	public void setSiteDTO(SiteDTO siteDTO) {
		this.siteDTO = siteDTO;
	}
	public String getBuyerEmailDTO() {
		return buyerEmailDTO;
	}
	public void setBuyerEmailDTO(String buyerEmailDTO) {
		this.buyerEmailDTO = buyerEmailDTO;
	}
	public String getBuyerNameDTO() {
		return buyerNameDTO;
	}
	public void setBuyerNameDTO(String buyerNameDTO) {
		this.buyerNameDTO = buyerNameDTO;
	}
	public String getBuyerIdDTO() {
		return buyerIdDTO;
	}
	public void setBuyerIdDTO(String buyerIdDTO) {
		this.buyerIdDTO = buyerIdDTO;
	}
	public String getOrderTypeDTO() {
		return orderTypeDTO;
	}
	public void setOrderTypeDTO(String orderTypeDTO) {
		this.orderTypeDTO = orderTypeDTO;
	}
	public String getEarliestDeliveryDateDTO() {
		return earliestDeliveryDateDTO;
	}
	public void setEarliestDeliveryDateDTO(String earliestDeliveryDateDTO) {
		this.earliestDeliveryDateDTO = earliestDeliveryDateDTO;
	}
	public String getLatestDeliveryDateDTO() {
		return latestDeliveryDateDTO;
	}
	public void setLatestDeliveryDateDTO(String latestDeliveryDateDTO) {
		this.latestDeliveryDateDTO = latestDeliveryDateDTO;
	}
	
}
