package org.mega.order.orderitem;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.bse.currency.Currency;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.order.order.Order;
import org.mega.product.channelsku.ProductChannelSKU;

@Entity
@Table(name="ORDER_ORDER_ITEM", uniqueConstraints = @UniqueConstraint(name = "PK_ORDER_ORDER_ITEM", columnNames = "ROW_ID"))
public class OrderItem extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ROW_ID")
	private long rowId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ORDER_ID", foreignKey = @ForeignKey(name = "FK_ORDER_ITEM_ORDER") , nullable = true)
	private Order order;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CHANNEL_SKU_ID", foreignKey = @ForeignKey(name = "FK_ORDER_ITEM_CHANNEL") , nullable = true)
	private ProductChannelSKU productChannelSKU;

	@Column(name = "CHANNEL_ORDER_ITEM_ID")
	private String channelOrderItemId;
	
	@Column(name = "CHANNEL_SKU")
	private String channelSKU;
	
	@Column(name = "QUANTITY_SHIPPED")
	private int quantityShipped;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CURRENCY_ID", foreignKey = @ForeignKey(name = "FK_ORDER_ITEM_CURRENCY") , nullable = true)
	private Currency currency;

	@Column(name = "Quantity")
	private double quantity;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TAX_CURRENCY_ID", foreignKey = @ForeignKey(name = "FK_ORDER_ITEM_TAX_CURRENCY") , nullable = true)
	private Currency taxCurrency;
	
	@Column(name = "TAXT_AMOUNT")
	private double taxtAmount;
	
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getChannelSKU() {
		return channelSKU;
	}

	public void setChannelSKU(String channelSKU) {
		this.channelSKU = channelSKU;
	}

	public String getChannelOrderItemId() {
		return channelOrderItemId;
	}

	public void setChannelOrderItemId(String channelOrderItemId) {
		this.channelOrderItemId = channelOrderItemId;
	}

	public int getQuantityShipped() {
		return quantityShipped;
	}

	public void setQuantityShipped(int quantityShipped) {
		this.quantityShipped = quantityShipped;
	}


	public void setRowId(long rowId) {
		this.rowId = rowId;
	}
	
	@Override
	public Long getRowId() {
		return rowId;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public Currency getTaxCurrency() {
		return taxCurrency;
	}

	public void setTaxCurrency(Currency taxCurrency) {
		this.taxCurrency = taxCurrency;
	}

	public double getTaxtAmount() {
		return taxtAmount;
	}

	public void setTaxtAmount(double taxtAmount) {
		this.taxtAmount = taxtAmount;
	}
	
	public ProductChannelSKU getProductChannelSKU() {
		return productChannelSKU;
	}

	public void setProductChannelSKU(ProductChannelSKU productChannelSKU) {
		this.productChannelSKU = productChannelSKU;
	}

	@Override
	public void prePersist() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = channelOrderItemId;		
	}

	@Override
	public void preUpdate() throws Exception {
	      rowId = IDGenerator.genId(this);
	      fullTitle = channelOrderItemId;		
	}

}
