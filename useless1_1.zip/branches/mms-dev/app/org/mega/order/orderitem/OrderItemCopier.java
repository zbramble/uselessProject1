package org.mega.order.orderitem;



import org.mega.bse.currency.Currency;
import org.mega.bse.currency.CurrencyDTO;
import org.mega.bse.site.SiteDTO;
import org.mega.core.base.BaseCopier;
import org.mega.order.order.Order;
import org.mega.order.order.OrderDTO;
import org.mega.product.channelsku.ProductChannelSKU;
import org.mega.product.channelsku.ProductChannelSKUDTO;
import org.mega.util.DateUtil;

public class OrderItemCopier extends BaseCopier<OrderItem, OrderItemDTO>{

	@Override
	public OrderItemDTO copyFromEntity(OrderItem orderItem) {
		OrderItemDTO orderItemDTO = new OrderItemDTO();
		orderItemDTO.setRowId(orderItem.getRowId());
		if(orderItem.getOrder() != null){
			OrderDTO orderDTO = new OrderDTO();
			orderDTO.setRowId(orderItem.getOrder().getRowId());
			orderDTO.setChannelOrderIdDTO(orderItem.getOrder().getChannelOrderId());
			orderDTO.setPurchaseDateDTO(DateUtil.getDateString(orderItem.getOrder().getPurchaseDate(), "en"));
			orderDTO.setBuyerNameDTO(orderItem.getOrder().getBuyerName());
			//System.out.println(orderItem.getOrder().getSite().getSiteName());
			SiteDTO siteDTO = new SiteDTO();
			if(orderItem.getOrder().getSite() != null){
				siteDTO.setRowId(orderItem.getOrder().getSite().getRowId());
				siteDTO.setSiteName(orderItem.getOrder().getSite().getSiteName());
				orderDTO.setSiteDTO(siteDTO);
			}
			orderDTO.setBuyerIdDTO(orderItem.getOrder().getBuyerId());
			orderDTO.setBuyerEmailDTO(orderItem.getOrder().getBuyerEmail());
			orderDTO.setOrderStatusDTO(orderItem.getOrder().getOrderStatus());
			orderDTO.setOrderTypeDTO(orderItem.getOrder().getOrderType());
			orderItemDTO.setOrderDTO(orderDTO);
		}
		if(orderItem.getProductChannelSKU() != null){
			ProductChannelSKUDTO productChannelSKUDTO = new ProductChannelSKUDTO();
			productChannelSKUDTO.setRowId(orderItem.getProductChannelSKU().getRowId());
			productChannelSKUDTO.setFullTitle(orderItem.getProductChannelSKU().getFullTitle());
			productChannelSKUDTO.setAccessKey(orderItem.getProductChannelSKU().getAccessKey());
			orderItemDTO.setProductChannelSKUDTO(productChannelSKUDTO);
		}
		orderItemDTO.setChannelOrderItemIdDTO(orderItem.getChannelOrderItemId());
		orderItemDTO.setQuantityShippedDTO(orderItem.getQuantityShipped());
		if(orderItem.getCurrency() != null){
			CurrencyDTO currencyDTO = new CurrencyDTO();
			currencyDTO.setRowId(orderItem.getCurrency().getRowId());
			currencyDTO.setTitle(orderItem.getCurrency().getTitle());
			orderItemDTO.setCurrencyDTO(currencyDTO);
		}
		orderItemDTO.setQuantityDTO(orderItem.getQuantity());
		if(orderItem.getTaxCurrency() != null){
			CurrencyDTO currencyDTO = new CurrencyDTO();
			currencyDTO.setRowId(orderItem.getTaxCurrency().getRowId());
			currencyDTO.setTitle(orderItem.getTaxCurrency().getTitle());
			orderItemDTO.setTaxCurrencyDTO(currencyDTO);
		}
		orderItemDTO.setTaxtAmountDTO(orderItem.getTaxtAmount());
		orderItemDTO.setChannelSKUDTO(orderItem.getChannelSKU());
		copyFromEntityBaseField(orderItem, orderItemDTO);
		return orderItemDTO;
	}

	@Override
	public OrderItem copyToEntity(OrderItemDTO orderItemDTO) throws Exception {
		OrderItem orderItem = new OrderItem();
		//*********
		orderItem.setRowId(orderItemDTO.getRowId());
		if(orderItemDTO.getOrderDTO() != null){
			Order order = new Order();
			order.setRowId(orderItemDTO.getOrderDTO().getRowId());
			orderItem.setOrder(order);
		}
		if(orderItemDTO.getProductChannelSKUDTO() != null){
			ProductChannelSKU productChannelSKU = new ProductChannelSKU();
			productChannelSKU.setRowId(orderItemDTO.getProductChannelSKUDTO().getRowId());
			orderItem.setProductChannelSKU(productChannelSKU);
		}
		orderItem.setChannelOrderItemId(orderItemDTO.getChannelOrderItemIdDTO());
		orderItem.setQuantityShipped(orderItemDTO.getQuantityShippedDTO());
		if(orderItemDTO.getCurrencyDTO() != null){
			Currency currency = new Currency();
			currency.setRowId(orderItemDTO.getCurrencyDTO().getRowId());
			orderItem.setCurrency(currency);
		}
		orderItem.setQuantity(orderItemDTO.getQuantityDTO());
		if(orderItemDTO.getTaxCurrencyDTO() != null){
			Currency currency = new Currency();
			currency.setRowId(orderItemDTO.getTaxCurrencyDTO().getRowId());
			orderItem.setTaxCurrency(currency);
		}
		orderItem.setTaxtAmount(orderItemDTO.getTaxtAmountDTO());
		orderItem.setChannelSKU(orderItemDTO.getChannelSKUDTO());
		//*********
		copyToEntityBaseField(orderItem, orderItemDTO);
		return orderItem;
	}

}
