package org.mega.util;

import javax.persistence.PersistenceException;

import org.hibernate.exception.ConstraintViolationException;
import org.mega.core.base.ServiceResult.ERROR_CODE;

public class ExceptionUtil {

	public static String getMessage(Exception e) {
		if(e instanceof ConstraintViolationException)
			return "Request failed. First delete related data.";
		if(e instanceof PersistenceException || (e.getCause() != null && e.getCause() instanceof PersistenceException))
			return "Duplicate data, Request failed";
		if(e.getMessage().indexOf("Access denied") > -1)
			return "You dont access to this action";

		if(e.getCause() != null && e.getCause().getMessage().startsWith("not-null"))
			return "Complete mandatory fields";
		else
			return "Error";
	}

	public static ERROR_CODE getErrorCode(ERROR_CODE errorCode, Exception e) {
		if(e instanceof ConstraintViolationException)
			return ERROR_CODE.CONSTRAINT_VIOLATION;
		if(e instanceof PersistenceException || (e.getCause() != null && e.getCause() instanceof PersistenceException))
			return ERROR_CODE.DUPLICATE;
		if(e.getMessage().indexOf("Access denied") > -1)
			return ERROR_CODE.ACCESS_DENIED;
		if(e.getCause() != null && (e.getCause().getMessage().startsWith("not-null")))
			return ERROR_CODE.IS_NULL;
		return errorCode;
	}

}
