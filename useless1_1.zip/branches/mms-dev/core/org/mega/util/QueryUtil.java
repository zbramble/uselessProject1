package org.mega.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.mega.core.base.BaseLogger;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.PairValue.CONDITION;

public class QueryUtil {

    public enum QUERY_TYPE {
        SELECT,
        DELETE,
        UPDATE,
        WHERE_ONLY
    }

    public static String genQuery(Class<?> EntityClass, Filter filter)
            throws NoSuchFieldException, SecurityException {

        return genQuery(EntityClass, filter, QUERY_TYPE.SELECT);
    }

    public static String genQuery(Class<?> EntityClass, Filter filter, QUERY_TYPE queryType)
            throws NoSuchFieldException, SecurityException {

        return genQuery(EntityClass, filter, queryType, null);
    }

    /**
     * @param entityClass
     * @param filter
     * @param queryType   QueryType:{SELECT,DELETE...}
     *                    WHERE_ONLY: فقط شرط را درست می کند و کاری با کلاس ندارد برای کویری نیتیو مناسب اسب در این صورت کلاس موجودیت می تواند نال باشد
     * @param constraint
     * @return
     * @throws NoSuchFieldException
     * @throws SecurityException
     */
    public static String genQuery(Class<?> entityClass, Filter filter, QUERY_TYPE queryType, String constraint) {

        StringBuilder whereClause = getWhereClause(filter, constraint);

        String result = "";
        switch (queryType) {
            case WHERE_ONLY:
                result = whereClause.toString();
                break;
            case SELECT:
                result = "SELECT e FROM " + entityClass.getSimpleName() + " e " + whereClause.toString() +
                        (whereClause.length() > 0 ? " AND " : " WHERE ") +
                        " e.deleted = 0 " + getOrderByClause(filter);
                break;
            case UPDATE:
                result = "";
                break;
            case DELETE:
                result = "UPDATE " + entityClass.getSimpleName() + " e SET e.deleted = e.rowId , " +
                        "e.updated = sysdate " + whereClause.toString();
        }

        BaseLogger.getLogger().debug("EJBQL for list:" + result);
        return result;
    }

    public static StringBuilder getWhereClause(Filter filter, String constraint) {
        StringBuilder whereClause = new StringBuilder();

        if (filter != null) {
            List<PairValue> filters = filter.getParams().stream()
                    .filter(pairValue -> pairValue.getCondition() != CONDITION.NAN
                            && pairValue.getCondition() != CONDITION.ORDER
                            && !pairValue.getValue().isEmpty()).collect(Collectors.toList());

            for (PairValue pairValue : filters) {
                whereClause = whereClause.length() > 0 ? whereClause.append(" and ") : whereClause;

                switch (pairValue.getCondition()) {
                    case CONTAINS:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" like '%")
                                .append(pairValue.getValue()).append("%'");
                        break;
                    case START_WITH:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" like '%")
                                .append(pairValue.getValue()).append("'");
                        break;
                    case END_WITH:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" like '")
                                .append(pairValue.getValue()).append("%'");
                        break;
                    case IN:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" in (")
                                .append(pairValue.getValue()).append(")");
                        break;
                    case NOT_IN:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" not in (")
                                .append(pairValue.getValue()).append(")");
                        break;
                    case NOT_EQUAL:
                        whereClause.append(" e.").append(pairValue.getKey()).append("<>'")
                                .append(pairValue.getValue()).append("'");
                        break;
                    case IS_NULL:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" IS NULl");
                        break;
                    case WHERE:
                        whereClause.append(pairValue.getValue());
                        break;
                    case LESS:
                        whereClause.append(" e.").append(pairValue.getKey()).append(" < " + pairValue.getValue());
                    	break;
                    case LESS_OR_EQUAL:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" <= " + pairValue.getValue());
                    	break;
                    case GREATER:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" > " + pairValue.getValue());
                    	break;
                    case GREATER_OR_EQUAL:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" >= " + pairValue.getValue());
                    	break;
                    case FROM_DATE:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" >= TO_Date('" + pairValue.getValue() +"','YYYY/MM/DD')");
                    	break;
                    case TO_DATE:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" <= TO_Date('" + pairValue.getValue() +"','YYYY/MM/DD')");
                    	break;
                    case FROM_TIME:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" >= TO_Date('" + pairValue.getValue() +"','YYYY/MM/DD hh24:mi:ss')");
                    	break;
                    case TO_TIME:
                    	whereClause.append(" e.").append(pairValue.getKey()).append(" <= TO_Date('" + pairValue.getValue() +"','YYYY/MM/DD hh24:mi:ss')");
                    	break;
                    case BOOLEAN_EQUAL:
                    	 whereClause.append(" e.").append(pairValue.getKey()).append("=")
                         	.append(pairValue.getValue());
                    	break;
                    case EQUAL:
                    default:
                        whereClause.append(" e.").append(pairValue.getKey()).append("='")
                                .append(pairValue.getValue()).append("'");
                        break;
                }
            }
        }

        if (constraint != null) {
            if (whereClause.length() > 0) {
                whereClause.append(" AND ");
            }
            whereClause.append(" (").append(constraint).append(") ");
        }

        if (whereClause.length() > 0) {
            whereClause.insert(0, " WHERE ");
        }

        return whereClause;
    }

    public static String getOrderByClause(Filter filter) {
        StringBuilder OrderByClause = new StringBuilder();

        if (filter != null) {
            List<PairValue> filters = filter.getParams().stream()
                    .filter(pairValue -> pairValue.getCondition() == CONDITION.ORDER
                            && !pairValue.getValue().isEmpty()).collect(Collectors.toList());

            for (PairValue pairValue : filters) {
                OrderByClause = OrderByClause.length() > 0 ? OrderByClause.append(" , ") : OrderByClause;
                OrderByClause.append(" e.").append(pairValue.getValue());
            }
        }

        if (OrderByClause.length() == 0) {
            OrderByClause.insert(0, " ORDER BY e.created DESC");
        } else {
            OrderByClause.insert(0, " ORDER BY ");
        }
        return OrderByClause.toString();
    }

    public static Connection getConnection() {

        Connection connection = null;
        try {
            InitialContext ic = new InitialContext();
            Context xmlContext = (Context) ic.lookup("java:comp/env");
            DataSource myDatasource = (DataSource) xmlContext.lookup("jdbc/ntnet_db");
            connection = myDatasource.getConnection();
        } catch (NamingException | SQLException e) {
            System.out.println(e.getMessage());
        }

        return connection;
    }
}