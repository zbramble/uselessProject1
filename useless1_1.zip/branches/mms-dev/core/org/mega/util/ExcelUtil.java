package org.mega.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import org.mega.core.base.ServiceResult;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class ExcelUtil {

    public static byte[] toExcel(ServiceResult result, String[] header, String title) throws IOException, RowsExceededException, WriteException {
        return toExcel((List<Object[]>)result.getResult(), header, title);
    }
   
    public static byte[] toExcel(List<Object[]> content, String[] header, String title) throws IOException, RowsExceededException, WriteException {
    	
    	ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    	WritableWorkbook workbook = Workbook.createWorkbook(outputStream);
    	WritableSheet sheet = workbook.createSheet(title, 0);
    	int j = 0;
    	for (int i = 0; i < content.size(); i++) {
    		j = 0;
    		if(!(content.get(i) instanceof Object[]))
    				continue;
    		Object[] row = (Object[]) content.get(i);
    		for (Object s : row) {
    			Label label;
    			if (row[j] instanceof BigDecimal)
    				label = new Label(j, i, ((BigDecimal) row[j]).toString());
    			else if (row[j] instanceof Timestamp)
    				label = new Label(j, i, ((Timestamp) row[j]).toLocaleString());
    			else
    				label = new Label(j, i, (String) row[j]);
    			sheet.addCell(label);
    			System.out.print(label.getContents() + "\t");
    			j++;
    		}
    		System.out.println();
    	}
    	
    	workbook.write();
    	workbook.close();
    	return outputStream.toByteArray();
    	
    }
}
