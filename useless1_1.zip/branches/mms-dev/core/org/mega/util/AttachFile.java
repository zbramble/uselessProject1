package org.mega.util;

public class AttachFile {
	byte[] content;
	String name;
	String mime;

	private AttachFile() {
	}

	public AttachFile(byte[] content, String name, String mime) {
		this.name = name;
		this.content = content;
		this.mime = mime;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMime() {
		return mime;
	}

	public void setMime(String mime) {
		this.mime = mime;
	}
	
	
}
