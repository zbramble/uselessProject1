package org.mega.core.log;

import org.mega.core.base.BaseCopier;

public class LogCopier extends BaseCopier<Log, LogDTO> {
    @Override
    public LogDTO copyFromEntity(Log log) {
        LogDTO logDTO = new LogDTO();

        logDTO.setRowId(log.getRowId());
        logDTO.setEntityName(log.getEntityName());
        logDTO.setTableRowId(log.getTableRowId());
        logDTO.setAction(log.getAction());
        logDTO.setDescription(log.getDescription());
        copyFromEntityBaseField(log, logDTO);

        return logDTO;
    }

    @Override
    public Log copyToEntity(LogDTO logDTO) throws Exception {
        return new Log();
    }
}