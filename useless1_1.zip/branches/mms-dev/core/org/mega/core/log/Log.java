package org.mega.core.log;

import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.user.User;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "CO_LOG", uniqueConstraints = @UniqueConstraint(name = "PK_CO_LOG", columnNames = "ID"))
public class Log extends BaseEntity {
    @Id
    @Column(name = "ID")
    private Long rowId;

    @Column(name = "ENTITY_NAME", length = 35)
    private String entityName;

    @Column(name = "TABLE_ROW_ID")
    private Long tableRowId;

    @Column(name = "ACTION")
    @Enumerated(EnumType.STRING)
    private ACTION action;

    @Column(name = "DESCRIPTION", length = 4000)
    private String description;

    public Log() {
    }

    public Log(String entityName, Long tableRowId, User changedBy) {
        this.entityName = entityName;
        this.tableRowId = tableRowId;
        this.setCreatedBy(changedBy);
        this.setUpdatedBy(changedBy);
    }

    public Log(String entityName, Long tableRowId, ACTION action, User changedBy, String description) {
        this.entityName = entityName;
        this.tableRowId = tableRowId;
        this.action = action;
        this.setCreatedBy(changedBy);
        this.setUpdatedBy(changedBy);
        this.description = description;
    }

    @Override
    public Long getRowId() {
        return rowId;
    }

    public void setRowId(Long rowId) {
        this.rowId = rowId;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public Long getTableRowId() {
        return tableRowId;
    }

    public void setTableRowId(Long tableRowId) {
        this.tableRowId = tableRowId;
    }

    public ACTION getAction() {
        return action;
    }

    public void setAction(ACTION action) {
        this.action = action;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    @PrePersist
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        setCreated(new Date(System.currentTimeMillis()));
        setUpdated(new Date(System.currentTimeMillis()));
        setActive(true);
    }

    @Override
    public void preUpdate() throws Exception {

    }

    @Override
    public String toString() {
        return "Log{" +
                "rowId=" + rowId +
                ", entityName='" + entityName + '\'' +
                ", tableRowId=" + tableRowId +
                ", action=" + action +
                ", description='" + description + '\'' +
                '}';
    }
}