package org.mega.core.log;

import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseDTO;

public class LogDTO extends BaseDTO {
    private long rowId;
    private String entityName;
    private long tableRowId;
    private ACTION action;
    private String description;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public long getTableRowId() {
        return tableRowId;
    }

    public void setTableRowId(long tableRowId) {
        this.tableRowId = tableRowId;
    }

    public ACTION getAction() {
        return action;
    }

    public void setAction(ACTION action) {
        this.action = action;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}