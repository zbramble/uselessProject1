package org.mega.core.log;

import java.util.Date;

import javax.persistence.Query;

import org.mega.core.action.ActionDTO;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.Filter;
import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;
import org.mega.util.BeanUtil;
import org.mega.util.DateUtil;

public class LogFacade extends BaseFacade {
    private static LogFacade facade = new LogFacade();
    private static LogCopier copier = new LogCopier();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static LogFacade getInstance() {
        return facade;
    }

    public void logger(Log log) {
        super.logger(log);
    }

    public ServiceResult lastLogin(BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);
        Filter filter = businessParam.getFilter();
        if (filter == null) {
            return new ServiceResult(ServiceResult.ERROR_CODE.IS_NULL, "filter is null", "");
        }

        try {
            BaseDB db = businessParam.getDB();
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ActionDTO.ACTION.search);
            //UserSessionManager.checkAccess(filter.getTicket(), entityClass.getSimpleName(), UserSession.ACTION.search);

            Query query = db.createNativeQuery(" select max(CREATEd)" +
                    "  from CO_LOG" +
                    " where ACTION = 'login'" +
                    "   and DESCRIPTION = 'Successful'" +
                    "   and CREATED_BY in (select U.USER_ID as id" +
                    "                        from co_user u" +
                    "                        left JOIN CO_PERSON p" +
                    "                          on u.person_id = p.person_id" +
                    "                        left join stu_student s" +
                    "                          on p.person_id = s.person_id" +
                    "                       where s.STUDENT_ID = ?)");
            query.setFirstResult((filter.getPageNo() - 1) * filter.getPageSize());
            query.setMaxResults(filter.getPageSize());
            PairValue pairValue = filter.getParams().get(0);
            String id = pairValue.getValue();
            query.setParameter(1, id);
            Date result = (Date) query.getSingleResult();
            String lastLogin = DateUtil.getDateString(result, "fa");

            businessParam.releaseDB();
            return new ServiceResult(lastLogin, 0);
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error getList " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error getList LocationDTO", e);
        }
    }
}