package org.mega.core.user;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;
import org.mega.core.file.File;
import org.mega.core.person.Person;
import org.mega.core.userrole.UserRole;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "CO_USER", uniqueConstraints = {@UniqueConstraint(name = "PK_CO_USER", columnNames = "USER_ID"),
        @UniqueConstraint(name = "UK_USER_USERNAME", columnNames = "USERNAME")})
public class User extends BaseEntity {
    @Id
    @Column(name = "USER_ID")
    private long rowId;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "PERSON_ID", foreignKey = @ForeignKey(name = "FK_USER_2__PERSON__PERSON_ID"))
    private Person person;

    @Column(name = "FULL_NAME", nullable = false, length = 50)
    private String fullName;

    @Column(name = "COMPANY_NAME", nullable = false, length = 50)
    private String companyName;

    @OneToMany(mappedBy = "user")
    private List<UserRole> userRoles;

    @Column(name = "USERNAME", nullable = false, length = 30)
    private String username;

    @Column(name = "ACCESS_KEY", nullable = false, length = 30, updatable = false)
    private String accessKey;

    @Column(name = "USER_PASSWORD", nullable = false, length = 100, updatable = false)
    private String userPassword;

    @Column(name = "EMAIL", length = 100)
    private String email;

    @Column(name = "email_is_confirmed")
    private boolean emailIsConfirmed;

    @Column(name = "FAILED_LOGIN")
    Integer failedLogin = 0;

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "FILE_ID", nullable = true, foreignKey = @ForeignKey(name = "FK_USER_REF_FILE"))
    private File file;

    public Integer getFailedLogin() {
        return failedLogin;
    }

    public void setFailedLogin(Integer failedLogin) {
        this.failedLogin = failedLogin;
    }

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public List<UserRole> getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(List<UserRole> userRoles) {
        this.userRoles = userRoles;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEmailIsConfirmed() {
        return emailIsConfirmed;
    }

    public void setEmailIsConfirmed(boolean emailIsConfirmed) {
        this.emailIsConfirmed = emailIsConfirmed;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = fullName + "(" + username + ")";
    }

    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
        fullTitle = fullName + "(" + username + ")";
    }
}