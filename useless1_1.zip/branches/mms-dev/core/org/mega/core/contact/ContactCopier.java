package org.mega.core.contact;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;
import org.mega.core.location.Location;
import org.mega.core.location.LocationDTO;
import org.mega.core.organization.Organization;
import org.mega.core.organization.OrganizationDTO;
import org.mega.core.person.Person;
import org.mega.core.person.PersonDTO;
import org.mega.core.user.User;
import org.mega.core.user.UserDTO;


public class ContactCopier extends BaseCopier<Contact, ContactDTO> {
    @Override
    public ContactDTO copyFromEntity(Contact contact) {
        ContactDTO contactDTO = new ContactDTO();

        contactDTO.setRowId(contact.getRowId());
        if (contact.getType() != null) {
            ComboValDTO typeDTO = new ComboValDTO();
            typeDTO.setRowId(contact.getType().getRowId());
            typeDTO.setName(contact.getType().getName());
            contactDTO.setType(typeDTO);
        }
        if (contact.getPerson() != null) {
            PersonDTO personDTO = new PersonDTO();
            personDTO.setRowId(contact.getPerson().getRowId());
            personDTO.setFullTitle(contact.getPerson().getFullTitle());
            personDTO.setFirstName(contact.getPerson().getFirstName());
            personDTO.setLastName(contact.getPerson().getLastName());
            contactDTO.setPerson(personDTO);
        }
        if (contact.getOrganization() != null) {
            OrganizationDTO organizationDTO = new OrganizationDTO();
            organizationDTO.setRowId(contact.getOrganization().getRowId());
            organizationDTO.setName(contact.getOrganization().getName());
            contactDTO.setOrganization(organizationDTO);
        }
        if (contact.getUser() != null) {
            UserDTO userDTO = new UserDTO();
            userDTO.setRowId(contact.getUser().getRowId());
            userDTO.setUsername(contact.getUser().getUsername());
            /*if (OnlineUserManager.getInstance().isOnline(contact.getUser().getRowId())) {
                userDTO.setStatus(UserStatus.ONLINE);
            } else {
                userDTO.setStatus(UserStatus.OFFLINE);
            }*/
            contactDTO.setUser(userDTO);
        }
        if (contact.getGender() != null) {
            ComboValDTO genderDTO = new ComboValDTO();
            genderDTO.setRowId(contact.getGender().getRowId());
            genderDTO.setName(contact.getGender().getName());
            contactDTO.setGender(genderDTO);
        }
        contactDTO.setNameFamily(contact.getNameFamily());
        contactDTO.setPhone(contact.getPhone());
        contactDTO.setMobile(contact.getMobile());
        contactDTO.setPhoneSocialNetwork(contact.getPhoneSocialNetwork());
        contactDTO.setSocialNetwork(contact.getSocialNetwork());
        contactDTO.setAddressSocialNetwork(contact.getAddressSocialNetwork());

        if (contact.getState() != null) {
            LocationDTO stateDTO = new LocationDTO();
            stateDTO.setRowId(contact.getState().getRowId());
            stateDTO.setName(contact.getState().getName());
            contactDTO.setState(stateDTO);
        }
        if (contact.getCity() != null) {
            LocationDTO cityDTO = new LocationDTO();
            cityDTO.setRowId(contact.getCity().getRowId());
            cityDTO.setName(contact.getCity().getName());
            contactDTO.setCity(cityDTO);
        }

        contactDTO.setAddress(contact.getAddress());
        contactDTO.setPostalCode(contact.getPostalCode());
        contactDTO.setEmail(contact.getEmail());
        contactDTO.setNote(contact.getNote());

        copyFromEntityBaseField(contact, contactDTO);

        return contactDTO;
    }

    @Override
    public Contact copyToEntity(ContactDTO contactDTO) {
        Contact contact = new Contact();

        contact.setRowId(contactDTO.getRowId());
        if (contactDTO.getType() != null) {
            ComboVal type = new ComboVal();
            type.setRowId(contactDTO.getType().getRowId());
            contact.setType(type);
        }
        if (contactDTO.getPerson() != null) {
            Person person = new Person();
            person.setRowId(contactDTO.getPerson().getRowId());
            contact.setPerson(person);
        }
        if (contactDTO.getOrganization() != null) {
            Organization organization = new Organization();
            organization.setRowId(contactDTO.getOrganization().getRowId());
            contact.setOrganization(organization);
        }
        if (contactDTO.getUser() != null) {
            User user = new User();
            user.setRowId(contactDTO.getUser().getRowId());
            contact.setUser(user);
        }
        if (contactDTO.getGender() != null) {
            ComboVal gender = new ComboVal();
            gender.setRowId(contactDTO.getGender().getRowId());
            gender.setName(contactDTO.getGender().getName());
            contact.setGender(gender);
        }
        contact.setNameFamily(contactDTO.getNameFamily());
        contact.setPhone(contactDTO.getPhone());
        contact.setMobile(contactDTO.getMobile());
        contact.setPhoneSocialNetwork(contactDTO.getPhoneSocialNetwork());
        contact.setSocialNetwork(contactDTO.getSocialNetwork());

        if (contactDTO.getState() != null) {
            Location state = new Location();
            state.setRowId(contactDTO.getState().getRowId());
            contact.setState(state);
        }
        if (contactDTO.getCity() != null) {
            Location city = new Location();
            city.setRowId(contactDTO.getCity().getRowId());
            contact.setCity(city);
        }

        contact.setAddressSocialNetwork(contactDTO.getAddressSocialNetwork());
        contact.setPostalCode(contactDTO.getPostalCode());
        contact.setAddress(contactDTO.getAddress());
        contact.setEmail(contactDTO.getEmail());
        contact.setNote(contactDTO.getNote());

        copyToEntityBaseField(contact, contactDTO);

        return contact;
    }
}
