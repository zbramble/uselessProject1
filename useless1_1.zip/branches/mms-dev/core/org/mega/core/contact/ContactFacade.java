package org.mega.core.contact;

import java.util.List;

import javax.persistence.Query;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.core.user.User;
import org.mega.core.user.UserFacade;
import org.mega.util.QueryUtil;

public class ContactFacade extends BaseFacade {
    private static ContactFacade facade = new ContactFacade();
    private static ContactCopier copier = new ContactCopier();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static ContactFacade getInstance() {
        return facade;
    }

    /*public ServiceResult save(List<ContactDTO> masterContactDTO, MasterContactRelationDTO masterContactRelationDTO, BusinessParam businessParam) {
        ArrayList<Object> result = new ArrayList<>();
        for (int j = 0; j < masterContactDTO.size(); j++) {
            ServiceResult contactResult = super.save(masterContactDTO.get(j), businessParam);
            if (contactResult.isDone()) {
                ContactDTO contactDTO = new ContactDTO();
                contactDTO.setRowId((Long) contactResult.getResult());
                if (masterContactRelationDTO.getContactRelation().size() > 0) {
                    //masterContactRelationDTO.setContactRelation(new ArrayList<>());
                    masterContactRelationDTO.getContactRelation().get(j).setContact(contactDTO);
                }
                ServiceResult conRel = ContactRelationFacade.getInstance().save(masterContactRelationDTO.getContactRelation().get(j), businessParam);
                result.add(contactResult);
            }
        }*/

        /*ArrayList<Object> resultRelation = new ArrayList<>();
        try {
            for (int i = 0; i < masterContactRelationDTO.getContactRelation().size(); i++) {
                ServiceResult conRel = super.save(masterContactRelationDTO.getContactRelation().get(i), businessParam);
                if (conRel.isDone()) resultRelation.add(conRel);
            }
        } catch (Exception e) {
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving ", e);
        }*/
    //return new ServiceResult(result, result.size());
    //}

    /*public ServiceResult delete(BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);
        try {
            BaseDB db = businessParam.getDB();
            int result = db.runNativeQuery("delete from CO_CONTACT_RELATION where CONTACT_ID = " + businessParam.getFilter().getParams().get(0).getValue() + " or PARENT_ID = " + businessParam.getFilter().getParams().get(0).getValue());
            businessParam.releaseDB();
            super.delete(businessParam);
            return new ServiceResult("Deleted", result);
        } catch (Exception e) {
            businessParam.rolback();
            BaseLogger.getLogger().info("Error " + entityClass.getSimpleName() + " delete", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, "Error delete " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }*/


    public ServiceResult userList(BusinessParam businessParam) {
        long userId = businessParam.getUserSession().getUserInfo().getUserId();

        try {
            Query query = businessParam.getDB().createQuery(
                    "SELECT distinct e.user " +
                            "FROM Contact e " +
                            QueryUtil.getWhereClause(businessParam.getFilter()
                                    , " e.active = TRUE " +
                                            "AND e.deleted = 0 " +
                                            "AND e.user IS NOT NULL " +
                                            "AND e.createdBy.rowId = :userId " +
                                            (getConstraint(businessParam) != null ? "AND (" + getConstraint(businessParam) + ")" : "")));

            query.setParameter("userId", userId);
            query.setFirstResult((businessParam.getFilter().getPageNo() - 1) * businessParam.getFilter().getPageSize());
            query.setMaxResults(businessParam.getFilter().getPageSize());

            List<User> users = query.getResultList();
            ServiceResult serviceResult =
                    new ServiceResult(UserFacade.getInstance().getCopier().copyFromEntity(users), users.size());
            businessParam.releaseDB();
            return serviceResult;
        } catch (Exception e) {
            businessParam.rolback();
            return new ServiceResult(ServiceResult.ERROR_CODE.UNKNOWN, "Error fetching data", e);
        }
    }
}
