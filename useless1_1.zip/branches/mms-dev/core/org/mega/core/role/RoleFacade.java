package org.mega.core.role;

import java.util.List;

import org.hibernate.query.Query;
import org.mega.core.action.ActionDTO.ACTION;
import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseDB;
import org.mega.core.base.BaseFacade;
import org.mega.core.base.BaseLogger;
import org.mega.core.base.BusinessParam;
import org.mega.core.base.ServiceResult;
import org.mega.util.BeanUtil;

public class RoleFacade extends BaseFacade {
    static RoleCopier copier = new RoleCopier();
    private static RoleFacade facade = new RoleFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static RoleFacade getInstance() {
        return facade;
    }

    public ServiceResult manyToManySave(RoleDTO roleDTO,
                                        List<String> addItems,
                                        List<String> removeItems,
                                        BusinessParam businessParam) {
        Class<?> entityClass = BeanUtil.getEntityClass(this);

        try {
            businessParam.getUserSession().checkAccess(entityClass.getSimpleName(), ACTION.insert);

            ServiceResult resultSave = save(roleDTO, businessParam);
            BaseDB db = BaseDB.open(entityClass.getSimpleName() + "Facade.list");
            if (addItems != null && addItems.size() > 0) {
                for (int i = 0; i < addItems.size(); i++) {
                    String queryAddString = "INSERT INTO CO_ROLE_ACCESS_GRP T " +
                            "(T.ACCESS_GRP_ID,T.ROLE_ID) " +
                            "VALUES ( :accessGrpId, :roleId )";
                    Query queryAdd = (Query) db.createNativeQuery(queryAddString);
                    queryAdd.setParameter("accessGrpId", addItems.get(i));
                    queryAdd.setParameter("roleId", resultSave.getResult());
                    queryAdd.executeUpdate();
                }
            }
            if (removeItems != null && removeItems.size() > 0) {
                for (int i = 0; i < removeItems.size(); i++) {
                    String queryDeleteString = "DELETE FROM CO_ROLE_ACCESS_GRP t " +
                            "WHERE t.access_grp_id= :accessGrpId" +
                            " and t.role_id= :roleId";
                    Query queryDelete = (Query) db.createNativeQuery(queryDeleteString);
                    queryDelete.setParameter("accessGrpId", removeItems.get(i));
                    queryDelete.setParameter("roleId", resultSave.getResult());
                    queryDelete.executeUpdate();
                }
            }
            db.commitAndclose();
            return resultSave;
        } catch (Exception e) {
            BaseLogger.getLogger().info("Error saving " + entityClass.getSimpleName() + "DTO", e);
            return new ServiceResult(ServiceResult.ERROR_CODE.DB_GENERAL, "Error saving " + entityClass.getSimpleName(), e.getLocalizedMessage());
        }
    }
}