package org.mega.core.tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.mega.util.IOUtil;

public class RunQuery {
	public static void main(String[] args) {
		String sql = IOUtil.readFromFile("D:/workspace/mms/doc/create first/3-constraints.sql","utf-8");
		Connection conn = null;
		try{
//		String url = "jdbc:oracle:thin:@localhost:1521:xe";
//        conn = DriverManager.getConnection(url,"mbi","mbi##321");
		
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        conn = DriverManager.getConnection(url,"mms","mms");
        Statement stmt = conn.createStatement();
        int okCount=0,failCount=0;
        for(String s:sql.split(";")){
        	System.out.println(s);
        	try{
        		stmt.execute(s);
        		System.out.println("OK\n");
        		okCount++;
        	}catch (Exception e) {
        		System.out.println("Fail\n");
        		failCount++;
        	}
        }
        System.out.println("\nOK:" + okCount);
        System.out.println("\nFail:" + failCount);
        }catch (Exception e) {
        	e.printStackTrace();
        }finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}
}
