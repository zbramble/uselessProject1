package org.mega.core.file;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.mega.core.base.BaseEntity;
import org.mega.core.base.IDGenerator;

@Entity
@Table(name = "CO_FILE", uniqueConstraints = @UniqueConstraint(name = "PK_CO_File", columnNames = "ID"))
public class File extends BaseEntity {
    @Id
    @Column(name = "ID")
    private long rowId;

    @Column(name = "NAME", length = 100)
    private String name;

    @Column(name = "PATH", length = 100)
    private String path;

    @Column(name = "TITLE", length = 100)
    private String title;

    @Column(name = "USE_TITLE", length = 100)
    private String useTitle;

    @Column(name = "USE_ENTITY", length = 100)
    private String useEntity;

    @Column(name = "DATA_SIZE", length = 100)
    private String dataSize;

    @Column(name = "DATA_TYPE", length = 50)
    private String dataType;

    @Column(name = "DESCRIPTION", length = 500)
    private String description;

    @Column(name = "IMAGE_CONTENT")
    @Lob
    private byte[] imageContent;

    public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUseTitle() {
        return useTitle;
    }

    public void setUseTitle(String useTitle) {
        this.useTitle = useTitle;
    }

    public String getUseEntity() {
        return useEntity;
    }

    public void setUseEntity(String useEntity) {
        this.useEntity = useEntity;
    }

    public String getDataSize() {
        return dataSize;
    }

    public void setDataSize(String dataSize) {
        this.dataSize = dataSize;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getImageContent() {
        return imageContent;
    }

    public void setImageContent(byte[] imageContent) {
        this.imageContent = imageContent;
    }

    @PrePersist
    @Override
    public void prePersist() throws Exception {
        rowId = IDGenerator.genId(this);
        fullTitle = name + " " + title;
    }
    
    @PreUpdate
    @Override
    public void preUpdate() throws Exception {
        fullTitle = name + " " + title;
    }
}