package org.mega.core.base;

import org.apache.log4j.Logger;

public class BaseLogger extends Logger {
    private final static Logger logger = Logger.getLogger(BaseLogger.class);

    public BaseLogger(String name) {
        super(name);
    }

    public static Logger getLogger() {
        return logger;
    }

    public static Logger getLogger(Class clazz) {
        return Logger.getLogger(clazz);
    }
}
