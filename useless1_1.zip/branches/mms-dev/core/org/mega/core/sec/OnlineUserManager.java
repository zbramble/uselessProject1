package org.mega.core.sec;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.mega.core.SystemConfig;
import org.mega.core.user.UserStatus;
import org.mega.msg.conversationuser.ConversationUserFacade;

public class OnlineUserManager implements OnlineAwareI {
    private static OnlineUserManager onlineSupportManager;
    private ConcurrentHashMap<Long, OnlineSupport> onlineSupports = new ConcurrentHashMap<>();
    private ConcurrentHashMap<Long, Long> onlineUser = new ConcurrentHashMap<>();

    public static void init() {
        onlineSupportManager = new OnlineUserManager();
        UserSessionManager.addOnlineAware(onlineSupportManager);
    }

    public static OnlineUserManager getInstance() {
        return onlineSupportManager;
    }

    @Override
    public void login(UserInfo userInfo) {
        onlineUser.put(userInfo.getUserId(), System.currentTimeMillis());
        ConversationUserFacade.getInstance().broadcastUserStatus(userInfo.getUserId(), UserStatus.ONLINE);
        if (userInfo.getRoleId() == SystemConfig.SUPPORT_USER_ROLE_ID) {
            OnlineSupport onlineSupport = new OnlineSupport(userInfo.getUserId());
            onlineSupports.put(userInfo.getUserId(), onlineSupport);
        }
    }

    @Override
    public void logout(UserInfo userInfo) {
        onlineUser.remove(userInfo.getUserId());
        ConversationUserFacade.getInstance().broadcastUserStatus(userInfo.getUserId(), UserStatus.OFFLINE);
        if (userInfo.getRoleId() == SystemConfig.SUPPORT_USER_ROLE_ID) {
            onlineSupports.remove(userInfo.getUserId());
        }
    }

    public long getSupporter() {
        Optional<OnlineSupport> responder = onlineSupports.values().stream()
                .filter(onlineSupport -> (!onlineSupport.isBusy() && onlineSupport.isAnswer()))
                .sorted((o1, o2) -> o1.getLastAnswer().compareTo(o2.getLastAnswer()))
                .findFirst();
        if (responder.isPresent()) {
            long userId = responder.get().getUserId();
            //onlineSupports.get(userId).setBusy(true);
            onlineSupports.get(userId).getLastAnswer().setTime(System.currentTimeMillis());
            onlineSupports.get(userId).incCountAnswered();
            return userId;
        } else {
            return 0;
        }
    }

    public void supportRelease(long userId) {
        onlineSupports.get(userId).setBusy(false);
    }

    public Map getCount() {
        Map<String, Integer> count = new HashMap<>(3);

        int isBusy = (int) onlineSupports.values().stream().filter(onlineSupport -> (onlineSupport.isBusy())).count();
        int isAnswer = (int) onlineSupports.values().stream().filter(onlineSupport -> (onlineSupport.isAnswer())).count();

        count.put("Count", onlineSupports.size());
        count.put("Is Busy", isBusy);
        count.put("Is Answer", isAnswer);

        return count;
    }

    public boolean isOnline(long userId) {
        return onlineUser.containsKey(userId);
    }
}