package org.mega.core.sec;

import java.util.Date;

public class OnlineSupport {
    private long userId;
    private Date lastAnswer = new Date(System.currentTimeMillis());
    private int countAnswered;
    private boolean busy = false;
    private boolean answer = true;

    public OnlineSupport() {
    }

    public OnlineSupport(long userId) {
        this.userId = userId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Date getLastAnswer() {
        return lastAnswer;
    }

    public void setLastAnswer(Date lastAnswer) {
        this.lastAnswer = lastAnswer;
    }

    public int getCountAnswered() {
        return countAnswered;
    }

    public void incCountAnswered() {
        ++this.countAnswered;
    }

    public boolean isBusy() {
        return busy;
    }

    public void setBusy(boolean busy) {
        this.busy = busy;
    }

    public boolean isAnswer() {
        return answer;
    }

    public void setAnswer(boolean answer) {
        this.answer = answer;
    }
}
