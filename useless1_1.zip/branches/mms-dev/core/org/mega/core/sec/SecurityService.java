package org.mega.core.sec;

import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.mega.core.base.PairValue;
import org.mega.core.base.ServiceResult;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/security")
public class SecurityService {

    @POST
    @Path("/login")
    public ServiceResult login(LoginDTO loginDTO) {
        return SecurityManager.getInstance().login(loginDTO);
    }

    @POST
    @Path("/selectUserRole")
    public ServiceResult selectUserRole(UserInfo userInfo) {
        return SecurityManager.getInstance().selectUserRole(userInfo);
    }

    @POST
    @Path("/logout")
    public ServiceResult logout(PairValue ticketPair) {
        return SecurityManager.getInstance().logout(ticketPair);
    }

    @POST
    @Path("/forgetPassword")
    public ServiceResult forgetPassword(Map<String, String> params) {
        return SecurityManager.getInstance().forgetPassword(params);
    }

    @POST
    @Path("/register")
    public ServiceResult register(Map<String, String> params) {
        return SecurityManager.getInstance().register(params);
    }

    @POST
    @Path("/changePassword")
    public ServiceResult changePassword(Map<String, String> params) {
        return SecurityManager.getInstance().changePassword(params);
    }

    @POST
    @Path("/activationCode")
    public ServiceResult activationCode(Map<String, String> params) {
        return SecurityManager.getInstance().activationCode(params);
    }

    @POST
    @Path("/unLockUser")
    public ServiceResult unLockUser(Map<String, String> params) {
        return SecurityManager.getInstance().activationCode(params);
    }
    @POST
    @Path("/resetCaptcha")
    public void resetCaptcha(String username) {
    	SecurityManager.getInstance().setCaptcha(username);
    }

    public static String getCaptch(String username){
    	return SecurityManager.getInstance().getCaptch(username);
    }
}