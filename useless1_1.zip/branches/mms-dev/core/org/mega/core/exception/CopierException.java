package org.mega.core.exception;

public class CopierException extends Exception {
    public CopierException() {
        super();
    }

    public CopierException(String message) {
        super(message);
    }
}