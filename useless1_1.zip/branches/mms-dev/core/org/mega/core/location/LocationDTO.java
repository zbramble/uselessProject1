package org.mega.core.location;

import org.mega.core.base.BaseDTO;
import org.mega.core.comboval.ComboValDTO;

public class LocationDTO extends BaseDTO {
    private long rowId;
    private String name;
    private ComboValDTO type;
    private LocationDTO parent;
    //private List<LocationDTO> locations;

	public Long getRowId() {
        return rowId;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ComboValDTO getType() {
        return type;
    }

    public void setType(ComboValDTO type) {
        this.type = type;
    }

    public LocationDTO getParent() {
        return parent;
    }

    public void setParent(LocationDTO parent) {
        this.parent = parent;
    }

   /* public List<LocationDTO> getLocations() {
        return locations;
    }

    public void setLocations(List<LocationDTO> locations) {
        this.locations = locations;
    }*/
}
