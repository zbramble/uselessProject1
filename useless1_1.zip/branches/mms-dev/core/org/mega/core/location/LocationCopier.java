package org.mega.core.location;

import org.mega.core.base.BaseCopier;
import org.mega.core.comboval.ComboVal;
import org.mega.core.comboval.ComboValDTO;

public class LocationCopier extends BaseCopier<Location, LocationDTO> {

	@Override
	public LocationDTO copyFromEntity(Location location) {
		LocationDTO locationDTO = new LocationDTO();

		locationDTO.setRowId(location.getRowId());
		locationDTO.setName(location.getName());
		if (location.getType() != null) {
			ComboValDTO comboValDTO = new ComboValDTO();
			comboValDTO.setRowId(location.getType().getRowId());
			comboValDTO.setName(location.getType().getName());
			comboValDTO.setVal(location.getType().getVal());
			locationDTO.setType(comboValDTO);
		}
		if (location.getParent() != null) {
			LocationDTO parentLocationDTO = new LocationDTO();
			parentLocationDTO.setRowId(location.getParent().getRowId());
			parentLocationDTO.setName(location.getParent().getName());
			locationDTO.setParent(parentLocationDTO);
		}
		copyFromEntityBaseField(location, locationDTO);

		return locationDTO;
	}

	@Override
	public Location copyToEntity(LocationDTO locationDTO) {
		Location location = new Location();

		location.setRowId(locationDTO.getRowId());
		location.setName(locationDTO.getName());
		if (locationDTO.getType() != null) {
			ComboVal comboVal = new ComboVal();
			comboVal.setRowId(locationDTO.getType().getRowId());
			comboVal.setName(locationDTO.getType().getName());
			location.setType(comboVal);
		}
		if (locationDTO.getParent() != null) {
			Location parentLocation = new Location();
			parentLocation.setRowId(locationDTO.getParent().getRowId());
			location.setParent(parentLocation);
		}
		copyToEntityBaseField(location, locationDTO);

		return location;
	}
}