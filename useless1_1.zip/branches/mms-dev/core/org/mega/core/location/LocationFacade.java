package org.mega.core.location;

import org.mega.core.base.BaseCopier;
import org.mega.core.base.BaseFacade;

public class LocationFacade extends BaseFacade {
     private static LocationCopier copier = new LocationCopier();
    private static LocationFacade facade = new LocationFacade();

    @Override
    public BaseCopier getCopier() {
        return copier;
    }

    public static LocationFacade getInstance() {
        return facade;
    }
}